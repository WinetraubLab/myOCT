import unittest

from pyspectralradar import LogLevel, set_log_level
from pyspectralradar.data import ColoredData


class ColoredDataTest(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def test_data_create(self):
        dut = ColoredData()
        self.assertIsInstance(dut, ColoredData)

    def test_to_numpy(self):
        dut = ColoredData()
        self.assertTrue(dut.to_numpy().shape == (0, 0, 0))


if __name__ == '__main__':
    unittest.main()
