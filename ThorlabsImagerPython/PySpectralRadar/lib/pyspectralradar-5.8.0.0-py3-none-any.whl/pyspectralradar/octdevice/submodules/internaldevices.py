from ctypes import c_char_p, c_double, c_int, create_string_buffer
from typing import Dict, Tuple

from pyspectralradar.base import Submodule
from pyspectralradar.spectralradar import c_handle, get_error, sr


class InternalDevices(Submodule):
    """Class containing Functions for access to all kinds of Digital-to-Analog and Analog-to-Digital on the device."""

    DEFAULT_NAME_BUFFER_SIZE = 1024
    DEFAULT_UNIT_BUFFER_SIZE = DEFAULT_NAME_BUFFER_SIZE

    def get_names_and_units(self) -> Tuple[Dict[str, int], Dict[int, str]]:
        """Retrieves all available devices and their units

        Returns:
            Two dictionaries (``names``, ``units``), where the first one (``names``) mapping device names to their
            corresponding indices, the second one (``units``) mapping device indices to their units.
        """

        n = self._get_number_of_internal_values()
        names = {}
        units = {}
        for i in range(n):
            name, unit = self._get_name_and_unit(i)
            names.update({name: i})
            units.update({i: unit})
        return names, units

    def _get_number_of_internal_values(self) -> int:
        """ Returns the number of Analog-to-Digital Converter present in the device.

        Returns:
            The number of Analog-to-Digital Converter present in the device.
        """
        sr.getNumberOfInternalDeviceValues.argtypes = [c_handle]
        sr.getNumberOfInternalDeviceValues.restype = c_int
        res = sr.getNumberOfInternalDeviceValues(self.handle)
        get_error()
        return res

    def _get_name_and_unit(self, index: int, max_name_string_size=DEFAULT_NAME_BUFFER_SIZE,
                           max_unit_string_size=DEFAULT_UNIT_BUFFER_SIZE) -> Tuple[str, str]:
        """Returns names and unit for the specified Analog-to-Digital Converter.

        Args:
            :index: The index of the internal value whose name and unit are sought.
                    The index is a running number, starting with 0, smaller than the length of the dictionaries
                    returned by :func:`~get_names_and_units`
            :max_name_string_size: The maximal number of bytes that will be copied onto the array holding the name
            :max_unit_string_size: The maximal number of bytes that will be copied onto the array holding the unit

        Returns:
            A tuple containing the names and units.
        """
        name = create_string_buffer(max_name_string_size)
        unit = create_string_buffer(max_unit_string_size)
        sr.getInternalDeviceValueName.argtypes = [c_handle, c_int, c_char_p, c_int, c_char_p, c_int]
        sr.getInternalDeviceValueName(self.handle, index, name, max_name_string_size, unit, max_unit_string_size)
        get_error()
        return name.value.decode('UTF-8'), unit.value.decode('UTF-8')

    def get_value_by_index(self, device_index: int) -> float:
        """Returns the value of the selected ADC.

        Args:
            :device_index: The index of the internal device value.

        Returns:
            The internal device value.
        """

        sr.getInternalDeviceValueByIndex.argtypes = [c_handle, c_int]
        sr.getInternalDeviceValueByIndex.restype = c_double
        res = sr.getInternalDeviceValueByIndex(self.handle, device_index)
        get_error()
        return res

    def set_value_by_index(self, device_index: int, value: float):
        """Sets the value of the selected ADC.

        The index is running number, starting with 0, smaller than the length of the dictionary returned by
        :func:`~get_names_and_units`.

        Args:
            :device_index: The index of the internal device value.
            :value: The internal device value.
        """
        sr.setInternalDeviceValueByIndex.argtypes = [c_handle, c_int, c_double]
        sr.setInternalDeviceValueByIndex(self.handle, device_index, value)
        get_error()

    def get_value_by_name(self, name: str) -> float:
        """Returns the value of the specified Analog-to-Digital Converter (ADC).

        The ADC is specified by the name returned by the first dictionary of :func:`~get_names_and_units`.

        Args:
            :name: Name of the internal device value.

        Returns:
            The internal device value. If value is not defined, returns 0.0.
        """
        sr.getInternalDeviceValueByName.argtypes = [c_handle, c_char_p]
        sr.getInternalDeviceValueByName.restype = c_double
        res = sr.getInternalDeviceValueByName(self.handle, c_char_p(bytes(name, encoding="ascii")))
        get_error()
        return res
