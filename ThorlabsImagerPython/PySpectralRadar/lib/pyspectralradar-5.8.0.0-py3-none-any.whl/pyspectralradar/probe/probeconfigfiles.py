from ctypes import c_char_p, c_int, create_string_buffer
from typing import List

from pyspectralradar.spectralradar import get_error, sr


class ProbeConfigFiles:
    @staticmethod
    def _get_number_of_probe_configs() -> int:
        """Returns the number of available probe configuration files.

        Returns:
            The number of available probe configuration files.
        """
        sr.getNumberOfProbeConfigs.restype = c_int
        res = sr.getNumberOfProbeConfigs()
        get_error()
        return res

    @staticmethod
    def _get_config_name(idx: int) -> str:
        """Returns the name of the specified probe configuration file.

        Args:
            :idx: Selects one specific configuration file from all available probe configuration files.

        Returns:
            Return value for the name of the probe configuration file.

        """
        str_size = 1024
        probe_name = create_string_buffer(str_size)
        sr.getProbeConfigName.argtypes = [c_int, c_char_p, c_int]
        sr.getProbeConfigName(idx, probe_name, str_size)
        get_error()
        return probe_name.value.decode('UTF-8')

    @staticmethod
    def get_conf_filenames() -> List[str]:
        """Returns a list of all available probe configuration files.

        A common default file is e.g. the Probe.ini

        Returns:
            List of probe configuration files

        """
        n = ProbeConfigFiles._get_number_of_probe_configs()
        conf_files = [ProbeConfigFiles._get_config_name(idx) for idx in range(n)]
        return conf_files
