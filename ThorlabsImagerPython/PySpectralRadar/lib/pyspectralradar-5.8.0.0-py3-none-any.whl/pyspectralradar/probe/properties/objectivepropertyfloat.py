from ctypes import c_char_p, c_int
from enum import IntEnum

from pyspectralradar.base.propertygetter import FloatPropertyGetter
from pyspectralradar.spectralradar import sr


class PropertyFloat(IntEnum):
    """Properties of the objective mounted to the scanner such as the focal length of the lens."""

    FOCAL_LENGTH_MM = 0
    """Focal length in mm of the specified objective"""

    OPTICAL_PATH_LENGTH = 1
    """Optical path length, in millimeter (without counting the focal length, multiplied by the equivalent refractive
    index)."""


class ObjectivePropertyFloat(FloatPropertyGetter):

    def __init__(self, handle, objective_name: str):
        super().__init__(handle, sr.getObjectivePropertyFloat)
        self._objective_name = objective_name
        self._getter.argtypes = [c_char_p, c_int]

    def _get_raw(self, entry: IntEnum, c_res_type):
        self._getter.restype = c_res_type
        res = self._getter(c_char_p(bytes(self._objective_name, encoding="ascii")), c_int(entry))
        return res

    def get_focal_length_mm(self) -> float:
        """Focal length in mm of the specified objective"""
        return self._get(PropertyFloat.FOCAL_LENGTH_MM)

    def get_optical_path_length(self) -> float:
        """Optical path length, in millimeter (without counting the focal length, multiplied by the equivalent
        refractive index)."""
        return self._get(PropertyFloat.OPTICAL_PATH_LENGTH)
