from pyspectralradar.octdevice import OCTDevice
from pyspectralradar.probe import ProbeFactory
from pyspectralradar.processing import DeviceBoundProcessingFactory


class OCTSystem:
    """OCTSystem class represents an optical coherence tomography (OCT) system.

    This class initializes and manages the core components required for operating an OCT device, including the OCT
    device itself, a probe factory for creating probes, and a processing factory for handling device-bound processing
    tasks.

    Attributes:
        :dev: An instance of the :class:`~pyspectralradar.octdevice.octdevice.OCTDevice` class representing the
            OCT device
        :probe_factory: An instance of the :class:`~pyspectralradar.probe.probefactory.ProbeFactory` class responsible
            for creating and managing probes associated with the OCT device
        :processing_factory: An instance of the
            :class:`~pyspectralradar.processing.processingfactory.DeviceBoundProcessingFactory` class responsible for
            handling processing tasks that are bound to the OCT device
    """

    def __init__(self):
        self.dev: OCTDevice = OCTDevice()
        self.probe_factory: ProbeFactory = ProbeFactory(self.dev)
        self.processing_factory: DeviceBoundProcessingFactory = DeviceBoundProcessingFactory(self.dev)

    def __enter__(self):
        return self

    def __del__(self):
        self._delete()

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._delete()

    def _delete(self):
        self.dev.__del__()
