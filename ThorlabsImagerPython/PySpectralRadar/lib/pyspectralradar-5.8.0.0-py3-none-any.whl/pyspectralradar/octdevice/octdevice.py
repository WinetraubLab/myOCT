from ctypes import *
from typing import Tuple

from pyspectralradar.base import HandleManagerWithDefaultConstructor
from pyspectralradar.data import RealData
from pyspectralradar.octdevice import staticmethods as stm
from pyspectralradar.octdevice.properties import DeviceProperties, DevicePropertyExposer
from pyspectralradar.octdevice.submodules import InternalDevices, LightSource, OutputDevices
from pyspectralradar.octdevice.submodules.acquisition import Acquisition, AnalogInputChannel, Camera
from pyspectralradar.octdevice.submodules.presets import Presets
from pyspectralradar.octdevice.submodules.sweptsourcecontrols import Amplification, PolarizationAdjustment, \
    RefIntensity, RefStage
from pyspectralradar.octdevice.submodules.trigger import DeviceTriggerIoMode, DeviceTriggerMode
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import ApoWindowType, FFTType


class OCTDevice(HandleManagerWithDefaultConstructor):
    """
    The OCTDevice class is used as a handle for using the SpectralRadar system.

    This class manages the initialization and closure of the SpectralRadar device, incorporating
    various static methods, properties, and submodules necessary for its operation.

    Attributes:
        :properties: An instance of
            :class:`~pyspectralradar.octdevice.properties.devicepropertyexposer .DevicePropertyExposer` that exposes
            various properties of the device
        :acquisition: An instance of the
            :class:`~pyspectralradar.octdevice.submodules.acquisition.acquisition.Acquisition` class that manages
            data acquisition from the device
        :presets: An instance of the :class:`~pyspectralradar.octdevice.submodules.presets.devicepresets.Presets`
            class that handles device presets
        :camera: An instance of the :class:`~pyspectralradar.octdevice.submodules.acquisition.camera.Camera` class
            that manages the camera module of the device
        :light_source: An instance of the :class:`~pyspectralradar.octdevice.submodules.lightsource.LightSource`
            class that manages the light source module
        :output_device: An instance of the :class:`~pyspectralradar.octdevice.submodules.outputdevices.OutputDevices`
            class that manages output devices connected to the OCT device
        :internal_devices: An instance of the
            :class:`~pyspectralradar.octdevice.submodules.internaldevices.InternalDevices` class that manages internal
            devices of the OCT system
        :analog_input_channel: An instance of the
            :class:`~pyspectralradar.octdevice.submodules.acquisition.analoginputchannel.AnalogInputChannel` class that
            manages the analog input channels
        :trigger_mode: An instance of the
            :class:`~pyspectralradar.octdevice.submodules.trigger.devicetriggermode.DeviceTriggerMode` class that
            manages the trigger mode of the device
        :trigger_io_mode: An instance of the
            :class:`~pyspectralradar.octdevice.submodules.trigger.devicetriggeriomode.DeviceTriggerIoMode` class that
            manages the trigger I/O mode of the device
        :polarization_adjustment: An instance of the
            :class:`~pyspectralradar.octdevice.submodules.sweptsourcecontrols.PolarizationAdjustment`
            class that manages polarization adjustment (available in swept-source systems only)
        :ref_stage: An instance of the
            :class:`~pyspectralradar.octdevice.submodules.sweptsourcecontrols.refstage.RefStage` class that manages
            the reference stage (available in swept-source systems only)
        :ref_intensity: An instance of the
            :class:`~pyspectralradar.octdevice.submodules.sweptsourcecontrols.refintensity.RefIntensity` class that
            manages the reference intensity (available in swept-source systems only)
        :amplification: An instance of the
            :class:`~pyspectralradar.octdevice.submodules.sweptsourcecontrols.amplification.Amplification` class that
            manages amplification settings (available in swept-source systems only)

    """

    @property
    def _create_handle_func(self):
        return sr.initDevice

    @property
    def _del_func(self):
        return sr.closeDevice

    def __init__(self):
        super().__init__()

        # static methods
        self._incorporate_static_device_methods()

        # properties
        self._properties = DeviceProperties(self.handle)
        self.properties: DevicePropertyExposer = DevicePropertyExposer(self._properties)

        # submodules
        self.acquisition: Acquisition = Acquisition(self.handle)
        self.presets: Presets = Presets(self.handle)
        self.camera: Camera = Camera(self.handle, self._properties)
        self.light_source: LightSource = LightSource(self.handle)
        self.output_device: OutputDevices = OutputDevices(self.handle)
        self.internal_devices: InternalDevices = InternalDevices(self.handle)
        self.analog_input_channel: AnalogInputChannel = AnalogInputChannel(self.handle)
        self.trigger_mode: DeviceTriggerMode = DeviceTriggerMode(self.handle)
        self.trigger_io_mode: DeviceTriggerIoMode = DeviceTriggerIoMode(self.handle)
        self.polarization_adjustment: PolarizationAdjustment = PolarizationAdjustment(self.handle)
        self.ref_stage: RefStage = RefStage(self.handle)
        self.ref_intensity: RefIntensity = RefIntensity(self.handle)
        self.amplification: Amplification = Amplification(self.handle)

    def _incorporate_static_device_methods(self):
        self.get_device_error = stm.get_device_error
        self.available = stm.available
        self.reset_camera = stm.reset_camera
        self.set_required_SLD_on_time = stm.set_required_SLD_on_time
        self.get_device_state = stm.get_device_state

    def get_calibration(self, camera_idx: int = 0) -> (
            Tuple)[RealData, RealData, RealData, int, int, bool, float, float, FFTType, float, ApoWindowType]:
        """Returns current devices calibration data

        Args:
            :camera_idx: The spectrometer camera index, most systems only provide a single camera with
                ``camera_idx=0``

        Returns:
            A tuple (``offset``, ``apo``, ``chirp``, ``spectrum_size``, ``bytes_per_raw_pixel``, ``signed``,
            ``scaling_factor``, ``min_electrons``, ``fft_type``, ``fft_oversampling``, ``apo_window``) containing ...
        """
        offset = RealData()
        apo = RealData()
        chirp = RealData()
        spectrum_size = c_int()
        bytes_per_raw_pixel = c_int()
        signed = c_bool()
        scaling_factor = c_double()
        min_electrons = c_double()
        fft_type = c_int()
        fft_oversampling = c_double()
        apo_window = c_int()

        sr.getDeviceCalibration.argtypes = [c_handle, c_int,
                                            c_handle, c_handle, c_handle,
                                            POINTER(c_int), POINTER(c_int), POINTER(c_bool),
                                            POINTER(c_double), POINTER(c_double), POINTER(c_int),
                                            POINTER(c_double), POINTER(c_int)]

        sr.getDeviceCalibration(self.handle, camera_idx,
                                offset.handle, apo.handle, chirp.handle,
                                spectrum_size, bytes_per_raw_pixel, signed,
                                scaling_factor, min_electrons, fft_type,
                                fft_oversampling, apo_window)
        get_error()
        return (offset, apo, chirp,
                spectrum_size.value, bytes_per_raw_pixel.value, signed.value,
                scaling_factor.value, min_electrons.value, FFTType(fft_type.value),
                fft_oversampling.value, ApoWindowType(apo_window.value))

    def get_quantum_efficiency(self, center_wavelength_nm: float, power_into_spectrometer_W: float,
                               spectrum_e: RealData) -> float:
        """Calculates the quantum efficiency from the processed input spectrum in the ``spectrum_e`` instance.

        Args:
            :center_wavelength_nm: The systems center wavelength
            :power_into_spectrometer_W: The power in watt
            :spectrum_e: The input spectrum

        Returns:
            The calculated quantum efficiency
        """
        sr.QuantumEfficiency.restype = c_double
        sr.QuantumEfficiency.argtypes = [c_handle, c_double, c_double, c_handle]
        res = sr.QuantumEfficiency(self.handle, center_wavelength_nm, power_into_spectrometer_W, spectrum_e.handle)
        get_error()
        return res

    def add_probe_button_callback(self, callback):
        """Registers a callback function to notify when a button on the probe has been pressed.

        The int parameter passed to the callback function will contain the pressed button's ID.

        :Caution: Since the callbacks will not be called in separate threads but in the order of addition, make sure
            that the callback function returns as soon as possible.
        """
        raise NotImplementedError

    def remove_probe_button_callback(self, callback):
        """Removes a previously registered probe button callback function"""
        raise NotImplementedError
