import unittest

from pyspectralradar.data.precisiondata import PrecisionData

EXPERIMENTAL = False


class PrecisionDataTest(unittest.TestCase):
    @unittest.skipUnless(EXPERIMENTAL, "Function exists in experimental only")
    def test_data_create(self):
        dut = PrecisionData()
        self.assertIsInstance(dut, PrecisionData)


if __name__ == '__main__':
    unittest.main()
