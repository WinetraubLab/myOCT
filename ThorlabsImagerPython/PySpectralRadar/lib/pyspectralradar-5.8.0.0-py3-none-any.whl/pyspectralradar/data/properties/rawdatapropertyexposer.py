from typing import Tuple

from pyspectralradar.data.properties.rawdatapropertyfloat import RawDataPropertyFloatGetter
from pyspectralradar.data.properties.rawdatapropertyint import RawDataPropertyIntGetter
from pyspectralradar.data.utility import IShapeProperties
from pyspectralradar.spectralradar import c_handle


class RawDataPropertyExposer(IShapeProperties):
    def __init__(self, handle: c_handle):
        self._property_int = RawDataPropertyIntGetter(handle)
        self._property_float = RawDataPropertyFloatGetter(handle)

    """---- CommonTensorProperties ----"""

    @property
    def shape(self):
        return self._property_int.get_size1(), self._property_int.get_size2(), self._property_int.get_size3()

    @property
    def size(self):
        return self._property_int.get_number_of_elements()

    @property
    def size_bytes(self):
        return self._property_int.get_size_bytes()

    @property
    def bytes_per_element(self):
        return self._property_int.get_bytes_per_element()

    """---- int properties ----"""

    @property
    def lost_frames(self) -> int:
        return self._property_int.get_lost_frames()

    """---- float properties ----"""

    @property
    def range(self) -> Tuple[float, float, float]:
        pfl = self._property_float
        return pfl.get_range1(), pfl.get_range2(), pfl.get_range3()
