from ctypes import c_bool, c_int

from pyspectralradar.base import Submodule
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import TriggerMode


class DeviceTriggerMode(Submodule):

    def get(self) -> TriggerMode:
        """Returns the trigger mode used for acquisition.

        Returns:
            Current trigger mode.
        """
        sr.getTriggerMode.restype = c_int
        sr.getTriggerMode.argtypes = [c_handle]
        res = sr.getTriggerMode(self.handle)
        get_error()
        return TriggerMode(res)

    def set(self, mode: TriggerMode):
        """Sets the trigger mode for the OCT device used for acquisition.

        Additional hardware may be needed.

        \nImportant follow-up:
            After a change of the trigger mode, and before an acquisition is started,
            two actions are needed: (1) the current preset should also be updated (even if the preset value
            stays the same), and (2) the scan patterns should be re-created. Note that the order of these
            follow-up actions is important.
            The reason: the change of the trigger mode should be propagated to the other objects in the
            application. A programmer may write an application instantiating many probes and different scan
            patterns, and combining them differently as time progresses. All those objects are independent
            and need to be notified when important changes take place.

        Args:
            :mode: Trigger mode to use
        """
        sr.setTriggerMode.argtypes = [c_handle, c_int]
        sr.setTriggerMode(self.handle, mode)
        get_error()

    def is_available(self, mode: TriggerMode) -> bool:
        """Returns whether the specified trigger mode is possible or not for the used device.

        Args:
            :mode: Mode to query
        """
        sr.isTriggerModeAvailable.restype = c_bool
        sr.isTriggerModeAvailable.argtypes = [c_handle, c_int]
        res = sr.isTriggerModeAvailable(self.handle, mode)
        get_error()
        return res

    def get_timeout(self) -> int:
        """Returns the timeout of the camera in seconds (not used in trigger mode ``FREE_RUNNING``).

        Returns:
            Timeout in external trigger mode in seconds
        """
        sr.getTriggerTimeout_s.restype = c_int
        sr.getTriggerTimeout_s.argtypes = [c_handle]
        res = sr.getTriggerTimeout_s(self.handle)
        get_error()
        return res

    def set_timeout(self, timeout_sec: int):
        """Sets the timeout of the camera in seconds (useful in external trigger mode).

        Args:
            :timeout_sec: Timeout in external trigger mode in seconds
        """
        sr.setTriggerTimeout_s.argtypes = [c_handle, c_int]
        sr.setTriggerTimeout_s(self.handle, timeout_sec)
        get_error()
