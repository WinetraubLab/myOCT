import abc
from ctypes import c_bool, c_char_p, c_double, c_float, c_int, c_void_p
from enum import IntEnum

from pyspectralradar.spectralradar import c_handle, get_error


class PropertySetter:
    def __init__(self, handle, setter):
        self._handle = handle
        self._setter = setter
        self._setter.restype = c_void_p

    def _set_raw(self, entry: IntEnum, value, c_arg_type):
        self._setter.argtypes = [c_handle, c_int, c_arg_type]
        if c_arg_type is c_char_p:
            self._setter(self._handle, c_int(entry), c_char_p(bytes(value, encoding="ascii")))
        else:
            self._setter(self._handle, c_int(entry), c_arg_type(value))
        get_error()

    def _set_raw_indexed(self, entry: IntEnum, index: int, value, c_arg_type):
        self._setter.restype = c_bool
        self._setter.argtypes = [c_handle, c_int, c_int, c_arg_type]
        if c_arg_type is c_char_p:
            res = self._setter(self._handle, c_int(entry), index, c_char_p(bytes(value, encoding="ascii")))
        else:
            res = self._setter(self._handle, c_int(entry), index, c_arg_type(value))
        get_error()
        return res

    @abc.abstractmethod
    def _set(self, entry: IntEnum, value):
        raise NotImplementedError


class StringPropertySetter(PropertySetter):
    def _set(self, entry: IntEnum, value: str):
        self._set_raw(entry, value, c_char_p)

    def _set_indexed(self, entry: IntEnum, index: int, value: str):
        return self._set_raw_indexed(entry, index, value, c_int)


class IntPropertySetter(PropertySetter):
    def _set(self, entry: IntEnum, value: int):
        self._set_raw(entry, value, c_int)

    def _set_indexed(self, entry: IntEnum, index: int, value: int):
        return self._set_raw_indexed(entry, index, value, c_int)


class FloatPropertySetter(PropertySetter):
    def _set(self, entry: IntEnum, value: float):
        self._set_raw(entry, value, c_double)

    def _set_indexed(self, entry: IntEnum, index: int, value: float):
        return self._set_raw_indexed(entry, index, value, c_double)


class CFloatPropertySetter(PropertySetter):
    def _set(self, entry: IntEnum, value: float):
        self._set_raw(entry, value, c_float)


class FlagPropertySetter(PropertySetter):
    def _set(self, entry: IntEnum, value: bool):
        self._set_raw(entry, value, c_bool)

    def _set_indexed(self, entry: IntEnum, index: int, value: bool):
        return self._set_raw_indexed(entry, index, value, c_bool)


class StaticFlagSetter:
    @staticmethod
    @abc.abstractmethod
    def _get_setter():
        raise NotImplementedError

    @classmethod
    def _set_raw(cls, entry: IntEnum, value: bool):
        _setter = cls._get_setter()
        _setter.argtypes = [c_int, c_bool]
        return _setter(entry, value)
