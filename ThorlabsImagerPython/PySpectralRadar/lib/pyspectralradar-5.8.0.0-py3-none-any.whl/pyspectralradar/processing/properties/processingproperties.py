from pyspectralradar.base.submodule import Submodule
from pyspectralradar.processing.properties.processingpropertyflag import ProcessingPropertyFlag
from pyspectralradar.processing.properties.processingpropertyfloat import ProcessingPropertyFloat
from pyspectralradar.processing.properties.processingpropertyint import ProcessingPropertyInt


class ProcessingProperties(Submodule):
    def __init__(self, handle):
        super().__init__(handle)
        self._int: ProcessingPropertyInt = ProcessingPropertyInt(self.handle)
        self._float = ProcessingPropertyFloat(self.handle)
        self._flag = ProcessingPropertyFlag(self.handle)

        # Property int
        self.get_spectrum_avg = self._int.get_spectrum_avg
        self.set_spectrum_avg = self._int.set_spectrum_avg
        self.get_ascan_avg = self._int.get_ascan_avg
        self.set_ascan_avg = self._int.set_ascan_avg
        self.get_bscan_avg = self._int.get_bscan_avg
        self.set_bscan_avg = self._int.set_bscan_avg
        self.get_zero_padding = self._int.get_zero_padding
        self.set_zero_padding = self._int.set_zero_padding
        self.get_number_of_threads = self._int.get_number_of_threads
        self.set_number_of_threads = self._int.set_number_of_threads
        self.get_fourier_avg = self._int.get_fourier_avg
        self.set_fourier_avg = self._int.set_fourier_avg

        # property float
        # self.get_apo_damping = self._float.get_apo_damping
        # self.set_apo_damping = self._float.set_apo_damping
        self.get_min_electrons = self._float.get_min_electrons
        self.set_min_electrons = self._float.set_min_electrons
        self.get_fft_oversampling = self._float.get_fft_oversampling
        # self.set_fft_oversampling = self._float.set_fft_oversampling
        self.get_max_sensor_value = self._float.get_max_sensor_value
        self.set_max_sensor_value = self._float.set_max_sensor_value

        # property flag
        self.get_use_offset = self._flag.get_use_offset
        self.set_use_offset = self._flag.set_use_offset
        self.get_remove_dc = self._flag.get_remove_dc
        self.set_remove_dc = self._flag.set_remove_dc
        self.get_remove_dc_adv = self._flag.get_remove_dc_adv
        self.set_remove_dc_adv = self._flag.set_remove_dc_adv
        self.get_apodization = self._flag.get_apodization
        self.set_apodization = self._flag.set_apodization
        self.get_scan_for_apo = self._flag.get_scan_for_apo
        self.set_scan_for_apo = self._flag.set_scan_for_apo
        self.get_undersampling_filter = self._flag.get_undersampling_filter
        self.set_undersampling_filter = self._flag.set_undersampling_filter
        self.get_dispersion = self._flag.get_dispersion
        self.set_dispersion = self._flag.set_dispersion
        self.get_dechirp = self._flag.get_dechirp
        self.set_dechirp = self._flag.set_dechirp
        self.get_ext_adjust = self._flag.get_ext_adjust
        self.set_ext_adjust = self._flag.set_ext_adjust
        self.get_full_range = self._flag.get_full_range
        self.set_full_range = self._flag.set_full_range
        self.get_filter_dc = self._flag.get_filter_dc
        self.set_filter_dc = self._flag.set_filter_dc
        self.get_autocorr_corr = self._flag.get_autocorr_corr
        self.set_autocorr_corr = self._flag.set_autocorr_corr
        self.get_defr = self._flag.get_defr
        self.set_defr = self._flag.set_defr
        self.get_only_win = self._flag.get_only_win
        self.set_only_win = self._flag.set_only_win
        self.get_fixed_pattern = self._flag.get_fixed_pattern
        self.set_fixed_pattern = self._flag.set_fixed_pattern
        self.get_saturation = self._flag.get_saturation
        self.set_saturation = self._flag.set_saturation
        # experimental only
        # self.get_calculate_rel_interference_amp = self._flag.get_calculate_rel_interference_amp
        # self.set_calculate_rel_interference_amp = self._flag.set_calculate_rel_interference_amp
        # self.get_invert_phase = self._flag.get_invert_phase
        # self.set_invert_phase = self._flag.set_invert_phase
