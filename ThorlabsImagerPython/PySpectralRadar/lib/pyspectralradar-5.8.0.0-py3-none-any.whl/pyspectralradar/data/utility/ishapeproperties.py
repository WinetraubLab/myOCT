import abc
from typing import Tuple


class IShapeProperties:
    @property
    @abc.abstractmethod
    def shape(self) -> Tuple[int, int, int]:
        """Number of elements along the z-, x- and y-axis"""

    @property
    @abc.abstractmethod
    def size(self) -> int:
        """The number of elements in the data object."""

    @property
    @abc.abstractmethod
    def size_bytes(self) -> int:
        """The size of the data object in bytes."""

    @property
    @abc.abstractmethod
    def bytes_per_element(self) -> int:
        """The number of bytes of a single element."""
