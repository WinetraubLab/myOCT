from enum import IntEnum, auto


class DispersionCorrectionType(IntEnum):
    """Enum To select the dispersion correction algorithm."""

    NONE = 0
    """No software dispersion correction is used."""

    QUADRATIC = 1
    """Quadratic dispersion correction is used with the factor specified in 
    :func:`~pyspectralradar.processing.dispersion.Dispersion.quadratic_coeff`."""

    PRESET = 2
    """The specified dispersion preset specified by 
    :func:`~pyspectralradar.processing.dispersion.Dispersion.set_preset` is used. For more information please see the 
    documentation of :func:`~pyspectralradar.processing.dispersion.Dispersion.set_preset`."""

    MANUAL = 3
    """Vector for dispersion correction needs to be supplied manually. Please use the 
    :func:`~pyspectralradar.processing.calibration.Calibration.set` function."""


class ApoWindowType(IntEnum):
    """Enum To select the apodization window function."""

    HANN = 0
    """Hann window function"""

    HAMMING = 1
    """Hamming window function"""

    GAUSS = 2
    """Gaussian window function"""

    TAPERED_COSINE = 3
    """Tapered cosine window function"""

    BLACKMAN = 4
    """Blackman window function"""

    BLACKMAN_HARRIS = 5
    """4-Term Blackman-Harris window function"""

    LIGHT_SOURCE = 6
    """The apodization function is determined, based on the shape of the light source at hand. Warning:{This feature 
    is still experimental.}"""

    UNKNOWN = 999
    """Unknown apodization window"""


class ApoWindowParameter(IntEnum):
    """Enum Sets certain parameters that are used by the window functions to be applied during apodization."""

    SIGMA = 0
    """Sets the width of a Gaussian apodization window"""

    RATIO = 1
    """Sets the ratio of the constant to the cosine part when using a tapered cosine window."""

    FREQUENCY = 2
    """Sets the corner frequency of the filter applied when using a light-source based apodization. Warning:{Light 
    source based apodization is still experimental and might contain bugs or decrease performance of the OCT 
    system.}"""


class ApodizationDataType(IntEnum):
    """Enum Specifies the data source for the apodization vector that was used in a given OCT processing"""

    UNKNOWN = 0
    """Source of apodization data is unknown (commonly caused by loading legacy OCT files)"""

    NONE = 1
    """No apodization data was used"""

    MEASURED = 2
    """Apodization vector was measured at some point before the OCT scan"""

    ACQUIRED_IN_SCAN = 3
    """Apodization vector was acquired as part of the OCT scan """

    OCT_DATA = 4
    """Apodization vector was not measured but calculated based on the OCT scan data"""


class CalibrationType(IntEnum):
    """Enum Data describing the calibration of the processing routines."""

    OFFSET_ERRORS = 0
    """Calibration vector used as offset."""

    APO_SPECTRUM = 1
    """Calibration data used as reference spectrum."""

    APO_VECTOR = 2
    """Calibration data used as apodization multiplier."""

    DISPERSION = 3
    """Calibration data used to compensate for dispersion."""

    CHIRP = 4
    """Calibration data used for de-chirping spectral data."""

    EXT_ADJUST = 5
    """Calibration data used as extended adjust."""

    FIXED_PATTERN = 6
    """Calibration data used as fixed scan pattern data."""


class FFTType(IntEnum):
    """Enum defines the algorithm used for de-chirping the input signal and Fourier transformation"""

    STANDARD_FFT = 0
    """FFT with no de-chirp algorithm applied."""

    STANDARD_NDFT = 1
    """Full matrix multiplication ("filter bank"). Mathematical precise de-chirp, but rather slow."""

    IFFT = 2
    """Linear interpolation prior to FFT."""

    NFFT1 = 3
    """NFFT algorithm with parameter m=1."""

    NFFT2 = 4
    """NFFT algorithm with parameter m=2."""

    NFFT3 = 5
    """NFFT algorithm with parameter m=3."""

    NFFT4 = 6
    """NFFT algorithm with parameter m=4."""


class AvgAlgorithm(IntEnum):
    """Enum This sets the averaging algorithm to be used for processing.

    :Warning: {This features is still experimental and might contain bugs.}
    """

    MIN = 0
    """Minimum"""

    MEAN = 1
    """Mean (Default)"""

    MEDIAN = 2
    """Median"""

    NORM2 = 3
    """Norm2"""

    MAX = 4
    """MAx"""

    FOURIER_MIN = 5
    """Fourier Min"""

    FOURIER_NORM4 = 6
    """Fourier Norm4"""

    FOURIER_MAX = 7
    """Fourier Max"""

    STD_DEV_ABS = 8
    """Standard Deviation of Absolute"""

    PHASE_MATCHED = 9
    """Phase matched"""


class SpectrumType(IntEnum):
    """Enum Specifies the type of the resulting spectrum output data"""

    RAW = auto()
    """resulting spectral data"""

    OFFSET_CORRECTED = auto()
    """resulting offset corrected spectral data"""

    DC_CORRECTED = auto()
    """resulting DC removed spectral data"""

    APODIZED = auto()
    """resulting apodized spectral data"""
