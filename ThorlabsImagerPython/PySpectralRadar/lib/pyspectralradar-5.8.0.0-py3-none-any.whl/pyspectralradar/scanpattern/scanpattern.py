from ctypes import *
from typing import TYPE_CHECKING, Tuple

import numpy as np

from pyspectralradar.base import HandleManager
from pyspectralradar.data import ColoredData
from pyspectralradar.scanpattern.properties import ScanPatternProperties
from pyspectralradar.scanpattern.submodules import LUT, ScanPointsFactory
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import AcqType

if TYPE_CHECKING:
    from pyspectralradar.probe import Probe
    from pyspectralradar.octdevice import OCTDevice


class ScanPattern(HandleManager):
    """
    Class containing methods that describe the movement of the scanner during measurement.

    This class manages and configures scan patterns, which define the movement of the scanner during OCT
    measurements. It includes properties and submodules necessary for managing scan points and lookup tables (LUTs).

    Attributes:
        :properties: An instance of the
            :class:`~pyspectralradar.scanpattern.properties.scanpatternproperties.ScanPatternProperties` class that
            manages the properties of the scan pattern
        :scan_points: An instance of the :class:`~pyspectralradar.scanpattern.submodules.scanpoints.ScanPoints` class
            that manages the scan points for the pattern
        :LUT: An instance of the :class:`~pyspectralradar.scanpattern.submodules.lut.LUT` class that handles lookup
            tables associated with the scan pattern

    """

    def __init__(self, handle):
        super().__init__(handle)

        # properties
        self.properties = ScanPatternProperties(handle)

        # submodules
        self.scan_points_factory = ScanPointsFactory()
        self.LUT = LUT(handle)

    @property
    def _del_func(self):
        """Clears the specified scan pattern
        """
        return sr.clearScanPattern

    def __len__(self):
        return self.size()

    def size(self) -> int:
        """Returns the number of points in the scan pattern, including expansion points.

        Returns:
            The number of points in the scan pattern, including expansion points.
        """
        sr.getScanPointsSize.argtypes = [c_handle]
        sr.getScanPointsSize.restype = c_int
        res = sr.getScanPointsSize(self.handle)
        get_error()
        return res

    def scan_points(self) -> Tuple[np.ndarray, np.ndarray]:
        """Returns the position coordinates (in mm) of the points in the scan pattern.

        Returns:
            A tuple (``scan_posx_mm``, ``scan_posy_mm``) containing the :class:`numpy` array
            ``scan_posx_mm`` of x-coordinates of the scan pattern and the :class:`numpy` array
            ``scan_posy_mm`` of y-coordinates of the scan pattern.

        """
        number_of_scan_points = self.size()
        scan_posx_mm = np.empty(number_of_scan_points)
        scan_posy_mm = np.empty(number_of_scan_points)
        sr.getScanPoints.argtypes = [c_handle,
                                     np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                     np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS')]
        sr.getScanPoints(self.handle, scan_posx_mm, scan_posy_mm)
        get_error()
        return scan_posx_mm, scan_posy_mm

    def exp_acquisition_time(self, device: "OCTDevice") -> float:
        """Returns the expected acquisition time of the scan pattern in seconds.

        Args:
            :device: A valid :class:`~pyspectralradar.octdevice.octdevice.OCTDevice` object used for
                data acquisition routines

        Returns:
            The expected acquisition time of the scan pattern in seconds
        """
        sr.expectedAcquisitionTime_s.restype = c_double
        sr.expectedAcquisitionTime_s.argtypes = [c_handle, c_handle]
        res = sr.expectedAcquisitionTime_s(self.handle, device.handle)
        get_error()
        return res

    def is_acquisition_type_available(self, acq_type: AcqType) -> bool:
        """Returns whether the acquisition type is available for the scan pattern.

        Args:
            :acq_type: The acquisition type that shall be checked.

        Returns:
            ``True`` if the acquisition type is available for the scan pattern, ``False`` if not
        """
        sr.isAcqTypeForScanPatternAvailable.restype = c_bool
        sr.isAcqTypeForScanPatternAvailable.argtypes = [c_handle, c_int]
        res = sr.isAcqTypeForScanPatternAvailable(self.handle, acq_type)
        get_error()
        return res

    def check_available_memory_for_raw_data(self, device: "OCTDevice", additional_memory: c_int64) -> bool:
        """Checks whether sufficient memory is available for raw data acquired with the specified scan pattern.

        Args:
            :device: A valid :class:`~pyspectralradar.octdevice.octdevice.OCTDevice` that is used for data acquisition
            :additional_memory: The parameter specifies additional memory that will be required during the measurement
                (from :func:`~pyspectralradar.octdevice.submodules.acquisition.acquisition.Acquisition.start` to
                :func:`~pyspectralradar.octdevice.submodules.acquisition.acquisition.Acquisition.stop`) unknown to
                the SDK and/or memory that will be freed/available prior to the call of
                :func:`~pyspectralradar.octdevice.submodules.acquisition.acquisition.Acquisition.start`.

        Returns:
            ``True`` if memory is available for raw data, ``False`` if not.
        """
        sr.checkAvailableMemoryForRawData.restype = c_bool
        sr.checkAvailableMemoryForRawData.argtypes = [c_handle, c_handle, c_int64]
        res = sr.checkAvailableMemoryForRawData(device.handle, self.handle, additional_memory)
        get_error()
        return res

    def memory_requirements(self, device: "OCTDevice", acquisition_type: AcqType) -> int:
        """Returns the size of the required memory, e.g. for a raw data object, in bytes to acquire the scan pattern
        once.

        Args:
            :device: A valid (non-null) :obj:`~pyspectralradar.octdevice.octdevice.OCTDevice`
            :acquisition_type: Determines the kind of acquisition process
                :class:`~pyspectralradar.types.octdevicetypes.AcqType`. The type of acquisition process affects e.g.
                whether consecutive B-scans are acquired or if it is possible to lose some data.

        Returns:
            The size of the required memory.
        """
        sr.projectMemoryRequirement.argtypes = [c_handle, c_handle, c_handle]
        sr.projectMemoryRequirement.restype = c_size_t
        res = sr.projectMemoryRequirement(device.handle, self.handle, acquisition_type)
        get_error()
        return res

    def update(self):
        """Updates the scan pattern and computes the full look-up-table in place.

        The different scan-pattern creation functions compute both the coordinates of the scan and the connections
        between the scan parts. However, those functions do not build the final table of coordinates. The reason is
        that many scan patterns may be created separately, and then stacked together. The individual creation
        functions know nothing about the big picture. Before the acquisition actually starts, a final table of
        coordinates should be written, consolidating all involved parts. This is the job of this function.

        This function gets invoked automatically before every start of a measurement. Hence, most users do not need
        to invoke it at all. However, if the user loads an OCT file containing raw data, and a processing that
        depends on the coordinates is attempted, then the final table of positions should be written, because only
        at that point the coordinates are placed in exactly the same sequence as they were during the acquisition.
        An example of coordinates-dependent processing is the image field correction.
        This function should be used after every rotation or shift has been completed.
        """
        sr.updateScanPattern.argtype = [c_handle]
        sr.updateScanPattern(self.handle)
        get_error()

    def rotate(self, angle_rad: float, idx: int = -1):
        """Rotates the scan pattern.

        :idx==-1: Rotates the :obj:`~ScanPattern`, counter-clockwise. The rotation is relative to current angle,
            not to the horizontal. That is, after multiple invocations of this function the final rotation is the
            addition of all rotations
        :idx!=1: Counter-clockwise rotates the scan Index: idx (0-based, i.e. zero for the first, one for the second,
            and so on) of the scan pattern. The rotation is relative to current angle, not to the horizontal. That
            is, after multiple invocations of this function the final rotation is the addition of all rotations.

        This function is specific of volume scan patterns, although only a slice of it will be rotated.
        A volume scan pattern is actually a stack of B-scan patterns. In the default orientation (first axis is the
        depth ``z``, second axis is ``x``, third axis is ``y``), the slices will be accommodated along the ``y`` axis.
        The number of slices in the stack may be retrieved by invoking the function
        :func:`~pyspectralradar.scanpattern.properties.scanpatternpropertyint.ScanPatternPropertyInt.get_cycles`.

        Args:
            :angle_rad: The angle (expressed in radians) of the counter-clockwise rotation.
            :idx: The slice of the stack that should be rotated. If ``idx==-1``, a 2D :obj:`~ScanPattern` is assumed
        """
        if idx == -1:
            sr.rotateScanPattern.argtypes = [c_handle, c_double]
            sr.rotateScanPattern(self.handle, angle_rad)
        else:
            sr.rotateScanPatternEx.argtypes = [c_handle, c_double, c_int]
            sr.rotateScanPatternEx(self.handle, angle_rad, idx)
        get_error()

    def shift(self, shift_x_mm: float, shift_y_mm: float, shift_apo: bool = False, idx: int = -1):
        """Shifts the scan pattern.

        :idx==-1: Shifts the scan pattern. The shift is relative to current position, not to (0,0). That is,
            after multiple invocations of this function the final shift is the addition of all shifts
        :idx!=-1: Shifts the scan index (0-based, i.e. zero for the first, one for the second, and so on) of the
            volume pattern. The shift is relative to current position, not to (0,0). That is, after multiple
            invocations of this function the final shift is the addition of all shifts. With ``idx!=1``, this function
            is specific of volume scan patterns, although only a slice of it will be shifted. A volume scan pattern
            is actually a stack of B-scan patterns. In the default orientation (first axis is the depth ``z``,
            second axis is ``x``, third axis is ``y``), the slices will be accommodated along the ``y`` axis. The number
            of slices in the stack may be retrieved by invoking the function
            :func:`~pyspectralradar.scanpattern.properties.scanpatternpropertyint.ScanPatternPropertyInt.get_cycles`.

        Args:
            :shift_x_mm: The relative shift in the x-axis direction, expressed in mm
            :shift_y_mm: The relative shift in the y-axis direction, expressed in mm
            :shift_apo: ``True`` if the apodization should also be shifted. ``False`` otherwise
            :idx: The slice of the stack that should be shifted
        """
        if idx == -1:
            sr.shiftScanPattern.argtypes = [c_handle, c_double, c_double]
            sr.shiftScanPattern(self.handle, shift_x_mm, shift_y_mm)
        else:
            sr.shiftScanPatternEx.argtypes = [c_handle, c_double, c_double, c_bool, c_int]
            sr.shiftScanPatternEx(self.handle, shift_x_mm, shift_y_mm, shift_apo, idx)
        get_error()

    def zoom(self, factor: float):
        """Zooms the scan pattern around the optical center that coincides with the center of the camera image and the
        physical coordinates (0 mm,0 mm).

        The apodization position will not be modified.

        Args:
            :factor: The zoom factor.
        """
        sr.zoomScanPattern.argtypes = [c_handle, c_double]
        sr.zoomScanPattern(self.handle, factor)
        get_error()

    def visualize_on_image(self, probe: 'Probe', video_image: ColoredData):
        """Visualizes the scan pattern on top of the camera image; scan pattern data is written into the image.

        Args:
            :probe: A valid (non-null) :obj:`~pyspectralradar.probe.probe.Probe`
            :video_image: A valid (non-null) :obj:`~pyspectralradar.data.coloreddata.ColoredData`, which holds the
                video camera image where the scan pattern shall be visualized on
        """
        sr.visualizeScanPatternOnImage.argtypes = [c_handle, c_handle, c_handle]
        sr.visualizeScanPatternOnImage(probe.handle, self.handle, video_image.handle)
        get_error()

    def visualize_on_device(self, device: 'OCTDevice', probe: 'Probe', show_raw_pattern: bool):
        """Visualizes the scan pattern on top of the camera image; if appropriate hardware is used for visualization.

        Args:
            :device: A valid (non-null) :obj:`~pyspectralradar.octdevice.octdevice.OCTDevice`
            :probe: A valid (non-null) :obj:`~pyspectralradar.probe.probe.Probe`
            :show_raw_pattern: Indicates whether the scan pattern should be shown (``True``) or hidden (``False``).
        """
        sr.visualizeScanPatternOnDevice.argtypes = [c_handle, c_handle, c_handle, c_bool]
        sr.visualizeScanPatternOnDevice(device.handle, probe.handle, self.handle, show_raw_pattern)
        get_error()
