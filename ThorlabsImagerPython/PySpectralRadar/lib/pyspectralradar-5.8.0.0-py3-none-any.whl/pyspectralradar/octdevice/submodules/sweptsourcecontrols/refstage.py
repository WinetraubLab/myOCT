from ctypes import c_bool, c_double, c_int

from pyspectralradar.base import Submodule
from pyspectralradar.probe import Probe
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import RefStageMovementDirection, RefStageSpeed, RefStageStatus, RefStageWaitForMovement


class RefStage(Submodule):
    def is_available(self) -> bool:
        """Returns whether a motorized reference stage is available or not for the specified device.

        Please note that a motorized reference stage is not included in all systems.

        Returns:
            Whether a motorized reference stage is available (``True``) or not (``False``).
        """
        sr.isRefstageAvailable.restype = c_bool
        sr.isRefstageAvailable.argtypes = [c_handle]
        res = sr.isRefstageAvailable(self.handle)
        get_error()
        return res

    def get_status(self) -> RefStageStatus:
        """Returns the current status of the reference stage, e.g. if it is moving.

        Returns:
            The current status of the reference stage, e.g. if it is moving.
        """
        sr.getRefstageStatus.restype = c_int
        sr.getRefstageStatus.argtypes = [c_handle]
        res = sr.getRefstageStatus(self.handle)
        get_error()
        return RefStageStatus(res)

    def get_length(self, probe: Probe) -> float:
        """Returns the total length in mm of the reference stage.

        Args:
            :probe: The used probe.

        Returns:
            The total length in mm of the reference stage.
        """
        sr.getRefstageLength_mm.restype = c_double
        sr.getRefstageLength_mm.argtypes = [c_handle, c_handle]
        res = sr.getRefstageLength_mm(self.handle, probe.handle)
        get_error()
        return res

    def get_position(self, probe: Probe) -> float:
        """Returns the current position in mm of the reference stage.

        Args:
            :probe: The used probe.

        Returns:
            The current position in mm of the reference stage.
        """
        sr.getRefstagePosition_mm.argtypes = [c_handle, c_handle]
        sr.getRefstagePosition_mm.restype = c_double
        res = sr.getRefstagePosition_mm(self.handle, probe.handle)
        get_error()
        return res

    def home(self, wait_for_moving: RefStageWaitForMovement):
        """Homes the reference stage to calibrate the zero position.

        Args:
            :wait_for_moving: specifies whether to wait for the end of the homing process before returning from the
                function or not.
        """
        assert isinstance(wait_for_moving, RefStageWaitForMovement)
        sr.homeRefstage.argtypes = [c_handle, c_int]
        sr.homeRefstage(self.handle, wait_for_moving)
        get_error()

    def move_to_position(self, probe, pos_mm: float, speed: RefStageSpeed, wait_for_moving: RefStageWaitForMovement):
        """Moves the reference stage to the specified position in mm.

        Args:
            :probe: The used probe
            :pos_mm: Gives the desired position in mm
            :speed: Is the velocity of the reference stage movement
            :wait_for_moving: defines whether the function should wait until the movement of the reference stage has
                stopped or not until it returns
        """
        assert isinstance(speed, RefStageSpeed)
        assert isinstance(wait_for_moving, RefStageWaitForMovement)
        sr.moveRefstageToPosition_mm.argtypes = [c_handle, c_handle, c_double, c_int, c_int]
        sr.moveRefstageToPosition_mm(self.handle, probe.handle, pos_mm, speed, wait_for_moving)
        get_error()

    def move_mm(self, probe, length: float, direction: RefStageMovementDirection, speed: RefStageSpeed,
                wait_for_moving: RefStageWaitForMovement):
        """Moves the reference stage with the specified length in mm.

        Args:
            :probe: The used probe.
            :length: Gives the desired length in mm relative to the current position
            :direction: Is the specified direction of the movement
            :speed: Is the velocity of the reference stage movement
            :wait_for_moving: Defines whether the function should wait until the movement of the reference stage has
                stopped or not until it returns
        """
        assert isinstance(direction, RefStageMovementDirection)
        assert isinstance(speed, RefStageSpeed)
        assert isinstance(wait_for_moving, RefStageWaitForMovement)
        sr.moveRefstage_mm.argtypes = [c_handle, c_handle, c_double, c_int, c_int, c_int]
        sr.moveRefstage_mm(self.handle, probe.handle, length, direction, speed, wait_for_moving)
        get_error()

    def start(self, direction: RefStageMovementDirection, speed: RefStageSpeed):
        """Starts the movement of the reference stage with the chosen speed.

        Please note that the movement does not stop until :func:`~stop` is called.

        Args:
            :direction: Is the specified direction of the movement
            :speed: Is the velocity of the reference stage movement
        """
        assert isinstance(direction, RefStageMovementDirection)
        assert isinstance(speed, RefStageSpeed)
        sr.startRefstageMovement.argtypes = [c_handle, c_int, c_int]
        sr.startRefstageMovement(self.handle, direction, speed)
        get_error()

    def stop(self):
        """Stops the movement of the reference stage."""
        sr.stopRefstageMovement.argtypes = [c_handle]
        sr.stopRefstageMovement(self.handle)
        get_error()

    def set_speed(self, speed: RefStageSpeed):
        """Sets the velocity of the movement of the reference stage.

        Args:
            :speed: The chosen velocity of the movement.
        """
        assert isinstance(speed, RefStageSpeed)
        sr.setRefstageSpeed.argtypes = [c_handle, c_int]
        sr.setRefstageSpeed(self.handle, speed)
        get_error()

    def _set_status_callback(self, callback):
        """Registers the callback to get notified if the reference stage status changed.

        Args:
            :callback: callback to register.
        """
        raise NotImplementedError

    def _set_pos_changed_callback(self, callback):
        """Registers the callback to get notified if the reference stage position changed.

        Args:
            :callback: callback to register.
        """
        raise NotImplementedError

    def get_min_position_mm(self, probe) -> float:
        """Returns the minimal position in mm the reference stage can move to.

        Args:
            :probe: The used probe.

        Returns:
            The minimal, reachable position in mm.
        """
        sr.getRefstageMinPosition_mm.argtypes = [c_handle, c_handle]
        sr.getRefstageMinPosition_mm.restype = c_double
        res = sr.getRefstageMinPosition_mm(self.handle, probe.handle)
        get_error()
        return res

    def get_max_position_mm(self, probe) -> float:
        """Returns the maximal position in mm the reference stage can move to.

        Args:
            :probe: The used probe.

        Returns:
            The maximal, reachable position in mm.
        """
        sr.getRefstageMaxPosition_mm.argtypes = [c_handle, c_handle]
        sr.getRefstageMaxPosition_mm.restype = c_double
        res = sr.getRefstageMaxPosition_mm(self.handle, probe.handle)
        get_error()
        return res
