from pyspectralradar.base.submodule import Submodule
from pyspectralradar.probe.properties.objectivepropertyfloat import ObjectivePropertyFloat
from pyspectralradar.probe.properties.objectivepropertyint import ObjectivePropertyInt
from pyspectralradar.probe.properties.objectivepropertystring import ObjectivePropertyString


class ObjectiveProperties(Submodule):
    def __init__(self, handle, objective_name: str):
        super().__init__(handle)
        self._str = ObjectivePropertyString(self.handle, objective_name)
        self._int = ObjectivePropertyInt(self.handle, objective_name)
        self._float = ObjectivePropertyFloat(self.handle, objective_name)

        # string
        self.get_display_name = self._str.get_display_name
        self.get_mount = self._str.get_mount

        # int
        self.get_range_max_x_mm = self._int.get_range_max_x_mm
        self.get_range_max_y_mm = self._int.get_range_max_y_mm

        # float
        self.get_focal_length_mm = self._float.get_focal_length_mm
        self.get_optical_path_length = self._float.get_optical_path_length
