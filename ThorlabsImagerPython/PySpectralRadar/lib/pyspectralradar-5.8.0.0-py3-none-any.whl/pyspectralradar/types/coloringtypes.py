from __future__ import annotations

from enum import IntEnum


class ColorScheme(IntEnum):
    """A class that selects the color scheme of the data to transform real data to colored data"""

    BLACK_AND_WHITE = 0
    """Black and white (monochrome) coloring"""

    INVERTED = 1
    """Black and white inverted (monochrome inverted) coloring"""

    COLOR = 2
    """Colored"""

    BLACK_AND_ORANGE = 3
    """Orange and black coloring"""

    BLACK_AND_Red = 4
    """Red and black coloring"""

    BLACK_RED_AND_YELLOW = 5
    """Black, red and yellow coloring"""

    DOPPLER_PHASE = 6
    """Doppler phase data coloring. Red and blue always colored in a range from -pi to +pi.
       Setting the boundaries for this color scheme is only allowed in between +pi and -pi"""

    BLUE_AND_BLACK = 7
    """Blue and black coloring"""

    POLARIZATION_RETARDATION = 8
    """colorful colorscheme"""

    GREEN_BLUE_AND_BLACK = 9
    """Green, blue and black is used as one half of a Doppler color scheme"""

    BLACK_AND_RED_YELLOW = 10
    """Black, red, and yellow  is used as one half of a Doppler color scheme"""

    TRANSPARENT_AND_WHITE = 11
    """Transparent and white coloring for overlay and 3D volume rendering purposes"""

    GREEN_BLUE_WHITE_RED_YELLOW = 12
    """Green, blue, White, Red, and Yellow for polarization sensitive measurements"""

    BLUE_GREEN_BLACK_YELLOW_RED = 13
    """Blue, green, black, yellow, and red for polarization sensitive measurements"""

    RED_GREEN_BLUE = 14
    """Red, green, and blue for polarization sensitive measurements"""

    GREEN_BLUE_RED = 15
    """Green, blue and red for polarization sensitive measurements"""

    BLUE_RED_GREEN = 16
    """Blue, red, and green for polarization sensitive measurements"""

    GREEN_BLUE_RED_GREEN = 17
    """Green, blue and red for polarization sensitive measurements"""

    BLUE_RED_GREEN_BLUE = 18
    """Blue, red, and green for polarization sensitive measurements"""

    INVERSE_RED_GREEN_BLUE = 19
    """Red, green, and blue for polarization sensitive measurements"""

    INVERSE_GREEN_BLUE_RED = 20
    """Green, blue and red for polarization sensitive measurements"""

    INVERSE_BLUE_RED_GREEN = 21
    """Blue, red, and green for polarization sensitive measurements"""

    INVERSE_GREEN_BLUE_RED_GREEN = 22
    """Green, blue and red for polarization sensitive measurements"""

    INVERSE_BLUE_RED_GREEN_BLUE = 23
    """Blue, red, and green for polarization sensitive measurements"""

    RED_YELLOW_GREEN_BLUE_RED = 24
    """Red, yellow, green, blue, and red for polarization sensitive measurements"""

    RED_GREEN_BLUE_RED = 25
    """Red, green, blue, and red for polarization sensitive measurements"""

    INVERSE_RED_GREEN_BLUE_RED = 26
    """Red, green, blue, and red for polarization sensitive measurements"""

    RED_YELLOW_BLUE = 27
    """Red, yellow, and blue"""

    INVERSE_RED_YELLOW_BLUE = 28
    """Red, yellow, and blue inverted"""

    DEM_NORMAL = 29
    """DEM"""

    INVERSE_DEM_NORMAL = 30
    """DEM inverted"""

    DEM_BLIND = 31
    """DEM blind"""

    INVERSE_DEM_BLIND = 32
    """DEM blind inverted"""

    WHITE_BLACK_WHITE = 33
    """White, black, white"""

    BLACK_WHITE_BLACK = 34
    """Black, white, black"""


class ByteOrder(IntEnum):
    """Selects the byte order of the coloring to be applied."""

    RGBA = 0
    """Byte order RGBA."""

    BGRA = 1
    """Byte order BGRA."""

    ARGB = 2
    """Byte order ARGB."""


class ColorEnhancement(IntEnum):
    """Selects the byte order of the coloring to be applied."""

    NONE = 0
    """Use no color enhancement"""

    SINE = 1
    """Apply a sine function as enhancement"""

    PARABLE = 2
    """Apply a parable as enhancement"""

    CUBIC = 3
    """Apply a cubic function as enhancement"""

    SQRT = 4
    """Apply a sqrt function as enhancement"""
