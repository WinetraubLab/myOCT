from __future__ import annotations

from ctypes import *
from typing import TYPE_CHECKING, Tuple

from pyspectralradar.base import HandleManagerWithDefaultConstructor
from pyspectralradar.data import ComplexData, RealData
from pyspectralradar.doppler.properties import DopplerProperties
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import DopplerOutput

if TYPE_CHECKING:
    from pyspectralradar.octfile import OCTFile


class Doppler(HandleManagerWithDefaultConstructor):
    """Class for the use of Doppler-computation routines."""

    @property
    def _create_handle_func(self):
        return sr.createDopplerProcessing

    def __init__(self, handle: c_handle = None):
        super().__init__(handle)
        self.properties: DopplerProperties = DopplerProperties(self.handle)

    @classmethod
    def from_file(cls, oct_file: 'OCTFile') -> Doppler:
        """Returns an object containing the handle for the use of Doppler-computation routines.
        The handle is created based on a saved OCT file.

        Returns:
            Doppler object containing the handle for Doppler Processing to the created Doppler routines.

        """
        sr.createDopplerProcessingForFile.restype = c_handle
        sr.createDopplerProcessingForFile.argtype = [c_handle]
        handle = sr.createDopplerProcessingForFile(oct_file.handle)
        res = Doppler(handle)
        get_error()
        return res

    @property
    def _del_func(self):
        """Closes the Doppler processing routines and frees the memory that has been allocated for these to work
        properly."""
        return sr.clearDopplerProcessing

    def set_output(self, output_type: DopplerOutput, output: RealData):
        """Sets the location of the resulting Doppler amplitude or phase output.

        Args:
            :output_type: Selects if amplitude or phase data will be set
            :output: A valid (non-None) :class:`~pyspectralradar.data.realdata.RealData` object, where the resulting
                amplitudes or phase of the Doppler computation will be written. The right number of dimensions,
                sizes, and ranges will be automatically adjusted by the function
                :func:`~pyspectralradar.doppler.doppler.Doppler.execute`.
        """
        assert isinstance(output_type, DopplerOutput)
        assert isinstance(output, RealData)
        function = None
        if output_type is DopplerOutput.AMPLITUDE:
            function = sr.setDopplerAmplitudeOutput
        elif output_type is DopplerOutput.PHASE:
            function = sr.setDopplerPhaseOutput

        function.argtypes = [c_handle, c_handle]
        function(self.handle, output.handle)
        get_error()

    def execute(self, input_data: ComplexData):
        """Executes the Doppler processing of the input data and returns phases and amplitudes.

        Doppler processing takes place after the standard processing. It takes as input complex data computed by the
        standard processing, and during execution it writes amplitudes and phases, provided either (or both) if the
        function :func:`~pyspectralradar.doppler.doppler.Doppler.set_output` has previously been invoked.

        Args:
            :input_data: A valid (non-None) object holding the complex data. These data should have previously
                obtained initialization of a :class:`~pyspectralradar.data.complexdata.ComplexData` object and
                invoking the functions :func:`~pyspectralradar.processing.processing.Processing.set_data_output` and
                :func:`~pyspectralradar.processing.processing.Processing.execute`.
        """
        assert isinstance(input_data, ComplexData)
        sr.executeDopplerProcessing.argtypes = [c_handle, c_handle]
        sr.executeDopplerProcessing(self.handle, input_data.handle)
        get_error()

    def phase_to_velocity(self, data: RealData) -> RealData:
        """Scales phases computed by Doppler OCT to actual flow velocities in scan direction

        This requires the Doppler scan rate, Doppler angle and center velocity of the Doppler object to be set
        correctly.

        Args:
            :data: An object representing the phase data.

        Returns:
            An object that contains the calculated velocity data.
        """
        assert isinstance(data, RealData)
        velocities = data.clone()
        sr.dopplerPhaseToVelocity.argtypes = [c_handle, c_handle]
        sr.dopplerPhaseToVelocity(self.handle, velocities.handle)
        get_error()
        return velocities

    def velocity_to_phase(self, data: RealData) -> RealData:
        """Scales flow velocities computed by Doppler OCT back to original phase differences

        This requires the Doppler scan rate, Doppler angle and center velocity of the Doppler object to be set
        correctly.

        Args:
            :data: An object representing the velocity data

        Returns:
            An object that contains the calculated phase data.
        """
        assert isinstance(data, RealData)
        phases = data.clone()
        sr.dopplerVelocityToPhase.argtypes = [c_handle, c_handle]
        sr.dopplerVelocityToPhase(self.handle, phases.handle)
        get_error()
        return phases

    def get_output_size_pre_processing(self, size1_in: int, size2_in: int) -> Tuple[int, int]:
        """Returns the final size of the Doppler output if :func:`~pyspectralradar.doppler.doppler.Doppler.execute`
        is executed using data of the specified input size.

        Args:
            :size1_in: The ``SIZE1`` value of
                :class:`~pyspectralradar.data.properties.datapropertyint.DataPropertyInt` of the complex-data that will
                be used as input. In the default orientation, this is the number of pixels along the z-axis
            :size2_in: The ``SIZE2`` value of
                :class:`~pyspectralradar.data.properties.datapropertyint.DataPropertyInt` of the complex-data that
                will be used as input. In the default orientation, this is the number of pixels along the x-axis.

        Returns:
            A tuple (``size1_out``, ``size2_out``) containing ``size1_out`` as the ``SIZE1`` value of
            :class:`~pyspectralradar.data.properties.datapropertyint.DataPropertyInt` (in the default orientation,
            this is the number of pixels along the z-axis) of the amplitude/phase data and ``size2_out`` as the
            ``SIZE2`` value of :class:`~pyspectralradar.data.properties.datapropertyint.DataPropertyInt` (in the default
            orientation, this is the number of pixels along the x-axis) of the amplitude/phase data that will result
            upon invocation of the function :func:`~pyspectralradar.doppler.doppler.Doppler.execute`.
        """
        size1_out = c_int()
        size2_out = c_int()
        sr.getDopplerOutputSize.argtypes = [c_handle, c_int, c_int, POINTER(c_int), POINTER(c_int)]
        sr.getDopplerOutputSize(self.handle, size1_in, size2_in, size1_out, size2_out)
        get_error()
        return size1_out.value, size2_out.value

    @staticmethod
    def threshold_doppler_data(phase: RealData, intensity: RealData, intensity_threshold: float,
                               phase_target_value: float):
        """At points whose Intensity does not exceed the ``intensity_threshold``, the phase is set to the
        ``phase_target_value``.

        Args:
            :phase: The phase data
            :intensity: The intensity data
            :intensity_threshold: The threshold to be applied
            :phase_target_value: The target value tha phase shall be set to at points where ``intensity_threshold``
                is not exceeded
        """
        assert isinstance(phase, RealData)
        assert isinstance(intensity, RealData)
        sr.thresholdDopplerData.argtypes = [c_handle, c_handle, c_float, c_float]
        sr.thresholdDopplerData(phase.handle, intensity.handle, intensity_threshold, phase_target_value)
        get_error()
