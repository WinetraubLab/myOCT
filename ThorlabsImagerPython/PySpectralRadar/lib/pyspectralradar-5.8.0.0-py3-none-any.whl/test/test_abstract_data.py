import unittest

import pyspectralradar.types as pt
from pyspectralradar import OCTSystem, RealData, LogLevel, set_log_level


class AbstractDataTestCase(unittest.TestCase):
    _dut = RealData()

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

        sys = OCTSystem()
        dev = sys.dev
        proc = sys.processing_factory.from_device()
        probe = sys.probe_factory.create_default()
        pattern = probe.scan_pattern.create_bscan_pattern(10.0, 1024)

        dev.acquisition.start(pattern, pt.AcqType.ASYNC_FINITE)
        raw = dev.acquisition.get_raw_data()

        proc.set_data_output(cls._dut)
        proc.execute(raw)
        dev.acquisition.stop()

    @classmethod
    def tearDownClass(cls):
        del cls._dut

    def test_data_append(self):
        dut = self._dut.clone()
        dut.append(self._dut, pt.DataDirection.DIR3)
        self.assertEqual(dut.size, (1024 * 1024 * 1) * 2)
        self.assertTrue(dut.shape == (1024, 1024, 2))
        dut.set_range(5.12, 10.0, 2.0)
        self.assertTrue(dut.range == (5.12, 10.0, 2.0))

    def test_data_pointer(self):
        pointer = self._dut.pointer()
        print(pointer[0:10])

    def test_data_reserve(self):
        dut = RealData()
        dut.reserve(1024, 200, 200)

    def test_data_clone(self):
        dut_clone = self._dut.clone()
        self.assertIsInstance(dut_clone, RealData)
        self.assertEqual(dut_clone.size, 1024 * 1024 * 1)
        self.assertTrue(dut_clone.shape == (1024, 1024, 1))
        self.assertTrue(dut_clone.range == (5.12, 10.0, 1.0))


if __name__ == '__main__':
    unittest.main()
