from __future__ import annotations

from ctypes import ArgumentError, c_char_p, c_double, c_int
from typing import List

from pyspectralradar.base import Submodule
from pyspectralradar.probe import Probe
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import DispersionCorrectionType


class Dispersion(Submodule):

    def set_presets_from_probe(self, probe: Probe):
        """Sets the dispersion presets for the probe.

        Unfortunately no perfect and easy method to predict the dispersion coefficient(s) is offered here. The
        coefficients (currently) used in the software do not correspond to physically meaningful parameters,
        but are rather given in arbitrary units. Hence, it is suggested to use image quality as of criterion to set
        the coefficients, because this criterion usually works quite well. The quadratic coefficient can be easily
        found by using the ThorImage OCT software, and using the built-in quadratic slider and simultaneously looking
        for image quality and axial sharpness. Usually, the quadratic parameter alone gives rather good quality and
        dispersion correction and only for very broadband sources and strong dispersion higher coefficients are
        required. To set higher coefficients, either this SDK is required or an entry ``Dispersion_NameOfPreset``
        has to be added to the respective probe.ini file being used (see Settings Dialog of ThorImage OCT). This file
        is default located in "C:/Program Files/Thorlabs/SpectralRadar/Config" (or equivalent, if the software has
        been installed to another location). In probe.ini, the relevant entry looks like: Dispersion_Probe = 10.0,
        2.0, -1.0 and this particular example would set three dispersion factors, the quadratic one being 10,
        the third degree 2, and fourth degree -1. Again, unfortunately, there is no option to set these
        automatically. The user has to experiment with different parameters and iteratively optimize for a sharp
        signal. After this entry has been added to the file probe.ini, the Preset dispersions menu will contain a new
        entry on the next software start of ThorImageOCT. Of course, the presets added to probe.ini can also be
        used by the functions in this SDK. Each line should give a different preset-name, and after this function is
        invoked, all of them will be available through indices or names (see :func:`~set_preset`).

        Args:
            :probe: Probe object which dispersion preset shall be set.
        """
        sr.setDispersionPresets.argtypes = [c_handle, c_handle]
        sr.setDispersionPresets(self.handle, probe.handle)
        get_error()

    def set_preset(self, preset: int | str):
        """Sets the dispersion preset specified with name.

        For a detailed explanation, do please refer to the documentation of :func:`~set_presets_from_probe`.

        Args:
            :preset: A zero terminated string with the name OR integer with index of the desired dispersion preset
                that has to be set.
        """
        if isinstance(preset, int):
            if preset < self._get_number_dispersion_presets():
                sr.setDispersionPresetByIndex.argtypes = [c_handle, c_int]
                sr.setDispersionPresetByIndex(self.handle, preset)
            else:
                raise ArgumentError('Invalid preset')
        elif isinstance(preset, str):
            if preset in str(self.get_presets()):
                sr.setDispersionPresetByName.argtypes = [c_handle, c_char_p]
                sr.setDispersionPresetByName(self.handle, c_char_p(bytes(preset, encoding="ascii")))
            else:
                raise ArgumentError('Invalid preset')
        else:
            raise ArgumentError('Invalid preset type')

    def get_current_preset_name(self) -> str:
        """Gets the name of the active dispersion preset.

        Returns:
            A zero terminated string with the name of the active dispersion preset.
        """
        sr.getCurrentDispersionPresetName.argtypes = [c_handle]
        sr.getCurrentDispersionPresetName.restype = c_char_p
        res = sr.getCurrentDispersionPresetName(self.handle)
        get_error()
        return res.decode('UTF-8')

    def get_presets(self) -> List[str, ...]:
        """Gets the names of all available dispersion presets.

        For a detailed explanation, do please refer to the documentation of :func:`~set_presets_from_probe`.

        Returns:
            A list of all available dispersion preset names.
        """
        n = self._get_number_dispersion_presets()
        res = [self._get_dispersion_preset_name(i) for i in range(n)]
        get_error()
        return res

    def get_quadratic_coeff(self) -> float:
        """Gets the coefficient for the quadratic correction of the dispersion.

        Returns:
            The coefficient currently used for the quadratic correction of the dispersion.

        """
        sr.getDispersionQuadraticCoeff.argtypes = [c_handle]
        sr.getDispersionQuadraticCoeff.restype = c_double
        res = sr.getDispersionQuadraticCoeff(self.handle)
        get_error()
        return res

    def set_quadratic_coeff(self, coeff: float):
        """Sets the coefficient for the quadratic correction of the dispersion.

        Args:
            :coeff: The desired coefficient.
        """
        sr.setDispersionQuadraticCoeff.argtypes = [c_handle, c_double]
        sr.setDispersionQuadraticCoeff(self.handle, c_double(coeff))
        get_error()

    def get_correction_type(self) -> DispersionCorrectionType:
        """Sets the active dispersion correction type.

        Returns:
            The currently active dispersion correction algorithm.
        """
        sr.getDispersionCorrectionType.argtypes = [c_handle]
        sr.getDispersionCorrectionType.restype = c_int
        res = sr.getDispersionCorrectionType(self.handle)
        res = DispersionCorrectionType(res)
        get_error()
        return res

    def set_correction_type(self, correction_type: DispersionCorrectionType):
        """Sets the active dispersion correction type.

        Args:
            :correction_type: The specification of the dispersion correction algorithm.
        """
        assert isinstance(correction_type, DispersionCorrectionType)
        sr.setDispersionCorrectionType.argtypes = [c_handle, c_int]
        sr.setDispersionCorrectionType(self.handle, correction_type)
        get_error()

    def _get_number_dispersion_presets(self) -> int:
        """Gets the number of dispersion presets.

        For a detailed explanation, do please refer to the documentation of :func:`~set_presets_from_probe`.

        Returns:
            The number of dispersion presets.
        """
        sr.getNumberOfDispersionPresets.argtypes = [c_handle]
        sr.getNumberOfDispersionPresets.restype = c_int
        res = sr.getNumberOfDispersionPresets(self.handle)
        get_error()
        return res

    def _get_dispersion_preset_name(self, idx) -> str:
        """Gets the name of the dispersion preset specified with index.

        For a detailed explanation, do please refer to the documentation of :func:`~set_presets_from_probe`.

        Args:
            :idx: The index of the desired dispersion preset.

        Returns:
            A zero terminated string with the name of the dispersion preset associated with the given index.
        """
        sr.getDispersionPresetName.argtypes = [c_handle, c_int]
        sr.getDispersionPresetName.restype = c_char_p
        res = sr.getDispersionPresetName(self.handle, idx).decode('ascii')
        get_error()
        return res
