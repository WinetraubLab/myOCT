import time
import unittest
from os import remove
from os.path import exists

from matplotlib import pyplot as plt

import pyspectralradar.types as pt
from pyspectralradar import ColoredData, Coloring, ComplexData, OCTSystem, RawData, RealData, get_rgb_values, \
    LogLevel, set_log_level

ENABLE_PLOTS = False


def check_and_remove(path):
    if exists(path):
        remove(path)
        time.sleep(0.05)


class DataFileIOCase(unittest.TestCase):
    _real = RealData()
    _raw = RawData()
    _complex = ComplexData()
    _colored = ColoredData()

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

        sys = OCTSystem()
        dev = sys.dev
        proc = sys.processing_factory.from_device()
        probe = sys.probe_factory.create_default()
        pattern = probe.scan_pattern.create_bscan_pattern(10.0, 128)

        dev.camera.get_image(cls._colored)

        dev.acquisition.start(pattern, pt.AcqType.ASYNC_FINITE)
        dev.acquisition.get_raw_data(buffer=cls._raw)

        proc.set_data_output(cls._real)
        proc.execute(cls._raw)

        proc.set_data_output(cls._complex)
        proc.execute(cls._raw)

        dev.acquisition.stop()

    @classmethod
    def tearDownClass(cls):
        del cls._real
        del cls._raw
        del cls._complex
        del cls._colored

    def test_import_export_raw(self):
        io_path = 'C:\\tmp\\raw_data.srr'

        plt.figure()
        plt.title('test_import_export_raw')
        plt.imshow(self._raw.to_numpy()[:, :, 0])

        self._raw.export(pt.RawDataExportFormat.SRR, io_path)
        self.assertTrue(exists(io_path))

        if exists(io_path):
            dut = RawData().from_file(io_path)
            print(type(dut), dut.shape, dut.to_numpy().shape)

            plt.figure()
            plt.title('test_import_export_raw')
            plt.imshow(dut.to_numpy()[:, :, 0])
            self.assertTrue(dut.to_numpy().shape == (2048, 193, 1))

        if ENABLE_PLOTS:
            plt.show()
        else:
            plt.close()
        check_and_remove(io_path)

    def test_import_export_real(self):
        io_path = 'C:\\tmp\\real_data.raw'
        img_io_path = 'C:\\tmp\\real_data.jpg'

        plt.figure()
        plt.title('test_import_export_real')
        plt.imshow(self._real.to_numpy()[:, :, 0])

        self._real.export(pt.DataExportFormat.RAW, io_path)
        self.assertTrue(exists(io_path))

        color = Coloring(pt.ColorScheme.RED_GREEN_BLUE, pt.ByteOrder.RGBA)
        color.set_boundaries(10.0, 70.0)
        self._real.export_data_as_image(color, pt.ColoredDataExportFormat.JPG, pt.DataDirection.DIR3, img_io_path)
        self.assertTrue(exists(img_io_path))

        if exists(io_path):
            dut = RealData().from_file(io_path, 1024, 128, 1)

            print(type(dut), dut.shape, dut.to_numpy().shape)

            plt.figure()
            plt.title('test_import_export_real')
            plt.imshow(dut.to_numpy()[:, :, 0])

            self.assertTrue(dut.to_numpy().shape == (1024, 128, 1))

        if ENABLE_PLOTS:
            plt.show()
        else:
            plt.close()
        check_and_remove(io_path)
        check_and_remove(img_io_path)

    def test_import_export_complex(self):
        io_path = 'C:\\tmp\\complex_data.raw'

        self._complex.export(pt.ComplexDataExportFormat.RAW, io_path)
        self.assertTrue(exists(io_path))

        check_and_remove(io_path)

    def test_import_export_colored(self):
        io_path = 'C:\\tmp\\colored_data.png'
        rgb = get_rgb_values(self._colored.to_numpy())
        print(rgb.shape)

        if ENABLE_PLOTS:
            plt.figure()
            plt.title('test_import_export_colored')
            plt.subplot(1, 3, 1)
            plt.imshow(rgb[:, :, 0])
            plt.subplot(1, 3, 2)
            plt.imshow(rgb[:, :, 1])
            plt.subplot(1, 3, 3)
            plt.imshow(rgb[:, :, 2])
            plt.show()

        self._colored.export(pt.ColoredDataExportFormat.PNG, pt.DataDirection.DIR3, io_path)
        self.assertTrue(exists(io_path))

        check_and_remove(io_path)


if __name__ == '__main__':
    unittest.main()
