from ctypes import c_bool, c_char_p, c_int

from pyspectralradar.base import Submodule
from pyspectralradar.spectralradar import c_handle, get_error, sr


class AnalogInputChannel(Submodule):
    def get_name(self, channel_idx: int) -> str:
        """Returns the name of an analog input channel. Use
        :func:`~pyspectralradar.octdevice.properties.devicepropertyint.DevicePropertyInt.get_num_analog_input_channels`
        to determine the number of available channels.

        Args:
            :channel_idx: Index of the analog input channel to query

        Returns:
            String containing the descriptive name of the channel.
        """
        sr.getAnalogInputChannelName.argtypes = [c_handle, c_int]
        sr.getAnalogInputChannelName.restype = c_char_p
        res = sr.getAnalogInputChannelName(self.handle, channel_idx).decode('ascii')
        get_error()
        return res

    def set_enabled(self, channel_idx: int, enable: bool):
        """Enables or disables an analog input channel. Use
        :func:`~pyspectralradar.octdevice.properties.devicepropertyint.DevicePropertyInt.get_num_analog_input_channels`
        to determine the number of available channels.

        Args:
            :channel_idx: Index of the analog input channel to activate or deactivate
            :enable: ``True`` to enable channel, ``False`` to disable
        """
        sr.setAnalogInputChannelEnabled.argtypes = [c_handle, c_int, c_bool]
        sr.setAnalogInputChannelEnabled(self.handle, channel_idx, enable)
        get_error()

    def get_enabled(self, channel_idx: int) -> bool:
        """Returns the current status (enabled/disabled) of an analog input channel. Use
        :func:`~pyspectralradar.octdevice.properties.devicepropertyint.DevicePropertyInt
        .get_num_analog_input_channels` to determine the number of available channels.

        Args:
            :channel_idx: Index of the analog input channel to query

        Returns:
            ``True`` if channel is enabled, ``False`` otherwise
        """
        sr.getAnalogInputChannelEnabled.argtypes = [c_handle, c_int]
        sr.getAnalogInputChannelEnabled.restype = c_bool
        res = sr.getAnalogInputChannelEnabled(self.handle, channel_idx)
        get_error()
        return res
