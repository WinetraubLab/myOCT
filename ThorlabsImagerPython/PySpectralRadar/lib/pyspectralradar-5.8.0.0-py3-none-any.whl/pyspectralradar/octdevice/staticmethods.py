from ctypes import c_bool, c_char_p, c_int, c_void_p, create_string_buffer

from pyspectralradar.spectralradar import get_error, sr
from pyspectralradar.types import DevState


def get_device_error(string_size: int = 1024) -> str:
    """Returns the error message given by the hardware.

    It is assumed, but not mandatory, that the user previously invoked the function
    :func:`~pyspectralradar.octdevice.staticmethods.get_device_state`. If there are no errors, nothing will be done (
    the user may want to write a dfault answer to catch this case). This function can be invoked as many times as
    desired (e.g. in a polling strategy) without side effects.

    Args:
        :string_size: The maximum space available to write the error description.

    Returns:
        The device error message
    """
    error_msg = create_string_buffer(string_size)
    sr.getDeviceError.argtypes = [c_char_p, c_int]
    sr.getDeviceError.restype = c_void_p
    sr.getDeviceError(error_msg, c_int(string_size))
    get_error()
    return error_msg.value.decode('UTF-8')


def available() -> bool:
    """Returns whether any supported Base-Unit is available.

    This function attempts to communicate with the device, and returns ``True`` if a minimum of working functionality
    can be guaranteed, ``False`` otherwise. This function can be invoked as many times as desired (e.g. in a polling
    strategy) without side effects.

    Returns:
        ``True`` if a minimum of working functionality can be guaranteed, ``False`` otherwise.
    """
    sr.isDeviceAvailable.restype = c_bool
    res = sr.isDeviceAvailable()
    get_error()
    return res


def reset_camera():
    """Resets the spectrometer camera."""
    sr.resetCamera.restype = c_void_p
    sr.resetCamera()
    get_error()


def set_required_SLD_on_time(time_s: int):
    """Sets the time the SLD needs to be switched on before any measurement can be started. Default is 3 seconds.

    Args:
        :time_s: Minimum required on time in seconds.
    """
    sr.setRequiredSLDOnTime_s.argtypes = [c_int]
    sr.setRequiredSLDOnTime_s(c_int(time_s))
    get_error()


def get_device_state() -> DevState:
    """Returns the state of supported base-unit.

    This function attempts to communicate with the device, and returns the state of the base-unit if a minimum
    of working functionality can be guaranteed. If no device can be found or communication fails, this function
    will return ``UNAVAILABLE``. This function can be invoked as many times as desired (e.g. in a
    polling strategy) without side effects.

    Returns:
        The state of the base-unit if a minimum of working functionality can be guaranteed. If no device can
        be found or communication fails, this function will return ``UNAVAILABLE``.
    """
    sr.getDeviceState.restype = c_int
    get_error()
    state = DevState(sr.getDeviceState())
    return state
