import logging
import unittest

import matplotlib.pyplot as plt
import numpy as np

from pyspectralradar import ComplexData, Doppler, OCTFile, OCTSystem, RawData, RealData, set_log_level
from pyspectralradar.types import *

ENABLE_PLOTS = False


class TestDopplerCreate(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def test_doppler_create(self):
        dut = Doppler()
        self.assertIsInstance(dut, Doppler)

    def test_doppler_create_from_file(self):
        oct_file = OCTFile(
            '\\\\lbknetapp01\\Public\\Doc\\Software\\Unittests\\PySpectralRadarTests\\Unittest_0001_ModeDoppler.oct')
        dut = Doppler.from_file(oct_file)
        self.assertIsInstance(dut, Doppler)


class DopplerPropertyTestCase(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def setUp(self):
        self._doppler = Doppler()

    def tearDown(self):
        del self._doppler


class TestDopplerPropertyFloat(DopplerPropertyTestCase):

    def setUp(self):
        super().setUp()
        self.dut = self._doppler.properties

    def test_property_float(self):
        print('RI:', self.dut.get_refractive_index())
        self.dut.set_refractive_index(1.4)
        print(self.dut.get_refractive_index())
        self.assertAlmostEqual(self.dut.get_refractive_index(), 1.4, places=3)

        print('Scan Rate:', self.dut.get_scan_rate_hz())
        self.dut.set_scan_rate_hz(11111.1)
        print(self.dut.get_scan_rate_hz())
        self.assertAlmostEqual(self.dut.get_scan_rate_hz(), 11111.1, places=3)

        print('CWL:', self.dut.get_center_wavelength_nm())
        self.dut.set_center_wavelength_nm(1060.5)
        print(self.dut.get_center_wavelength_nm())
        self.assertAlmostEqual(self.dut.get_center_wavelength_nm(), 1060.5, places=3)

        print('Angle:', self.dut.get_doppler_angle_deg())
        self.dut.set_doppler_angle_deg(45)
        print(self.dut.get_doppler_angle_deg())
        self.assertAlmostEqual(self.dut.get_doppler_angle_deg(), 45, places=3)


class TestDopplerPropertyInt(DopplerPropertyTestCase):

    def setUp(self):
        super().setUp()
        self.dut = self._doppler.properties

    def test_property_float(self):
        self.dut.set_averaging_1(8)
        self.assertEqual(self.dut.get_averaging_1(), 8)

        self.dut.set_averaging_2(6)
        self.assertEqual(self.dut.get_averaging_2(), 6)

        self.dut.set_stride_1(7)
        self.assertEqual(self.dut.get_stride_1(), 7)

        self.dut.set_stride_2(5)
        self.assertEqual(self.dut.get_stride_2(), 5)


class TestDopplerPropertyFlag(DopplerPropertyTestCase):

    def setUp(self):
        super().setUp()
        self.dut = self._doppler.properties

    def test_property_float(self):
        print(self.dut.get_doppler_velocity_scaling())
        self.dut.set_doppler_velocity_scaling(True)
        self.assertTrue(self.dut.get_doppler_velocity_scaling())


class DopplerTestCase(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def setUp(self):
        self.dut = Doppler()

        self.sys = OCTSystem()
        self.dev = self.sys.dev
        self.probe = self.sys.probe_factory.create_default()
        self.probe.properties.set_oversampling(3)
        self.proc = self.sys.processing_factory.from_device()
        self.proc.properties.set_spectrum_avg(3)
        self.pattern = self.probe.scan_pattern.create_bscan_pattern(5.0, 200)

        self.raw = RawData()
        self.complex_bscan = ComplexData()

        self.amplitude = RealData()
        self.phase = RealData()

        self.dev.acquisition.start(self.pattern, AcqType.ASYNC_FINITE)
        self.dev.acquisition.get_raw_data(buffer=self.raw)
        self.proc.set_data_output(self.complex_bscan)
        self.proc.execute(self.raw)
        self.dev.acquisition.stop()

        self.dut.set_output(DopplerOutput.AMPLITUDE, self.amplitude)
        self.dut.set_output(DopplerOutput.PHASE, self.phase)

    def tearDown(self):
        del self.phase
        del self.amplitude
        del self.complex_bscan
        del self.raw
        del self.pattern
        del self.proc
        del self.probe
        del self.dev
        del self.sys
        del self.dut

    def test_doppler_execute(self):
        self.dut.execute(self.complex_bscan)
        self.assertEqual(self.amplitude.to_numpy().shape, (1024, 199, 1))
        self.assertEqual(self.phase.to_numpy().shape, (1024, 199, 1))

        if ENABLE_PLOTS:
            plt.figure()
            plt.title('test_doppler_execute')
            plt.subplot(1, 2, 1)
            plt.imshow(self.amplitude.to_numpy()[:, :, 0])
            plt.subplot(1, 2, 2)
            plt.imshow(self.phase.to_numpy()[:, :, 0])

            plt.show()

    def _scale_phase_to_velocity_np(self, phases: np.ndarray,
                                    scan_rate: float,
                                    doppler_angle: float,
                                    center_wavelength_nm: float,
                                    refractive_index: float) -> np.ndarray:
        _center_wavelength_m = center_wavelength_nm * 1e-9
        _cos_angle = np.cos((doppler_angle * np.pi) / 180.0)
        _scaling_factor = (_center_wavelength_m * scan_rate) / (2.0 * 2.0 * np.pi * refractive_index * _cos_angle)

        velocities = phases.copy()
        velocities *= _scaling_factor

        self.assertFalse(np.allclose(phases, velocities))

        return velocities

    def _scale_velocities_to_phase_np(self, velocities: np.ndarray,
                                      scan_rate: float,
                                      doppler_angle: float,
                                      center_wavelength_nm: float,
                                      refractive_index: float) -> np.ndarray:
        _center_wavelength_m = center_wavelength_nm * 1e-9
        _cos_angle = np.cos((doppler_angle * np.pi) / 180.0)

        _scaling_factor = (2.0 * 2.0 * np.pi * refractive_index * _cos_angle) / (_center_wavelength_m * scan_rate)

        phases = velocities.copy()
        phases *= _scaling_factor

        self.assertFalse(np.allclose(velocities, phases))

        return phases

    def test_doppler_phase_to_velocity_and_back(self):
        doppler_angle_deg = 20.0
        refractive_index = 1.0

        logging.debug(self.dut.properties.get_scan_rate_hz())
        logging.debug(self.dut.properties.get_center_wavelength_nm())

        self.dut.properties.set_doppler_angle_deg(doppler_angle_deg)
        self.dut.properties.set_refractive_index(refractive_index)
        self.dut.properties.set_averaging_1(3)
        self.dut.properties.set_averaging_2(3)
        self.dut.properties.set_doppler_velocity_scaling(False)

        self.dut.execute(self.complex_bscan)
        logging.debug(self.dut.properties.get_scan_rate_hz())
        logging.debug(self.dut.properties.get_center_wavelength_nm())
        logging.debug(self.dut.properties.get_doppler_angle_deg())
        logging.debug(self.dut.properties.get_refractive_index())

        phases_np = self.phase.to_numpy()

        velocities = self.dut.phase_to_velocity(self.phase)
        velocities_np = velocities.to_numpy()
        velocities_py = self._scale_phase_to_velocity_np(phases_np,
                                                         self.dut.properties.get_scan_rate_hz(),
                                                         self.dut.properties.get_doppler_angle_deg(),
                                                         self.dut.properties.get_center_wavelength_nm(),
                                                         self.dut.properties.get_refractive_index())

        re_phases = self.dut.velocity_to_phase(velocities)
        re_phases_np = re_phases.to_numpy()
        re_phases_py = self._scale_velocities_to_phase_np(velocities_py,
                                                          self.dut.properties.get_scan_rate_hz(),
                                                          self.dut.properties.get_doppler_angle_deg(),
                                                          self.dut.properties.get_center_wavelength_nm(),
                                                          self.dut.properties.get_refractive_index())

        if ENABLE_PLOTS:
            plt.figure(figsize=(10, 10))
            rows = 2
            cols = 4

            plt.subplot(rows, cols, 1)
            plt.title('phases')
            plt.imshow(phases_np[:, :, 0], cmap="gray")

            plt.subplot(rows, cols, 2)
            plt.title('velocities_py')
            plt.imshow(velocities_py[:, :, 0], cmap="gray")

            plt.subplot(rows, cols, 3)
            plt.title('re-phases_py')
            plt.imshow(re_phases_py[:, :, 0], cmap="gray")

            plt.subplot(rows, cols, 4)
            plt.title('phase - re-phases')
            plt.imshow(phases_np[:, :, 0] - re_phases_py[:, :, 0], cmap="gray")
            plt.tight_layout()

            plt.subplot(rows, cols, 5)
            plt.title('phases')
            plt.imshow(phases_np[:, :, 0], cmap="gray")

            plt.subplot(rows, cols, 6)
            plt.title('velocities')
            plt.imshow(velocities_np[:, :, 0], cmap="gray")

            plt.subplot(rows, cols, 7)
            plt.title('re-phases')
            plt.imshow(re_phases_np[:, :, 0], cmap="gray")

            plt.subplot(rows, cols, 8)
            plt.title('phase - re-phases')
            plt.imshow(phases_np[:, :, 0] - re_phases_np[:, :, 0], cmap="gray")
            plt.tight_layout()

            plt.tight_layout()
            plt.show()

        self.assertTrue(np.allclose(phases_np, re_phases_np))

    def test_doppler_get_output_sizes(self):
        self.dut.properties.set_averaging_1(3)

        self.dut.execute(self.complex_bscan)

        self.assertEqual(self.dut.get_output_size_pre_processing(1024, 200), self.amplitude.shape[:2])

    def test_threshold_doppler_data(self):
        self.dut.execute(self.complex_bscan)

        phase_clone = self.phase.clone()
        Doppler.threshold_doppler_data(phase_clone, self.amplitude, 10.0, 3.14)

        if ENABLE_PLOTS:
            plt.figure()
            plt.title('test_threshold_doppler_data')
            plt.subplot(1, 2, 1)
            plt.title('phases')
            plt.imshow(self.phase.to_numpy()[:, :, 0])

            plt.subplot(1, 2, 2)
            plt.title('threshold phases')
            plt.imshow(phase_clone.to_numpy()[:, :, 0])

            plt.show()

        self.assertFalse(np.allclose(phase_clone.to_numpy(), self.phase.to_numpy()))


if __name__ == '__main__':
    unittest.main()
