from enum import IntEnum

from pyspectralradar.base.propertygetter import StringPropertyGetter
from pyspectralradar.spectralradar import sr


class PropertyString(IntEnum):
    """String-properties of the device that can be retrieved with the function #getDevicePropertyString."""

    TYPE = 0
    """The type name of the device."""

    SERIES = 1
    """The series of the device"""

    SERIAL_NUMBER = 2
    """Serial number of the device."""

    HARDWARE_CONFIG = 3
    """Hardware Config of the currently used device."""


class DevicePropertyString(StringPropertyGetter):
    """String-properties of the device that can be retrieved with the function #getDevicePropertyString.
    """

    def __init__(self, handle):
        super().__init__(handle, sr.getDevicePropertyString)

    def get_type(self) -> str:
        """The type name of the device."""
        return self._get(PropertyString.TYPE)

    def get_series(self) -> str:
        """The series of the device"""
        return self._get(PropertyString.SERIES)

    def get_serial_number(self) -> str:
        """Serial number of the device."""
        return self._get(PropertyString.SERIAL_NUMBER)

    def get_hardware_config(self) -> str:
        """Hardware Config of the currently used device."""
        return self._get(PropertyString.HARDWARE_CONFIG)
