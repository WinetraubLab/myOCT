from ctypes import c_int
from enum import IntEnum


class DataExportFormat(IntEnum):
    """Export formats for :class:`~pyspectralradar.data.realdata.RealData` objects"""

    SRM = 0
    """Spectral Radar Meta format, containing no data but many additional parameters, such as spacing, size, etc."""

    RAW = 1
    """RAW data format containing the data of the object as binary, single precision floating point values, 
    little endian."""

    CSV = 2
    """CSV (Comma separated Values) is a text file having all values stored, comma separated and human readable."""

    TXT = 3
    """TXT is a text file having all values stored space separated and human readable."""

    TableTXT = 4
    """TableTXT is a human readable text-file in a table like format, having the physical 1- and 2-axis as first two 
    columns and the data value as third. Currently only works for 1D- and 2D-Data."""

    Fits = 5
    """FITS Data format"""

    VFF = 6
    """VFF data format."""

    VTK = 7
    """VTK data format."""

    TIFF = 8
    """TIFF Data format as 32-bit floating point numbers"""


class PepperFilterType(IntEnum):
    """Specifies the type of pepper filter to be applied."""

    HORIZONTAL = 0
    """Values along the horizontal axis are taken into account for the pepper filter."""

    VERTICAL = 1
    """Values along the vertical axis are taken into account for the pepper filter."""

    STAR = 2
    """Values along the vertical and horizontal axis (star shape) are taken into account for the pepper filter."""

    BLOCK = 3
    """Values in a block surrounding the destination pixel are taken into account."""


class FilterType3D(IntEnum):
    """Specifies the type of 3D-filter to be applied. All filters are normalized."""

    GAUSSIAN_3X3X3 = 0
    """A gaussian filter of size 3x3 to smooth the data"""


class FilterType2D(IntEnum):
    """Specifies the type of 2D-filter to be applied. All filters are normalized."""

    GAUSSIAN_3X3 = 0
    """A gaussian filter of size 3x3 to smooth the data"""

    GAUSSIAN_5X5 = 1
    """A gaussian filter of size 5x5 to smooth the data"""

    Prewitt_HOR_3X3 = 2
    """Horizontal Prewitt filter of size 3x3 to detect edges in horizontal direction"""

    Prewitt_VER_3X3 = 3
    """Vertical Prewitt filter of size 3x3 to detect edges in vertical direction"""

    NONLINEAR_Prewitt_3X3 = 4
    """Maximum of horizontal and vertical Prewitt filter each of size 3x3 to detect edges"""

    SOBEL_HOR_3X3 = 5
    """Horizontal sobel filter of size 3x3 to detect edges in horizontal direction while smoothing in vertical 
    direction"""

    SOBEL_VER_3X3 = 6
    """Vertical Prewitt filter of size 3x3 to detect edges in vertical direction while smoothing in horizontal 
    direction"""

    NONLINEAR_SOBEL_3X3 = 7
    """Maximum of horizontal and vertical sobel filter each of size 3x3 to detect edges while smoothing the data 
    simultaneously"""

    LAPLACIAN_NO_DIAGONAL_3X3 = 8
    """Laplacian filter of size 3x3 to detect horizontal and vertical edges, no diagonal edges"""

    LAPLACIAN_3X3 = 9
    """Laplacian filter of size 3x3 to detect horizontal, vertical and diagonal edges"""


class FilterType1D(IntEnum):
    """Specifies the type of 1D-filter to be applied. All filters are normalized."""

    GAUSSIAN_5 = 0
    """A gaussian 1D-filter of size 5 to smooth the data"""


class DataDirection(IntEnum):
    """Specifies the data direction"""

    DIR1 = 0
    """z-axis"""

    DIR2 = 1
    """x-axis"""

    DIR3 = 2
    """y-axis"""


class DataOrientation(IntEnum):
    """Supported data orientations. The default orientation is the first one."""

    ZXY = 0
    """ZXY orientation"""

    ZYX = 1
    """ZYX orientation"""

    XZY = 2
    """XZY orientation"""

    XYZ = 3
    """XYZ orientation"""

    YXZ = 4
    """YXZ orientation"""

    YZX = 5
    """YZX orientation"""

    ZTX = 6
    """ZTX orientation"""

    ZXT = 7
    """ZXT orientation"""


class DataImportFormat(IntEnum):
    """Supported import format to load data from disk.
    It is searched for an appropriate file with same name but different extension containing the according data.
    """

    SRM = 0
    """Spectral Radar Meta format containing no data but all additional parameters, such as spacing, size, etc."""


class RawDataImportFormat(IntEnum):
    """Supported raw data import formats to load data from disk."""

    SRR = 0
    """Spectral Radar raw data-format, specified additional information such as apodization scans, scan range, etc."""


class AnalysisTypes(IntEnum):
    """Specifies the data analysis types"""

    MIN = 0
    """Minimum of the values in the data."""

    MEAN = 1
    """Arithmetic mean of all values in the data."""

    MAX = 2
    """Maximum of the values in the data."""

    MAX_DEPTH = 3
    """The depth of the maximum of the values in the data."""

    # TODO: not supported in C API
    # MEDIAN = 4
    # """The median of the values in the data."""


class AScanAnalysis(IntEnum):
    """Specifies the A-scan analysis types"""

    NOISE_DB = 0
    """Noise of the A-scan in dB. This assumes that no signal is present in the A-scan. The noise is computed by 
    averaging all fourier channels larger than 50."""

    NOISE_ELECTRONS = 1
    """Noise of the A-scan in electrons. This assumes that no signal is present in the A-scan. The noise is computed 
    by averaging all fourier channels larger than 50."""

    PEAK_POS_PIXEL = 2
    """Peak position of the highest peak in pixels. The peak position is determined by computing a parable going 
    through the maximum value point and its surrounding pixels. The position of the maximum is used."""

    PEAK_POS_PHYS_UNIT = 3
    """Peak position of the highest peak in physical units. The peak position is determined by computing a parable 
    going through the maximum value point and its surrounding pixels. The position of the maximum is used. Physical 
    coordinates are computed by using the calibrated zSpacing property of the device. The concrete physical units of 
    the return value depends on the calibration."""

    PEAK_HEIGHT_DB = 4
    """Peak height of the highest peak in dB. The peak height is determined by computing a parable going through the 
    maximum value point and its surrounding pixels. The height of the resulting parable is returned."""

    PEAK_WIDTH_6DB = 5
    """Signal width at -6dB. This is the FWHM."""

    PEAK_WIDTH_20DB = 6
    """Signal width at -20dB."""

    PEAK_WIDTH_40DB = 7
    """Signal width at -40dB."""

    PEAK_PHASE = 8
    """Phase of the highest peak in radians. This value is only accepted by the function 
    :func:`~pyspectralradar.data.analysis.complexdataanalysis.ComplexDataAnalysis.analyze_ascan`."""

    PEAK_REAL_PART = 9
    """Real part of the highest peak, expressed in $e^-$. This value is only accepted by the function 
    :func:`~pyspectralradar.data.analysis.complexdataanalysis.ComplexDataAnalysis.analyze_ascan`."""

    PEAK_IMAG_PART = 10
    """Imaginary part of the highest peak, expressed in $e^-$. This value is only accepted by the function 
    :func:`~pyspectralradar.data.analysis.complexdataanalysis.ComplexDataAnalysis.analyze_ascan`."""


class ExportOptionMasks:
    """Available export mask options"""

    NONE = c_int(0x00000000)
    """For default or no specific export options."""

    DRAW_SCALEBAR = c_int(0x00000001)
    """Draw scale bar on exported image."""

    DRAW_MARKERS = c_int(0x00000002)
    """Draw markers on exported image."""

    USE_PHYSICAL_ASPECT_RATIO = c_int(0x00000004)
    """Honor physical aspect ratio when exporting data (width and height of each pixel will have the same physical
    dimensions)."""

    FLIP_X_AXIS = c_int(0x00000008)
    """Flip X-axis"""

    FLIP_Y_AXIS = c_int(0x00000010)
    """Flip Y-axis"""

    FLIP_Z_AXIS = c_int(0x00000020)
    """Flip Z-axis"""


class ColoredDataExportFormat(IntEnum):
    """Export formats for :class:`~pyspectralradar.data.coloreddata.ColoredData` objects"""

    SRM = 0
    """Spectral Radar Meta format, containing no data but all additional parameters, such as spacing, size, etc."""

    RAW = 1
    """RAW data format containing the data of the object as binary, 32-bit unsigned integer values, little endian. 
    The concrete format of the data depends on the :class:`~pyspectralradar.data.coloreddata.ColoredData` object. In 
    most cases it will be RGB32 or RGBA32."""

    BMP = 2
    """BMP - Bitmap image format."""

    PNG = 3
    """PNG image format."""

    JPG = 4
    """JPG/JPEG image format."""

    PDF = 5
    """PDF image format."""

    TIFF = 6
    """TIFF image format"""


class RawDataExportFormat(IntEnum):
    """Export formats for :class:`~pyspectralradar.data.rawdata.RawData` objects"""

    RAW = 0
    """Single precision floating point raw data."""

    SRR = 1
    """Spectral Radar raw data format, specified additional information such as apodization scans, scan range, etc."""


class ComplexDataExportFormat(IntEnum):
    """Export format for :class:`~pyspectralradar.data.complexdata.ComplexData` objects"""

    RAW = 0
    """RAW data format containing binary data."""


class ComplexDataFilterType2D(IntEnum):
    """Specifies the type of filter to be applied to complex data."""

    PHASE_CONTRAST = 0
    """A filter applied to complex data to get a phase contrast image."""
