from enum import IntEnum

from pyspectralradar.base.propertygetter import IntPropertyGetter
from pyspectralradar.spectralradar import sr


class PropertyInt(IntEnum):
    """Integer properties of the device that can be retrieved with the function #getDevicePropertyInt"""

    SPECTRUM_ELEMENTS = 0
    """The number of pixels provided by the spectrometer."""

    BYTES_PER_ELEMENT = 1
    """The number of bytes one element of the spectrum occupies."""

    MAX_LIVE_VOL_SCANS = 2
    """The maximum number of scans per dimension in the live volume rendering mode."""

    BIT_DEPTH = 3
    "Bit depth of the DAQ."

    NUM_CAMERAS = 4
    """Number of spectrometer cameras"""

    REV_NUMBER = 5
    """Revision number of the device"""

    NUM_ANALOG_INPUT_CHANNELS = 6
    """Number of analog input channels available (maybe zero)"""

    MIN_SPECTRA_PER_BUFFER = 7
    """Minimum number of spectra per buffer (only applies in continuous mode and when using 
    #measureSpectraContinuousEx)"""


class DevicePropertyInt(IntPropertyGetter):
    """Integer properties of the device that can be retrieved with the function #getDevicePropertyInt
    """

    def __init__(self, handle):
        super().__init__(handle, sr.getDevicePropertyInt)

    def get_spectrum_elements(self) -> int:
        """The number of pixels provided by the spectrometer."""
        return self._get(PropertyInt.SPECTRUM_ELEMENTS)

    def get_bytes_per_element(self) -> int:
        """The number of bytes one element of the spectrum occupies."""
        return self._get(PropertyInt.BYTES_PER_ELEMENT)

    def get_max_live_vol_scans(self) -> int:
        """The maximum number of scans per dimension in the live volume rendering mode."""
        return self._get(PropertyInt.MAX_LIVE_VOL_SCANS)

    def get_bit_depth(self) -> int:
        """Bit depth of the DAQ."""
        return self._get(PropertyInt.BIT_DEPTH)

    def get_num_cameras(self) -> int:
        """Number of spectrometer cameras"""
        return self._get(PropertyInt.NUM_CAMERAS)

    def get_rev_number(self) -> int:
        """Revision number of the device"""
        return self._get(PropertyInt.REV_NUMBER)

    def get_num_analog_input_channels(self) -> int:
        """Number of analog input channels available (maybe zero)"""
        return self._get(PropertyInt.NUM_ANALOG_INPUT_CHANNELS)

    def get_min_spectra_per_buffer(self) -> int:
        """Minimum number of spectra per buffer (only applies in continuous mode and when using
        #measureSpectraContinuousEx)"""
        return self._get(PropertyInt.MIN_SPECTRA_PER_BUFFER)
