from enum import IntEnum

from pyspectralradar.base.propertygetter import FlagPropertyGetter
from pyspectralradar.base.propertysetter import FlagPropertySetter
from pyspectralradar.spectralradar import sr


class PropertyFlag(IntEnum):
    """Enum Flags that determine the behaviour of the :class:`Polarization` processing routines."""

    APPLY_THRESHOLDING = 0
    """True if thresholding should be applied. In that case, the total intensity will be compared to the threshold.
       If lower, then the computed Stokes parameters will be set to zero."""

    Y_AXIS_IS_FRAME_AXIS = 1
    """When post-processing a multi-frame B-scan, this flag signals that the many frames are encoded along the
    Y-axis."""


class PolarizationPropertyFlag(FlagPropertyGetter, FlagPropertySetter):
    def __init__(self, handle):
        FlagPropertyGetter.__init__(self, handle, sr.getPolarizationFlag)
        FlagPropertySetter.__init__(self, handle, sr.setPolarizationFlag)

    def get_apply_thresholding(self) -> bool:
        """true if thresholding should be applied. In that case, the total intensity will be compared to the threshold.
        If lower, then the computed Stokes parameters will be set to zero."""
        return self._get(PropertyFlag.APPLY_THRESHOLDING)

    def set_apply_thresholding(self, value: bool):
        """true if thresholding should be applied. In that case, the total intensity will be compared to the threshold.
        If lower, then the computed Stokes parameters will be set to zero."""
        self._set(PropertyFlag.APPLY_THRESHOLDING, value)

    def get_y_axis_is_frame_axis(self) -> bool:
        """When post-processing a multi-frame B-scan, this flag signals that the many frames are encoded along the
        Y-axis."""
        return self._get(PropertyFlag.Y_AXIS_IS_FRAME_AXIS)

    def set_y_axis_is_frame_axis(self, value: bool):
        """When post-processing a multi-frame B-scan, this flag signals that the many frames are encoded along the
        Y-axis."""
        self._set(PropertyFlag.Y_AXIS_IS_FRAME_AXIS, value)
