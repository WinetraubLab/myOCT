from enum import IntEnum

from pyspectralradar.base.propertygetter import IntPropertyGetter
from pyspectralradar.base.propertysetter import IntPropertySetter
from pyspectralradar.spectralradar import sr


class MetadataInt(IntEnum):
    """Enum identifying file metadata fields of integer type"""

    PROCESS_STATE = 0
    """Contains the specific data format."""

    SIZE_X = 1
    """Number of pixels in x."""

    SIZE_Y = 2
    """Number of pixels in y."""

    SIZE_Z = 3
    """Number of pixels in z."""

    OVERSAMPLING = 4
    """Oversampling parameter."""

    AVG_SPECTRA = 5
    """Spectrum averaging"""

    AVG_ASCANS = 6
    """A-scan averaging"""

    AVG_BSCANS = 7
    """B-scan averaging"""

    DOPPLER_AVG_X = 8
    """Averaging for doppler processing in x-direction."""

    DOPPLER_AVG_Z = 9
    """Averaging for doppler processing in z-direction."""

    APO_WINDOW = 10
    """Type of window used for apodization."""

    DEVICE_BIT_DEPTH = 11
    """Bits per pixel of the camera."""

    SPECTROMETER_ELEMENTS = 12
    """Number of elements of the spectrometer."""

    EXPERIMENT_NO = 13
    """Serial number of the dataset"""

    DEV_BYTES_PER_PIXEL = 14
    """Bytes per pixel of the camera."""

    SPECKLE_AVG_FAST_AXIS = 15
    """Averaging parameter of the fast scan axis in speckle variance mode."""

    SPECKLE_AVG_SLOW_AXIS = 16
    """Averaging parameter of the slow scan axis in speckle variance mode."""

    PROC_FFT_TYPE = 17
    """FFT algorithm used"""

    NUM_CAMERAS = 18
    """Number of cameras, or sensors, stored in the file. In case of legacy files, this property takes the default
    value "1"."""

    SELECTED_CAMERA = 19
    """In devices with more than one camera, some modi need to know which camera is active, because they do not
    support work with multiple cameras. In case of legacy files, this property takes the default value "0"."""

    APO_TYPE = 20
    """This field sets/indicates the apodization type set when the data was acquired (see 
    :class:`ScanPattern.ApodizationType`)."""

    ACQ_ORDER = 21
    """This field sets/indicates the acquisition order set when the data was acquired (see 
    :class:`ScanPattern.AcquisitionOrder`)."""

    DOPU_FILTER = 22
    """DOPU filter specification. See #PolarizationDOPUFilterType."""

    DOPU_AVG_Z = 23
    """Number of pixels for DOPU averaging in the z-direction."""

    DOPU_AVG_X = 24
    """Number of pixels for DOPU averaging in the x-direction."""

    DOPU_AVG_Y = 25
    """Number of pixels for DOPU averaging in the y-direction."""

    POLAR_AVG_Z = 26
    """Number of pixels for averaging along the z-axis."""

    POLAR_AVG_X = 27
    """Number of pixels for averaging along the x-axis."""

    POLAR_AVG_Y = 28
    """Number of pixels for averaging along the y-axis."""

    SAMPLING_AMP = 29
    """Sampling amplification for VEGA systems"""

    SAMPLING_AMP_STEPS = 30
    """Sampling amplification steps for VEGA systems"""

    ANALOG_IN_CHANNELS = 31
    """Number of channels provided by analog input"""

    PROC_APODIZATION_DATA_TYPE = 32
    """Type of apodization vector used in processing, see :class:`pyspectralradar.types.ApodizationDataType`"""

    ACTUAL_SIZE_OF_APODIZATION = 33
    """Size of apodization used in acquisition. This may be different from the value stored in the Probe.ini if an 
    override was used."""


class OCTFilePropertyInt(IntPropertyGetter, IntPropertySetter):

    def __init__(self, handle):
        IntPropertyGetter.__init__(self, handle, sr.getFileMetadataInt)
        IntPropertySetter.__init__(self, handle, sr.setFileMetadataInt)

    def get_process_state(self) -> int:
        """Contains the specific data format."""
        return self._get(MetadataInt.PROCESS_STATE)

    def set_process_state(self, value: int):
        """Contains the specific data format."""
        self._set(MetadataInt.PROCESS_STATE, value)

    def get_size_x(self) -> int:
        """Number of pixels in x."""
        return self._get(MetadataInt.SIZE_X)

    def set_size_x(self, value: int):
        """Number of pixels in x."""
        self._set(MetadataInt.SIZE_X, value)

    def get_size_y(self) -> int:
        """Number of pixels in y."""
        return self._get(MetadataInt.SIZE_Y)

    def set_size_y(self, value: int):
        """Number of pixels in y."""
        self._set(MetadataInt.SIZE_Y, value)

    def get_size_z(self) -> int:
        """Number of pixels in z."""
        return self._get(MetadataInt.SIZE_Z)

    def set_size_z(self, value: int):
        """Number of pixels in z."""
        self._set(MetadataInt.SIZE_Z, value)

    def get_oversampling(self) -> int:
        """Oversampling parameter."""
        return self._get(MetadataInt.OVERSAMPLING)

    def set_oversampling(self, value: int):
        """Oversampling parameter."""
        self._set(MetadataInt.OVERSAMPLING, value)

    def get_avg_spectra(self) -> int:
        """Spectrum averaging"""
        return self._get(MetadataInt.AVG_SPECTRA)

    def set_avg_spectra(self, value: int):
        """Spectrum averaging"""
        self._set(MetadataInt.AVG_SPECTRA, value)

    def get_avg_ascans(self) -> int:
        """A-scan averaging"""
        return self._get(MetadataInt.AVG_ASCANS)

    def set_avg_ascans(self, value: int):
        """A-scan averaging"""
        self._set(MetadataInt.AVG_ASCANS, value)

    def get_avg_bscans(self) -> int:
        """B-scan averaging"""
        return self._get(MetadataInt.AVG_BSCANS)

    def set_avg_bscans(self, value: int):
        """B-scan averaging"""
        self._set(MetadataInt.AVG_BSCANS, value)

    def get_doppler_avg_x(self) -> int:
        """Averaging for doppler processing in x-direction."""
        return self._get(MetadataInt.DOPPLER_AVG_X)

    def set_doppler_avg_x(self, value: int):
        """Averaging for doppler processing in x-direction."""
        self._set(MetadataInt.DOPPLER_AVG_X, value)

    def get_doppler_avg_z(self) -> int:
        """Averaging for doppler processing in z-direction."""
        return self._get(MetadataInt.DOPPLER_AVG_Z)

    def set_doppler_avg_z(self, value: int):
        """Averaging for doppler processing in z-direction."""
        self._set(MetadataInt.DOPPLER_AVG_Z, value)

    def get_apo_window(self) -> int:
        """Type of window used for apodization."""
        return self._get(MetadataInt.APO_WINDOW)

    def set_apo_window(self, value: int):
        """Type of window used for apodization."""
        self._set(MetadataInt.APO_WINDOW, value)

    def get_device_bit_depth(self) -> int:
        """Bits per pixel of the camera."""
        return self._get(MetadataInt.DEVICE_BIT_DEPTH)

    def set_device_bit_depth(self, value: int):
        """Bits per pixel of the camera."""
        self._set(MetadataInt.DEVICE_BIT_DEPTH, value)

    def get_spectrometer_elements(self) -> int:
        """Number of elements of the spectrometer."""
        return self._get(MetadataInt.SPECTROMETER_ELEMENTS)

    def set_spectrometer_elements(self, value: int):
        """Number of elements of the spectrometer."""
        self._set(MetadataInt.SPECTROMETER_ELEMENTS, value)

    def get_experiment_no(self) -> int:
        """Serial number of the dataset"""
        return self._get(MetadataInt.EXPERIMENT_NO)

    def set_experiment_no(self, value: int):
        """Serial number of the dataset"""
        self._set(MetadataInt.EXPERIMENT_NO, value)

    def get_dev_bytes_per_pixel(self) -> int:
        """Bytes per pixel of the camera."""
        return self._get(MetadataInt.DEV_BYTES_PER_PIXEL)

    def set_dev_bytes_per_pixel(self, value: int):
        """Bytes per pixel of the camera."""
        self._set(MetadataInt.DEV_BYTES_PER_PIXEL, value)

    def get_speckle_avg_fast_axis(self) -> int:
        """Averaging parameter of the fast scan axis in speckle variance mode."""
        return self._get(MetadataInt.SPECKLE_AVG_FAST_AXIS)

    def set_speckle_avg_fast_axis(self, value: int):
        """Averaging parameter of the fast scan axis in speckle variance mode."""
        self._set(MetadataInt.SPECKLE_AVG_FAST_AXIS, value)

    def get_speckle_avg_slow_axis(self) -> int:
        """Averaging parameter of the slow scan axis in speckle variance mode."""
        return self._get(MetadataInt.SPECKLE_AVG_SLOW_AXIS)

    def set_speckle_avg_slow_axis(self, value: int):
        """Averaging parameter of the slow scan axis in speckle variance mode."""
        self._set(MetadataInt.SPECKLE_AVG_SLOW_AXIS, value)

    def get_proc_fft_type(self) -> int:
        """FFT algorithm used"""
        return self._get(MetadataInt.PROC_FFT_TYPE)

    def set_proc_fft_type(self, value: int):
        """FFT algorithm used"""
        self._set(MetadataInt.PROC_FFT_TYPE, value)

    def get_num_cameras(self) -> int:
        """Number of cameras, or sensors, stored in the file. In case of legacy files, this property takes the default
        value "1"."""
        return self._get(MetadataInt.NUM_CAMERAS)

    def set_num_cameras(self, value: int):
        """Number of cameras, or sensors, stored in the file. In case of legacy files, this property takes the default
        value "1"."""
        self._set(MetadataInt.NUM_CAMERAS, value)

    def get_selected_camera(self) -> int:
        """In devices with more than one camera, some modi need to know which camera is active, because they do not
        support work with multiple cameras. In case of legacy files, this property takes the default value "0"."""
        return self._get(MetadataInt.SELECTED_CAMERA)

    def set_selected_camera(self, value: int):
        """In devices with more than one camera, some modi need to know which camera is active, because they do not
        support work with multiple cameras. In case of legacy files, this property takes the default value "0"."""
        self._set(MetadataInt.SELECTED_CAMERA, value)

    def get_apo_type(self) -> int:
        """This field sets/indicates the apodization type set when the data was acquired (see
        :class:`ScanPattern.ApodizationType`)."""
        return self._get(MetadataInt.APO_TYPE)

    def set_apo_type(self, value: int):
        """This field sets/indicates the apodization type set when the data was acquired (see
        :class:`ScanPattern.ApodizationType`)."""
        self._set(MetadataInt.APO_TYPE, value)

    def get_acq_order(self) -> int:
        """"""
        return self._get(MetadataInt.ACQ_ORDER)

    def set_acq_order(self, value: int):
        """This field sets/indicates the acquisition order set when the data was acquired (see
        :class:`ScanPattern.AcquisitionOrder`)."""
        self._set(MetadataInt.ACQ_ORDER, value)

    def get_dopu_filter(self) -> int:
        """DOPU filter specification. See #PolarizationDOPUFilterType."""
        return self._get(MetadataInt.DOPU_FILTER)

    def set_dopu_filter(self, value: int):
        """DOPU filter specification. See #PolarizationDOPUFilterType."""
        self._set(MetadataInt.DOPU_FILTER, value)

    def get_dopu_avg_z(self) -> int:
        """Number of pixels for DOPU averaging in the z-direction."""
        return self._get(MetadataInt.DOPU_AVG_Z)

    def set_dopu_avg_z(self, value: int):
        """Number of pixels for DOPU averaging in the z-direction."""
        self._set(MetadataInt.DOPU_AVG_Z, value)

    def get_dopu_avg_x(self) -> int:
        """Number of pixels for DOPU averaging in the x-direction."""
        return self._get(MetadataInt.DOPU_AVG_X)

    def set_dopu_avg_x(self, value: int):
        """Number of pixels for DOPU averaging in the x-direction."""
        self._set(MetadataInt.DOPU_AVG_X, value)

    def get_dopu_avg_y(self) -> int:
        """Number of pixels for DOPU averaging in the y-direction."""
        return self._get(MetadataInt.DOPU_AVG_Y)

    def set_dopu_avg_y(self, value: int):
        """Number of pixels for DOPU averaging in the y-direction."""
        self._set(MetadataInt.DOPU_AVG_Y, value)

    def get_polar_avg_z(self) -> int:
        """Number of pixels for averaging along the z-axis."""
        return self._get(MetadataInt.POLAR_AVG_Z)

    def set_polar_avg_z(self, value: int):
        """Number of pixels for averaging along the z-axis."""
        self._set(MetadataInt.POLAR_AVG_Z, value)

    def get_polar_avg_x(self) -> int:
        """Number of pixels for averaging along the x-axis."""
        return self._get(MetadataInt.POLAR_AVG_X)

    def set_polar_avg_x(self, value: int):
        """Number of pixels for averaging along the x-axis."""
        self._set(MetadataInt.POLAR_AVG_X, value)

    def get_polar_avg_y(self) -> int:
        """Number of pixels for averaging along the y-axis."""
        return self._get(MetadataInt.POLAR_AVG_Y)

    def set_polar_avg_y(self, value: int):
        """Number of pixels for averaging along the y-axis."""
        self._set(MetadataInt.POLAR_AVG_Y, value)

    def get_sampling_amp(self) -> int:
        """Sampling amplification for VEGA systems"""
        return self._get(MetadataInt.SAMPLING_AMP)

    def set_sampling_amp(self, value: int):
        """Sampling amplification for VEGA systems"""
        self._set(MetadataInt.SAMPLING_AMP, value)

    def get_sampling_amp_steps(self) -> int:
        """Sampling amplification steps for VEGA systems"""
        return self._get(MetadataInt.SAMPLING_AMP_STEPS)

    def set_sampling_amp_steps(self, value: int):
        """Sampling amplification steps for VEGA systems"""
        self._set(MetadataInt.SAMPLING_AMP_STEPS, value)

    def get_analog_in_channels(self) -> int:
        """Number of channels provided by analog input"""
        return self._get(MetadataInt.ANALOG_IN_CHANNELS)

    def set_analog_in_channels(self, value: int):
        """Number of channels provided by analog input"""
        self._set(MetadataInt.ANALOG_IN_CHANNELS, value)

    def get_proc_apodization_data_type(self) -> int:
        """Type of apodization vector used in processing, see :class:`pyspectralradar.types.ApodizationDataType`"""
        return self._get(MetadataInt.PROC_APODIZATION_DATA_TYPE)

    def set_proc_apodization_data_type(self, value: int):
        """Type of apodization vector used in processing, see :class:`pyspectralradar.types.ApodizationDataType`"""
        return self._set(MetadataInt.PROC_APODIZATION_DATA_TYPE, value)

    def get_actual_size_of_apodization(self) -> int:
        """Size of apodization used in acquisition. This may be different from the value stored in the Probe.ini if
        an override was used."""
        return self._get(MetadataInt.ACTUAL_SIZE_OF_APODIZATION)

    def set_actual_size_of_apodization(self, value: int):
        """Size of apodization used in acquisition. This may be different from the value stored in the Probe.ini if
        an override was used."""
        return self._set(MetadataInt.ACTUAL_SIZE_OF_APODIZATION, value)
