from pyspectralradar.base.handlemanager import HasHandle
from pyspectralradar.spectralradar import c_handle


class Submodule(HasHandle):
    @property
    def handle(self) -> c_handle:
        return self._handle

    def __init__(self, handle: c_handle):
        self._handle = handle
