from __future__ import annotations

from enum import IntEnum


class ScanRangeShape(IntEnum):
    """The shape of the maximal valid scan range."""

    RECT = 0
    """The shape of the valid scan range for the specified objective"""

    ROUND = 1
    """The maximum range in mm of the y-direction for the specified objective"""
