from ctypes import POINTER, c_int
from typing import Tuple

from pyspectralradar.base import Submodule
from pyspectralradar.data import ColoredData
from pyspectralradar.octdevice.properties.devicepropertyexposer import DeviceProperties
from pyspectralradar.spectralradar import c_handle, get_error, sr


class Camera(Submodule):
    def __init__(self, handle, props: DeviceProperties):
        super().__init__(handle)

        self._props = props
        self.is_available = self._props.flag.get_camera_avail
        self.show_scan_pattern = self._props.flag.get_camera_show_scan_pattern
        self.get_bit_depth = self._props.int.get_bit_depth

    def get_max_image_size(self) -> Tuple[int, int]:
        """Returns the maximum possible camera image size for the current device.

        Returns:
            A tuple (``size_x``, ``size_y``) containing ``size_x`` as the maximum pixel size along the x-axis and
            ``size_y`` as the maximum possible pixel size along the y-axis.
        """
        size_x = c_int()
        size_y = c_int()
        sr.getMaxCameraImageSize.argtypes = [c_handle, POINTER(c_int), POINTER(c_int)]
        sr.getMaxCameraImageSize(self.handle, size_x, size_y)
        get_error()
        return size_x.value, size_y.value

    def get_image(self, buffer: ColoredData | None = None) -> ColoredData:
        """Gets a camera image.

        :Warning: Requires an initialized :obj:`~pyspectralradar.probe.probe.Probe`.

        Args:
            :buffer: Optional pre-allocated object to hold the video camera data

        Returns:
            An object containing the image data.
        """
        assert self.is_available(), "Camera not available; is the probe initialized?"

        if buffer is None:
            buffer = ColoredData()
        sr.getCameraImage.argtypes = [c_handle, c_handle]
        sr.getCameraImage(self.handle, buffer.handle)
        get_error()
        return buffer
