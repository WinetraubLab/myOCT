from pyspectralradar.base.submodule import Submodule
from pyspectralradar.scanpattern.properties.scanpatternpropertyfloat import ScanPatternPropertyFloat
from pyspectralradar.scanpattern.properties.scanpatternpropertyint import ScanPatternPropertyInt


class ScanPatternProperties(Submodule):
    def __init__(self, handle):
        super().__init__(handle)
        self._int = ScanPatternPropertyInt(self.handle)
        self._float = ScanPatternPropertyFloat(self.handle)

        # Property int
        self.get_size_total = self._int.get_size_total
        self.get_cycles = self._int.get_cycles
        self.get_size_cycles = self._int.get_size_cycles
        self.get_size_preparation_cycles = self._int.get_size_preparation_cycles
        self.get_size_imaging_cycles = self._int.get_size_imaging_cycles
        self.get_size_preparation_scan = self._int.get_size_preparation_scan

        # Property float
        self.get_range_x = self._float.get_range_x
        self.get_range_y = self._float.get_range_y
        self.get_center_x = self._float.get_center_x
        self.get_center_y = self._float.get_center_y
        self.get_angle = self._float.get_angle
        self.get_mean_length = self._float.get_mean_length
