import numpy as np

from pyspectralradar.data.base import AbstractProcessedData
from pyspectralradar.spectralradar import sr


# TODO: not part of main, only trunk/experimental
class PrecisionData(AbstractProcessedData):
    @property
    def _pointer_func(self):
        return sr.getPrecisionDataPtr

    @property
    def _create_handle_func(self):
        return sr.createPrecisionData

    @property
    def _del_func(self):
        return sr.clearPrecisionData

    @property
    def _export_func(self):
        return sr.exportPrecisionData

    @property
    def _set_data_range_func(self):
        raise NotImplementedError

    @property
    def _c_crop_func(self):
        raise NotImplementedError

    @property
    def _orientation_get(self):
        raise NotImplementedError

    @property
    def _orientation_set(self):
        raise NotImplementedError

    @property
    def _get_slice_at_pos_func(self):
        raise NotImplementedError

    @property
    def _separate_func(self):
        raise NotImplementedError

    @property
    def _flip_func(self):
        raise NotImplementedError

    @property
    def _copy_func(self):
        raise NotImplementedError

    @property
    def _c_append_func(self):
        raise NotImplementedError

    @property
    def _reserve_func(self):
        raise NotImplementedError

    @property
    def _set_data_content_func(self):
        raise NotImplementedError

    @property
    def _copy_content_func(self):
        raise NotImplementedError

    @property
    def _np_data_type(self) -> np.dtype:
        raise NotImplementedError

    @property
    def _int_get(self):
        raise NotImplementedError

    @property
    def _float_get(self):
        raise NotImplementedError

    @property
    def _resize_func(self):
        raise NotImplementedError

    @property
    def _import_func(self):
        raise NotImplementedError

    @property
    def _get_slice_at_index_func(self):
        raise NotImplementedError
