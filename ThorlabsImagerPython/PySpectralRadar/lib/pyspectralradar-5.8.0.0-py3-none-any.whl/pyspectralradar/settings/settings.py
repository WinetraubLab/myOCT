from ctypes import POINTER, byref, c_char_p, c_double, c_int

import numpy as np

from pyspectralradar.base import HandleManager
from pyspectralradar.spectralradar import c_handle, get_error, sr


class SettingsFile(HandleManager):
    """Class containing Service functions for direct access to INI files and settings."""

    def __init__(self, path: str):
        """Loads a settings file (usually *.ini); and prepares its properties to be read.

        Args:
            :path: Path to the settings file location.
        """
        super().__init__(None)
        sr.initSettingsFile.restype = c_handle
        sr.initSettingsFile.argtypes = [c_handle]
        handle = c_handle(sr.initSettingsFile(c_char_p(bytes(path, encoding="ascii"))))
        get_error()
        self._handle = int(handle.value)

    @property
    def _del_func(self):
        """Closes the specified ini file and stores the set entries"""
        return sr.closeSettingsFile

    def read_int(self, node: str, default_value: int) -> int:
        """Gets an integer number from the specified ini file

        Args:
            :node: Value-identifier within settings file
            :default_value: Value set if no entry in settings file found.

        Returns:
            Integer value read from settings file
        """
        sr.getSettingsEntryInt.restype = c_int
        sr.getSettingsEntryInt.argtypes = [c_handle, c_char_p, c_int]
        res = sr.getSettingsEntryInt(self.handle, c_char_p(bytes(node, encoding="ascii")), default_value)
        get_error()
        return res

    def read_float(self, node: str, default_value: float) -> float:
        """Gets a floating point number from the specified ini file

        Args:
            :node: Value-identifier within settings file
            :default_value: Value set if no entry in settings file found.

        Returns:
            Floating point value read from settings file
        """
        sr.getSettingsEntryFloat.restype = c_double
        sr.getSettingsEntryFloat.argtypes = [c_handle, c_char_p, c_double]
        res = sr.getSettingsEntryFloat(self.handle, c_char_p(bytes(node, encoding="ascii")), default_value)
        get_error()
        return res

    def read_array(self, node: str, default_values: np.ndarray[float]):
        """Gets an array of floating point values from the specified ini file

        Args:
            :node: Value-identifier within settings file

        Returns:
            :class:`numpy` array of floating point values read from settings file
        """
        default_values_ptr = default_values.ctypes.data_as(POINTER(c_double))
        values_ptr = np.empty(len(default_values), dtype=np.double)
        size = c_int()

        sr.getSettingsEntryFloatArray.argtypes = [c_handle,
                                                  c_char_p,
                                                  POINTER(c_double),
                                                  np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                                  POINTER(c_int)]

        sr.getSettingsEntryFloatArray(self.handle,
                                      node.encode('utf-8'),
                                      default_values_ptr,
                                      values_ptr,
                                      byref(size))

        values = np.ctypeslib.as_array(values_ptr)[:size.value]

        get_error()
        return values

    def read_string(self, node: str, default_value: str) -> str:
        """Gets a string from the specified ini file

        The resulting const char* ptr will be valid until the settings file is closed.

        Args:
            :node: Value-identifier within settings file
            :default_value: Value set if no entry in settings file found.

        Returns:
            String read from settings file
        """
        sr.getSettingsEntryString.restype = c_char_p
        sr.getSettingsEntryString.argtypes = [c_handle, c_char_p, c_char_p]
        res = sr.getSettingsEntryString(self.handle,
                                        c_char_p(bytes(node, encoding="ascii")),
                                        c_char_p(bytes(default_value, encoding="ascii")))
        get_error()
        return res.decode('UTF-8')

    def write_int(self, node: str, value: int):
        """Sets an integer entry in the specified ini file

        Args:
            :node: Value-identifier within settings file
            :value: Integer value set as entry to settings file
        """
        sr.setSettingsEntryInt.argtypes = [c_handle, c_char_p, c_int]
        sr.setSettingsEntryInt(self.handle, c_char_p(bytes(node, encoding="ascii")), value)
        get_error()

    def write_float(self, node: str, value: float):
        """Sets a floating point entry in the specified ini file

        Args:
            :node: Value-identifier within settings file
            :value: Floating point value set as entry to settings file
        """
        sr.setSettingsEntryFloat.argtypes = [c_handle, c_char_p, c_double]
        sr.setSettingsEntryFloat(self.handle, c_char_p(bytes(node, encoding="ascii")), value)
        get_error()

    def write_string(self, node: str, value: str):
        """Sets a string in the specified ini file

        Args:
            :node: Value-identifier within settings file
            :value: String set as entry to settings file
        """
        sr.setSettingsEntryString.argtypes = [c_handle, c_char_p, c_char_p]
        sr.setSettingsEntryString(self.handle, c_char_p(bytes(node, encoding="ascii")),
                                  c_char_p(bytes(value, encoding="ascii")))
        get_error()

    def save(self):
        """Saves the changes to the specified Settings file."""
        sr.saveSettings.argtypes = [c_handle]
        sr.saveSettings(self.handle)
        get_error()
