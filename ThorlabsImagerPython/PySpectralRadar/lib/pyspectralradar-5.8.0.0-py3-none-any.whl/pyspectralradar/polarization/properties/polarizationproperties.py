from pyspectralradar.base.submodule import Submodule
from pyspectralradar.polarization.properties.polarizationpropertyflag import PolarizationPropertyFlag
from pyspectralradar.polarization.properties.polarizationpropertyfloat import PolarizationPropertyFloat
from pyspectralradar.polarization.properties.polarizationpropertyint import PolarizationPropertyInt


class PolarizationProperties(Submodule):
    def __init__(self, handle):
        super().__init__(handle)
        self._int = PolarizationPropertyInt(self.handle)
        self._float = PolarizationPropertyFloat(self.handle)
        self._flag = PolarizationPropertyFlag(self.handle)

        # Property int
        self.get_dopu_z = self._int.get_dopu_z
        self.set_dopu_z = self._int.set_dopu_z
        self.get_dopu_x = self._int.get_dopu_x
        self.set_dopu_x = self._int.set_dopu_x
        self.get_dopu_y = self._int.get_dopu_y
        self.set_dopu_y = self._int.set_dopu_y
        self.get_dopu_filter_type = self._int.get_dopu_filter_type
        self.set_dopu_filter_type = self._int.set_dopu_filter_type
        self.get_bscan_averaging = self._int.get_bscan_averaging
        self.set_bscan_averaging = self._int.set_bscan_averaging
        self.get_averaging_z = self._int.get_averaging_z
        self.set_averaging_z = self._int.set_averaging_z
        self.get_averaging_x = self._int.get_averaging_x
        self.set_averaging_x = self._int.set_averaging_x
        self.get_averaging_y = self._int.get_averaging_y
        self.set_averaging_y = self._int.set_averaging_y
        self.get_ascan_averaging = self._int.get_ascan_averaging
        self.set_ascan_averaging = self._int.set_ascan_averaging
        self.get_bscan_averaged = self._int.get_bscan_averaged
        self.set_bscan_averaged = self._int.set_bscan_averaged

        # Property float
        self.get_intensity_threshold_db = self._float.get_intensity_threshold_db
        self.set_intensity_threshold_db = self._float.set_intensity_threshold_db
        self.get_pmd_correction_angle_rad = self._float.get_pmd_correction_angle_rad
        self.set_pmd_correction_angle_rad = self._float.set_pmd_correction_angle_rad
        self.get_central_wavelength_nm = self._float.get_central_wavelength_nm
        self.set_central_wavelength_nm = self._float.set_central_wavelength_nm
        self.get_optical_axis_offset_rad = self._float.get_optical_axis_offset_rad
        self.set_optical_axis_offset_rad = self._float.set_optical_axis_offset_rad

        # Property flag
        self.get_apply_thresholding = self._flag.get_apply_thresholding
        self.set_apply_thresholding = self._flag.set_apply_thresholding
        self.get_y_axis_is_frame_axis = self._flag.get_y_axis_is_frame_axis
        self.set_y_axis_is_frame_axis = self._flag.set_y_axis_is_frame_axis
