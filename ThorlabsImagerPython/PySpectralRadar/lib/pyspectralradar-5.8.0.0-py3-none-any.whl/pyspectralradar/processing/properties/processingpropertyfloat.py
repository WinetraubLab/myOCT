from enum import IntEnum

from pyspectralradar.base.propertygetter import FloatPropertyGetter
from pyspectralradar.base.propertysetter import FloatPropertySetter
from pyspectralradar.spectralradar import sr


class PropertyFloat(IntEnum):
    """Enum Parameters that set the behaviour of the processing algorithms."""

    APO_DAMPING = 0
    """Sets how much influence newly acquired apodizations have compared to older ones."""

    MIN_ELECTRONS = 1
    """Determines the minimum signal intensity on the edge channels of the spectra. Warning: {Setting this value may 
    seriously reduce performance of the system.}"""

    FFT_OVERSAMPLING = 2
    """FFT oversampling to applied for non-equispaced FFT processing algorithms. In general, higher values indicate 
    better imaging quality but slower processing. If unsure, 2 is a good value in most cases."""

    MAX_SENSOR_VALUE = 3
    """Largest (absolute) value that the processing will expect for raw samples."""


class ProcessingPropertyFloat(FloatPropertyGetter, FloatPropertySetter):
    def __init__(self, handle):
        FloatPropertyGetter.__init__(self, handle, sr.getProcessingParameterFloat)
        FloatPropertySetter.__init__(self, handle, sr.setProcessingParameterFloat)

    def get_apo_damping(self) -> float:
        """Sets how much influence newly acquired apodizations have compared to older ones."""
        return self._get(PropertyFloat.APO_DAMPING)

    def set_apo_damping(self, value: float):
        """Sets how much influence newly acquired apodizations have compared to older ones."""
        self._set(PropertyFloat.APO_DAMPING, value)

    def get_min_electrons(self) -> float:
        """Determines the minimum signal intensity on the edge channels of the spectra. Warning: {Setting this value
        may seriously reduce performance of the system.}"""
        return self._get(PropertyFloat.MIN_ELECTRONS)

    def set_min_electrons(self, value: float):
        """Determines the minimum signal intensity on the edge channels of the spectra. Warning: {Setting this value
        may seriously reduce performance of the system.}"""
        self._set(PropertyFloat.MIN_ELECTRONS, value)

    def get_fft_oversampling(self) -> float:
        """FFT oversampling to applied for non-equispaced FFT processing algorithms. In general, higher values
        indicate better imaging quality but slower processing. If unsure, 2 is a good value in most cases."""
        return self._get(PropertyFloat.FFT_OVERSAMPLING)

    def set_fft_oversampling(self, value: float):
        """FFT oversampling to applied for non-equispaced FFT processing algorithms. In general, higher values
        indicate better imaging quality but slower processing. If unsure, 2 is a good value in most cases."""
        self._set(PropertyFloat.FFT_OVERSAMPLING, value)

    def get_max_sensor_value(self) -> float:
        """Largest (absolute) value that the processing will expect for raw samples."""
        return self._get(PropertyFloat.MAX_SENSOR_VALUE)

    def set_max_sensor_value(self, value: float):
        """Largest (absolute) value that the processing will expect for raw samples."""
        self._set(PropertyFloat.MAX_SENSOR_VALUE, value)
