from __future__ import annotations

from typing import TYPE_CHECKING

from pyspectralradar.base import HandleManagerWithDefaultConstructor
from pyspectralradar.data import ComplexData, RealData
from pyspectralradar.polarization.properties import PolarizationProperties
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import PolarizationOutput

if TYPE_CHECKING:
    from pyspectralradar.octfile import OCTFile


class Polarization(HandleManagerWithDefaultConstructor):
    """A class for processing of polarization sensitive data"""

    @property
    def _create_handle_func(self):
        return sr.createPolarizationProcessing

    def __init__(self, handle: c_handle = None):
        super().__init__(handle)
        self.properties = PolarizationProperties(self.handle)

    @classmethod
    def from_file(cls, oct_file: OCTFile) -> Polarization:
        """Loads metadata to the specified file.

        These metadata specify the operational arguments needed by the
        :class:`~pyspectralradar.polarization.polarization.Polarization` processing routines to redo the
        polarization-analysis starting from two :class:`~pyspectralradar.data.complexdata.ComplexData` objects
        delivered by the corresponding :class:`~pyspectralradar.polarization.polarization.Polarization` objects,
        exactly as they were done before the file was written.

        Returns:
            A polarization object that holds the processing routines for polarization analysis.

        """
        sr.createPolarizationProcessingForFile.restype = c_handle
        sr.createPolarizationProcessingForFile.argtype = [c_handle]
        handle = sr.createPolarizationProcessingForFile(oct_file.handle)
        get_error()
        res = Polarization(handle)
        get_error()
        return res

    @property
    def _del_func(self):
        return sr.clearPolarizationProcessing

    def set_data_output(self, output_data: RealData, pol_output_type: PolarizationOutput):
        """Sets the location of the resulting polarization output (Stokes parameter ``I``/``Q``/``U``/``V``,
        ``DOPU``, ``Retardation`` and ``Optic`` axis).

        Check :class:`~pyspectralradar.types.polarizationtypes.PolarizationOutput` for more details.

        Args:
            :output_data: Data object that will hold the computed data upon return
            :pol_output_type: Type identifier, selects the data type that will be computed
        """
        assert isinstance(pol_output_type, PolarizationOutput)
        function = None

        if pol_output_type == PolarizationOutput.INTENSITY:
            function = sr.setPolarizationOutputI
        elif pol_output_type == PolarizationOutput.STOKES_Q:
            function = sr.setPolarizationOutputQ
        elif pol_output_type == PolarizationOutput.STOKES_U:
            function = sr.setPolarizationOutputU
        elif pol_output_type == PolarizationOutput.STOKES_V:
            function = sr.setPolarizationOutputV
        elif pol_output_type == PolarizationOutput.DOPU:
            function = sr.setPolarizationOutputDOPU
        elif pol_output_type == PolarizationOutput.RETARDATION:
            function = sr.setPolarizationOutputRetardation
        elif pol_output_type == PolarizationOutput.OPTIC_AXIS:
            function = sr.setPolarizationOutputOpticAxis

        function.argtypes = [c_handle, c_handle]
        function(self.handle, output_data.handle)
        get_error()

    def execute(self, data_cam_0: ComplexData, data_cam_1: ComplexData):
        """Executes the polarization processing of the input data and returns, if previously setup, intensity,
        retardation, and phase differences.

        If the sample does not alter the polarization state of the incident light (e.g. it is a mirror),
        the interference pattern will be captured by the first sensor (Camera-0), except for residual signals due to
        the optical components being not ideal. If the setup had no QWPs, the opposite would happen: the interference
        pattern would've been captured by the second sensor (Camera-1). The setup has the QWPs at precise angles for
        the system to be equally sensitive to both components.

        Args:
            :data_cam_0: Complex data obtained with :func:`~pyspectralradar.processing.processing.Processing.execute`
                starting from spectral data of the sensor "0"
            :data_cam_1: Complex data obtained with :func:`~pyspectralradar.processing.processing.Processing.execute`
                starting from spectral data of the sensor "1"
        """
        sr.executePolarizationProcessing.argtypes = [c_handle, c_handle, c_handle]
        sr.executePolarizationProcessing(self.handle, data_cam_1.handle, data_cam_0.handle)
        get_error()

    def set_metadata_to_file(self, oct_file: OCTFile):
        """Saves metadata to the specified file.

        These metadata specify the operational arguments needed by the polarization processing routines to redo the
        polarization-analysis starting from two :class:`~pyspectralradar.data.complexdata.ComplexData`
        object handles delivered by the :obj:`~pyspectralradar.polarization.polarization.Polarization` proc_0 and
        proc_1.

        Args:
            :oct_file: OCT file that the metadata will be stored to.
        """
        sr.saveFileMetadataPolarization.argtypes = [c_handle, c_handle]
        sr.saveFileMetadataPolarization(oct_file.handle, self.handle)
        get_error()
