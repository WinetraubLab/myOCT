from enum import IntEnum

from pyspectralradar.base.propertygetter import IntPropertyGetter
from pyspectralradar.spectralradar import sr


class RawDataPropertyInt(IntEnum):
    """Integer properties of rawdata (#DataHandle) that can be retrieved with the function #getRawDataPropertyInt."""

    SIZE1 = 0
    """Size of the first dimension. For OCT data this is usually the longitudinal axis (z)"""

    SIZE2 = 1
    """Size of the first dimension. For OCT data this is usually a transversal axis (x)"""

    SIZE3 = 2
    """Size of the first dimension. For OCT data this is usually a transversal axis (y)"""

    ELEMENTS = 3
    """The number of elements in the data object."""

    SIZE_BYTES = 4
    """The size of the data object in bytes."""

    BYTES_PER_ELEMENT = 5
    """The number of bytes of a single element."""

    LOST_FRAMES = 6
    """The number of lost frames during data acquisition. Lost frames are the usual consequence of a scanning 
    dynamics going too fast in comparison to the acquisition settings (or capabilities) of the camera. To remedy the 
    situation, consider increasing the number of measurements along the x-axis (size 2), or increasing the A-scan 
    averaging."""


class RawDataPropertyIntGetter(IntPropertyGetter):
    """Integer properties of data (#RawDataHandle) that can be retrieved with the function #getRawDataPropertyInt."""

    def __init__(self, handle):
        super().__init__(handle, sr.getRawDataPropertyInt)

    def get_size1(self) -> int:
        """Size of the first dimension. For OCT data this is usually the longitudinal axis (z)"""
        return self._get(RawDataPropertyInt.SIZE1)

    def get_size2(self) -> int:
        """Size of the second dimension. For OCT data this is usually a transversal axis (x)"""
        return self._get(RawDataPropertyInt.SIZE2)

    def get_size3(self) -> int:
        """Size of the third dimension. For OCT data this is usually a transversal axis (y)"""
        return self._get(RawDataPropertyInt.SIZE3)

    def get_number_of_elements(self) -> int:
        """The number of elements in the data object."""
        return self._get(RawDataPropertyInt.ELEMENTS)

    def get_size_bytes(self) -> int:
        """The size of the data object in bytes."""
        return self._get(RawDataPropertyInt.SIZE_BYTES)

    def get_bytes_per_element(self) -> int:
        """The number of bytes of a single element."""
        return self._get(RawDataPropertyInt.BYTES_PER_ELEMENT)

    def get_lost_frames(self) -> int:
        """The number of lost frames during data acquisition. Lost frames are the usual consequence of a scanning
        dynamics going too fast in comparison to the acquisition settings (or capabilities) of the camera. To remedy
        the situation, consider increasing the number of measurements along the x-axis (size 2), or increasing the
        A-scan averaging."""
        return self._get(RawDataPropertyInt.LOST_FRAMES)
