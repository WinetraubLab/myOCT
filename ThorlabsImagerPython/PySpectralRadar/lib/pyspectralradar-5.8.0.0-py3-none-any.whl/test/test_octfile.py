import time
import unittest
from os import remove
from os.path import exists

from pyspectralradar import Doppler, OCTFile, OCTSystem, Polarization, RawData, RealData, SpeckleVariance, \
    LogLevel, set_log_level


def check_and_remove(path):
    if exists(path):
        remove(path)
        time.sleep(0.05)


class TestOctFileCreation(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def test_oct_file_create(self):
        dut = OCTFile()
        self.assertIsInstance(dut, OCTFile)
        self.assertEqual(len(dut), 0)
        del dut

    @unittest.skip  # currently an SR C Api issue; calling save does not allow to re-open the original source file again
    def test_oct_file_load_and_save(self):
        test_file_path = ('\\\\lbknetapp01\\Public\\Doc\\Software\\Unittests\\PySpectralRadarTests'
                          '\\Unittest_0001_Mode2D.oct')
        dut = OCTFile(test_file_path)
        self.assertIsInstance(dut, OCTFile)
        self.assertEqual(len(dut), 8)

        output_file_path = 'C:\\tmp\\Test_OCTFile_0001_Mode2D.oct'
        # TODO: currently an SR C Api issue; calling save does not allow to re-open the original source file again
        # dut.save(output_file_path)
        self.assertTrue(exists(output_file_path))
        del dut

        if exists(output_file_path):
            dut2 = OCTFile(output_file_path)
            self.assertIsInstance(dut2, OCTFile)
            self.assertEqual(len(dut2), 8)
            data = RealData()
            dut2.add_data(data, 'realdata')
            self.assertEqual(len(dut2), 9)
            # dut2.save_changes()

            del dut2
            remove(output_file_path)


class OctFilePropertyTestCase(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def setUp(self):
        file_path = '\\\\lbknetapp01\\Public\\Doc\\Software\\Unittests\\PySpectralRadarTests\\Unittest_0001_Mode2D.oct'
        print('\nnew test')
        print('\ncreate oct file\n')
        self.file = OCTFile(file_path)
        print('\noct file created\n')

    def tearDown(self):
        print('\nclose oct file\n')
        del self.file
        print('\noct file closed\n')


class TestOctFilePropertyString(OctFilePropertyTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self.file.properties

    def test_oct_file_property_string(self):
        self.dut.set_device_series('TestDummy')
        self.assertEqual(self.dut.get_device_series(), 'TestDummy')

        self.dut.set_device_name('DUMDUM')
        self.assertEqual(self.dut.get_device_name(), 'DUMDUM')

        self.assertEqual(self.dut.get_serial(), '0123456789')
        self.dut.set_serial('9876543210')
        self.assertEqual(self.dut.get_serial(), '9876543210')

        self.dut.set_comment('Comment for test')
        self.assertEqual(self.dut.get_comment(), 'Comment for test')

        self.dut.set_custom_info('Custom info for test')
        self.assertEqual(self.dut.get_custom_info(), 'Custom info for test')

        self.assertEqual(self.dut.get_acquisition_mode(), 'Mode2D')
        self.dut.set_acquisition_mode('Mode7x')
        self.assertEqual(self.dut.get_acquisition_mode(), 'Mode7x')

        self.assertEqual(self.dut.get_study(), 'Test')
        self.dut.set_study('Test1')
        self.assertEqual(self.dut.get_study(), 'Test1')

        self.assertEqual(self.dut.get_dispersion_preset(), '')
        self.dut.set_dispersion_preset('None')
        self.assertEqual(self.dut.get_dispersion_preset(), 'None')

        self.assertEqual(self.dut.get_probe_name(), 'Probe.ini')
        self.dut.set_probe_name('Probe_to_test.ini')
        self.assertEqual(self.dut.get_probe_name(), 'Probe_to_test.ini')

        self.dut.set_freeform_scan_pattern_interpolation('None')
        self.assertEqual(self.dut.get_freeform_scan_pattern_interpolation(), 'None')

        self.dut.set_hardware_config('Dummy_V333')
        self.assertEqual(self.dut.get_hardware_config(), 'Dummy_V333')

        self.dut.set_orig_version('5.x.x')
        self.assertEqual(self.dut.get_orig_version(), '5.x.x')

        self.dut.set_last_mod_version('5.x.x')
        self.assertEqual(self.dut.get_last_mod_version(), '5.x.x')

        self.dut.set_analog_input_active_channels('VAL')
        self.assertEqual(self.dut.get_analog_input_active_channels(), 'VAL')

        self.assertEqual(self.dut.get_analog_input_channel_names(), 'Channel 1,Channel 2,Channel 3,Channel 4')
        self.dut.set_analog_input_channel_names('VAL')
        self.assertEqual(self.dut.get_analog_input_channel_names(), 'VAL')


class TestOctFilePropertyFloat(OctFilePropertyTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self.file.properties

    def test_oct_file_property_float(self):
        self.assertEqual(self.dut.get_refractive_index(), 1.0)
        self.dut.set_refractive_index(2.0)
        self.assertEqual(self.dut.get_refractive_index(), 2.0)

        self.dut.set_range_x(5.3)
        self.assertEqual(self.dut.get_range_x(), 5.3)

        self.dut.set_range_y(1.4)
        self.assertEqual(self.dut.get_range_y(), 1.4)

        self.dut.set_range_z(7.3)
        self.assertEqual(self.dut.get_range_z(), 7.3)

        self.dut.set_center_x(-2.5)
        self.assertEqual(self.dut.get_center_x(), -2.5)

        self.dut.set_center_y(0.3)
        self.assertEqual(self.dut.get_center_y(), 0.3)

        self.dut.set_angle(43)
        self.assertEqual(self.dut.get_angle(), 43)

        self.dut.set_bin_electron_scaling(1.1111)
        self.assertEqual(self.dut.get_bin_electron_scaling(), 1.1111)

        self.assertEqual(self.dut.get_central_wavelength_nm(), 930)
        self.dut.set_central_wavelength_nm(999)
        self.assertEqual(self.dut.get_central_wavelength_nm(), 999)

        self.dut.set_source_bandwidth_nm(50.8)
        self.assertEqual(self.dut.get_source_bandwidth_nm(), 50.8)

        self.dut.set_min_electrons(101)
        self.assertEqual(self.dut.get_min_electrons(), 101)

        self.dut.set_quadratic_dispersion_correction_factor(-400)
        self.assertEqual(self.dut.get_quadratic_dispersion_correction_factor(), -400)

        self.dut.set_speckle_variance_threshold(4.1)
        self.assertEqual(self.dut.get_speckle_variance_threshold(), 4.1)

        self.dut.set_scan_time_sec(700.456)
        self.assertEqual(self.dut.get_scan_time_sec(), 700.456)

        self.dut.set_reference_intensity(80.1)
        self.assertEqual(self.dut.get_reference_intensity(), 80.1)

        self.dut.set_scan_pause_sec(1.2345)
        self.assertEqual(self.dut.get_scan_pause_sec(), 1.2345)

        self.dut.set_zoom(1.55)
        self.assertEqual(self.dut.get_zoom(), 1.55)

        self.dut.set_min_point_distance(0.00456)
        self.assertEqual(self.dut.get_min_point_distance(), 0.00456)

        self.dut.set_max_point_distance(0.007)
        self.assertEqual(self.dut.get_max_point_distance(), 0.007)

        self.dut.set_fft_oversampling(2.2)
        self.assertEqual(self.dut.get_fft_oversampling(), 2.2)

        self.dut.set_full_well_capacity(300000)
        self.assertEqual(self.dut.get_full_well_capacity(), 300000)

        self.dut.set_saturation(50.6)
        self.assertEqual(self.dut.get_saturation(), 50.6)

        self.dut.set_camera_line_rate_hz(11111)
        self.assertEqual(self.dut.get_camera_line_rate_hz(), 11111)

        self.dut.set_pmd_correction_angle_rad(4)
        self.assertEqual(self.dut.get_pmd_correction_angle_rad(), 4)

        self.dut.set_optic_axis_offset_rad(0.5)
        self.assertEqual(self.dut.get_optic_axis_offset_rad(), 0.5)

        self.dut.set_reference_length_mm(14)
        self.assertEqual(self.dut.get_reference_length_mm(), 14)

        self.dut.set_reference_intensity_control_value(1.6)
        self.assertEqual(self.dut.get_reference_intensity_control_value(), 1.6)

        self.dut.set_pol_adjustment_quarter_wave(0.74)
        self.assertEqual(self.dut.get_pol_adjustment_quarter_wave(), 0.74)

        self.dut.set_pol_adjustment_half_wave(0.55)
        self.assertEqual(self.dut.get_pol_adjustment_half_wave(), 0.55)

        # TODO: Still under development
        # self.dut.set_rel_interference_amp(1.8)
        # self.assertEqual(self.dut.get_rel_interference_amp(), 1.8)


class TestOctFilePropertyInt(OctFilePropertyTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self.file.properties

    def test_oct_file_property_int(self):
        self.assertEqual(self.dut.get_process_state(), 2)
        self.dut.set_process_state(1)
        self.assertEqual(self.dut.get_process_state(), 1)

        self.assertEqual(self.dut.get_size_x(), 444)
        self.dut.set_size_x(1)
        self.assertEqual(self.dut.get_size_x(), 1)

        self.assertEqual(self.dut.get_size_y(), 1)
        self.dut.set_size_y(5)
        self.assertEqual(self.dut.get_size_y(), 5)

        self.assertEqual(self.dut.get_size_z(), 1024)
        self.dut.set_size_z(1)
        self.assertEqual(self.dut.get_size_z(), 1)

        self.assertEqual(self.dut.get_oversampling(), 0)
        self.dut.set_oversampling(1)
        self.assertEqual(self.dut.get_oversampling(), 1)

        self.assertEqual(self.dut.get_avg_spectra(), 1)
        self.dut.set_avg_spectra(4)
        self.assertEqual(self.dut.get_avg_spectra(), 4)

        self.assertEqual(self.dut.get_avg_ascans(), 1)
        self.dut.set_avg_ascans(3)
        self.assertEqual(self.dut.get_avg_ascans(), 3)

        self.assertEqual(self.dut.get_avg_bscans(), 1)
        self.dut.set_avg_bscans(2)
        self.assertEqual(self.dut.get_avg_bscans(), 2)

        self.assertEqual(self.dut.get_doppler_avg_x(), 2)
        self.dut.set_doppler_avg_x(1)
        self.assertEqual(self.dut.get_doppler_avg_x(), 1)

        self.assertEqual(self.dut.get_doppler_avg_z(), 1)
        self.dut.set_doppler_avg_z(2)
        self.assertEqual(self.dut.get_doppler_avg_z(), 2)

        self.assertEqual(self.dut.get_apo_window(), 0)
        self.dut.set_apo_window(1)
        self.assertEqual(self.dut.get_apo_window(), 1)

        self.assertEqual(self.dut.get_device_bit_depth(), 16)
        self.dut.set_device_bit_depth(32)
        self.assertEqual(self.dut.get_device_bit_depth(), 32)

        self.assertEqual(self.dut.get_spectrometer_elements(), 2048)
        self.dut.set_spectrometer_elements(1111)
        self.assertEqual(self.dut.get_spectrometer_elements(), 1111)

        self.assertEqual(self.dut.get_experiment_no(), 1)
        self.dut.set_experiment_no(18)
        self.assertEqual(self.dut.get_experiment_no(), 18)

        self.assertEqual(self.dut.get_dev_bytes_per_pixel(), 2)
        self.dut.set_dev_bytes_per_pixel(4)
        self.assertEqual(self.dut.get_dev_bytes_per_pixel(), 4)

        self.assertEqual(self.dut.get_speckle_avg_fast_axis(), 1)
        self.dut.set_speckle_avg_fast_axis(5)
        self.assertEqual(self.dut.get_speckle_avg_fast_axis(), 5)

        self.assertEqual(self.dut.get_speckle_avg_slow_axis(), 1)
        self.dut.set_speckle_avg_slow_axis(4)
        self.assertEqual(self.dut.get_speckle_avg_slow_axis(), 4)

        self.assertEqual(self.dut.get_proc_fft_type(), 0)
        self.dut.set_proc_fft_type(1)
        self.assertEqual(self.dut.get_proc_fft_type(), 1)

        self.assertEqual(self.dut.get_num_cameras(), 1)
        self.dut.set_num_cameras(7)
        self.assertEqual(self.dut.get_num_cameras(), 7)

        self.assertEqual(self.dut.get_selected_camera(), 0)
        self.dut.set_selected_camera(4)
        self.assertEqual(self.dut.get_selected_camera(), 4)

        self.assertEqual(self.dut.get_apo_type(), 1)
        self.dut.set_apo_type(2)
        self.assertEqual(self.dut.get_apo_type(), 2)

        self.assertEqual(self.dut.get_acq_order(), 0)
        self.dut.set_acq_order(1)
        self.assertEqual(self.dut.get_acq_order(), 1)

        self.assertEqual(self.dut.get_dopu_filter(), 1)
        self.dut.set_dopu_filter(2)
        self.assertEqual(self.dut.get_dopu_filter(), 2)

        self.assertEqual(self.dut.get_dopu_avg_z(), 1)
        self.dut.set_dopu_avg_z(3)
        self.assertEqual(self.dut.get_dopu_avg_z(), 3)

        self.assertEqual(self.dut.get_dopu_avg_x(), 1)
        self.dut.set_dopu_avg_x(3)
        self.assertEqual(self.dut.get_dopu_avg_x(), 3)

        self.assertEqual(self.dut.get_dopu_avg_y(), 1)
        self.dut.set_dopu_avg_y(6)
        self.assertEqual(self.dut.get_dopu_avg_y(), 6)

        self.assertEqual(self.dut.get_polar_avg_z(), 1)
        self.dut.set_polar_avg_z(3)
        self.assertEqual(self.dut.get_polar_avg_z(), 3)

        self.assertEqual(self.dut.get_polar_avg_x(), 1)
        self.dut.set_polar_avg_x(2)
        self.assertEqual(self.dut.get_polar_avg_x(), 2)

        self.assertEqual(self.dut.get_polar_avg_y(), 1)
        self.dut.set_polar_avg_y(6)
        self.assertEqual(self.dut.get_polar_avg_y(), 6)

        self.assertEqual(self.dut.get_sampling_amp(), 0)
        self.dut.set_sampling_amp(1)
        self.assertEqual(self.dut.get_sampling_amp(), 1)

        self.assertEqual(self.dut.get_sampling_amp_steps(), 1)
        self.dut.set_sampling_amp_steps(56)
        self.assertEqual(self.dut.get_sampling_amp_steps(), 56)

        self.assertEqual(self.dut.get_analog_in_channels(), 4)
        self.dut.set_analog_in_channels(23)
        self.assertEqual(self.dut.get_analog_in_channels(), 23)

        self.assertEqual(self.dut.get_proc_apodization_data_type(), 0)
        self.dut.set_proc_apodization_data_type(4)
        self.assertEqual(self.dut.get_proc_apodization_data_type(), 4)

        self.assertEqual(self.dut.get_actual_size_of_apodization(), -1)
        self.dut.set_actual_size_of_apodization(1234)
        self.assertEqual(self.dut.get_actual_size_of_apodization(), 1234)


class TestOctFilePropertyFlag(OctFilePropertyTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self.file.properties

    def test_oct_file_property_flag(self):
        self.assertTrue(self.dut.get_offset_applied())
        self.dut.set_offset_applied(False)
        self.assertFalse(self.dut.get_offset_applied())

        self.assertTrue(self.dut.get_dc_subtracted())
        self.dut.set_dc_subtracted(False)
        self.assertFalse(self.dut.get_dc_subtracted())

        self.assertTrue(self.dut.get_apo_applied())
        self.dut.set_apo_applied(False)
        self.assertFalse(self.dut.get_apo_applied())

        self.assertTrue(self.dut.get_de_chirp_applied())
        self.dut.set_de_chirp_applied(False)
        self.assertFalse(self.dut.get_de_chirp_applied())

        self.assertFalse(self.dut.get_under_sampling_filter())
        self.dut.set_under_sampling_filter(True)
        self.assertTrue(self.dut.get_under_sampling_filter())

        self.dut.set_dispersion_comp(False)
        self.assertFalse(self.dut.get_dispersion_comp())

        self.dut.set_quadratic_dispersion_comp(True)
        self.assertTrue(self.dut.get_quadratic_dispersion_comp())

        self.dut.set_image_field_corr(True)
        self.assertTrue(self.dut.get_image_field_corr())

        self.assertTrue(self.dut.get_scan_line_shown())
        self.dut.set_scan_line_shown(False)
        self.assertFalse(self.dut.get_scan_line_shown())

        self.assertFalse(self.dut.get_auto_corr_comp())
        self.dut.set_auto_corr_comp(True)
        self.assertTrue(self.dut.get_auto_corr_comp())

        self.assertFalse(self.dut.get_bscan_cross_corr())
        self.dut.set_bscan_cross_corr(True)
        self.assertTrue(self.dut.get_bscan_cross_corr())

        self.assertTrue(self.dut.get_dc_subtracted_adv())
        self.dut.set_dc_subtracted_adv(False)
        self.assertFalse(self.dut.get_dc_subtracted_adv())

        self.assertFalse(self.dut.get_only_windowing())
        self.dut.set_only_windowing(True)
        self.assertTrue(self.dut.get_only_windowing())

        self.assertFalse(self.dut.get_raw_data_signed())
        self.dut.set_raw_data_signed(True)
        self.assertTrue(self.dut.get_raw_data_signed())

        self.assertFalse(self.dut.get_freeform_scan_pattern_active())
        self.dut.set_freeform_scan_pattern_active(True)
        self.assertTrue(self.dut.get_freeform_scan_pattern_active())

        self.assertFalse(self.dut.get_freeform_scan_pattern_closed())
        self.dut.set_freeform_scan_pattern_closed(True)
        self.assertTrue(self.dut.get_freeform_scan_pattern_closed())

        self.assertFalse(self.dut.get_is_swept_source())
        self.dut.set_is_swept_source(True)
        self.assertTrue(self.dut.get_is_swept_source())

        self.assertFalse(self.dut.get_doppler_oversampling())
        self.dut.set_doppler_oversampling(True)
        self.assertTrue(self.dut.get_doppler_oversampling())


class TestNewOctFile(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def setUp(self):
        self.dut = OCTFile()

    def tearDown(self):
        del self.dut

    def test_oct_file_metadata(self):
        oct_system = OCTSystem()
        dev = oct_system.dev
        proc = oct_system.processing_factory.from_device()
        probe = oct_system.probe_factory.create_default()
        pattern = probe.scan_pattern.create_bscan_pattern(10.0, 100)

        self.assertFalse('Chirp.data' in self.dut)
        self.assertFalse('OffsetErrors.data' in self.dut)

        self.dut.set_metadata(dev, proc, probe, pattern)
        self.dut.save_calibration(proc)

        self.assertTrue('Chirp.data' in self.dut)
        self.assertTrue('OffsetErrors.data' in self.dut)

        del pattern
        del probe
        del proc
        del dev
        del oct_system

    def test_oct_file_doppler(self):
        doppler = Doppler()
        doppler.properties.set_averaging_1(7)
        self.dut.set_doppler_metadata(doppler)
        self.assertEqual(self.dut.properties.get_doppler_avg_z(), 7)

        del doppler

    def test_oct_file_speckle(self):
        spv = SpeckleVariance()
        spv.properties.set_averaging3(8)
        self.dut.set_speckle_metadata(spv)
        self.assertEqual(self.dut.properties.get_speckle_avg_slow_axis(), 8)

        del spv

    def test_oct_file_polarization(self):
        pol = Polarization()
        pol.properties.set_dopu_x(11)
        self.dut.set_polarization_metadata(pol)
        self.assertEqual(self.dut.properties.get_dopu_avg_x(), 11)

        del pol

    def test_oct_file_copy_metadata(self):
        file_path = '\\\\lbknetapp01\\Public\\Doc\\Software\\Unittests\\PySpectralRadarTests\\Unittest_0001_Mode2D.oct'
        donor_file = OCTFile(file_path)
        self.assertEqual(self.dut.properties.get_range_x(), 0)
        self.dut.copy_metadata_from(donor_file)
        self.assertEqual(self.dut.properties.get_range_x(), 10.0)
        del donor_file

    def test_oct_file_spectral_data(self):
        for i in range(10):
            self.assertEqual(self.dut.get_spectral_data_name(i), f'data\\Spectral{i}.data')


class TestOctFileDataObjects(unittest.TestCase):

    def setUp(self):
        file_path = '\\\\lbknetapp01\\Public\\Doc\\Software\\Unittests\\PySpectralRadarTests\\Unittest_0001_Mode2D.oct'
        self.dut = OCTFile(file_path)

    def tearDown(self):
        del self.dut

    def test_oct_file_object_data_types(self):
        for index in range(len(self.dut)):
            print(index, self.dut.get_data_type(index), self.dut.get_data_name(index))

        self.assertEqual([self.dut.get_data_type(0), self.dut.get_data_name(0)],
                         [('COLORED', 1), 'data\\VideoImage.data'])
        self.assertEqual([self.dut.get_data_type(1), self.dut.get_data_name(1)],
                         [('COLORED', 1), 'data\\PreviewImage.data'])
        self.assertEqual([self.dut.get_data_type(2), self.dut.get_data_name(2)], [('REAL', 0), 'data\\Intensity.data'])
        self.assertEqual([self.dut.get_data_type(3), self.dut.get_data_name(3)], [('RAW', 3), 'data\\Spectral0.data'])
        self.assertEqual([self.dut.get_data_type(4), self.dut.get_data_name(4)],
                         [('REAL', 0), 'data\\ApodizationSpectrum.data'])
        self.assertEqual([self.dut.get_data_type(5), self.dut.get_data_name(5)], [('REAL', 0), 'data\\Chirp.data'])
        self.assertEqual([self.dut.get_data_type(6), self.dut.get_data_name(6)],
                         [('REAL', 0), 'data\\OffsetErrors.data'])
        self.assertEqual([self.dut.get_data_type(7), self.dut.get_data_name(7)], [('TEXT', 5), 'data\\Probe.ini'])

    def test_oct_file_find_data(self):
        self.assertEqual(self.dut.find('data\\ApodizationSpectrum.data'), 4)
        self.assertEqual(self.dut.find('data\\OffsetErrors.data'), 6)

    def test_oct_file_get_data_object(self):
        self.assertIsInstance(self.dut.get_data_object(2), RealData)
        self.assertIsInstance(self.dut.get_data_object(3), RawData)

    def test_oct_file_data_sizes(self):
        self.assertEqual(self.dut.get_data_size(2), (1024, 444, 1))
        self.assertEqual(self.dut.get_data_size(3), (2048, 444 + 25, 1))

    def test_oct_file_data_ranges(self):
        self.assertAlmostEqual(self.dut.get_data_ranges(2)[0], 5.12, 5)
        self.assertAlmostEqual(self.dut.get_data_ranges(2)[1], 10.0)
        self.assertAlmostEqual(self.dut.get_data_ranges(2)[2], 0.0)
        self.assertAlmostEqual(self.dut.get_data_ranges(3)[0], 5.12, 5)
        self.assertAlmostEqual(self.dut.get_data_ranges(3)[1], 10.0)
        self.assertAlmostEqual(self.dut.get_data_ranges(3)[2], 1.0)

    def test_oct_file_contains(self):
        self.assertTrue('data\\Spectral0.data' in self.dut)
        self.assertTrue(self.dut.contains_raw())

    def test_oct_file_timestamp(self):
        self.assertEqual(self.dut.get_timestamp(), 1701350989)
        self.dut.set_timestamp(152)
        self.assertEqual(self.dut.get_timestamp(), 152)

    def test_oct_file_presets(self):
        pre_presets = self.dut.get_presets()
        self.assertEqual(pre_presets, [('Speed/Sensitivity', 'High Speed (100 kHz)')])
        self.dut.add_presets('Speed/Sensitivity', 'High Speed (10 kHz)')
        presets = self.dut.get_presets()
        self.assertEqual(presets, [('Speed/Sensitivity', 'High Speed (100 kHz)'), ('Speed/Sensitivity', 'High Speed ('
                                                                                                        '10 kHz)')])

    def test_oct_file_markers(self):
        extracted_real_data = self.dut.get_data_object(2)
        self.dut.copy_markers_from_data(extracted_real_data)
        real_data = RealData()
        self.dut.copy_markers_to_data(real_data)
        self.dut.clear_markers()

        del extracted_real_data
        del real_data


if __name__ == '__main__':
    unittest.main()
