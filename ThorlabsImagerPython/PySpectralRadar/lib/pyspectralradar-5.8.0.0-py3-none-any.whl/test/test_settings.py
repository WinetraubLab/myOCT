import os
import shutil
import time
import unittest

import numpy as np

from pyspectralradar import SettingsFile


def copy_ini_file(source_path, output_filename):
    if not os.path.exists(source_path):
        print(f"Error: Source file '{source_path}' does not exist.")
        return

    source_directory = os.path.dirname(source_path)
    destination_path = os.path.join(source_directory, output_filename)

    try:
        shutil.copy(source_path, destination_path)
    except Exception as e:
        print(f"Error: Unable to copy file - {e}")


class SettingsFileTestCase(unittest.TestCase):
    _directory = "\\\\lbknetapp01\\Public\\Doc\\Software\\Unittests\\PySpectralRadarTests\\"
    _source_file = 'Probe.ini'
    _tmp_file = 'tmp_probe.ini'
    _dut = None

    def setUp(self):
        copy_ini_file(os.path.join(self._directory, self._source_file), self._tmp_file)
        if os.path.exists(os.path.join(self._directory, self._tmp_file)):
            self._dut = SettingsFile(os.path.join(self._directory, self._tmp_file))

    def tearDown(self):
        del self._dut
        if os.path.exists(os.path.join(self._directory, self._tmp_file)):
            os.remove(os.path.join(self._directory, self._tmp_file))
            """https://stackoverflow.com/questions/18942437/python-is-there-a-way-to-wait-os-unlink-or-os-remove-to
            -finish"""
            time.sleep(0.05)


class TestSettingsFile(SettingsFileTestCase):
    def test_settings_file__int(self):
        self.assertEqual(self._dut.read_int('CameraScalingX', 1), 50)
        self.assertEqual(self._dut.read_int('CameraScalingXNotAvailable', 1), 1)
        self._dut.write_int('CameraScalingXNotAvailable', 5)
        self.assertEqual(self._dut.read_int('CameraScalingXNotAvailable', 1), 5)

    def test_settings_file_float(self):
        self.assertEqual(self._dut.read_float('FactorX', 1.5), 1.0)
        self.assertEqual(self._dut.read_float('FactorXNotAvailable', 1.5), 1.5)
        self._dut.write_float('FactorXNotAvailable', 5.5)
        self.assertEqual(self._dut.read_float('FactorXNotAvailable', 1.1), 5.5)

    def test_settings_file_string(self):
        self.assertEqual(self._dut.read_string('Description', 'Standard_String_Test'),
                         'Standard_OCTG')
        self.assertEqual(self._dut.read_string('DescriptionNotAvailable', 'Standard_String_Test'),
                         'Standard_String_Test')
        self._dut.write_string('DescriptionNotAvailable', 'Standard_String_Test')
        self.assertEqual(self._dut.read_string('DescriptionNotAvailable', 'Standard_OCTG'),
                         'Standard_String_Test')

    def test_settings_file_array(self):
        default_arr = np.array([1, 2, 3, 4, 5, 7])
        read_arr = self._dut.read_array('Dispersion_Probe', default_arr)
        print(read_arr)
        print(type(read_arr))
        print(len(read_arr))

        self.assertTrue(np.allclose(self._dut.read_array('Dispersion_Probe', default_arr), [10.0, 2.0, -1.0]))

    def test_settings_file_change_and_save(self):
        self._dut.write_int('CameraScalingXNotAvailable', 5)
        self._dut.write_float('FactorXNotAvailable', 5.5)
        self._dut.write_string('DescriptionNotAvailable', 'Standard_String_Test')
        self._dut.save()


if __name__ == '__main__':
    unittest.main()
