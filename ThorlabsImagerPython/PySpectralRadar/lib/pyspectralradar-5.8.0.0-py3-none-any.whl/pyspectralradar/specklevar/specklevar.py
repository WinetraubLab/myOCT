from __future__ import annotations

from ctypes import *
from typing import TYPE_CHECKING, Tuple

from pyspectralradar.base import HandleManagerWithDefaultConstructor
from pyspectralradar.data import ComplexData, RealData
from pyspectralradar.specklevar.properties import SpeckleVarianceProperties
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import SpeckleVarianceType

if TYPE_CHECKING:
    from pyspectralradar.octfile import OCTFile


class SpeckleVariance(HandleManagerWithDefaultConstructor):
    """Class containing Service functions for Speckle Variance Contrast Processing."""

    @property
    def _create_handle_func(self):
        return sr.initSpeckleVariance

    def __init__(self, handle: c_handle = None):
        super().__init__(handle)
        self.properties = SpeckleVarianceProperties(self.handle)

    @classmethod
    def from_file(cls, oct_file: 'OCTFile') -> SpeckleVariance:
        """Initializes the speckle variance contrast processing instance, based on the parameters stored in an OCT file.

        Args:
            :oct_file: An object containing the handle to the OCT-File used to create the speckle variance processing
                      routines from.

        Returns:
            Speckle variance processing instance, based on the parameters provided by the given OCT file
        """
        sr.initSpeckleVarianceForFile.restype = c_handle
        sr.initSpeckleVarianceForFile.argtype = [c_handle]
        handle = sr.initSpeckleVarianceForFile(oct_file.handle)
        get_error()
        res = SpeckleVariance(handle)
        get_error()
        return res

    @property
    def _del_func(self):
        """Closes the speckle variance contrast processing instance and frees all used resources."""
        return sr.closeSpeckleVariance

    def compute(self, complex_data_in: ComplexData) -> Tuple[RealData, RealData]:
        """Computes the speckle variance contrast

        Args:
            :complex_data_in: Object holding the processed complex data.

        Returns:
            A tuple containing the mean and variance data (``mean_out``, ``var_out``)
        """
        assert isinstance(complex_data_in, ComplexData)
        mean_out = RealData()
        var_out = RealData()
        sr.computeSpeckleVariance.argtypes = [c_handle, c_handle, c_handle, c_handle]
        sr.computeSpeckleVariance(self.handle, complex_data_in.handle, mean_out.handle, var_out.handle)
        get_error()
        return mean_out, var_out

    def get_type(self) -> SpeckleVarianceType:
        """Returns the speckle variance type the instance is using.

        Returns:
            Enum identifying the speckle variance processing type.
        """
        sr.getSpeckleVarianceType.argtypes = [c_handle]
        sr.getSpeckleVarianceType.restype = c_int
        res = SpeckleVarianceType(sr.getSpeckleVarianceType(self.handle))
        get_error()
        return SpeckleVarianceType(res)

    def set_type(self, sv_type: SpeckleVarianceType):
        """Sets the speckle variance type to the given value.

        Args:
            :sv_type: Enum identifying the speckle variance processing type.
        """
        sr.setSpeckleVarianceType.argtypes = [c_handle, c_int]
        sr.setSpeckleVarianceType(self.handle, sv_type)
        get_error()
