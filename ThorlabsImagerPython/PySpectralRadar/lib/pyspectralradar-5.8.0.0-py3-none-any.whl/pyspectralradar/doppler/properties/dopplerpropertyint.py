from enum import IntEnum

from pyspectralradar.base.propertygetter import IntPropertyGetter
from pyspectralradar.base.propertysetter import IntPropertySetter
from pyspectralradar.spectralradar import sr


class PropertyInt(IntEnum):
    """Enum Values that determine the behaviour of the Doppler processing routines."""

    AVERAGING_1 = 0
    """Averaging along the first axis, usually the longitudinal axis (z)"""

    AVERAGING_2 = 1
    """Averaging along the first axis, usually the first transversal axis (x)"""

    STRIDE_1 = 2
    """Step size for calculating the doppler processing in the longitudinal axis (z).
       Stride needs to be smaller or equal to Doppler_Averaging_1 and larger or equal to 1."""

    STRIDE_2 = 3
    """Step size for calculating the doppler processing in the transversal axis (x).
       Stride needs to be smaller or equal to Doppler_Averaging_2 and larger or equal to 1."""


class DopplerPropertyInt(IntPropertyGetter, IntPropertySetter):
    def __init__(self, handle1, handle2):
        IntPropertyGetter.__init__(self, handle1, sr.getDopplerPropertyInt)
        IntPropertySetter.__init__(self, handle2, sr.setDopplerPropertyInt)

    def get_averaging_1(self) -> int:
        """Averaging along the first axis, usually the longitudinal axis (z)"""
        return self._get(PropertyInt.AVERAGING_1)

    def set_averaging_1(self, value: int):
        """Averaging along the first axis, usually the longitudinal axis (z)"""
        self._set(PropertyInt.AVERAGING_1, value)

    def get_averaging_2(self) -> int:
        """Averaging along the first axis, usually the first transversal axis (x)"""
        return self._get(PropertyInt.AVERAGING_2)

    def set_averaging_2(self, value: int):
        """Averaging along the first axis, usually the first transversal axis (x)"""
        self._set(PropertyInt.AVERAGING_2, value)

    def get_stride_1(self) -> int:
        """Step size for calculating the doppler processing in the longitudinal axis (z).
       Stride needs to be smaller or equal to Doppler_Averaging_1 and larger or equal to 1."""
        return self._get(PropertyInt.STRIDE_1)

    def set_stride_1(self, value: int):
        """Step size for calculating the doppler processing in the longitudinal axis (z).
       Stride needs to be smaller or equal to Doppler_Averaging_1 and larger or equal to 1."""
        self._set(PropertyInt.STRIDE_1, value)

    def get_stride_2(self) -> int:
        """Step size for calculating the doppler processing in the transversal axis (x).
       Stride needs to be smaller or equal to Doppler_Averaging_2 and larger or equal to 1."""
        return self._get(PropertyInt.STRIDE_2)

    def set_stride_2(self, value: int):
        """Step size for calculating the doppler processing in the transversal axis (x).
       Stride needs to be smaller or equal to Doppler_Averaging_2 and larger or equal to 1."""
        self._set(PropertyInt.STRIDE_2, value)
