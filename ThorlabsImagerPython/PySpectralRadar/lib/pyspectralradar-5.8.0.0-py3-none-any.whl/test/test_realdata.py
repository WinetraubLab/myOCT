import unittest

import matplotlib.pyplot as plt
import numpy as np

import pyspectralradar.types as pt
from pyspectralradar import OCTSystem, RealData, LogLevel, set_log_level

ENABLE_PLOTS = False


class DataTest(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def test_from_scan_points(self):
        xi = yi = np.linspace(0, 1, 3)
        x, y = np.meshgrid(xi, yi)
        p_ints = np.ones_like(x, dtype=int)
        x = np.repeat(x, 4, axis=0)
        y = np.repeat(y, 4, axis=0)
        p_ints = np.concatenate((p_ints * 0, p_ints * 1, p_ints * 2, p_ints * 4))
        data = RealData.from_scan_points(x.flatten(), y.flatten(), p_ints.flatten())
        self.assertIsInstance(data, RealData)


class RealDataTestCase(unittest.TestCase):
    dut = RealData()

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

        sys = OCTSystem()
        dev = sys.dev
        proc = sys.processing_factory.from_device()
        probe = sys.probe_factory.create_default()
        pattern = probe.scan_pattern.create_bscan_pattern(10.0, 1024)

        dev.acquisition.start(pattern, pt.AcqType.ASYNC_FINITE)
        raw = dev.acquisition.get_raw_data()

        proc.set_data_output(cls.dut)
        proc.execute(raw)
        dev.acquisition.stop()

        del raw
        del pattern
        del proc
        del probe
        del dev
        del sys

    @classmethod
    def tearDownClass(cls):
        del cls.dut

    def test_data_append(self):
        dut = self.dut.clone()
        dut.append(self.dut, pt.DataDirection.DIR3)
        self.assertEqual(dut.size, (1024 * 1024 * 1) * 2)
        self.assertTrue(dut.shape == (1024, 1024, 2))
        dut.set_range(5.12, 10.0, 2.0)
        self.assertTrue(dut.range == (5.12, 10.0, 2.0))

    def test_data_pointer(self):
        pointer = self.dut.pointer()
        print(pointer)

    def test_data_reserve(self):
        print(self.dut.shape)
        self.dut.reserve(1024, 200, 200)
        print(self.dut.shape)

    def test_data_clone(self):
        dut_clone = self.dut.clone()
        self.assertIsInstance(dut_clone, RealData)
        self.assertEqual(dut_clone.size, 1024 * 1024 * 1)
        self.assertTrue(dut_clone.shape == (1024, 1024, 1))
        self.assertTrue(dut_clone.range == (5.12, 10.0, 1.0))

    def test_data_range(self):
        print(self.dut.range)
        self.assertTrue(self.dut.range == (5.12, 10.0, 1.0))
        self.dut.set_range(2 * 5.12, 2 * 10.0, 2 * 1.0)
        self.assertTrue(self.dut.range == (2 * 5.12, 2 * 10.0, 2 * 1.0))

    def test_data_spacing(self):
        range_1, range_2, range_3 = self.dut.range
        size_1, size_2, size_3 = self.dut.shape
        self.assertAlmostEqual(self.dut.spacing[0], range_1 / size_1)
        self.assertAlmostEqual(self.dut.spacing[1], range_2 / size_2)
        self.assertAlmostEqual(self.dut.spacing[2], range_3 / size_3)

    def test_data_copy(self):
        dut_copy = self.dut.copy()
        self.assertIsInstance(dut_copy, RealData)
        self.assertEqual(dut_copy.size, 1024 * 1024 * 1)
        self.assertTrue(dut_copy.shape == (1024, 1024, 1))
        self.assertTrue(dut_copy.range == (5.12, 10.0, 1.0))

    def test_data_compute_projection(self):
        min_value = self.dut.compute_projection(pt.DataDirection.DIR1, pt.AnalysisTypes.MIN)
        mean = self.dut.compute_projection(pt.DataDirection.DIR1, pt.AnalysisTypes.MEAN)
        max_value = self.dut.compute_projection(pt.DataDirection.DIR1, pt.AnalysisTypes.MIN)
        max_depth = self.dut.compute_projection(pt.DataDirection.DIR1, pt.AnalysisTypes.MAX_DEPTH)
        # median = self.dut.compute_projection(pt.DataDirection.DIR1, pt.AnalysisTypes.MEDIAN)

        print(min_value.to_numpy())
        print(mean.to_numpy())
        print(max_value.to_numpy())
        print(max_depth.to_numpy())

    def test_data_transpose(self):
        dut = self.dut.clone()

        if ENABLE_PLOTS:
            plt.figure()
            plt.title('test_data_transpose - dut')
            plt.imshow(dut.to_numpy()[:, :, 0])

        dut_t = dut.transpose()

        if ENABLE_PLOTS:
            plt.figure()
            plt.title('test_data_transpose - dut_t')
            plt.imshow(dut_t.to_numpy()[:, :, 0])

        dut.transpose(True)

        if ENABLE_PLOTS:
            plt.figure()
            plt.title('test_data_transpose - dut.transpose')
            plt.imshow(dut.to_numpy()[:, :, 0])

            plt.show()
        else:
            plt.close()

        self.assertTrue(np.all(dut_t.to_numpy() == dut.to_numpy()))

    def test_data_transpose_and_scale(self):
        dut = self.dut.clone()
        max_ = 70.5
        min_ = 10.5
        dut_t = dut.transpose_and_scale(min_, max_)

        print(dut.shape)
        print(dut_t.shape)

        diff = 1.0 / (max_ - min_)
        test_arr = np.asarray([(element - min_) * diff for element in dut.to_numpy()])

        print(dut_t.to_numpy().shape)
        print(test_arr.shape)

        if ENABLE_PLOTS:
            plt.figure()
            plt.title('test_data_transpose_and_scale')
            plt.subplot(1, 4, 1)
            plt.imshow(dut.to_numpy()[:, :, 0])
            plt.subplot(1, 4, 2)
            plt.imshow(dut.to_numpy()[:, :, 0].T)
            plt.subplot(1, 4, 3)
            plt.imshow(dut_t.to_numpy()[:, :, 0])
            plt.subplot(1, 4, 4)
            plt.imshow(test_arr[:, :, 0].T)

            plt.show()
        else:
            plt.close()

        self.assertTrue(np.allclose(dut_t.to_numpy()[:, :, 0], test_arr[:, :, 0].T))

    def test_data_normalize(self):
        dut = self.dut.clone()
        max_ = 70.5
        min_ = 10.5

        diff = max_ - min_
        test_arr = np.asarray([(element - min_) / diff for element in dut.to_numpy()])

        dut.normalize(min_, max_)

        self.assertTrue(np.allclose(dut.to_numpy(), test_arr))

    @unittest.skip  # somehow takes ages when running all tests
    def test_data_cross_correlated_projection(self):
        dut = self.dut.clone()
        appendix = self.dut.clone()
        dut.append(appendix, pt.DataDirection.DIR3)
        dut.append(appendix, pt.DataDirection.DIR3)
        dut.cross_correlated_projection()

        self.assertIsInstance(dut, RealData)
        self.assertTrue(dut.shape, (1024, 1, 1))

    def test_data_extract_line(self):
        dut = self.dut.clone()
        line = dut.extract_line(1.0, 2.0, 3.2, 7.5)
        print(line.shape)

    def test_data_extract_local_max(self):
        dut = self.dut.clone()
        number_of_maxima, positions, heights = dut.extract_local_maximum(5, 0.3)
        print(number_of_maxima, positions, heights)

    def test_data_extract_ascan(self):
        dut = self.dut.clone()
        ascan = dut.extract_ascan(512, 0)

        self.assertTrue(dut.shape == (1024, 1024, 1))
        self.assertIsInstance(ascan, RealData)
        self.assertTrue(ascan.shape == (1024, 1, 1))

        if ENABLE_PLOTS:
            plt.figure()
            plt.title('test_data_extract_ascan')
            plt.subplot(1, 2, 1)
            plt.imshow(ascan.to_numpy())
            plt.subplot(1, 2, 2)
            plt.imshow(dut.to_numpy()[:, 512])
            plt.show()

        self.assertTrue(np.all(ascan.to_numpy()[:, 0, 0] == self.dut.to_numpy()[:, 512, 0]))


class FilterTestCase(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def setUp(self):
        np.random.seed(42)
        signal_length = 100
        self.data_1d = np.linspace(0, 100, signal_length) + np.random.normal(0, 1, signal_length)
        self.data_2d = np.random.rand(*(signal_length, 32))
        self.data_3d = np.array([[[1, 2, 3], [4, 5, 6], [7, 8, 9]],
                                 [[10, 11, 12], [13, 14, 15], [16, 17, 18]],
                                 [[19, 20, 21], [22, 23, 24], [25, 26, 27]]])
        self.data_3d[0, 1, 1] = 100
        self.data_3d[2, 2, 2] = 50

    @staticmethod
    def median_filter_4_ref(data, filter_size):
        ny, nx, nz = data.shape
        result = np.empty_like(data)

        for y in range(ny):
            for x in range(nx):
                res = np.zeros(nz, dtype=data.dtype)

                for z in range(nz):
                    lower_bound = max(z - filter_size // 2, 0)
                    upper_bound = min(z + filter_size // 2 + 1, nz)

                    tmp = data[y, x, lower_bound:upper_bound]
                    median_value = np.median(tmp)

                    res[z] = median_value

                result[y, x, :] = res

        return result

    # TODO: find reason for discrepancy
    def test_median_filter_1d(self):
        filter_size = 3

        ref_data = self.median_filter_4_ref(self.data_3d, filter_size)

        dut = RealData.from_numpy(self.data_3d)
        dut.filter.median_filter_1d(filter_size, pt.DataDirection.DIR1)

        if ENABLE_PLOTS:
            for i in range(self.data_3d.shape[2]):
                plt.figure(figsize=(10, 4))
                plt.subplot(1, 3, 1)
                plt.imshow(self.data_3d[:, :, i], cmap='viridis', origin='upper')
                plt.title(f'Original Data (Slice {i + 1})')

                plt.subplot(1, 3, 2)
                plt.imshow(ref_data[:, :, i], cmap='viridis', origin='upper')
                plt.title(f'Filtered Reference Data (Slice {i + 1})')

                plt.subplot(1, 3, 3)
                plt.imshow(dut.to_numpy()[:, :, i], cmap='viridis', origin='upper')
                plt.title(f'Filtered SR Data (Slice {i + 1})')

            plt.show()
        else:
            plt.close()

    # TODO: find reason for discrepancy
    def test_median_filter_2d(self):
        filter_size = 3

        ref_data = self.median_filter_4_ref(self.data_3d, filter_size)

        dut = RealData.from_numpy(self.data_3d)
        dut.filter.median_filter_2d(filter_size, pt.DataDirection.DIR1)

        if ENABLE_PLOTS:
            for i in range(self.data_3d.shape[2]):
                plt.figure(figsize=(10, 4))
                plt.subplot(1, 3, 1)
                plt.imshow(self.data_3d[:, :, i], cmap='viridis', origin='upper')
                plt.title(f'Original Data (Slice {i + 1})')

                plt.subplot(1, 3, 2)
                plt.imshow(ref_data[:, :, i], cmap='viridis', origin='upper')
                plt.title(f'Filtered Reference Data (Slice {i + 1})')

                plt.subplot(1, 3, 3)
                plt.imshow(dut.to_numpy()[:, :, i], cmap='viridis', origin='upper')
                plt.title(f'Filtered SR Data (Slice {i + 1})')

            plt.show()
        else:
            plt.close()

    # TODO: looks all the same...
    def test_pepper_filter_2d(self):

        threshold = 80.0
        direction = pt.DataDirection.DIR1

        dut = RealData.from_numpy(self.data_2d)
        ref = dut.clone()
        dut_hor = dut.clone()
        dut_hor.filter.pepper_filter_2d(pt.PepperFilterType.HORIZONTAL, threshold, direction)
        dut_ver = dut.clone()
        dut_ver.filter.pepper_filter_2d(pt.PepperFilterType.VERTICAL, threshold, direction)
        dut_star = dut.clone()
        dut_star.filter.pepper_filter_2d(pt.PepperFilterType.STAR, threshold, direction)
        dut_block = dut.clone()
        dut_block.filter.pepper_filter_2d(pt.PepperFilterType.BLOCK, threshold, direction)

        if ENABLE_PLOTS:
            plt.figure(figsize=(18, 4))
            plt.subplot(1, 5, 1)
            plt.imshow(ref.to_numpy()[:, :, 0], cmap='viridis', origin='upper')
            plt.title(f'Reference RealData')

            plt.subplot(1, 5, 2)
            plt.imshow(dut_hor.to_numpy()[:, :, 0], cmap='viridis', origin='upper')
            plt.title(f'Filtered horizontal SR RealData')

            plt.subplot(1, 5, 3)
            plt.imshow(dut_ver.to_numpy()[:, :, 0], cmap='viridis', origin='upper')
            plt.title(f'Filtered vertical SR RealData')

            plt.subplot(1, 5, 4)
            plt.imshow(dut_star.to_numpy()[:, :, 0], cmap='viridis', origin='upper')
            plt.title(f'Filtered star SR RealData')

            plt.subplot(1, 5, 5)
            plt.imshow(dut_block.to_numpy()[:, :, 0], cmap='viridis', origin='upper')
            plt.title(f'Filtered block SR RealData')

            plt.show()
        else:
            plt.close()

    # TODO find meaningful assertion
    def test_convolution_filter_1d(self):
        ref = RealData.from_numpy(self.data_3d)
        filter_1d = np.array([1, 0, -1])

        dut_1 = ref.clone()
        dut_1.filter.convolution_filter_1d(filter_1d, pt.DataDirection.DIR1)
        dut_2 = ref.clone()
        dut_2.filter.convolution_filter_1d(filter_1d, pt.DataDirection.DIR2)
        dut_3 = ref.clone()
        dut_3.filter.convolution_filter_1d(filter_1d, pt.DataDirection.DIR3)

        if ENABLE_PLOTS:
            plt.figure(figsize=(18, 4))
            plt.subplot(1, 4, 1)
            plt.imshow(ref.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Reference RealData')

            plt.subplot(1, 4, 2)
            plt.imshow(dut_1.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered DIR1 SR RealData')

            plt.subplot(1, 4, 3)
            plt.imshow(dut_2.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered DIR2 SR RealData')

            plt.subplot(1, 4, 4)
            plt.imshow(dut_3.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered DIR3 SR RealData')

            plt.show()
        else:
            plt.close()

    # TODO find meaningful assertion
    def test_convolution_filter_2d(self):
        ref = RealData.from_numpy(self.data_3d)
        filter_2d = np.array([[1, 0, -1],
                              [2, 0, -2],
                              [1, 0, -1]])

        dut_1 = ref.clone()
        dut_1.filter.convolution_filter_2d(filter_2d, pt.DataDirection.DIR1)
        dut_2 = ref.clone()
        dut_2.filter.convolution_filter_2d(filter_2d, pt.DataDirection.DIR2)
        dut_3 = ref.clone()
        dut_3.filter.convolution_filter_2d(filter_2d, pt.DataDirection.DIR3)

        if ENABLE_PLOTS:
            plt.figure(figsize=(18, 4))
            plt.subplot(1, 4, 1)
            plt.imshow(ref.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Reference RealData')

            plt.subplot(1, 4, 2)
            plt.imshow(dut_1.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered DIR1 SR RealData')

            plt.subplot(1, 4, 3)
            plt.imshow(dut_2.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered DIR2 SR RealData')

            plt.subplot(1, 4, 4)
            plt.imshow(dut_3.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered DIR3 SR RealData')

            plt.show()
        else:
            plt.close()

    # TODO find meaningful assertion
    def test_convolution_filter_3d(self):
        ref = RealData.from_numpy(self.data_3d)
        filter_3d = np.array([[[1, 0, -1],
                               [2, 0, -2],
                               [1, 0, -1]],

                              [[-1, -2, -1],
                               [0, 0, 0],
                               [1, 2, 1]],

                              [[1, 2, 1],
                               [2, 4, 2],
                               [1, 2, 1]]])

        dut_1 = ref.clone()
        dut_1.filter.convolution_filter_3d(filter_3d)
        dut_2 = ref.clone()
        dut_2.filter.convolution_filter_3d(filter_3d)
        dut_3 = ref.clone()
        dut_3.filter.convolution_filter_3d(filter_3d)

        if ENABLE_PLOTS:
            plt.figure(figsize=(18, 4))
            plt.subplot(1, 4, 1)
            plt.imshow(ref.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Reference RealData')

            plt.subplot(1, 4, 2)
            plt.imshow(dut_1.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered DIR1 SR RealData')

            plt.subplot(1, 4, 3)
            plt.imshow(dut_2.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered DIR2 SR RealData')

            plt.subplot(1, 4, 4)
            plt.imshow(dut_3.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered DIR3 SR RealData')

            plt.show()
        else:
            plt.close()

    # TODO find meaningful assertion
    def test_predefined_filter_1d(self):
        ref = RealData.from_numpy(self.data_3d)

        dut_1 = ref.clone()
        dut_1.filter.predefined_filter_1d(pt.FilterType1D.GAUSSIAN_5, pt.DataDirection.DIR1)
        dut_2 = ref.clone()
        dut_2.filter.predefined_filter_1d(pt.FilterType1D.GAUSSIAN_5, pt.DataDirection.DIR2)
        dut_3 = ref.clone()
        dut_3.filter.predefined_filter_1d(pt.FilterType1D.GAUSSIAN_5, pt.DataDirection.DIR3)

        if ENABLE_PLOTS:
            plt.figure(figsize=(18, 4))
            plt.subplot(1, 4, 1)
            plt.imshow(ref.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Reference RealData')

            plt.subplot(1, 4, 2)
            plt.imshow(dut_1.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered DIR1 SR RealData')

            plt.subplot(1, 4, 3)
            plt.imshow(dut_2.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered DIR2 SR RealData')

            plt.subplot(1, 4, 4)
            plt.imshow(dut_3.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered DIR3 SR RealData')

            plt.show()
        else:
            plt.close()

    # TODO find meaningful assertion
    def test_predefined_filter_2d(self):
        ref = RealData.from_numpy(self.data_3d)

        dut_1 = ref.clone()
        dut_1.filter.predefined_filter_2d(pt.FilterType2D.GAUSSIAN_3X3, pt.DataDirection.DIR1)
        dut_2 = ref.clone()
        dut_2.filter.predefined_filter_2d(pt.FilterType2D.GAUSSIAN_3X3, pt.DataDirection.DIR2)
        dut_3 = ref.clone()
        dut_3.filter.predefined_filter_2d(pt.FilterType2D.GAUSSIAN_3X3, pt.DataDirection.DIR3)

        if ENABLE_PLOTS:
            plt.figure(figsize=(18, 4))
            plt.subplot(1, 4, 1)
            plt.imshow(ref.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Reference RealData')

            plt.subplot(1, 4, 2)
            plt.imshow(dut_1.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered DIR1 SR RealData')

            plt.subplot(1, 4, 3)
            plt.imshow(dut_2.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered DIR2 SR RealData')

            plt.subplot(1, 4, 4)
            plt.imshow(dut_3.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered DIR3 SR RealData')

        dut_4 = ref.clone()
        dut_4.filter.predefined_filter_2d(pt.FilterType2D.Prewitt_HOR_3X3, pt.DataDirection.DIR1)
        dut_5 = ref.clone()
        dut_5.filter.predefined_filter_2d(pt.FilterType2D.Prewitt_VER_3X3, pt.DataDirection.DIR1)
        dut_6 = ref.clone()
        dut_6.filter.predefined_filter_2d(pt.FilterType2D.NONLINEAR_Prewitt_3X3, pt.DataDirection.DIR1)
        dut_7 = ref.clone()
        dut_7.filter.predefined_filter_2d(pt.FilterType2D.SOBEL_HOR_3X3, pt.DataDirection.DIR1)
        dut_8 = ref.clone()
        dut_8.filter.predefined_filter_2d(pt.FilterType2D.SOBEL_VER_3X3, pt.DataDirection.DIR1)
        dut_9 = ref.clone()
        dut_9.filter.predefined_filter_2d(pt.FilterType2D.NONLINEAR_SOBEL_3X3, pt.DataDirection.DIR1)
        dut_10 = ref.clone()
        dut_10.filter.predefined_filter_2d(pt.FilterType2D.LAPLACIAN_NO_DIAGONAL_3X3, pt.DataDirection.DIR1)
        dut_11 = ref.clone()
        dut_11.filter.predefined_filter_2d(pt.FilterType2D.LAPLACIAN_3X3, pt.DataDirection.DIR1)

        if ENABLE_PLOTS:
            plt.figure(figsize=(15, 9))
            plt.subplot(3, 3, 1)
            plt.imshow(ref.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Reference RealData')

            plt.subplot(3, 3, 2)
            plt.imshow(dut_4.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered Prewitt_HOR_3X3 SR RealData')

            plt.subplot(3, 3, 3)
            plt.imshow(dut_5.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered Prewitt_VER_3X3 SR RealData')

            plt.subplot(3, 3, 4)
            plt.imshow(dut_6.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered NONLINEAR_Prewitt_3X3 SR RealData')

            plt.subplot(3, 3, 5)
            plt.imshow(dut_7.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered SOBEL_HOR_3X3 SR RealData')

            plt.subplot(3, 3, 6)
            plt.imshow(dut_8.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered SOBEL_VER_3X3 SR RealData')

            plt.subplot(3, 3, 7)
            plt.imshow(dut_9.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered NONLINEAR_SOBEL_3X3 SR RealData')

            plt.subplot(3, 3, 8)
            plt.imshow(dut_10.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered LAPLACIAN_NO_DIAGONAL_3X3 SR RealData')

            plt.subplot(3, 3, 9)
            plt.imshow(dut_11.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered LAPLACIAN_3X3 SR RealData')

            plt.show()
        else:
            plt.close()

    # TODO: find meaningful assertion
    def test_predefined_filter_3d(self):
        ref = RealData.from_numpy(self.data_3d)

        dut_1 = ref.clone()
        dut_1.filter.predefined_filter_3d(pt.FilterType3D.GAUSSIAN_3X3X3)

        if ENABLE_PLOTS:
            plt.figure(figsize=(18, 4))
            plt.subplot(1, 4, 1)
            plt.imshow(ref.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Reference RealData')

            plt.subplot(1, 4, 2)
            plt.imshow(dut_1.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered SR RealData [:, 0, :]')

            plt.subplot(1, 4, 3)
            plt.imshow(dut_1.to_numpy()[:, 1, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered SR RealData [:, 1, :]')

            plt.subplot(1, 4, 4)
            plt.imshow(dut_1.to_numpy()[:, 2, :], cmap='viridis', origin='upper')
            plt.title(f'Filtered SR RealData [:, 2, :]')

            plt.show()
        else:
            plt.close()

    def test_averaging_resize_filter(self):
        dut = RealData.from_numpy(self.data_3d)

        res = dut.filter.averaging_resize_filter(3, 3, 3)

        if ENABLE_PLOTS:
            plt.figure(figsize=(18, 4))
            plt.subplot(1, 2, 1)
            plt.imshow(dut.to_numpy()[:, 0, :], cmap='viridis', origin='upper')
            plt.title(f'Reference RealData')

            plt.subplot(1, 2, 2)
            plt.imshow(res.to_numpy(), cmap='viridis', origin='upper')
            plt.title(f'Reference RealData')

            plt.show()
        else:
            plt.close()

        self.assertEqual(res.to_numpy().shape, (1, 1, 1))
        self.assertAlmostEqual(res.to_numpy()[0, 0, 0], np.mean(self.data_3d), 5)


class DataAnalysisTestCase(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def setUp(self):
        np.random.seed(42)
        signal_length = 100
        self.data_1d = np.linspace(0, 100, signal_length) + np.random.normal(0, 1, signal_length)
        self.data_2d = np.random.rand(*(signal_length, 32))
        self.data_3d = np.array([[[1, 2, 3], [4, 5, 6], [7, 8, 9]],
                                 [[10, 11, 12], [13, 14, 15], [16, 17, 18]],
                                 [[19, 20, 21], [22, 23, 24], [25, 26, 27]]])

    def test_analyze(self):
        dut = RealData.from_numpy(self.data_3d)

        self.assertEqual(dut.analysis.analyze(pt.AnalysisTypes.MIN), 1)
        self.assertAlmostEqual(dut.analysis.analyze(pt.AnalysisTypes.MEAN), np.mean(self.data_3d), 5)
        self.assertEqual(dut.analysis.analyze(pt.AnalysisTypes.MAX), 27)
        print(dut.range, dut.shape, np.unravel_index(np.argmax(self.data_3d), self.data_3d.shape))
        self.assertAlmostEqual(dut.analysis.analyze(pt.AnalysisTypes.MAX_DEPTH), dut.range[0] * (
                np.unravel_index(np.argmax(self.data_3d), self.data_3d.shape)[0] / dut.shape[0]))

    # TODO: find meaningful assertion
    def test_analyze_ascan(self):
        dut = RealData.from_numpy(self.data_1d)

        print('NOISE_DB', dut.analysis.analyze_ascan(pt.AScanAnalysis.NOISE_DB))
        # self.assertAlmostEqual(dut.analysis.analyze_ascan(pt.AScanAnalysis.NOISE_DB), 1.0)
        print('NOISE_ELECTRONS', dut.analysis.analyze_ascan(pt.AScanAnalysis.NOISE_ELECTRONS))
        # self.assertAlmostEqual(dut.analysis.analyze_ascan(pt.AScanAnalysis.NOISE_ELECTRONS), 1.0)
        print('PEAK_POS_PIXEL', dut.analysis.analyze_ascan(pt.AScanAnalysis.PEAK_POS_PIXEL))
        # self.assertAlmostEqual(dut.analysis.analyze_ascan(pt.AScanAnalysis.PEAK_POS_PIXEL), 1.0)
        print('PEAK_POS_PHYS_UNIT', dut.analysis.analyze_ascan(pt.AScanAnalysis.PEAK_POS_PHYS_UNIT))
        # self.assertAlmostEqual(dut.analysis.analyze_ascan(pt.AScanAnalysis.PEAK_POS_PHYS_UNIT), 1.0)
        print('PEAK_HEIGHT_DB', dut.analysis.analyze_ascan(pt.AScanAnalysis.PEAK_HEIGHT_DB))
        # self.assertAlmostEqual(dut.analysis.analyze_ascan(pt.AScanAnalysis.PEAK_HEIGHT_DB), 1.0)
        print('PEAK_WIDTH_6DB', dut.analysis.analyze_ascan(pt.AScanAnalysis.PEAK_WIDTH_6DB))
        # self.assertAlmostEqual(dut.analysis.analyze_ascan(pt.AScanAnalysis.PEAK_WIDTH_6DB), 1.0)
        print('PEAK_WIDTH_20DB', dut.analysis.analyze_ascan(pt.AScanAnalysis.PEAK_WIDTH_20DB))
        # self.assertAlmostEqual(dut.analysis.analyze_ascan(pt.AScanAnalysis.PEAK_WIDTH_20DB), 1.0)
        print('PEAK_WIDTH_40DB', dut.analysis.analyze_ascan(pt.AScanAnalysis.PEAK_WIDTH_40DB))
        # self.assertAlmostEqual(dut.analysis.analyze_ascan(pt.AScanAnalysis.PEAK_WIDTH_40DB), 1.0)

    # TODO
    def test_analyze_peaks_in_ascan(self):
        dut = RealData.from_numpy(self.data_1d)

        print('PEAK_POS_PIXEL', dut.analysis.analyze_peaks_in_ascan(pt.AScanAnalysis.PEAK_POS_PIXEL, 2, 5))
        # self.assertAlmostEqual(dut.analysis.analyze_peaks_in_ascan(pt.AScanAnalysis.PEAK_POS_PIXEL, 2, 5)), 1.0)
        print('PEAK_POS_PHYS_UNIT', dut.analysis.analyze_peaks_in_ascan(pt.AScanAnalysis.PEAK_POS_PHYS_UNIT, 2, 5))
        # self.assertAlmostEqual(dut.analysis.analyze_peaks_in_ascan(pt.AScanAnalysis.PEAK_POS_PHYS_UNIT, 2, 5)), 1.0)
        print('PEAK_HEIGHT_DB', dut.analysis.analyze_peaks_in_ascan(pt.AScanAnalysis.PEAK_HEIGHT_DB, 2, 5))
        # self.assertAlmostEqual(dut.analysis.analyze_peaks_in_ascan(pt.AScanAnalysis.PEAK_HEIGHT_DB, 2, 5)), 1.0)
        print('PEAK_WIDTH_6DB', dut.analysis.analyze_peaks_in_ascan(pt.AScanAnalysis.PEAK_WIDTH_6DB, 2, 5))
        # self.assertAlmostEqual(dut.analysis.analyze_peaks_in_ascan(pt.AScanAnalysis.PEAK_WIDTH_6DB, 2, 5)), 1.0)
        print('PEAK_WIDTH_20DB', dut.analysis.analyze_peaks_in_ascan(pt.AScanAnalysis.PEAK_WIDTH_20DB, 2, 5))
        # self.assertAlmostEqual(dut.analysis.analyze_peaks_in_ascan(pt.AScanAnalysis.PEAK_WIDTH_20DB, 2, 5)), 1.0)
        print('PEAK_WIDTH_40DB', dut.analysis.analyze_peaks_in_ascan(pt.AScanAnalysis.PEAK_WIDTH_40DB, 2, 5))
        # self.assertAlmostEqual(dut.analysis.analyze_peaks_in_ascan(pt.AScanAnalysis.PEAK_WIDTH_40DB, 2, 5)), 1.0)

    def test_determine_surface(self):
        data = np.random.rand(100, 100, 100)
        data[:, 50, 50] = 100

        dut = RealData.from_numpy(data)
        surface = dut.analysis.determine_surface()

        self.assertTrue(dut.shape == data.shape)
        self.assertTrue(surface.shape == (100, 100, 1))

    # TODO: doubt that C function does what it should do...
    @staticmethod
    def test_determine_range():
        data = np.random.rand(100, 100, 100)
        data[:, 50, 50] = 100
        data_db = 10 * np.log10(data)
        dut = RealData.from_numpy(data)

        print('values:', np.min(data), np.max(data))
        print('db:', np.min(data_db), np.max(data_db))

        print(dut.analysis.determine_dynamic_range_db())

        print(dut.analysis.determine_dynamic_range_with_min_range_db(1.0))
        print(dut.analysis.determine_dynamic_range_with_min_range_db(5.0))
        print(dut.analysis.determine_dynamic_range_with_min_range_db(10.0))


if __name__ == '__main__':
    unittest.main()
