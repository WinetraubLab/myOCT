from ctypes import c_double

from pyspectralradar.base import Submodule
from pyspectralradar.spectralradar import c_handle, get_error, sr


class LightSource(Submodule):

    def get_timeout(self) -> float:
        """Gets the timeout in seconds, after which the OCT light source will be turned off if no scanning is performed.

        Returns:
            Time in seconds after which the light source will be turned off.
        """
        sr.getLightSourceTimeout_s.argtypes = [c_handle]
        sr.getLightSourceTimeout_s.restype = c_double
        res = sr.getLightSourceTimeout_s(self.handle)
        get_error()
        return res

    def set_timeout(self, timeout_s: float):
        """Sets the timeout in seconds, after which the OCT light source will be turned off if no scanning is performed.

        Args:
            :timeout_s: Time in seconds after which the light source will be turned off.
        """
        sr.setLightSourceTimeout_s.argtypes = [c_handle, c_double]
        sr.setLightSourceTimeout_s(self.handle, c_double(timeout_s))
        get_error()

    def set_timeout_callback(self, callback):
        """Sets a callback function that will be invoked by the SDK whenever the state of the light source of the device
        changes.

        Args:
            :callback: Callback to the #lightSourceStateCallback that will be called when state of the light
                source changes
        """
        raise NotImplementedError
