from enum import IntEnum

from pyspectralradar.base.propertygetter import FloatPropertyGetter
from pyspectralradar.base.propertysetter import FloatPropertySetter
from pyspectralradar.spectralradar import sr


class PropertyFloat(IntEnum):
    """Enum Values that determine the behaviour of the :class:`Polarization` processing routines."""

    INTENSITY_THRESHOLD_DB = 0
    """Threshold value to enable/disable features of PS computation based on the total intensity value."""

    PMD_CORRECTION_ANGLE_RAD = 1
    """Correction angle (in radians) to get circularly polarized light at the upper surface of the sample. This
       angle is a compensation fo the polarization-mode-dispersion (PMD).  More in detail, this angle is used to
       compute a phasor (exp(i\alpha)), that will be applied to the complex reflectivity vector associated
       with camera 0."""

    CENTRAL_WAVELENGTH_NM = 2
    """Assuming a gaussian light source, the value of the wave number with maximal intensity (in nm)."""

    OPTICAL_AXIS_OFFSET_RAD = 3
    """Refer to a particular orientation on the sample holder. The angle should be expressed in radians."""


class PolarizationPropertyFloat(FloatPropertyGetter, FloatPropertySetter):
    def __init__(self, handle):
        FloatPropertyGetter.__init__(self, handle, sr.getPolarizationPropertyFloat)
        FloatPropertySetter.__init__(self, handle, sr.setPolarizationPropertyFloat)

    def get_intensity_threshold_db(self) -> float:
        """Threshold value to enable/disable features of PS computation based on the total intensity value."""
        return self._get(PropertyFloat.INTENSITY_THRESHOLD_DB)

    def set_intensity_threshold_db(self, value: float):
        """Threshold value to enable/disable features of PS computation based on the total intensity value."""
        self._set(PropertyFloat.INTENSITY_THRESHOLD_DB, value)

    def get_pmd_correction_angle_rad(self) -> float:
        """Correction angle (in radians) to get circularly polarized light at the upper surface of the sample. This
        angle is a compensation fo the polarization-mode-dispersion (PMD).  More in detail, this angle is used to
        compute a phasor (exp(i\alpha)), that will be applied to the complex reflectivity vector associated
        with camera 0."""
        return self._get(PropertyFloat.PMD_CORRECTION_ANGLE_RAD)

    def set_pmd_correction_angle_rad(self, value: float):
        """Correction angle (in radians) to get circularly polarized light at the upper surface of the sample. This
        angle is a compensation fo the polarization-mode-dispersion (PMD).  More in detail, this angle is used to
        compute a phasor (exp(i\alpha)), that will be applied to the complex reflectivity vector associated
        with camera 0."""
        self._set(PropertyFloat.PMD_CORRECTION_ANGLE_RAD, value)

    def get_central_wavelength_nm(self) -> float:
        """Assuming a gaussian light source, the value of the wave number with maximal intensity (in nm)."""
        return self._get(PropertyFloat.CENTRAL_WAVELENGTH_NM)

    def set_central_wavelength_nm(self, value: float):
        """Assuming a gaussian light source, the value of the wave number with maximal intensity (in nm)."""
        self._set(PropertyFloat.CENTRAL_WAVELENGTH_NM, value)

    def get_optical_axis_offset_rad(self) -> float:
        """Refer to a particular orientation on the sample holder. The angle should be expressed in radians."""
        return self._get(PropertyFloat.OPTICAL_AXIS_OFFSET_RAD)

    def set_optical_axis_offset_rad(self, value: float):
        """Refer to a particular orientation on the sample holder. The angle should be expressed in radians."""
        self._set(PropertyFloat.OPTICAL_AXIS_OFFSET_RAD, value)
