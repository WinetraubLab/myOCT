from enum import IntEnum

from pyspectralradar.base.propertygetter import IntPropertyGetter


class DataPropertyInt(IntEnum):
    """Integer properties of data (#DataHandle) that can be retrieved with the function #getDataPropertyInt."""
    DIMENSIONS = 0
    """Dimension of the data object. Usually 1, 2 or 3. 0 indicates empty data."""

    SIZE1 = 1
    """Size of the first dimension. For OCT data this is usually the longitudinal axis (z)"""

    SIZE2 = 2
    """Size of the first dimension. For OCT data this is usually a transversal axis (x)"""

    SIZE3 = 3
    """Size of the first dimension. For OCT data this is usually a transversal axis (y)"""

    ELEMENTS = 4
    """The number of elements in the data object."""

    SIZE_BYTES = 5
    """The size of the data object in bytes."""

    BYTES_PER_ELEMENT = 6
    """The number of bytes of a single element."""


class DataPropertyIntGetter(IntPropertyGetter):
    """Integer properties of data (#DataHandle) that can be retrieved with the function #getDataPropertyInt."""

    def get_dimensions(self) -> int:
        """Dimension of the data object. Usually 1, 2 or 3. 0 indicates empty data."""
        return self._get(DataPropertyInt.DIMENSIONS)

    def get_size1(self) -> int:
        """Size of the first dimension. For OCT data this is usually the longitudinal axis (z)"""
        return self._get(DataPropertyInt.SIZE1)

    def get_size2(self) -> int:
        """Size of the second dimension. For OCT data this is usually a transversal axis (x)"""
        return self._get(DataPropertyInt.SIZE2)

    def get_size3(self) -> int:
        """Size of the third dimension. For OCT data this is usually a transversal axis (y)"""
        return self._get(DataPropertyInt.SIZE3)

    def get_number_of_elements(self) -> int:
        """The number of elements in the data object."""
        return self._get(DataPropertyInt.ELEMENTS)

    def get_size_bytes(self) -> int:
        """The size of the data object in bytes."""
        return self._get(DataPropertyInt.SIZE_BYTES)

    def get_bytes_per_element(self) -> int:
        """The number of bytes of a single element."""
        return self._get(DataPropertyInt.BYTES_PER_ELEMENT)
