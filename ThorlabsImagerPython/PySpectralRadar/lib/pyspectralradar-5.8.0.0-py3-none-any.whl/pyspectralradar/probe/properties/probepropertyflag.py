from enum import IntEnum

from pyspectralradar.base.propertygetter import FlagPropertyGetter
from pyspectralradar.spectralradar import sr


class Flags(IntEnum):
    """Boolean parameters describing the behaviour of the Probe."""

    CAMERA_INVERTED_X = 0
    """ Bool if the scan pattern in the video camera image is flipped around x-axis or not."""

    CAMERA_INVERTED_Y = 1
    """Bool if the scan pattern in the video camera image is flipped around y-axis or not."""

    HAS_MEMS_SCANNER = 2
    """Boolean if the probe type uses a MEMS mirror or not, e.g. a handheld probe."""

    APO_ONLY_X = 3
    """Boolean if the apodization position is used for the x-mirror (or x-axis) only or both axes (mirrors) are used. 
    This parameter can be set via the Probe.ini or prdf-file only."""


class ProbePropertyFlag(FlagPropertyGetter):
    """Boolean properties of the device that can be retrieved with the function #getDeviceFlag.
    """

    def __init__(self, handle):
        super().__init__(handle, sr.getProbeFlag)

    def get_camera_inverted_x(self) -> bool:
        """Bool if the scan pattern in the video camera image is flipped around x-axis or not."""
        return self._get(Flags.CAMERA_INVERTED_X)

    def get_camera_inverted_y(self) -> bool:
        """Bool if the scan pattern in the video camera image is flipped around y-axis or not."""
        return self._get(Flags.CAMERA_INVERTED_Y)

    def get_has_mems_scanner(self) -> bool:
        """Boolean if the probe type uses a MEMS mirror or not, e.g. a handheld probe."""
        return self._get(Flags.HAS_MEMS_SCANNER)

    def get_apo_only_x(self) -> bool:
        """Boolean if the apodization position is used for the x-mirror (or x-axis) only or both axes (mirrors) are
        used. This parameter can be set via the Probe.ini or prdf-file only."""
        return self._get(Flags.APO_ONLY_X)
