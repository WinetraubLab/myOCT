from ctypes import POINTER, c_double, c_int
from typing import Tuple

from pyspectralradar.base import Submodule
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import ApoWindowParameter, ApoWindowType


class Apodization(Submodule):

    def get_window_type(self) -> ApoWindowType:
        """Returns the current windowing function that is being used for apodization,
        :class:`~pyspectralradar.types.processingtypes.ApoWindowType` (this apodization is not the reference spectrum
        measured without a sample!)

        Returns:
            The current windowing function that is being used for apodization.
        """
        sr.getApodizationWindow.argtypes = [c_handle]
        win = ApoWindowType(sr.getApodizationWindow(self.handle))
        get_error()
        return win

    def set_window_type(self, window: ApoWindowType):
        """Sets the windowing function that will be used for apodization (this apodization has nothing to do with the
        reference spectra measured without a sample!).

        The selected windowing function will be used in all subsequent processing right before the fast Fourier
        transformation.

        The selection of a windowing function is a balance between the acceptable width of the main lobe (that is,
        how many "frequency bins" does it take the response to reach half maximum power) and the attenuation of the
        side lobes (that is, what level of artifacts caused by the spectral leakage can be tolerated). As such,
        it depends on the particular experiment. The default selection (Hann windowing) cannot be expected to fit
        everyone's needs. If this property is not explicitly set, a Hann window will be assumed (
        ``ApoWindowType.HANN``).

        Args:
            :window: The desired apodization window to be used for apodizations right before Fourier transformations.
        """
        sr.setApodizationWindow.argtypes = [c_handle, c_int]
        sr.setApodizationWindow(self.handle, window)
        get_error()

    def set_window_parameter(self, selection: ApoWindowParameter, value: float):
        """Sets the apodization window parameter, such as window width or ratio between constant and cosine part.

        Notice that this apodization is unrelated to the reference spectrum measured without a sample!.

        Args:
            :selection: The desired apodization window parameter whose value will be changed
            :value: The desired value for the parameter.
        """
        assert isinstance(selection, ApoWindowParameter)
        sr.setApodizationWindowParameter.argtypes = [c_handle, c_int, c_double]
        sr.setApodizationWindowParameter(self.handle, selection, c_double(value))
        get_error()

    def get_window_parameter(self, selection: ApoWindowParameter) -> ApoWindowParameter:
        """Gets the apodization window parameter, such as window width or ratio between constant and cosine part.

        Notice that this apodization is unrelated to the reference spectrum measured without a sample!.

        Args:
            :selection: The desired parameter whose value shall be retrieved.

        Returns:
            The current value of the parameter.
        """
        assert isinstance(selection, ApoWindowParameter)
        sr.getApodizationWindowParameter.argtypes = [c_handle, c_int]
        sr.getApodizationWindowParameter.restype = c_double
        res = sr.getApodizationWindowParameter(self.handle, selection)
        get_error()
        return res

    def get_edge_channels(self) -> Tuple[int, int]:
        """Returns the pixel positions of the left/right edge channels of the current apodization.

        Here apodization refers to the reference spectra measured without sample.

        The apodization spectra (i.e. the spectra measured without a sample) have regions, at their left and right
        edges, where the signal-to-noise ratio is too low for practical purposes. This function returns the position
        of the last pixel position (or channel) at which the measured intensity is insufficient for reliable
        computations. Notice that the camera is upside down. Hence, the right-most pixel refers to the shortest
        measured wavelength, and the left-most pixel refers to the longest measured wavelength. The second and
        third pointers are addresses in memory managed by the user, not by SpectralRadar.

        Returns:
            A tuple (``left_pixel``, ``right_pixel``) containing the ``left_pixel`` as the address to store the
            position of the last pixel position, starting from the left, at which the intensity is too low for
            reliable computations and the ``right_pixel`` as the address to store the position of the last pixel
            position, starting from the right, at which the intensity is too low for reliable computations. If a
            nullptr is given, nothing will be written on it.
        """
        left_pixel = c_int()
        right_pixel = c_int()
        sr.getCurrentApodizationEdgeChannels.argtypes = [c_handle, POINTER(c_int), POINTER(c_int)]
        sr.getCurrentApodizationEdgeChannels(self.handle, left_pixel, right_pixel)
        get_error()
        return left_pixel.value, right_pixel.value
