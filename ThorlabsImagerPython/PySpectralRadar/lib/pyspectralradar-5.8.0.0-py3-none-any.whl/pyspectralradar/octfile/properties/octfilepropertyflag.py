from enum import IntEnum

from pyspectralradar.base.propertygetter import FlagPropertyGetter
from pyspectralradar.base.propertysetter import FlagPropertySetter
from pyspectralradar.spectralradar import sr


class MetadataFlag(IntEnum):
    """Enum identifying file metadata fields of flag type"""

    OFFSET_APPLIED = 0
    """This field is the flag that can be accessed with :func:`Processing._flag_get` / :func:`Processing._flag_set` 
    and the constant ``Processing.PropertyFlag.USE_OFFSET``."""

    DC_SUBTRACTED = 1
    """This field is the flag that can be accessed with :func:`Processing._flag_get` / :func:`Processing._flag_set` 
    and the constant ``Processing.PropertyFlag.REMOVE_DC``."""

    APO_APPLIED = 2
    """Field indicates/sets whether an apodization was performed during processing of the respective OCT data file."""

    DE_CHIRP_APPLIED = 3
    """Field indicates/sets whether de-chirp was applied during processing of the respective OCT data file."""

    UNDER_SAMPLING_FILTER = 4
    """This field is the flag that can be accessed with :func:`Processing._flag_get` / :func:`Processing._flag_set` 
    and the constant ``Processing.PropertyFlag.UNDER_SAMPLING_FILTER``."""

    DISPERSION_COMP = 5
    """Field indicates/sets whether dispersion compensations was applied when acquiring the file."""

    QUADRATIC_DISPERSION_COMP = 6
    """Field indicates/sets whether quadratic dispersion compensations was applied when acquiring the file."""

    IMAGE_FIELD_CORR = 7
    """Field indicates/sets whether image field correction was applied when acquiring the file."""

    SCAN_LINE_SHOWN = 8
    """Field indicates/sets whether the scan line was visualized on the camera image when the file was acquired."""

    AUTO_CORR_COMP = 9
    """This field is the flag that can be accessed with :func:`Processing._flag_get` / :func:`Processing._flag_set` 
    and the constant ``Processing.PropertyFlag.AUTOCORR_CORR``."""

    BSCAN_CROSS_CORR = 10
    """Field indicates/sets whether B-scans were correlated during averaging when the file was acquired."""

    DC_SUBTRACTED_ADV = 11
    """This field is the flag that can be accessed with :func:`Processing._flag_get` / :func:`Processing._flag_set` 
    and the constant ``Processing.PropertyFlag.REMOVE_DC_ADV``."""

    ONLY_WINDOWING = 12
    """This field is the flag that can be accessed with :func:`Processing._flag_get` / :func:`Processing._flag_set` 
    and the constant ``Processing.PropertyFlag.ONLY_WIN``."""

    RAW_DATA_SIGNED = 13
    """This field is the flag that can be retrieved with :func:`OCTDevice._get_int` and the constant 
    ``OCTDevice.Flags.DATA_SIGNED``."""

    FREEFORM_SCAN_PATTERN_ACTIVE = 14
    """Field indicates/sets whether a freeform scan pattern was active during acquisition."""

    FREEFORM_SCAN_PATTERN_CLOSED = 15
    """Field indicates/sets whether the used freeform pattern was a closed."""

    IS_SWEPT_SOURCE = 16
    """Field indicates/sets whether data was acquired with a swept-source system."""

    DOPPLER_OVERSAMPLING = 17
    """Field indicates/sets whether data was acquired with oversampling parameter checker or not"""


class OCTFilePropertyFlag(FlagPropertyGetter, FlagPropertySetter):

    def __init__(self, handle):
        FlagPropertyGetter.__init__(self, handle, sr.getFileMetadataFlag)
        FlagPropertySetter.__init__(self, handle, sr.setFileMetadataFlag)

    def get_offset_applied(self) -> bool:
        """This field is the flag that can be accessed with :func:`Processing._flag_get` / :func:`Processing._flag_set`
        and the constant ``Processing.PropertyFlag.USE_OFFSET``."""
        return self._get(MetadataFlag.OFFSET_APPLIED)

    def set_offset_applied(self, value: bool):
        """This field is the flag that can be accessed with :func:`Processing._flag_get` / :func:`Processing._flag_set`
        and the constant ``Processing.PropertyFlag.USE_OFFSET``."""
        self._set(MetadataFlag.OFFSET_APPLIED, value)

    def get_dc_subtracted(self) -> bool:
        """This field is the flag that can be accessed with :func:`Processing._flag_get` / :func:`Processing._flag_set`
        and the constant ``Processing.PropertyFlag.REMOVE_DC``."""
        return self._get(MetadataFlag.DC_SUBTRACTED)

    def set_dc_subtracted(self, value: bool):
        """This field is the flag that can be accessed with :func:`Processing._flag_get` / :func:`Processing._flag_set`
        and the constant ``Processing.PropertyFlag.REMOVE_DC``."""
        self._set(MetadataFlag.DC_SUBTRACTED, value)

    def get_apo_applied(self) -> bool:
        """Field indicates/sets whether an apodization was performed during processing of the respective OCT data
        file."""
        return self._get(MetadataFlag.APO_APPLIED)

    def set_apo_applied(self, value: bool):
        """Field indicates/sets whether an apodization was performed during processing of the respective OCT data
        file."""
        self._set(MetadataFlag.APO_APPLIED, value)

    def get_de_chirp_applied(self) -> bool:
        """Field indicates/sets whether de-chirp was applied during processing of the respective OCT data file."""
        return self._get(MetadataFlag.DE_CHIRP_APPLIED)

    def set_de_chirp_applied(self, value: bool):
        """Field indicates/sets whether de-chirp was applied during processing of the respective OCT data file."""
        self._set(MetadataFlag.DE_CHIRP_APPLIED, value)

    def get_under_sampling_filter(self) -> bool:
        """This field is the flag that can be accessed with :func:`Processing._flag_get` / :func:`Processing._flag_set`
        and the constant ``Processing.PropertyFlag.UNDER_SAMPLING_FILTER``."""
        return self._get(MetadataFlag.UNDER_SAMPLING_FILTER)

    def set_under_sampling_filter(self, value: bool):
        """This field is the flag that can be accessed with :func:`Processing._flag_get` / :func:`Processing._flag_set`
        and the constant ``Processing.PropertyFlag.UNDER_SAMPLING_FILTER``."""
        self._set(MetadataFlag.UNDER_SAMPLING_FILTER, value)

    def get_dispersion_comp(self) -> bool:
        """Field indicates/sets whether dispersion compensations was applied when acquiring the file."""
        return self._get(MetadataFlag.DISPERSION_COMP)

    def set_dispersion_comp(self, value: bool):
        """Field indicates/sets whether dispersion compensations was applied when acquiring the file."""
        self._set(MetadataFlag.DISPERSION_COMP, value)

    def get_quadratic_dispersion_comp(self) -> bool:
        """Field indicates/sets whether quadratic dispersion compensations was applied when acquiring the file."""
        return self._get(MetadataFlag.QUADRATIC_DISPERSION_COMP)

    def set_quadratic_dispersion_comp(self, value: bool):
        """Field indicates/sets whether quadratic dispersion compensations was applied when acquiring the file."""
        self._set(MetadataFlag.QUADRATIC_DISPERSION_COMP, value)

    def get_image_field_corr(self) -> bool:
        """Field indicates/sets whether image field correction was applied when acquiring the file."""
        return self._get(MetadataFlag.IMAGE_FIELD_CORR)

    def set_image_field_corr(self, value: bool):
        """Field indicates/sets whether image field correction was applied when acquiring the file."""
        self._set(MetadataFlag.IMAGE_FIELD_CORR, value)

    def get_scan_line_shown(self) -> bool:
        """Field indicates/sets whether the scan line was visualized on the camera image when the file was acquired."""
        return self._get(MetadataFlag.SCAN_LINE_SHOWN)

    def set_scan_line_shown(self, value: bool):
        """Field indicates/sets whether the scan line was visualized on the camera image when the file was acquired."""
        self._set(MetadataFlag.SCAN_LINE_SHOWN, value)

    def get_auto_corr_comp(self) -> bool:
        """This field is the flag that can be accessed with :func:`Processing._flag_get` / :func:`Processing._flag_set`
        and the constant ``Processing.PropertyFlag.AUTOCORR_CORR``."""
        return self._get(MetadataFlag.AUTO_CORR_COMP)

    def set_auto_corr_comp(self, value: bool):
        """This field is the flag that can be accessed with :func:`Processing._flag_get` / :func:`Processing._flag_set`
        and the constant ``Processing.PropertyFlag.AUTOCORR_CORR``."""
        self._set(MetadataFlag.AUTO_CORR_COMP, value)

    def get_bscan_cross_corr(self) -> bool:
        """Field indicates/sets whether B-scans were correlated during averaging when the file was acquired."""
        return self._get(MetadataFlag.BSCAN_CROSS_CORR)

    def set_bscan_cross_corr(self, value: bool):
        """Field indicates/sets whether B-scans were correlated during averaging when the file was acquired."""
        self._set(MetadataFlag.BSCAN_CROSS_CORR, value)

    def get_dc_subtracted_adv(self) -> bool:
        """This field is the flag that can be accessed with :func:`Processing._flag_get` / :func:`Processing._flag_set`
        and the constant ``Processing.PropertyFlag.REMOVE_DC_ADV``."""
        return self._get(MetadataFlag.DC_SUBTRACTED_ADV)

    def set_dc_subtracted_adv(self, value: bool):
        """This field is the flag that can be accessed with :func:`Processing._flag_get` / :func:`Processing._flag_set`
        and the constant ``Processing.PropertyFlag.REMOVE_DC_ADV``."""
        self._set(MetadataFlag.DC_SUBTRACTED_ADV, value)

    def get_only_windowing(self) -> bool:
        """This field is the flag that can be accessed with :func:`Processing._flag_get` / :func:`Processing._flag_set`
        and the constant ``Processing.PropertyFlag.ONLY_WIN``."""
        return self._get(MetadataFlag.ONLY_WINDOWING)

    def set_only_windowing(self, value: bool):
        """This field is the flag that can be accessed with :func:`Processing._flag_get` / :func:`Processing._flag_set`
        and the constant ``Processing.PropertyFlag.ONLY_WIN``."""
        self._set(MetadataFlag.ONLY_WINDOWING, value)

    def get_raw_data_signed(self) -> bool:
        """This field is the flag that can be retrieved with :func:`OCTDevice._get_int` and the constant
        ``OCTDevice.Flags.DATA_SIGNED``."""
        return self._get(MetadataFlag.RAW_DATA_SIGNED)

    def set_raw_data_signed(self, value: bool):
        """This field is the flag that can be retrieved with :func:`OCTDevice._get_int` and the constant
        ``OCTDevice.Flags.DATA_SIGNED``."""
        self._set(MetadataFlag.RAW_DATA_SIGNED, value)

    def get_freeform_scan_pattern_active(self) -> bool:
        """Field indicates/sets whether a freeform scan pattern was active during acquisition."""
        return self._get(MetadataFlag.FREEFORM_SCAN_PATTERN_ACTIVE)

    def set_freeform_scan_pattern_active(self, value: bool):
        """Field indicates/sets whether a freeform scan pattern was active during acquisition."""
        self._set(MetadataFlag.FREEFORM_SCAN_PATTERN_ACTIVE, value)

    def get_freeform_scan_pattern_closed(self) -> bool:
        """Field indicates/sets whether the used freeform pattern was a closed."""
        return self._get(MetadataFlag.FREEFORM_SCAN_PATTERN_CLOSED)

    def set_freeform_scan_pattern_closed(self, value: bool):
        """Field indicates/sets whether the used freeform pattern was a closed."""
        self._set(MetadataFlag.FREEFORM_SCAN_PATTERN_CLOSED, value)

    def get_is_swept_source(self) -> bool:
        """Field indicates/sets whether data was acquired with a swept-source system."""
        return self._get(MetadataFlag.IS_SWEPT_SOURCE)

    def set_is_swept_source(self, value: bool):
        """Field indicates/sets whether data was acquired with a swept-source system."""
        self._set(MetadataFlag.IS_SWEPT_SOURCE, value)

    def get_doppler_oversampling(self) -> bool:
        """Field indicates/sets whether data was acquired with oversampling parameter checker or not"""
        return self._get(MetadataFlag.DOPPLER_OVERSAMPLING)

    def set_doppler_oversampling(self, value: bool):
        """Field indicates/sets whether data was acquired with oversampling parameter checker or not"""
        self._set(MetadataFlag.DOPPLER_OVERSAMPLING, value)
