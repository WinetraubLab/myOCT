import unittest

from pyspectralradar import DeviceBoundProcessingFactory, OCTDevice, OCTSystem, ProbeFactory, LogLevel, set_log_level


class OctSystemTestCase(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def test_init(self):
        dut = OCTSystem()

        self.assertIsInstance(dut, OCTSystem)
        self.assertIsInstance(dut.dev, OCTDevice)
        self.assertIsInstance(dut.probe_factory, ProbeFactory)
        self.assertIsInstance(dut.processing_factory, DeviceBoundProcessingFactory)

    def test_deinit(self):
        dut = OCTSystem()
        del dut

        with OCTSystem() as dut:
            pass

    def test_enter(self):
        with OCTSystem() as dut:
            self.assertIsInstance(dut, OCTSystem)
            self.assertIsInstance(dut.dev, OCTDevice)
            self.assertIsInstance(dut.probe_factory, ProbeFactory)
            self.assertIsInstance(dut.processing_factory, DeviceBoundProcessingFactory)
