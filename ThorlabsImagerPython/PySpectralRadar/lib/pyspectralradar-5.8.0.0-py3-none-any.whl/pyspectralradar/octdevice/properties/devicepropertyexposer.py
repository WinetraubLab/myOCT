from pyspectralradar.base.submodule import Submodule
from pyspectralradar.octdevice.properties.devicepropertyflag import DevicePropertyFlag
from pyspectralradar.octdevice.properties.devicepropertyfloat import DevicePropertyFloat
from pyspectralradar.octdevice.properties.devicepropertyint import DevicePropertyInt
from pyspectralradar.octdevice.properties.devicepropertystring import DevicePropertyString
from pyspectralradar.octdevice.properties.devicestaticproperties import DeviceStaticFlagGetter, DeviceStaticFlagSetter


class DeviceProperties(Submodule):
    def __init__(self, handle):
        super().__init__(handle)
        self.str = DevicePropertyString(self.handle)
        self.int = DevicePropertyInt(self.handle)
        self.float = DevicePropertyFloat(self.handle)
        self.flag = DevicePropertyFlag(self.handle)


class DevicePropertyExposer:
    def __init__(self, dev_props: DeviceProperties):
        p_str = dev_props.str
        p_int = dev_props.int
        p_float = dev_props.float
        p_flag = dev_props.flag

        # string
        self.get_type = p_str.get_type
        self.get_series = p_str.get_series
        self.get_serial_number = p_str.get_serial_number
        self.get_hardware_config = p_str.get_hardware_config

        # int
        self.get_spectrum_elements = p_int.get_spectrum_elements
        self.get_bytes_per_element = p_int.get_bytes_per_element
        self.get_max_live_vol_scans = p_int.get_max_live_vol_scans
        self.get_rev_number = p_int.get_rev_number
        self.get_num_analog_input_channels = p_int.get_num_analog_input_channels
        self.get_min_spectra_per_buffer = p_int.get_min_spectra_per_buffer

        # float
        self.get_full_well_capacity = p_float.get_full_well_capacity
        self.get_z_spacing = p_float.get_z_spacing
        self.get_z_range = p_float.get_z_range
        self.get_signal_min_db = p_float.get_signal_min_db
        self.get_signal_low_db = p_float.get_signal_low_db
        self.get_signal_high_db = p_float.get_signal_high_db
        self.get_signal_max_db = p_float.get_signal_max_db
        self.get_bin_electron_scaling = p_float.get_bin_electron_scaling
        self.get_temperature = p_float.get_temperature
        self.get_sld_on_time_sec = p_float.get_sld_on_time_sec
        self.get_center_wavelength_nm = p_float.get_center_wavelength_nm
        self.get_spectral_width_nm = p_float.get_spectral_width_nm
        self.get_max_trigger_freq_hz = p_float.get_max_trigger_freq_hz
        self.get_line_rate_hz = p_float.get_line_rate_hz

        # flag
        self.get_on = p_flag.get_on
        self.get_sld_avail = p_flag.get_sld_avail
        self.get_sld_status = p_flag.get_sld_status
        self.get_laser_diode_status = p_flag.get_laser_diode_status
        self.get_probe_controller_avail = p_flag.get_probe_controller_avail
        self.get_data_signed = p_flag.get_data_signed
        self.get_swept_source = p_flag.get_swept_source
        self.get_analog_in_avail = p_flag.get_analog_in_avail
        self.get_has_master_board = p_flag.get_has_master_board
        self.get_has_control_board = p_flag.get_has_control_board
        self.get_sld_status_quick = p_flag.get_sld_status_quick

        # static
        self.get_power_control_avail = DeviceStaticFlagGetter.get_power_control_avail
        self.set_power_on = DeviceStaticFlagSetter.set_power_on
