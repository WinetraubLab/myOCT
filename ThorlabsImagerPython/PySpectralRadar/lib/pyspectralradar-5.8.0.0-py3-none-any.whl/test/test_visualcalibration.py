import unittest

from matplotlib import pyplot as plt

from pyspectralradar import ColoredData, OCTFile, OCTSystem, LogLevel, set_log_level
from pyspectralradar.visualcalibration import VisualCalibration

ENABLE_PLOTS = False
USE_DUMMY = True
HARDWARE_CONNECTED = False


class TestCaseVisualCalibration(unittest.TestCase):
    _sys = None
    _dev = None
    _probe = None
    _dut = None

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

        cls._sys = OCTSystem()
        cls._dev = cls._sys.dev
        cls._probe = cls._sys.probe_factory.create_default()
        cls._dut = VisualCalibration(cls._dev, cls._probe, 3.0, True, False)

    @classmethod
    def tearDownClass(cls):
        del cls._dut
        del cls._probe
        del cls._dev
        del cls._sys

    def test_1_create(self):
        self.assertIsInstance(self._dut, VisualCalibration)

    def test_2_status(self):
        print('#####################\n')
        print('Status: ', self._dut.status())
        self.assertEqual(self._dut.status(), '')
        print('#####################\n')

    @unittest.skipUnless(HARDWARE_CONNECTED, "Requires hardware")
    def test_3_first_calibration_step(self):

        if USE_DUMMY:
            file = OCTFile(
                "\\\\lbknetapp01\\Public\\Doc\\Software\\Unittests\\PySpectralRadarTests"
                "\\Unittests_VisualCalibration_Mode3D.oct")
            video_img = file.get_data_object(0)
        else:
            video_img = self._dev.camera.get_image()
        self.assertIsInstance(video_img, ColoredData)

        if ENABLE_PLOTS:
            plt.figure()
            plt.imshow(video_img.to_numpy()[:, :, 0])
            plt.show()

        self.assertTrue(self._dut.first_step_camera_scaling(video_img))
        print('Status: ', self._dut.status())
        self.assertEqual(self._dut.status(), 'Camera scaling calibrated successfully. ')

    def test_4_get_holes(self):
        x0, y0, x1, y1, x2, y2 = self._dut.get_holes()
        print(x0, y0, x1, y1, x2, y2)

    @unittest.skipUnless(HARDWARE_CONNECTED, "Requires hardware")
    def test_5_second_calibration_step(self):

        if USE_DUMMY:
            file = OCTFile(
                "\\\\lbknetapp01\\Public\\Doc\\Software\\Unittests\\PySpectralRadarTests"
                "\\Unittests_VisualCalibration_Mode3D.oct")
            video_img = file.get_data_object(0)
        else:
            video_img = self._dev.camera.get_image()
        self.assertIsInstance(video_img, ColoredData)

        self.assertTrue(self._dut.second_step_galvo(video_img))
        print('Status: ', self._dut.status())
        self.assertEqual(self._dut.status(), 'Galvo has been successfully calibrated. ')

    @unittest.skipUnless(HARDWARE_CONNECTED, "Requires hardware")
    def test_6_preview(self):
        preview_image = self._dut.preview()
        self.assertIsInstance(preview_image, ColoredData)
        print('Status: ', self._dut.status())
        self.assertEqual(self._dut.status(),
                         'The calibration sample has been successfully detected.\nPlease make sure the image is sharp.')

        if ENABLE_PLOTS:
            plt.figure()
            plt.imshow(preview_image.to_numpy()[:, :, 0])
            plt.show()


if __name__ == '__main__':
    unittest.main()
