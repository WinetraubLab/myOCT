import abc
from ctypes import c_int

from pyspectralradar.base import HasHandle
from pyspectralradar.spectralradar import c_handle, get_error


class Resizable(HasHandle):
    def resize(self, size1: int, size2: int, size3: int):
        """Resizes the specified raw data buffer accordingly.

        Notice that raw data refers to the spectra as acquired, without processing of any kind.

        Args:
            :size1: The desired number of data along the first axis (``z`` in the default orientation).
            :size2: The desired number of data along the second axis (``x`` in the default orientation).
            :size3: The desired number of data along the third axis (``y`` in the default orientation).
        """
        self._resize_func.argtypes = [c_handle, c_int, c_int, c_int]
        self._resize_func(self.handle, size1, size2, size3)
        get_error()

    @property
    @abc.abstractmethod
    def _resize_func(self):
        raise NotImplementedError
