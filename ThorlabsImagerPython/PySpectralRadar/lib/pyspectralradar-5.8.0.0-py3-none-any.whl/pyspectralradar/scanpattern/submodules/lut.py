from ctypes import c_char_p, c_int
from typing import Tuple

import numpy as np

from pyspectralradar.base import Submodule
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import ScanPointsDataFormat


class LUT(Submodule):

    def size(self) -> int:
        """Returns the number of points in the scan patterns look-up-table, including apodization and non-null.

        The look-up-table mentioned here is a table with the voltages that will be sent to the galvos. It is computed
        beforehand.

        Returns:
            The size of the look-up-table.
        """
        sr.getScanPatternLUTSize.argtypes = [c_handle]
        sr.getScanPatternLUTSize.restype = c_int
        res = sr.getScanPatternLUTSize(self.handle)
        get_error()
        return res

    def get(self) -> Tuple[np.ndarray, np.ndarray]:
        """Returns the voltages that will be applied to reach the positions to be scanned, in the scan pattern.

        The look-up-table mentioned here is a table with the voltages that will be sent to the galvos.
        It is computed beforehand and includes flyback-to-apo-position coordinates, apo-scans, apo-position-to-scan
        coordinates.

        Returns:
            A tuple (``volt_x``, ``volt_y``) containing a :class:`numpy` array ``volt_x`` in which the voltage for
            the X-positions will be written and a :class:`numpy` array ``volt_y`` in which the voltage for the
            Y-positions will be written
        """
        size = self.size()
        volt_x = np.empty(size)
        volt_y = np.empty(size)
        sr.getScanPatternLUT.argtypes = [c_handle,
                                         np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                         np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS')]
        sr.getScanPatternLUT(self.handle, volt_x, volt_y)
        get_error()
        return volt_x, volt_y

    def save_to_file(self, indices: np.ndarray[int], filename: str, format: ScanPointsDataFormat):
        """Saves the scan points and scan indices to a file with the specified format
        :class:`~pyspectralradar.types.scanpatterntypes.ScanPointsDataFormat`.

        Args:
            :indices: The array specifies the assignment of each point to its B-scan. It needs to have the length size
                with entries from 0 to number of (B-scans - 1). The number of B-scans is defined with the entries of
                indices. To save scan points for a 2D-pattern set all entries to zero.
            :filename: Path and name of the file containing the scan points and indices.
            :format: The specified scan point data format

        """
        assert isinstance(format, ScanPointsDataFormat)

        size = self.size()
        posx, posy = self.get()
        casted_indices = np.asarray(indices, dtype=np.int32)
        sr.saveScanPointsToFile.argtypes = [np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                            np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                            np.ctypeslib.ndpointer(dtype=np.int32, flags='F_CONTIGUOUS'),
                                            c_int, c_char_p, c_handle]
        sr.saveScanPointsToFile(posx,
                                posy,
                                casted_indices,
                                size, c_char_p(bytes(filename, encoding="ascii")), format)
        get_error()
