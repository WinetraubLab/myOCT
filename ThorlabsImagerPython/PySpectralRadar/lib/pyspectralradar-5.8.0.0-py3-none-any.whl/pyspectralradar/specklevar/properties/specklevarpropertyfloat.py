from enum import IntEnum

from pyspectralradar.base.propertygetter import FloatPropertyGetter
from pyspectralradar.base.propertysetter import FloatPropertySetter
from pyspectralradar.spectralradar import sr


class PropertyFloat(IntEnum):
    """Enum identifying different properties of typ float for speckle variance processing."""

    THRESHOLD = 0
    """Threshold used for processed data"""


class SpeckleVariancePropertyFloat(FloatPropertyGetter, FloatPropertySetter):

    def __init__(self, handle_get, handle_set):
        FloatPropertyGetter.__init__(self, handle_get, sr.getSpeckleVariancePropertyFloat)
        FloatPropertySetter.__init__(self, handle_set, sr.setSpeckleVariancePropertyFloat)

    def get_threshold(self) -> float:
        """Threshold used for processed data"""
        return self._get(PropertyFloat.THRESHOLD)

    def set_threshold(self, value: float):
        """Threshold used for processed data"""
        self._set(PropertyFloat.THRESHOLD, value)
