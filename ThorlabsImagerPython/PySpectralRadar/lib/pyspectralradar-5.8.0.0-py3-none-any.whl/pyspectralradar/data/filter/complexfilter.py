from ctypes import c_double, c_int

from pyspectralradar.base import Submodule
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import ComplexDataFilterType2D, DataDirection


class ComplexFilter(Submodule):
    def predefined_filter_2d(self, filter_type: ComplexDataFilterType2D, direction: DataDirection):
        """Applies the predefined 2D-Filter to the ComplexData

        Args:
            :filter_type: Chosen predefined filter for complex data. See
                :class:`~pyspectralradar.types.datatypes.ComplexDataFilterType2D` for selection.
            :direction: The normal of the direction the 2D-filter will be applied to the complex data, e.g. ``DIR3``
                for filtering each single B-scan
        """
        assert isinstance(filter_type, ComplexDataFilterType2D)
        assert isinstance(direction, DataDirection)
        sr.predefinedComplexFilter2D.argtypes = [c_handle, c_int, c_int]
        sr.predefinedComplexFilter2D(self.handle, filter_type, direction)
        get_error()

    def darkfield_filter_2d(self, radius: float, direction: DataDirection):
        """Filters the image such that the image contrast comes from light scattered by the sample.

        Args:
            :radius: Parameter to adjust the image contrast.
            :direction: The normal of the direction the 2D-filter will be applied to the complex data, e.g. ``DIR3``
                for filtering each single B-scan
        """
        assert isinstance(direction, DataDirection)
        sr.darkFieldComplexFilter2D.argtypes = [c_handle, c_double, c_int]
        sr.darkFieldComplexFilter2D(self.handle, radius, direction)
        get_error()

    def brightfield_filter_2d(self, radius: float, direction: DataDirection):
        """Filters the image such that the image contrast comes from absorbance of light in the sample.

        Args:
            :radius: Radius Parameter to adjust the image contrast.
            :direction: The normal of the direction the 2D-filter will be applied to the complex data, e.g. ``DIR3``
                for filtering each single B-scan
        """
        assert isinstance(direction, DataDirection)
        sr.brightFieldComplexFilter2D.argtypes = [c_handle, c_double, c_int]
        sr.brightFieldComplexFilter2D(self.handle, radius, direction)
        get_error()
