from abc import abstractmethod

from pyspectralradar.spectralradar import c_handle, get_error


class HasHandle:
    @property
    @abstractmethod
    def handle(self) -> c_handle:
        raise NotImplementedError


class HandleManager(HasHandle):
    """Work in progress base-class with the intention to successively replace the automatic property generation
    features by manual definitions"""

    @property
    @abstractmethod
    def _del_func(self):
        raise NotImplementedError

    @property
    def handle(self) -> c_handle:
        return c_handle(self._handle)

    def __init__(self, handle: c_handle | int | None):
        # Note: this strange looking casts deal with two issues:
        # 1. it makes the internal _handle None-able
        # 2: if not explicitly cast, python stores returned c_handles from dlls as int anyway.
        # Since Ints are longer than c_handle, this yielded unexpected errors when trying to use them again as
        # arguments for subsequent dll calls.
        self._handle = None
        if handle is None:
            return
        elif isinstance(handle, c_handle):
            self._handle = int(handle.value)
        elif isinstance(handle, int):
            self._handle = handle
        else:
            raise AttributeError

    def __del__(self):
        self._delete()

    def __enter__(self):
        return self.handle

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._delete()

    def _delete(self):
        if self._handle is None:
            return
        self._del_func.argtypes = [c_handle]
        self._del_func(self.handle)
        self._handle = None
        get_error()


class HandleManagerWithDefaultConstructor(HandleManager):
    @property
    @abstractmethod
    def _create_handle_func(self):
        raise NotImplementedError

    def __init__(self, handle: c_handle = None):
        if handle is None:
            handle = self._construct_empty_handle()
        super().__init__(handle)

    def _construct_empty_handle(self) -> c_handle:
        fun = self._create_handle_func
        fun.restype = c_handle
        handle = fun()
        get_error()
        return handle
