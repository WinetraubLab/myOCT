from __future__ import annotations

from ctypes import *

from pyspectralradar.base import HandleManagerWithDefaultConstructor
from pyspectralradar.data import ComplexData, RealData
from pyspectralradar.probe import Probe
from pyspectralradar.scanpattern import ScanPattern
from pyspectralradar.spectralradar import c_handle, get_error, sr


class ImageField(HandleManagerWithDefaultConstructor):
    """Holds the image field data"""

    @property
    def _create_handle_func(self):
        return sr.createImageField

    def __init__(self, handle: c_handle = None):
        super().__init__(handle)

    @property
    def _del_func(self):
        """Frees an object holding image field data.

        If the handle is a nullptr, this function does nothing.
        """
        return sr.clearImageField

    @classmethod
    def from_probe(cls, probe: Probe) -> ImageField:
        """Creates an object holding image field data from the specified probe.

        Args:
            :probe: A valid (non-null) :class:`~pyspectralradar.probe.probe.Probe` object.

        Returns:
            A newly created :class:`ImageField` object.
        """
        sr.createImageFieldFromProbe.argtypes = [c_handle]
        sr.createImageFieldFromProbe.restype = c_handle
        handle = sr.createImageFieldFromProbe(probe.handle)
        res = cls(handle)
        get_error()
        return res

    def save(self, filename: str):
        """Saves data containing image field data.

        Args:
            :filename: Filename (including path), where the data will be saved. If the file exists, it will be (
                merciless) overwritten.
        """
        sr.saveImageField.argtypes = [c_handle, c_char_p]
        sr.saveImageField(self.handle, c_char_p(bytes(filename, encoding="ascii")))
        get_error()

    def load(self, filename: str):
        """Loads data containing image field data.

        Args:
            :filename: Filename (including path), where the data will be read from.
        """
        sr.loadImageField.argtypes = [c_handle, c_char_p]
        sr.loadImageField(self.handle, c_char_p(bytes(filename, encoding="ascii")))
        get_error()

    def determine(self, pattern: ScanPattern, surface: RealData):
        """Determines the image field correction for the given surface data, previously measured with the given scan
        pattern.

        The purpose of the image field is to compensate the deformations introduced by the optical elements (e.g.
        lenses). To that end, a measurement of the substrate surface is carried out, and the geometric correction is
        computed. The default calibration of an instrument needs not be re-computed, unless a new objective is
        installed, or the objective is the same but the desired reference surface is non-planar (the user must supply
        the desired surface, which should actually be measured).

        Args:
            :pattern: A valid (non-null) volume :class:`~pyspectralradar.scanpattern.scanpattern.ScanPattern` object,
                created with one of the functions
                :func:`~pyspectralradar.scanpattern.scanpatternfactory.ScanPatternFactory.create_volume_pattern`,
                :func:`~pyspectralradar.scanpattern.scanpatternfactory.ScanPatternFactory
                .create_freeform_pattern_3D_from_LUT`, or
                :func:`~pyspectralradar.scanpattern.scanpatternfactory.ScanPatternFactory.create_freeform_pattern_3D`.
                The scan pattern should uniformly cover the whole field of view.

                :Warning: If the scan pattern is not uniform, or fails to cover some areas, the resulting image
                    field corrections will be impaired. The scan pattern enables the conversion between index
                    coordinates [i,j] and physical coordinates (in millimeter). Hence, it should be a scan pattern that
                    covers the coordinates of the ``surface``.

            :surface: A 2D data array, stored in a :class:`~pyspectralradar.data.realdata.RealData` object structure,
                whose entries are the depth of the surface at each (x,y) coordinate, expressed in millimeter. The
                surface can be calculated from a volume scan using
                :func:`~pyspectralradar.data.analysis.dataanalysis.DataAnalysis.determine_surface`. Notice that,
                unlike scans, the first coordinate is the x-axis and the second coordinate is the y-axis.
        """
        sr.determineImageField.argtypes = [c_handle, c_handle, c_handle]
        sr.determineImageField(self.handle, pattern.handle, surface.handle)
        get_error()

    def determine_with_mask(self, pattern: ScanPattern, surface: RealData, mask: RealData):
        """Determines the image field correction for the given surface data, previously measured with the given scan
        pattern. The positive entries of the mask determine the points that actually enter the computation.

        The purpose of the image field is to compensate the deformations introduced by the optical elements (e.g.
        lenses). To that end, a measurement of the substrate surface is carried out, and the geometric correction is
        computed. The default calibration of an instrument needs not be re-computed, unless a new objective is
        installed, or the objective is the same but the desired reference surface is non-planar (the user must supply
        the desired surface, which should actually be measured). This function checks that the first two dimensions
        (in pixels) of ``surface`` and ``mask`` match each other.

        Args:
            :pattern: A valid (non-null) handle of a volume
                :class:`~pyspectralradar.scanpattern.scanpattern.ScanPattern`, created with one of the functions
                :func:`~pyspectralradar.scanpattern.scanpatternfactory.ScanPatternFactory.create_volume_pattern`,
                :func:`~pyspectralradar.scanpattern.scanpatternfactory.ScanPatternFactory
                .create_freeform_pattern_3D_from_LUT`, or
                :func:`~pyspectralradar.scanpattern.scanpatternfactory.ScanPatternFactory
                .create_freeform_pattern_3D`. The scan pattern should uniformly cover the whole field of view.

                :Warning: If the scan pattern is non-uniform, or fails to cover some areas, the resulting image
                    field corrections will be impaired. The scan pattern enables the conversion between index
                    coordinates [i,j] and physical coordinates (in millimeter). Hence, it should be a scan pattern
                    that covers the coordinates of the ``surface``.
            :surface: A 2D data array, stored in a :class:`~pyspectralradar.data.realdata.RealData` structure,
                whose entries are the depth of the surface at each (x,y) coordinate, expressed in millimeter. The
                surface can be calculated from a volume scan using the function
                :func:`~pyspectralradar.data.analysis.dataanalysis.DataAnalysis.determine_surface`.
                Notice that, unlike scans, the first coordinate is the x-axis and the second coordinate is the y-axis.
            :mask: A 2D data array, stored in a :class:`~pyspectralradar.data.realdata.RealData` object, indicating
                which points of the ``surface`` should be taken into account (positive entries in ``mask``). Negative
                entries in ``mask`` identify points of the ``surface`` which should not be considered in the
                computation. Notice that the entries are single-precision floating-point numbers. In case a 3D data
                structure is passed, only the first slice will be used (index zero along the third ``Direction``).
        """
        sr.determineImageFieldWithMask.argtypes = [c_handle, c_handle, c_handle, c_handle]
        sr.determineImageFieldWithMask(self.handle, pattern.handle, surface.handle, mask.handle)
        get_error()

    def set_in_probe(self, probe: Probe):
        """Sets the specified image field to the specified :class:`~pyspectralradar.probe.probe.Probe` handle.

        Notice that no probe file will be automatically saved.

        Args:
            :probe: A valid (non-null) :class:`~pyspectralradar.probe.probe.Probe` object.
        """
        sr.setImageFieldInProbe.argtypes = [c_handle, c_handle]
        sr.setImageFieldInProbe(self.handle, probe.handle)
        get_error()

    def apply(self, pattern: ScanPattern, data: RealData | ComplexData):
        """Applies the image field correction to the given B-Scan or volume data in-place.

        Args:
            :pattern: A valid (non-null) handle of a volume
                :class:`~pyspectralradar.scanpattern.scanpattern.ScanPattern` object. This scan pattern should be the
                one used to acquire the `data`, because the correction depends on the measurement coordinates. The
                scan pattern enables the conversion between index coordinates (i,j) and physical coordinates (in
                millimeter). Hence, it should be a scan pattern that covers the coordinates of the ``data`` (second
                parameter). Notice that the final table of positions is needed (see the detailed explanation).
            :data: A valid (non-null) handle of a :class:`~pyspectralradar.data.realdata.RealData` or
                :class:`~pyspectralradar.data.complexdata.ComplexData` object. Pointing to data measured (acquired
                and processed) in a B-scan or in a volume scan.

        The different scan-pattern creation functions compute both the coordinates of the scan and the connections
        between the scan parts. However, those functions do not build the final table of coordinates. The reason is
        that many scan patterns may be created separately, and then stacked together. The individual creation
        functions know nothing about the big picture. Before the acquisition actually starts, a final table of
        coordinates should be written, consolidating all involved parts. This is accomplished by the function 
        :func:`~pyspectralradar.scanpattern.scanpattern.ScanPattern.update`. That function is invoked automatically
        before every start of a measurement.
        Hence, most users do not need to invoke it at all. However, if the user loads an OCT file containing raw
        data, and a processing that depends on the coordinates is attempted (as it is the case here), then the final
        table of positions should be written, because only at that point the coordinates are placed in exactly the same
        sequence as they were during the acquisition. The image-field correction is an example of coordinates-dependent
        processing.
        """
        if isinstance(data, RealData):
            sr.correctImageField.argtypes = [c_handle, c_handle, c_handle]
            sr.correctImageField(self.handle, pattern.handle, data.handle)
        if isinstance(data, ComplexData):
            sr.correctImageFieldComplex.argtypes = [c_handle, c_handle, c_handle]
            sr.correctImageFieldComplex(self.handle, pattern.handle, data.handle)
        get_error()

    def apply_on_surface(self, pattern: ScanPattern, surface: RealData):
        """Applies the image field correction to the given surface. Surface must contain depth values as a function of
        x/y coordinates.

        Args:
            :pattern: A valid (non-null) handle of a volume
                :class:`~pyspectralradar.scanpattern.scanpattern.ScanPattern`. This scan pattern should be the one
                used to acquire the ``surface``, because the correction depends on the measurement coordinates.The
                scan pattern enables the conversion between index coordinates (i,j) and physical coordinates (in
                millimeter). Hence, it should be a scan pattern that covers the coordinates of the `surface` (second
                parameter). Notice that the final table of positions is needed (see the detailed explanation).
            :surface: A 2D data array, stored in a :class:`~pyspectralradar.data.realdata.RealData` structure,
                whose entries are the depth of the surface at each (x,y) coordinate, expressed in millimeter. The
                surface can be calculated from a volume scan using the function
                :func:`~pyspectralradar.data.analysis.dataanalysis.DataAnalysis.determine_surface`.
                Notice that, unlike scans, the first coordinate is the x-axis and the second coordinate is the y-axis.

        The different scan-pattern creation functions compute both the coordinates of the scan and the connections
        between the scan parts. However, those functions do not build the final table of coordinates. The reason is
        that many scan patterns may be created separately, and then stacked together. The individual creation
        functions know nothing about the big picture. Before the acquisition actually starts, a final table of
        coordinates should be written, consolidating all involved parts. This is accomplished by the function 
        :func:`~pyspectralradar.scanpattern.scanpattern.ScanPattern.update`. That function is invoked automatically
        before every start of a measurement.
        Hence, most users do not need to invoke it at all. However, if the user loads an OCT file containing raw
        data, and a processing that depends on the coordinates is attempted (as it is the case here), then the final
        table of positions should be written, because only at that point the coordinates are placed in exactly the same
        sequence as they were during the acquisition. The image-field correction is an example of coordinates-dependent
        processing.
        """
        sr.correctSurface.argtypes = [c_handle, c_handle, c_handle]
        sr.correctSurface(self.handle, pattern.handle, surface.handle)
        get_error()
