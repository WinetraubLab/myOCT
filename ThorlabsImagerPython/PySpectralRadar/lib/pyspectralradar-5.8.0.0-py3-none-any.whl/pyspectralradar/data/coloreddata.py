from __future__ import annotations

import numpy as np

from pyspectralradar.data.base import AbstractProcessedData
from pyspectralradar.data.utility import ColoredDataFileIo
from pyspectralradar.spectralradar import sr


class ColoredData(AbstractProcessedData, ColoredDataFileIo):

    @property
    def _int_get(self):
        return sr.getColoredDataPropertyInt

    @property
    def _float_get(self):
        return sr.getColoredDataPropertyFloat

    @property
    def _create_handle_func(self):
        return sr.createColoredData

    @property
    def _del_func(self):
        return sr.clearColoredData

    @property
    def _c_crop_func(self):
        return sr.cropColoredData

    @property
    def _c_append_func(self):
        return sr.appendColoredData

    @property
    def _resize_func(self):
        return sr.resizeColoredData

    @property
    def _set_data_range_func(self):
        return sr.setColoredDataRange

    @property
    def _pointer_func(self):
        return sr.getColoredDataPtr

    @property
    def _reserve_func(self):
        return sr.reserveColoredData

    @property
    def _set_data_content_func(self):
        return sr.setColoredDataContent

    @property
    def _copy_func(self):
        return sr.copyColoredData

    @property
    def _copy_content_func(self):
        return sr.copyColoredDataContent

    @property
    def _np_data_type(self):
        return np.uint32

    @property
    def _orientation_get(self):
        return sr.getColoredDataOrientation

    @property
    def _orientation_set(self):
        return sr.setColoredDataOrientation

    @property
    def _get_slice_at_pos_func(self):
        return sr.getColoredDataSlicePos

    @property
    def _get_slice_at_index_func(self):
        return sr.getColoredDataSliceIndex

    @property
    def _separate_func(self):
        return sr.separateColoredData

    @property
    def _flip_func(self):
        return sr.flipColoredData
