import abc
from typing import Tuple

from pyspectralradar.data.properties.datapropertyfloat import DataPropertyFloatGetter
from pyspectralradar.data.properties.datapropertyint import DataPropertyIntGetter
from pyspectralradar.data.utility import IShapeProperties
from pyspectralradar.spectralradar import c_handle


class DataPropertyExposer(IShapeProperties):
    @property
    @abc.abstractmethod
    def _int_get(self):
        raise NotImplementedError

    @property
    @abc.abstractmethod
    def _float_get(self):
        raise NotImplementedError

    def __init__(self, handle: c_handle):
        self._property_int: DataPropertyIntGetter = DataPropertyIntGetter(handle, self._int_get)
        self._property_float: DataPropertyFloatGetter = DataPropertyFloatGetter(handle, self._float_get)

    """---- CommonTensorProperties ----"""

    @property
    def shape(self):
        return self._property_int.get_size1(), self._property_int.get_size2(), self._property_int.get_size3()

    @property
    def size(self):
        return self._property_int.get_number_of_elements()

    @property
    def size_bytes(self):
        return self._property_int.get_size_bytes()

    @property
    def bytes_per_element(self):
        return self._property_int.get_bytes_per_element()

    """---- int properties ----"""

    @property
    def ndim(self) -> int:
        """Dimension of the data object. Usually 1, 2 or 3. 0 indicates empty data."""
        return self._property_int.get_dimensions()

    """---- float properties ----"""

    @property
    def spacing(self) -> Tuple[float, float, float]:
        pfl = self._property_float
        return pfl.get_spacing1(), pfl.get_spacing2(), pfl.get_spacing3()

    @property
    def range(self) -> Tuple[float, float, float]:
        pfl = self._property_float
        return pfl.get_range1(), pfl.get_range2(), pfl.get_range3()
