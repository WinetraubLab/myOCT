from __future__ import annotations

from ctypes import c_bool, c_double, c_float, c_int, c_ulong
from typing import Tuple

import numpy as np

from pyspectralradar.base import HandleManager
from pyspectralradar.data import ColoredData, RealData
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import ByteOrder, ColorEnhancement, ColorScheme


class Coloring(HandleManager):
    """A class for routines that color available scans for displaying"""

    def __init__(self, colorscheme: ColorScheme, byteorder: ByteOrder = ByteOrder.RGBA):
        """Creates processing that can be used to color given floating point B-scans to 32 bit colored images.

        Args:
            :colorscheme: The color-table to be used
            :byteorder: The byte order the coloring is supposed to use.

        """
        assert isinstance(colorscheme, ColorScheme)
        assert isinstance(byteorder, ByteOrder)
        sr.createColoring32Bit.restype = c_handle
        sr.createColoring32Bit.argtypes = [c_int, c_int]
        handle = c_handle(sr.createColoring32Bit(colorscheme, byteorder))
        super().__init__(handle)
        get_error()

    @classmethod
    def from_lut(cls, lut: np.ndarray) -> Coloring:
        """Create custom coloring using the specified color look-up-table.

        Args:
            :lut: The look-up-table that shall read from.

        Returns:
            :class:`~pyspectralradar.coloring.coloring.Coloring` object containing coloring from look-up-table
        """
        res = cls.__new__(cls)
        lut_size = len(lut)
        casted_lut = np.asarray(lut, dtype=c_ulong)
        sr.createCustomColoring32Bit.argtypes = [c_int, np.ctypeslib.ndpointer(dtype=c_ulong, flags='F_CONTIGUOUS')]
        sr.createCustomColoring32Bit.restype = c_handle
        res._handle = sr.createCustomColoring32Bit(lut_size, casted_lut)
        get_error()
        return res

    @property
    def _del_func(self):
        return sr.clearColoring

    def set_boundaries(self, lower_db: float, upper_db: float):
        """Sets the boundaries in dB which are used by the coloring algorithm to map colors to floating point values in
        dB.

        Args:
            :lower_db: The lower boundary in dB
            :upper_db: The upper boundary in dB
        """
        sr.setColoringBoundaries.argtypes = [c_handle, c_float, c_float]
        sr.setColoringBoundaries(self.handle, lower_db, upper_db)
        get_error()

    def enhance(self, enhancement: ColorEnhancement):
        """Selects a function for non-linear coloring to enhance (subjective) image impression.

        Args:
            :enhancement: Selects the byte order of the coloring to be applied

        """
        assert isinstance(enhancement, ColorEnhancement)
        sr.setColoringEnhancement.argtypes = [c_handle, c_int]
        sr.setColoringEnhancement(self.handle, enhancement)
        get_error()

    def colorize(self, data_in: RealData, transpose: bool = False,
                 out_buffer: ColoredData | None = None) -> ColoredData:
        """Colors a given :class:`~pyspectralradar.data.realdata.RealData` object into a (optionally given)
        :class:`~pyspectralradar.data.coloreddata.ColoredData` object.

        Args:
            :data_in: The :class:`~pyspectralradar.data.realdata.RealData` object that shall be colorized
            :out_buffer (optional): :class:`~pyspectralradar.data.coloreddata.ColoredData` object that holds the
                colorized data; if none is given, a new object will be created and returned
            :transpose: Returned data will be transposed if ``True``. Set to False per default

        Returns:
            The colorized :class:`~pyspectralradar.data.coloreddata.ColoredData` object.
        """
        assert isinstance(data_in, RealData)
        if out_buffer is None:
            out_buffer = ColoredData()
        else:
            assert isinstance(out_buffer, ColoredData)
        sr.colorizeData.argtypes = [c_handle, c_handle, c_handle, c_bool]
        sr.colorizeData(self.handle, data_in.handle, out_buffer.handle, transpose)
        get_error()
        return out_buffer

    @staticmethod
    def colorize_doppler(amp_coloring: Coloring, phase_coloring: Coloring | Tuple[Coloring, Coloring],
                         amp_data: RealData, phase_data: RealData, min_signal: float,
                         transpose: bool = False) -> ColoredData:
        """Colors a given :class:`~pyspectralradar.data.realdata.RealData` object using overlay and intensity to
        represent phase and amplitude data.

        Used for Doppler imaging.
        In the extended version, two :class:`Coloring` objects can be specified, to provide different coloring for
        increasing and decreasing phase, for example.

        Args:
            :amp_coloring: :class:`Coloring` object used for amplitude data
            :phase_coloring: :class:`Coloring` object used for phase data
            :amp_data: :class:`~pyspectralradar.data.realdata.RealData` object containing the amplitude data
            :phase_data: :class:`~pyspectralradar.data.realdata.RealData` object containing the phase data
            :min_signal: Threshold
            :transpose: Returned data will be transposed if ``True``. Set to False per default

        Returns:
            The colorized doppler data as :class:`~pyspectralradar.data.coloreddata.ColoredData` object
        """
        output = ColoredData()
        if type(phase_coloring) is tuple:
            sr.colorizeDopplerDataEx.argtypes = [c_handle, c_handle, c_handle, c_handle, c_handle, c_double, c_bool]
            sr.colorizeDopplerDataEx(amp_coloring.handle, (phase_coloring[0].handle, phase_coloring[1].handle),
                                     amp_data.handle, phase_data.handle, output.handle, min_signal, transpose)
        else:
            sr.colorizeDopplerData.argtypes = [c_handle, c_handle, c_handle, c_handle, c_handle, c_double, c_bool]
            sr.colorizeDopplerData(amp_coloring.handle, phase_coloring.handle,
                                   amp_data.handle, phase_data.handle, output.handle, min_signal, transpose)
        get_error()
        return output


def get_rgb_values(colored_array: np.ndarray) -> np.ndarray:
    """Converts the result from :func:`ColoredData.to_numpy` into an actual r, g,
    b split array

        Args:
            :colored_array: From :class:`~pyspectralradar.data.coloreddata.ColoredData` extracted :class:`numpy` array

        Returns:
            R, g, b  split :class:`numpy` array.
        """
    if not isinstance(colored_array, np.ndarray):
        raise ValueError("Input must be a NumPy array")

    r = (colored_array & 0x00FF0000) >> 16
    g = (colored_array & 0x0000FF00) >> 8
    b = colored_array & 0x000000FF

    rgb_values = np.concatenate([r, g, b], axis=-1)
    return rgb_values


def get_rgba_values(colored_array: np.ndarray, byte_order: ByteOrder) -> np.ndarray:
    """Converts the result from :func:`ColoredData.to_numpy` into an actual r, g,
    b, a split array

    Args:
        colored_array: From :class:`~pyspectralradar.data.coloreddata.ColoredData` extracted :class:`numpy` array
        byte_order: The byte order the coloring is supposed to use.

    Returns:
        Depending on byte_order split :class:`numpy` array.
    """
    if not isinstance(colored_array, np.ndarray):
        raise ValueError("Input must be a NumPy array")

    a = r = g = b = 0
    if byte_order == 0 or 2:
        a = (colored_array & 0xFF000000) >> 24
        r = (colored_array & 0x00FF0000) >> 16
        g = (colored_array & 0x0000FF00) >> 8
        b = colored_array & 0x000000FF
    elif byte_order == 1:
        a = (colored_array & 0xFF000000)
        r = (colored_array & 0x000000FF) << 16
        g = (colored_array & 0x0000FF00)
        b = (colored_array & 0x00FF0000) >> 16

    res = np.concatenate([r, g, b, a], axis=-1)

    return res
