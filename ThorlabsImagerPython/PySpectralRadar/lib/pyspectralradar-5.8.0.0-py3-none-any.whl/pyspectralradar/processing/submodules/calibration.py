from __future__ import annotations

from ctypes import c_char_p, c_int

from pyspectralradar.base import Submodule
from pyspectralradar.data import RealData
from pyspectralradar.octfile import OCTFile
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import CalibrationType


class Calibration(Submodule):
    def set(self, calibration_type: CalibrationType, data: RealData):
        """Sets the calibration data.

        Args:
            :calibration_type: Indicates the calibration that will be set.
            :data: Data object that will hold the calibration data
        """
        assert isinstance(calibration_type, CalibrationType)
        sr.setCalibration.argtypes = [c_handle, c_int, c_handle]
        sr.setCalibration(self.handle, calibration_type, data.handle)
        get_error()

    def get(self, calibration_type: CalibrationType) -> RealData:
        """Retrieves the desired calibration vector.

        Args:
            :calibration_type: Indicates the calibration that will be received.

        Returns:
            A valid data object of the calibration data that will be retrieved. The resulting data will be
            automatically resized for the data to fit in the structure.
        """
        assert isinstance(calibration_type, CalibrationType)
        data = RealData()
        sr.getCalibration.argtypes = [c_handle, c_int, c_handle]
        sr.getCalibration(self.handle, calibration_type, data.handle)
        get_error()
        return data

    def save(self, calibration_type: CalibrationType, camera_idx: int = 0, path: str = ""):
        """Saves the selected calibration in its default path or defined path, for the selected camera.

        The default path will be used by SpectralRadar in subsequent executions to retrieve the calibration data.
        Warning: This will override your default calibration of the device.

        This function will only save calibration data pertaining to the selected camera. To save the calibration of all
        cameras, multiple invocations are needed. the order plays no role.

        Args:
            :calibration_type: Indicates the calibration that will be saved.
            :camera_idx: The camera index (0-based, i.e. zero for the first, one for the second, and so on).
            :path: A zero terminated string specifying the filename, including full path.
        """
        assert isinstance(calibration_type, CalibrationType)
        if path == "":
            sr.saveCalibrationDefaultEx.argtypes = [c_handle, c_int, c_int]
            sr.saveCalibrationDefaultEx(self.handle, calibration_type, c_int(camera_idx))
        else:
            sr.saveCalibration.argtypes = [c_handle, c_int, c_char_p]
            sr.saveCalibration(self.handle, calibration_type, c_char_p(bytes(path, encoding="ascii")))
        get_error()

    def load(self, calibration_type: CalibrationType, path: str):
        """Will load a specified calibration file and its content will be used for subsequent processing.

        Args:
            :calibration_type: Indicates the calibration that will be loaded.
            :path: A zero terminated string specifying the filename, including full path.
        """
        assert isinstance(calibration_type, CalibrationType)
        sr.loadCalibration.argtypes = [c_handle, c_int, c_char_p]
        sr.loadCalibration(self.handle, calibration_type, c_char_p(bytes(path, encoding="ascii")))
        get_error()

    def load_from_oct_file(self, file: OCTFile, camera_idx=0):
        """Loads Chirp, Offset, and Apodization vectors from the given OCT file into the given processing object.

        Args:
            :file: The OCT file that shall be read from
            :camera_idx: The camera index (0-based, i.e. zero for the first, one for the second, and so on).
        """
        sr.loadCalibrationFromFileEx.argtypes = [c_handle, c_handle, c_int]
        sr.loadCalibrationFromFileEx(file.handle, self.handle, camera_idx)
        get_error()

    def save_to_oct_file(self, file: OCTFile, camera_idx=0):
        """Saves Chirp, Offset, and Apodization vectors from the given processing object into the given OCT file.

        Args:
            :file: The OCT file the data shall be saved to
            :camera_idx: The camera index (0-based, i.e. zero for the first, one for the second, and so on).
        """
        sr.saveCalibrationToFileEx.argtypes = [c_handle, c_handle, c_int]
        sr.saveCalibrationToFileEx(file.handle, self.handle, camera_idx)
        get_error()
