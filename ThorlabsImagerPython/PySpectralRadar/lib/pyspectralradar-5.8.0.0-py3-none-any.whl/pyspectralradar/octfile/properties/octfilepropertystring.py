from enum import IntEnum

from pyspectralradar.base.propertygetter import StringPropertyGetter
from pyspectralradar.base.propertysetter import StringPropertySetter
from pyspectralradar.spectralradar import sr


class MetadataString(IntEnum):
    """Enum identifying file metadata fields of character string type"""

    DEVICE_SERIES = 0
    """Name of the OCT device series."""

    DEVICE_NAME = 1
    """Name of the OCT device."""

    SERIAL = 2
    """Serial number of the OCT device."""

    COMMENT = 3
    """Comment of the OCT data file."""

    CUSTOM_INFO = 4
    """Additional, custom info"""

    ACQUISITION_MODE = 5
    """Acquisition mode of the OCT data file."""

    STUDY = 6
    """Study of the OCT data file."""

    DISPERSION_PRESET = 7
    """Dispersion Preset of the OCT data file."""

    PROBE_NAME = 8
    """Name of the probe."""

    FREEFORM_SCAN_PATTERN_INTERPOLATION = 9

    HARDWARE_CONFIG = 10

    ORIG_VERSION = 11

    LAST_MOD_VERSION = 12

    ANALOG_INPUT_ACTIVE_CHANNELS = 13
    """Comma separated list of active channels"""

    ANALOG_INPUT_CHANNEL_NAMES = 14
    """Comma separated list of input channel descriptions"""


class OCTFilePropertyString(StringPropertyGetter, StringPropertySetter):

    def __init__(self, handle):
        StringPropertyGetter.__init__(self, handle, sr.getFileMetadataString)
        StringPropertySetter.__init__(self, handle, sr.setFileMetadataString)

    def get_device_series(self) -> str:
        """Name of the OCT device series."""
        return self._get(MetadataString.DEVICE_SERIES)

    def set_device_series(self, value: str):
        """Name of the OCT device series."""
        self._set(MetadataString.DEVICE_SERIES, value)

    def get_device_name(self) -> str:
        """Name of the OCT device."""
        return self._get(MetadataString.DEVICE_NAME)

    def set_device_name(self, value: str):
        """Name of the OCT device."""
        self._set(MetadataString.DEVICE_NAME, value)

    def get_serial(self) -> str:
        """Serial number of the OCT device."""
        return self._get(MetadataString.SERIAL)

    def set_serial(self, value: str):
        """Serial number of the OCT device."""
        self._set(MetadataString.SERIAL, value)

    def get_comment(self) -> str:
        """Comment of the OCT data file."""
        return self._get(MetadataString.COMMENT)

    def set_comment(self, value: str):
        """Comment of the OCT data file."""
        self._set(MetadataString.COMMENT, value)

    def get_custom_info(self) -> str:
        """Additional, custom info"""
        return self._get(MetadataString.CUSTOM_INFO)

    def set_custom_info(self, value: str):
        """Additional, custom info"""
        self._set(MetadataString.CUSTOM_INFO, value)

    def get_acquisition_mode(self) -> str:
        """Acquisition mode of the OCT data file."""
        return self._get(MetadataString.ACQUISITION_MODE)

    def set_acquisition_mode(self, value: str):
        """Acquisition mode of the OCT data file."""
        self._set(MetadataString.ACQUISITION_MODE, value)

    def get_study(self) -> str:
        """Study of the OCT data file."""
        return self._get(MetadataString.STUDY)

    def set_study(self, value: str):
        """Study of the OCT data file."""
        self._set(MetadataString.STUDY, value)

    def get_dispersion_preset(self) -> str:
        """Dispersion Preset of the OCT data file."""
        return self._get(MetadataString.DISPERSION_PRESET)

    def set_dispersion_preset(self, value: str):
        """Dispersion Preset of the OCT data file."""
        self._set(MetadataString.DISPERSION_PRESET, value)

    def get_probe_name(self) -> str:
        """Name of the probe."""
        return self._get(MetadataString.PROBE_NAME)

    def set_probe_name(self, value: str):
        """Name of the probe."""
        self._set(MetadataString.PROBE_NAME, value)

    def get_freeform_scan_pattern_interpolation(self) -> str:
        """"""
        return self._get(MetadataString.FREEFORM_SCAN_PATTERN_INTERPOLATION)

    def set_freeform_scan_pattern_interpolation(self, value: str):
        """"""
        self._set(MetadataString.FREEFORM_SCAN_PATTERN_INTERPOLATION, value)

    def get_hardware_config(self) -> str:
        """"""
        return self._get(MetadataString.HARDWARE_CONFIG)

    def set_hardware_config(self, value: str):
        """"""
        self._set(MetadataString.HARDWARE_CONFIG, value)

    def get_orig_version(self) -> str:
        """"""
        return self._get(MetadataString.ORIG_VERSION)

    def set_orig_version(self, value: str):
        """"""
        self._set(MetadataString.ORIG_VERSION, value)

    def get_last_mod_version(self) -> str:
        """"""
        return self._get(MetadataString.LAST_MOD_VERSION)

    def set_last_mod_version(self, value: str):
        """"""
        self._set(MetadataString.LAST_MOD_VERSION, value)

    def get_analog_input_active_channels(self) -> str:
        """Comma separated list of active channels"""
        return self._get(MetadataString.ANALOG_INPUT_ACTIVE_CHANNELS)

    def set_analog_input_active_channels(self, value: str):
        """Comma separated list of active channels"""
        self._set(MetadataString.ANALOG_INPUT_ACTIVE_CHANNELS, value)

    def get_analog_input_channel_names(self) -> str:
        """Comma separated list of input channel descriptions"""
        return self._get(MetadataString.ANALOG_INPUT_CHANNEL_NAMES)

    def set_analog_input_channel_names(self, value: str):
        """Comma separated list of input channel descriptions"""
        self._set(MetadataString.ANALOG_INPUT_CHANNEL_NAMES, value)
