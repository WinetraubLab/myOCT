from __future__ import annotations

from enum import IntEnum


class SpeckleVarianceType(IntEnum):
    """Enum identifying different speckle variance processing types."""

    LOG_SCALE_VAR_LINEAR = 0
    """Log-scale speckle variance with linear output"""

    LOG_SCALE_VAR_LOG = 1
    """Log-scale speckle variance with log-scale output"""

    LINEAR_VAR_LINEAR = 2
    """Linear speckle variance with linear output"""

    LINEAR_VAR_LOG = 3
    """Linear speckle variance with log-scale output"""

    COMPLEX_VAR_LINEAR = 4
    """Complex speckle variance with linear output"""

    COMPLEX_VAR_LOG = 5
    """Complex speckle variance with log-scale output"""
