from enum import IntEnum

from pyspectralradar.base.propertygetter import FloatPropertyGetter
from pyspectralradar.base.propertysetter import CFloatPropertySetter
from pyspectralradar.spectralradar import sr


class PropertyFloat(IntEnum):
    """Enum Values that determine the behaviour of the Doppler processing routines."""

    REFRACTIVE_INDEX = 0
    """Refractive index to be considered for Doppler evaluation"""

    SCAN_RATE_HZ = 1
    """Scan Rate (in Hz) that was used to acquire the Doppler data to be processed. This is only required for
       computing the actual velocity scaling"""

    CENTER_WAVELENGTH_NM = 2
    """Center Wavelength (in nanometers) that was used to acquire the Doppler data to be processed. This is only
       required for computing the actual velocity scaling"""

    DOPPLER_ANGLE_DEG = 3
    """Angle of the Doppler detection beam to the normal. This is only required for computing the actual velocity
       scaling"""


class DopplerPropertyFloat(FloatPropertyGetter, CFloatPropertySetter):
    def __init__(self, handle1, handle2):
        FloatPropertyGetter.__init__(self, handle1, sr.getDopplerPropertyFloat)
        CFloatPropertySetter.__init__(self, handle2, sr.setDopplerPropertyFloat)

    def get_refractive_index(self) -> float:
        """Refractive index to be considered for Doppler evaluation"""
        return self._get(PropertyFloat.REFRACTIVE_INDEX)

    def set_refractive_index(self, value: float):
        """Refractive index to be considered for Doppler evaluation"""
        self._set(PropertyFloat.REFRACTIVE_INDEX, value)

    def get_scan_rate_hz(self) -> float:
        """Scan Rate (in Hz) that was used to acquire the Doppler data to be processed. This is only required for
       computing the actual velocity scaling"""
        return self._get(PropertyFloat.SCAN_RATE_HZ)

    def set_scan_rate_hz(self, value: float):
        """Scan Rate (in Hz) that was used to acquire the Doppler data to be processed. This is only required for
       computing the actual velocity scaling"""
        self._set(PropertyFloat.SCAN_RATE_HZ, value)

    def get_center_wavelength_nm(self) -> float:
        """Center Wavelength (in nanometers) that was used to acquire the Doppler data to be processed. This is only
       required for computing the actual velocity scaling"""
        return self._get(PropertyFloat.CENTER_WAVELENGTH_NM)

    def set_center_wavelength_nm(self, value: float):
        """Center Wavelength (in nanometers) that was used to acquire the Doppler data to be processed. This is only
       required for computing the actual velocity scaling"""
        self._set(PropertyFloat.CENTER_WAVELENGTH_NM, value)

    def get_doppler_angle_deg(self) -> float:
        """Angle of the Doppler detection beam to the normal. This is only required for computing the actual velocity
       scaling"""
        return self._get(PropertyFloat.DOPPLER_ANGLE_DEG)

    def set_doppler_angle_deg(self, value: float):
        """Angle of the Doppler detection beam to the normal. This is only required for computing the actual velocity
       scaling"""
        self._set(PropertyFloat.DOPPLER_ANGLE_DEG, value)
