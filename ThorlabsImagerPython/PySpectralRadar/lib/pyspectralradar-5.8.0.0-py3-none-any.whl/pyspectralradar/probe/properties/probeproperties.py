from pyspectralradar.base.submodule import Submodule
from pyspectralradar.probe.properties.probepropertyflag import ProbePropertyFlag
from pyspectralradar.probe.properties.probepropertyfloat import ProbePropertyFloat
from pyspectralradar.probe.properties.probepropertyint import ProbePropertyInt
from pyspectralradar.probe.properties.probepropertystring import ProbePropertyString


class ProbeProperties(Submodule):
    def __init__(self, handle):
        super().__init__(handle)
        self._str = ProbePropertyString(self.handle)
        self._int = ProbePropertyInt(self.handle)
        self._float = ProbePropertyFloat(self.handle)
        self._flag = ProbePropertyFlag(self.handle)

        # string
        self.get_name = self._str.get_name
        self.set_name = self._str.set_name
        self.get_serial_number = self._str.get_serial_number
        self.set_serial_number = self._str.set_serial_number
        self.get_description = self._str.get_description
        self.set_description = self._str.set_description
        self.get_objective = self._str.get_objective
        self.set_objective = self._str.set_objective

        # int
        self.get_apodization_cycles = self._int.get_apodization_cycles
        self.set_apodization_cycles = self._int.set_apodization_cycles
        self.get_oversampling = self._int.get_oversampling
        self.set_oversampling = self._int.set_oversampling
        self.get_oversampling_slow_axis = self._int.get_oversampling_slow_axis
        self.set_oversampling_slow_axis = self._int.set_oversampling_slow_axis
        self.get_speckle_reduction = self._int.get_speckle_reduction
        self.set_speckle_reduction = self._int.set_speckle_reduction

        # float
        self.get_factor_x = self._float.get_factor_x
        self.set_factor_x = self._float.set_factor_x
        self.get_offset_x = self._float.get_offset_x
        self.set_offset_x = self._float.set_offset_x
        self.get_factor_y = self._float.get_factor_y
        self.set_factor_y = self._float.set_factor_y
        self.get_offset_y = self._float.get_offset_y
        self.set_offset_y = self._float.set_offset_y
        self.get_flyback_time_sec = self._float.get_flyback_time_sec
        self.set_flyback_time_sec = self._float.set_flyback_time_sec
        self.get_expansion_time_sec = self._float.get_expansion_time_sec
        self.set_expansion_time_sec = self._float.set_expansion_time_sec
        self.get_rotation_time_sec = self._float.get_rotation_time_sec
        self.set_rotation_time_sec = self._float.set_rotation_time_sec
        self.get_expected_scan_rate_hz = self._float.get_expected_scan_rate_hz
        self.set_expected_scan_rate_hz = self._float.set_expected_scan_rate_hz
        self.get_camera_scaling_x = self._float.get_camera_scaling_x
        self.set_camera_scaling_x = self._float.set_camera_scaling_x
        self.get_camera_offset_x = self._float.get_camera_offset_x
        self.set_camera_offset_x = self._float.set_camera_offset_x
        self.get_camera_scaling_y = self._float.get_camera_scaling_y
        self.set_camera_scaling_y = self._float.set_camera_scaling_y
        self.get_camera_offset_y = self._float.get_camera_offset_y
        self.set_camera_offset_y = self._float.set_camera_offset_y
        self.get_camera_angle = self._float.get_camera_angle
        self.set_camera_angle = self._float.set_camera_angle
        self.get_range_max_x = self._float.get_range_max_x
        self.set_range_max_x = self._float.set_range_max_x
        self.get_range_max_y = self._float.get_range_max_y
        self.set_range_max_y = self._float.set_range_max_y
        self.get_max_slope_xy = self._float.get_max_slope_xy
        self.set_max_slope_xy = self._float.set_max_slope_xy
        self.get_speckle_size = self._float.get_speckle_size
        self.set_speckle_size = self._float.set_speckle_size
        self.get_apo_volt_x = self._float.get_apo_volt_x
        self.set_apo_volt_x = self._float.set_apo_volt_x
        self.get_apo_volt_y = self._float.get_apo_volt_y
        self.set_apo_volt_y = self._float.set_apo_volt_y
        self.get_ref_stage_offset = self._float.get_ref_stage_offset
        self.set_ref_stage_offset = self._float.set_ref_stage_offset
        self.get_fiber_opl_mm = self._float.get_fiber_opl_mm
        self.set_fiber_opl_mm = self._float.set_fiber_opl_mm
        self.get_probe_opl_mm = self._float.get_probe_opl_mm
        self.set_probe_opl_mm = self._float.set_probe_opl_mm
        self.get_objective_opl_mm = self._float.get_objective_opl_mm
        self.set_objective_opl_mm = self._float.set_objective_opl_mm
        self.get_objective_focal_length_mm = self._float.get_objective_focal_length_mm
        self.set_objective_focal_length_mm = self._float.set_objective_focal_length_mm

        # flag
        self.get_camera_inverted_x = self._flag.get_camera_inverted_x
        self.get_camera_inverted_y = self._flag.get_camera_inverted_y
        self.get_has_mems_scanner = self._flag.get_has_mems_scanner
        self.get_apo_only_x = self._flag.get_apo_only_x
