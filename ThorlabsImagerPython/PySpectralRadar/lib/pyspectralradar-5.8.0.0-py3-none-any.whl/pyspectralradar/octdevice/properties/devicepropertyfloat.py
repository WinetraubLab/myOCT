from enum import IntEnum

from pyspectralradar.base.propertygetter import FloatPropertyGetter
from pyspectralradar.spectralradar import sr


class PropertyFloat(IntEnum):
    """Floating point properties of the device that can be retrieved with the function #getDevicePropertyFloat."""

    FULL_WELL_CAPACITY = 0
    """The full well capacity of the device."""

    Z_SPACING = 1
    """The spacing between two pixels in an A-scan."""

    Z_RANGE = 2
    """The maximum measurement range for an A-scan."""

    SIGNAL_MIN_DB = 3
    """The minimum expected dB value for final data."""

    SIGNAL_LOW_DB = 4
    """The typical low dB value for final data."""

    SIGNAL_HIGH_DB = 5
    """The typical high dB value for final data."""

    SIGNAL_MAX_DB = 6
    """The maximum expected dB value for final data."""

    BIN_ELECTRON_SCALING = 7
    """Scaling factor between binary raw data and electrons/photons"""

    TEMPERATURE = 8
    """Internal device temperature in degrees C"""

    SLD_ON_TIME_SEC = 9
    """Absolute power-on time of the SLD since first start in seconds"""

    CENTER_WAVELENGTH_NM = 10
    """The center wavelength of the device"""

    SPECTRAL_WIDTH_NM = 11
    """The approximate spectral width of the spectrometer"""

    MAX_TRIGGER_FREQ_HZ = 12
    """Maximal valid trigger frequency depending on the chosen camera preset."""

    LINE_RATE_HZ = 13
    """Expected line rate depending on the chosen camera preset."""


class DevicePropertyFloat(FloatPropertyGetter):
    """Floating point properties of the device that can be retrieved with the function #getDevicePropertyFloat."""

    def __init__(self, handle):
        super().__init__(handle, sr.getDevicePropertyFloat)

    def get_full_well_capacity(self) -> float:
        """The full well capacity of the device."""
        return self._get(PropertyFloat.FULL_WELL_CAPACITY)

    def get_z_spacing(self) -> float:
        """The spacing between two pixels in an A-scan."""
        return self._get(PropertyFloat.Z_SPACING)

    def get_z_range(self) -> float:
        """The maximum measurement range for an A-scan."""
        return self._get(PropertyFloat.Z_RANGE)

    def get_signal_min_db(self) -> float:
        """The minimum expected dB value for final data."""
        return self._get(PropertyFloat.SIGNAL_MIN_DB)

    def get_signal_low_db(self) -> float:
        """The typical low dB value for final data."""
        return self._get(PropertyFloat.SIGNAL_LOW_DB)

    def get_signal_high_db(self) -> float:
        """The typical high dB value for final data."""
        return self._get(PropertyFloat.SIGNAL_HIGH_DB)

    def get_signal_max_db(self) -> float:
        """The maximum expected dB value for final data."""
        return self._get(PropertyFloat.SIGNAL_MAX_DB)

    def get_bin_electron_scaling(self) -> float:
        """Scaling factor between binary raw data and electrons/photons"""
        return self._get(PropertyFloat.BIN_ELECTRON_SCALING)

    def get_temperature(self) -> float:
        """Internal device temperature in degrees C"""
        return self._get(PropertyFloat.TEMPERATURE)

    def get_sld_on_time_sec(self) -> float:
        """Absolute power-on time of the SLD since first start in seconds"""
        return self._get(PropertyFloat.SLD_ON_TIME_SEC)

    def get_center_wavelength_nm(self) -> float:
        """The center wavelength of the device"""
        return self._get(PropertyFloat.CENTER_WAVELENGTH_NM)

    def get_spectral_width_nm(self) -> float:
        """The approximate spectral width of the spectrometer"""
        return self._get(PropertyFloat.SPECTRAL_WIDTH_NM)

    def get_max_trigger_freq_hz(self) -> float:
        """Maximal valid trigger frequency depending on the chosen camera preset."""
        return self._get(PropertyFloat.MAX_TRIGGER_FREQ_HZ)

    def get_line_rate_hz(self) -> float:
        """Expected line rate depending on the chosen camera preset."""
        return self._get(PropertyFloat.LINE_RATE_HZ)
