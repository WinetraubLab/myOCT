from ctypes import POINTER, c_float, c_int

import numpy as np

from pyspectralradar.base import Submodule
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import DataDirection, FilterType1D, FilterType2D, FilterType3D, PepperFilterType


class Filter(Submodule):
    def __init__(self, handle, container_type):
        super().__init__(handle)
        self._container_type = container_type

    def median_filter_1d(self, rank: int, direction: DataDirection):
        """Computes a 1D-median filter on the specified data.

        Args:
             :rank: The size of the filter
             :direction: The direction the 1D-filter will be applied to the data.
        """
        assert isinstance(direction, DataDirection)
        sr.medianFilter1D.argtypes = [c_handle, c_int, c_int]
        sr.medianFilter1D(self.handle, rank, direction)
        get_error()

    def median_filter_2d(self, rank: int, direction: DataDirection):
        """Computes a 2D-median filter on the specified data.

        Args:
             :rank: The size of the filter
             :direction: The normal of the direction the 2D-filter will be applied to the data.
        """
        assert isinstance(direction, DataDirection)
        sr.medianFilter2D.argtypes = [c_handle, c_int, c_int]
        sr.medianFilter2D(self.handle, rank, direction)
        get_error()

    def pepper_filter_2d(self, filter_type: PepperFilterType, threshold: float, direction: DataDirection):
        """Removes pepper-noise (very low values, i.e. dark spots in the data).

        This enhances the visual (colored) representation of the data.

        Args:
             :filter_type: The type of the pepper filter
             :threshold: If the value is lower than the given value it will be replaced by the mean
             :direction: The normal of the direction the 2D-filter will be applied to the data

        The pepper filter compares all pixels to a mean of surrounding pixels. The surrounding pixels taking into
        account are specified by :class:`~pyspectralradar.types.datatypes.PepperFilterType`. If the pixels is lower
        than specified by the ``threshold`` the pixel will be replaced by the mean.
        """
        assert isinstance(filter_type, PepperFilterType)
        assert isinstance(direction, DataDirection)
        sr.pepperFilter2D.argtypes = [c_handle, c_int, c_float, c_int]
        sr.pepperFilter2D(self.handle, filter_type, threshold, direction)
        get_error()

    def convolution_filter_1d(self, filter_kernel: np.ndarray, direction: DataDirection):
        """Calculates a mathematical convolution of the Data and the 1D-FilterKernel

        Args:
             :filter_kernel: Pointer to the 1D-array containing the filter kernel
             :direction: The filter direction the 1D-filter will be applied to the data, e.g. ``DIR1`` for filtering
                each single A-scan
        """
        assert isinstance(direction, DataDirection)
        filter_size = len(filter_kernel)
        casted_filter_kernel_ptr = filter_kernel.ctypes.data_as(POINTER(c_float))
        sr.convolutionFilter1D.argtypes = [c_handle,
                                           c_int,
                                           POINTER(c_float),
                                           c_int]
        sr.convolutionFilter1D(self.handle, filter_size, casted_filter_kernel_ptr, direction)
        get_error()

    def convolution_filter_2d(self, filter_kernel: np.ndarray,
                              direction: DataDirection):
        """Calculates a mathematical convolution of the Data and the 2D-FilterKernel

        Args:
             :filter_kernel: Pointer to the 2D-array containing the filter kernel
             :direction: The normal of the direction the 2D-filter will be applied to the data, e.g. ``DIR3`` for
                filtering each single B-scan
        """
        assert isinstance(direction, DataDirection)
        filter_size1, filter_size2 = filter_kernel.shape
        casted_filter_kernel_ptr = filter_kernel.ctypes.data_as(POINTER(c_float))
        sr.convolutionFilter2D.argtypes = [c_handle,
                                           c_int,
                                           c_int,
                                           POINTER(c_float),
                                           c_int]
        sr.convolutionFilter2D(self.handle, filter_size1, filter_size2, casted_filter_kernel_ptr, direction)
        get_error()

    def convolution_filter_3d(self, filter_kernel: np.ndarray):
        """Calculates a mathematical convolution of the Data and the 3D-FilterKernel

        Args:
             :filter_kernel: Pointer to the 3D-array containing the filter kernel
        """
        filter_size1, filter_size2, filter_size3 = filter_kernel.shape
        casted_filter_kernel_ptr = filter_kernel.ctypes.data_as(POINTER(c_float))
        sr.convolutionFilter2D.argtypes = [c_handle,
                                           c_int,
                                           c_int,
                                           c_int,
                                           POINTER(c_float)]
        sr.convolutionFilter3D(self.handle, filter_size1, filter_size2, filter_size3, casted_filter_kernel_ptr)
        get_error()

    def predefined_filter_1d(self, filter_type: FilterType1D, direction: DataDirection):
        """Applies the predefined 1D-Filter to current data

        Args:
             :filter_type: Selection of a predefined filter
             :direction: The filter direction the 1D-filter will be applied to the data, e.g. ``DIR1`` for filtering
                each single A-scan
        """
        assert isinstance(filter_type, FilterType1D)
        assert isinstance(direction, DataDirection)
        sr.predefinedFilter1D.argtypes = [c_handle, c_int, c_int]
        sr.predefinedFilter1D(self.handle, filter_type, direction)
        get_error()

    def predefined_filter_2d(self, filter_type: FilterType2D, direction: DataDirection):
        """Applies the predefined 2D-Filter to the current data

        Args:
             :filter_type: Selection of a predefined filter
             :direction: The normal of the direction the 2D-filter will be applied to the data, e.g. ``DIR3`` for
                filtering each single B-scan
        """
        assert isinstance(filter_type, FilterType2D)
        assert isinstance(direction, DataDirection)
        sr.predefinedFilter2D.argtypes = [c_handle, c_int, c_int]
        sr.predefinedFilter2D(self.handle, filter_type, direction)
        get_error()

    def predefined_filter_3d(self, filter_type: FilterType3D):
        """Applies the predefined 3D-Filter to the current data

        Args:
             :filter_type: Selection of a predefined filter
        """
        assert isinstance(filter_type, FilterType3D)
        sr.predefinedFilter3D.argtypes = [c_handle, c_int]
        sr.predefinedFilter3D(self.handle, filter_type)
        get_error()

    def averaging_resize_filter(self, decimation1: int, decimation2: int, decimation3: int):
        """Resizes a data object by averaging.

        The number of pixels that are averaged on each axis can be specified by the decimation parameters.
        E.g. if ``decimation2`` is set to 3, dimension 2 of the resulting output object will be 1/3 of dimension 2 of
        the current data.

        Args:
             :decimation1: Number of pixels to average in dimension 1
             :decimation2: Number of pixels to average in dimension 2
             :decimation3: Number of pixels to average in dimension 3

        Returns:
            The average size corrected object.
        """
        data_out = self._container_type()
        sr.averagingResizeFilter.argtype = [c_handle, c_handle, c_int, c_int, c_int]
        sr.averagingResizeFilter(self.handle, data_out.handle, decimation1, decimation2, decimation3)
        get_error()
        return data_out
