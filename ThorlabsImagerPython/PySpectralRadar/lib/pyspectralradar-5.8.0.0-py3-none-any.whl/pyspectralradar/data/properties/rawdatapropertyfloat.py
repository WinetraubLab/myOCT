from enum import IntEnum

from pyspectralradar.base.propertygetter import FloatPropertyGetter
from pyspectralradar.spectralradar import sr


class RawDataPropertyFloat(IntEnum):
    RANGE1 = 0
    """Total range of the data in direction of the first axis in physical units (millimeter)."""

    RANGE2 = 2
    """Total range of the data in direction of the second axis in physical units (millimeter)."""

    RANGE3 = 3
    """Total range of the data in direction of the third axis in physical units (millimeter)."""


class RawDataPropertyFloatGetter(FloatPropertyGetter):
    def __init__(self, handle):
        super().__init__(handle, sr.getRawDataPropertyFloat)

    def get_range1(self) -> float:
        """Total range of the data in direction of the first axis in physical units (millimeter)."""
        return self._get(RawDataPropertyFloat.RANGE1)

    def get_range2(self) -> float:
        """Total range of the data in direction of the second axis in physical units (millimeter)."""
        return self._get(RawDataPropertyFloat.RANGE2)

    def get_range3(self) -> float:
        """Total range of the data in direction of the third axis in physical units (millimeter)."""
        return self._get(RawDataPropertyFloat.RANGE3)
