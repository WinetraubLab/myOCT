import abc
from abc import ABC
from ctypes import c_char_p, c_int

from pyspectralradar.base import HasHandle
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import ColoredDataExportFormat, ComplexDataExportFormat, DataDirection, DataExportFormat, \
    DataImportFormat, ExportOptionMasks, RawDataExportFormat, RawDataImportFormat


class AbstractDataFileIo(HasHandle):
    def _export(self,
                data_format: RawDataExportFormat | DataExportFormat | ColoredDataExportFormat | ComplexDataExportFormat,
                filename: str = ""):
        self._export_func.argtypes = [c_handle, c_handle, c_char_p]
        self._export_func(self.handle, data_format, c_char_p(bytes(filename, encoding="ascii")))
        get_error()

    def _from_file(self, import_format: RawDataImportFormat | DataImportFormat, filename: str):
        import_data = type(self)()
        # import_data = self._construct_empty_handle()
        self._import_func.argtypes = [c_handle, c_int, c_char_p]
        self._import_func(import_data.handle, import_format, c_char_p(bytes(filename, encoding="ascii")))
        get_error()
        return import_data

    @property
    @abc.abstractmethod
    def _export_func(self):
        raise NotImplementedError

    @property
    @abc.abstractmethod
    def _import_func(self):
        raise NotImplementedError

    @abc.abstractmethod
    def _construct_empty_handle(self):
        raise NotImplementedError


class RawDataFileIo(AbstractDataFileIo, ABC):
    def export(self, data_format: RawDataExportFormat, filename: str = ""):
        """Exports the specified data to disk.

        Notice that raw data refers to the spectra as acquired, without processing of any kind.

        Args:
            :data_format: The desired data-format to be stored in the file
            :filename: A zero-terminated string specifying the full pathname to the file to be written.
                Notice that backslashes should be escaped with an additional backslash.
        """
        self._export(data_format, filename)

    def from_file(self, filename: str):
        """Imports data with the specified format and copies it into a data object.

        Args:
            :filename: A zero-terminated string specifying the full pathname to the file to be written. Notice that
                backslashes should be escaped with an additional backslash.

        Returns:
            A valid (non-null) data handle of the same class. These data may be multidimensional.
        """
        return self._from_file(RawDataImportFormat.SRR, filename)

    @property
    def _export_func(self):
        return sr.exportRawData

    @property
    def _import_func(self):
        return sr.importRawData


class RealDataFileIo(AbstractDataFileIo, ABC):
    @property
    def _export_func(self):
        return sr.exportData

    @property
    def _import_func(self):
        return sr.importData

    def export(self, data_format: DataExportFormat, filename: str = ""):
        """Exports the specified data to disk.

        Args:
            :data_format: Format The desired data-format.
            :filename: A zero-terminated string specifying the full pathname to the file to be written. Notice that
                backslashes should be escaped with an additional backslash.
        """
        self._export(data_format, filename)

    def export_data_as_image(self, coloring, data_format: ColoredDataExportFormat,
                             direction: DataDirection, filename: str = "",
                             export_option_mask: ExportOptionMasks = ExportOptionMasks.NONE):
        """Exports 2-dimensional and 3-dimensional data objects as image data (such as BMP, PNG, JPEG, ...).

        Args:
            :coloring: A valid (non-None) :class:`~pyspectralradar.coloring.coloring.Coloring` object
            :data_format: The desired data-format
            :direction: Specifies the direction normal to the generated pictures
            :filename: A zero-terminated string specifying the full pathname to the file to be written. Notice that
                backslashes should be escaped with an additional backslash
            :export_option_mask: An OR-ed combination of the
                :class:`~pyspectralradar.types.datatypes.ExportOptionMasks` flags ``NONE``, ``DRAW_SCALEBAR``,
                ``DRAW_MARKERS``, and ``USE_PHYSICAL_ASPECT_RATIO``.
        """
        assert isinstance(data_format, ColoredDataExportFormat)
        assert isinstance(direction, DataDirection)
        sr.exportDataAsImage.argtypes = [c_handle, c_handle, c_handle, c_int, c_char_p, c_int]
        sr.exportDataAsImage(self.handle, coloring.handle, data_format, direction,
                             c_char_p(bytes(filename, encoding="ascii")), export_option_mask)
        get_error()

    def from_file(self, filename: str, size_z: int, size_x: int, size_y: int):
        """Read data object from raw data stream in file

        :Warning: Experimental: This function may change in its interface and behaviour, or even disappear in future
            versions.

        Args:
            :filename: File to read
            :size_z: SizeZ of dataset
            :size_x: SizeX of dataset
            :size_y: SizeY of dataset

        Returns:
            The read data.
        """
        res = type(self)()
        sr.readData.argtypes = [c_handle, c_char_p, c_int, c_int, c_int]
        sr.readData(res.handle, c_char_p(bytes(filename, encoding="ascii")), size_z, size_x, size_y)
        get_error()
        return res


class ComplexDataFileIo(AbstractDataFileIo, ABC):
    @property
    def _export_func(self):
        return sr.exportComplexData

    @property
    def _import_func(self):
        raise NotImplementedError

    def export(self, data_format: ComplexDataExportFormat, filename: str = ""):
        """Exports the specified data to disk.

        Args:
            :data_format: Format The desired data-format
            :filename: A zero-terminated string specifying the full pathname to the file to be written. Notice that
                backslashes should be escaped with an additional backslash.
        """
        self._export(data_format, filename)


class ColoredDataFileIo(AbstractDataFileIo, ABC):
    @property
    def _export_func(self):
        return sr.exportColoredData

    @property
    def _import_func(self):
        return sr.importColoredData

    def export(self, data_format: ColoredDataExportFormat, direction: DataDirection, filename: str,
               export_option_mask: ExportOptionMasks = ExportOptionMasks.NONE):
        """Exports colored data to disk.

        Args:
            :data_format: Format The desired data-format
            :direction: Specifies the direction normal to the generated pictures
            :filename: A zero-terminated string specifying the full pathname to the file to be written
            :export_option_mask: An OR-ed combination of the
                :class:`~pyspectralradar.types.datatypes.ExportOptionMasks` flags ``_NONE``, ``DRAW_SCALEBAR``,
                ``DRAW_MARKERS``, and ``USE_PHYSICAL_ASPECT_RATIO``.

        """
        self._export_func.argtypes = [c_handle, c_handle, c_int, c_char_p, c_int]
        self._export_func(self.handle, data_format, direction, c_char_p(bytes(filename, encoding="ascii")),
                          export_option_mask)
        get_error()

    def from_file(self, filename: str, import_format: DataImportFormat):
        """Imports data with the specified format and copies it into a data object.

        Args:
            :filename: A zero-terminated string specifying the full pathname to the file to be written. Notice that
                backslashes should be escaped with an additional backslash
            :import_format: The data-format stored in the file

        Returns:
            The imported data as object.
        """
        return self._from_file(import_format, filename)
