import unittest

import numpy as np

from pyspectralradar import OCTFile, OCTSystem, LogLevel, set_log_level
from pyspectralradar.processing.staticmethods import *
from pyspectralradar.spectralradar import SpectralRadarException
from pyspectralradar.types import AcqType, CalibrationType, SpectrumType

EXPERIMENTAL = False


class TestAlgorithm(unittest.TestCase):
    file = OCTFile("\\\\lbknetapp01\\Public\\Doc\\Software\\Unittests\\PySpectralRadarTests\\Unittest_0001_Mode2D.oct")
    bscan = file.get_data_object(2)
    raw = file.get_data_object(3)
    apo_spectrum = file.get_data_object(4)
    chirp = file.get_data_object(5)

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    @classmethod
    def tearDownClass(cls):
        del cls.file

    @unittest.skipUnless(EXPERIMENTAL, "Function exists in experimental only")
    def test_compute_chirp(self):
        dut = compute_chirp(self.apo_spectrum)
        self.assertTrue(np.allclose(dut.to_numpy(), self.chirp.to_numpy()))

    def test_compute_dispersion(self):
        sys = OCTSystem()
        dev = sys.dev
        proc = sys.processing_factory.from_device()

        raw = dev.acquisition.measure_spectra(1)
        apo_container1 = RealData()
        apo_container2 = RealData()
        proc.set_spectrum_output(apo_container1, SpectrumType.APODIZED)
        proc.execute(raw)
        proc.set_spectrum_output(apo_container2, SpectrumType.APODIZED)
        proc.execute(raw)

        # expects chirp error since chirp is not monotone without mirror signal
        self.assertRaises(SpectralRadarException, lambda: compute_dispersion(apo_container1, apo_container2))

    def test_compute_dispersion_by_coeff(self):
        self.assertIsInstance(compute_dispersion_by_coeff(200.0, self.chirp), RealData)

    def test_compute_dispersion_by_image(self):
        sys = OCTSystem()
        dev = sys.dev
        proc = sys.processing_factory.from_device()
        chirp = proc.calibration.get(CalibrationType.CHIRP)
        probe = sys.probe_factory.from_gui_settings()
        pattern = probe.scan_pattern.create_bscan_pattern(10.0, 1024)

        dev.acquisition.start(pattern, AcqType.ASYNC_FINITE)
        raw = dev.acquisition.get_raw_data()
        spectrum = RealData()
        proc.set_spectrum_output(spectrum, SpectrumType.RAW)
        proc.execute(raw)

        linear_sd = linearize_spectral_data(spectrum, chirp)
        print(linear_sd.shape)
        dispersion = compute_dispersion_by_image(linear_sd, chirp)
        self.assertIsInstance(dispersion, RealData)

    def test_calc_contrast(self):
        dut = calc_contrast(self.apo_spectrum)
        print(dut.shape)
        self.assertIsInstance(dut, RealData)

    def test_calc_spectrometer_quality(self):
        print(calc_spectrometer_img_quality(self.apo_spectrum))

    def test_analyze_max_peak(self):
        print(analyze_max_peak(self.bscan))


if __name__ == '__main__':
    unittest.main()
