import unittest

import numpy as np

from pyspectralradar import OCTDevice, OCTFile, Probe, ProbeFactory, LogLevel, set_log_level
from pyspectralradar.spectralradar import SpectralRadarException
from pyspectralradar.types import ScanAxis, ScanRangeShape


class ProbeFactoryTestCase(unittest.TestCase):
    def setUp(self):
        self._oct_dev = OCTDevice()
        self._probe_factory = ProbeFactory(self._oct_dev)

    def tearDown(self):
        del self._oct_dev


class TestProbeFactory(ProbeFactoryTestCase):

    def test_probe_factory_init(self):
        self.assertIsInstance(self._probe_factory.create_default(), Probe)

    def test_probe_factory_default(self):
        self.assertIsInstance(self._probe_factory.create_new('Standard_OCTG', 'LSM03'), Probe)

    def test_probe_factory_current(self):
        self.assertIsInstance(self._probe_factory.from_gui_settings(), Probe)

    def test_probe_factory_from_file(self):
        oct_file = OCTFile("\\\\lbknetapp01\\Public\\Doc\\Software\\Unittests\\PySRDemo\\PyDemo_0001_Mode2D.oct")
        self.assertIsInstance(self._probe_factory.from_oct_file(oct_file), Probe)


class ProbeTestCase(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def setUp(self):
        self.dev = OCTDevice()
        self._probe_factory = ProbeFactory(self.dev)
        self.probe = self._probe_factory.create_default()

    def tearDown(self):
        del self.dev
        del self.probe


class TestProbePropertyString(ProbeTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self.probe.properties

    def test_property_string(self):
        self.assertEqual(self.dut.get_name(), 'Probe')
        self.assertEqual(self.dut.get_serial_number(), '')
        self.assertEqual(self.dut.get_description(), 'Standard_OCTG')
        self.assertEqual(self.dut.get_objective(), 'LSM03')

        self.dut.set_name("Probe4Test")
        self.assertEqual(self.dut.get_name(), 'Probe4Test')
        self.dut.set_serial_number('1234123')
        self.assertEqual(self.dut.get_serial_number(), '1234123')
        self.dut.set_description('Used for Unittests')
        self.assertEqual(self.dut.get_description(), 'Used for Unittests')
        self.dut.set_objective('LSM_XX')
        self.assertEqual(self.dut.get_objective(), 'LSM_XX')


class TestProbePropertyInt(ProbeTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self.probe.properties

    def test_property_int(self):
        self.assertEqual(self.dut.get_apodization_cycles(), 25)
        self.assertEqual(self.dut.get_oversampling(), 1)
        self.assertEqual(self.dut.get_oversampling_slow_axis(), 1)
        self.assertEqual(self.dut.get_speckle_reduction(), 0)

        self.dut.set_apodization_cycles(20)
        self.assertEqual(self.dut.get_apodization_cycles(), 20)
        self.dut.set_oversampling(3)
        self.assertEqual(self.dut.get_oversampling(), 3)
        self.dut.set_oversampling_slow_axis(5)
        self.assertEqual(self.dut.get_oversampling_slow_axis(), 5)
        self.dut.set_speckle_reduction(2)
        self.assertEqual(self.dut.get_speckle_reduction(), 2)


class TestProbePropertyFloat(ProbeTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self.probe.properties

    def test_property_float(self):
        self.assertEqual(self.dut.get_factor_x(), 1.0)
        self.dut.set_factor_x(2.0)
        self.assertEqual(self.dut.get_factor_x(), 2.0)

        self.assertEqual(self.dut.get_offset_x(), 0.0)
        self.dut.set_offset_x(1.0)
        self.assertEqual(self.dut.get_offset_x(), 1.0)

        self.assertEqual(self.dut.get_factor_y(), 1.0)
        self.dut.set_factor_y(2.1)
        self.assertEqual(self.dut.get_factor_y(), 2.1)

        self.assertEqual(self.dut.get_offset_y(), 0.0)
        self.dut.set_offset_y(1.3)
        self.assertEqual(self.dut.get_offset_y(), 1.3)

        self.assertEqual(self.dut.get_flyback_time_sec(), 0.002)
        self.dut.set_flyback_time_sec(0.004)
        self.assertEqual(self.dut.get_flyback_time_sec(), 0.004)

        self.assertEqual(self.dut.get_expansion_time_sec(), 0.00019)
        self.dut.set_expansion_time_sec(0.003)
        self.assertEqual(self.dut.get_expansion_time_sec(), 0.003)

        self.assertEqual(self.dut.get_rotation_time_sec(), 0.0)
        self.dut.set_rotation_time_sec(0.05)
        self.assertEqual(self.dut.get_rotation_time_sec(), 0.05)

        self.assertEqual(self.dut.get_expected_scan_rate_hz(), 10000)
        self.dut.set_expected_scan_rate_hz(12000)
        self.assertEqual(self.dut.get_expected_scan_rate_hz(), 12000)

        self.assertEqual(self.dut.get_camera_scaling_x(), 50.0)
        self.dut.set_camera_scaling_x(39.5)
        self.assertEqual(self.dut.get_camera_scaling_x(), 39.5)

        self.assertEqual(self.dut.get_camera_offset_x(), 324.0)
        self.dut.set_camera_offset_x(350)
        self.assertEqual(self.dut.get_camera_offset_x(), 350)

        self.assertEqual(self.dut.get_camera_scaling_y(), 50)
        self.dut.set_camera_scaling_y(51)
        self.assertEqual(self.dut.get_camera_scaling_y(), 51)

        self.assertEqual(self.dut.get_camera_offset_y(), 242)
        self.dut.set_camera_offset_y(243)
        self.assertEqual(self.dut.get_camera_offset_y(), 243)

        self.assertEqual(self.dut.get_camera_angle(), 90)
        self.dut.set_camera_angle(90.1)
        self.assertEqual(self.dut.get_camera_angle(), 90.1)

        self.assertEqual(self.dut.get_range_max_x(), 10.0)
        self.dut.set_range_max_x(15.0)
        self.assertEqual(self.dut.get_range_max_x(), 15.0)

        self.assertEqual(self.dut.get_range_max_y(), 10.0)
        self.dut.set_range_max_y(11.0)
        self.assertEqual(self.dut.get_range_max_y(), 11.0)

        self.assertEqual(self.dut.get_max_slope_xy(), 0.125)
        self.assertRaises(SpectralRadarException, lambda: self.dut.set_max_slope_xy(0.25))

        self.assertEqual(self.dut.get_speckle_size(), 0.0)
        self.dut.set_speckle_size(1.1)
        self.assertEqual(self.dut.get_speckle_size(), 1.1)

        self.assertEqual(self.dut.get_apo_volt_x(), 10.0)
        self.dut.set_apo_volt_x(9.5)
        self.assertEqual(self.dut.get_apo_volt_x(), 9.5)

        self.assertEqual(self.dut.get_apo_volt_y(), 0.0)
        self.dut.set_apo_volt_y(-1.0)
        self.assertEqual(self.dut.get_apo_volt_y(), -1.0)

        self.assertEqual(self.dut.get_ref_stage_offset(), 0.0)
        self.dut.set_ref_stage_offset(1.0)
        self.assertEqual(self.dut.get_ref_stage_offset(), 1.0)

        self.assertEqual(self.dut.get_fiber_opl_mm(), 0.0)
        self.dut.set_fiber_opl_mm(1)
        self.assertEqual(self.dut.get_fiber_opl_mm(), 1)

        self.assertEqual(self.dut.get_probe_opl_mm(), 60.0)
        self.dut.set_probe_opl_mm(57.5)
        self.assertEqual(self.dut.get_probe_opl_mm(), 57.5)

        self.assertEqual(self.dut.get_objective_opl_mm(), 20.0)
        self.dut.set_objective_opl_mm(18.7)
        self.assertEqual(self.dut.get_objective_opl_mm(), 18.7)

        self.assertEqual(self.dut.get_objective_focal_length_mm(), 36.0)
        self.dut.set_objective_focal_length_mm(40.05)
        self.assertEqual(self.dut.get_objective_focal_length_mm(), 40.05)


class TestProbePropertyFlag(ProbeTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self.probe.properties

    def test_property_flag(self):
        # self.assertEqual(self.dut.get_camera_inverted_x(), False) # not available for dummy
        # self.assertEqual(self.dut.get_camera_inverted_y(), True) # not available for dummy
        self.assertEqual(self.dut.get_has_mems_scanner(), False)
        self.assertEqual(self.dut.get_apo_only_x(), True)


class TestObjective(ProbeTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self.probe.objective

    def test_objective(self):
        self.assertEqual(self.dut.get_display_name(), 'LK3/LSM03(-BB) V1')
        self.assertEqual(self.dut.get_number_of_compatible_objective(), 6)
        self.assertEqual(self.dut.get_compatible_objective(1), 'LKM20_V1')


class TestObjectivePropertyString(ProbeTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self.probe.objective.properties

    def test_property_string(self):
        self.assertEqual(self.dut.get_display_name()[1:-1], 'LK3/LSM03(-BB) V1')
        self.assertEqual(self.dut.get_mount(), "m25x0.75")


class TestObjectivePropertyInt(ProbeTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self.probe.objective.properties

    def test_property_int(self):
        self.assertEqual(self.dut.get_range_max_x_mm(), 10)
        self.assertEqual(self.dut.get_range_max_y_mm(), 10)


class TestObjectivePropertyFloat(ProbeTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self.probe.objective.properties

    def test_property_float(self):
        self.assertEqual(self.dut.get_focal_length_mm(), 36.0)
        self.assertEqual(self.dut.get_optical_path_length(), 20.0)


class TestProbe(ProbeTestCase):
    def test_probe_set_factors_and_save(self):
        from os import remove
        from os.path import exists

        factors_x = np.linspace(0, 1.5, 5)
        factors_y = np.linspace(0, 1.1, 5)
        self.probe.set_quadratic_factors(factors_x, factors_y)

        file_path = 'C:\\tmp\\Test_Probe_Save.ini'

        self.probe.save(file_path)
        self.assertTrue(exists(file_path),
                        "The file does not exist in the specified directory")
        if exists(file_path):
            remove(file_path)

    def test_probe_type(self):
        self.assertEqual(self.probe.get_type(), 'Standard_OCTG')
        self.probe.set_type('UserCustomizable_OCTP')
        self.assertEqual(self.probe.get_type(), 'UserCustomizable_OCTP')

    def test_scan_range_shape(self):
        self.assertEqual(self.probe.get_max_scan_range_shape(), ScanRangeShape.RECT)
        self.probe.set_max_scan_range_shape(ScanRangeShape.ROUND)
        self.assertEqual(self.probe.get_max_scan_range_shape(), ScanRangeShape.ROUND)


class TestProbeConversions(ProbeTestCase):
    def test_position_to_voltage(self):
        pos_x = 5.0
        pos_y = 5.0

        self.probe.properties.set_camera_angle(90.0)
        volt_x_90, volt_y_90 = self.probe.position_to_probe_voltage(self.dev, pos_x, pos_y)

        self.assertAlmostEqual(pos_x, volt_y_90)
        self.assertAlmostEqual(pos_y, volt_x_90)

        self.probe.properties.set_camera_angle(0.0)
        volt_x_0, volt_y_0 = self.probe.position_to_probe_voltage(self.dev, pos_x, pos_y)

        self.assertAlmostEqual(pos_x, volt_x_0)
        self.assertAlmostEqual(pos_y, -volt_y_0)

    def test_camera_pixel_to_position(self):
        video_img = self.dev.camera.get_image()

        print(video_img.shape)

        pos_x, pos_y = self.probe.camera_pixel_to_position(video_img, video_img.shape[0], video_img.shape[1])
        print(pos_x, pos_y)
        self.assertAlmostEqual(pos_x, 14.0)
        self.assertAlmostEqual(pos_y, -10.52)

        pos_x, pos_y = self.probe.camera_pixel_to_position(video_img, 0, 0)
        print(pos_x, pos_y)
        self.assertAlmostEqual(pos_x, -6.48)
        self.assertAlmostEqual(pos_y, 4.84)

    def test_position_to_camera_pixel(self):
        video_img = self.dev.camera.get_image()

        print(video_img.shape)

        pos_x, pos_y = self.probe.position_to_camera_pixel(video_img, 14.0, -10.52)
        print(pos_x, pos_y)
        self.assertEqual(pos_x, video_img.shape[0])
        self.assertEqual(pos_y, video_img.shape[1])

        pos_x, pos_y = self.probe.position_to_camera_pixel(video_img, -6.48, 4.84)
        print(pos_x, pos_y)
        self.assertEqual(pos_x, 0)
        self.assertEqual(pos_y, 0)


class TestProbeConfig(ProbeTestCase):
    def test_available_probe_internal(self):
        self.dut = self.probe.supported_probes

        self.assertEqual(self.dut._get_number_of_available_probes(), 4)
        self.assertEqual(self.dut._get_available_probe(2), 'Standard_OCTG_V1')

    def test_available_probes(self):
        self.dut = self.probe.supported_probes

        probes = self.dut.get_supported_probe_names()
        self.assertEqual(probes[2], 'Standard_OCTG_V1')

    def test_probe_configs_internal(self):
        self.dut = self.probe.config_files

        # note: differs for user directory
        self.assertIsInstance(self.dut._get_number_of_probe_configs(), int)
        self.assertEqual(self.dut._get_config_name(0), 'Probe.ini')

    def test_probe_configs(self):
        self.dut = self.probe.config_files

        # note: differs for user directory
        confs = self.dut.get_conf_filenames()
        self.assertEqual(confs[0], 'Probe.ini')


class TestProbeUseCalibration(ProbeTestCase):
    def test_probe_calibration(self):
        # experimental
        Probe.use_calibration(True)
        dut = self._probe_factory.create_default()
        self.assertIsInstance(dut, Probe)


class TestScanner(ProbeTestCase):

    def test_move_scanner(self):
        self.dut = self.probe.scanner
        self.dut.move(self.dev, ScanAxis.X, 1.2)
        self.dut.move(self.dev, ScanAxis.Y, -2.1)

    def test_move_to_apo_pos(self):
        self.dut = self.probe.scanner
        self.dut.move_to_apo_position(self.dev)


if __name__ == '__main__':
    unittest.main()
