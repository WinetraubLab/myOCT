import unittest

import numpy as np

from pyspectralradar import Buffer, OCTSystem, RealData, LogLevel, set_log_level


class BufferTestCase(unittest.TestCase):
    dut = None
    video_img = None
    dummy_real = None

    @classmethod
    @unittest.skip  # destructor throws OSError, further investigate
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

        cls.dut = Buffer()

        sys = OCTSystem()
        dev = sys.dev
        probe = sys.probe_factory.create_default()

        cls.video_img = dev.camera.get_image()

        random_real = np.random.rand(1024, 100, 1).astype(np.float32)
        cls.dummy_real = RealData.from_numpy(random_real)

    @unittest.skip  # destructor throws OSError, further investigate
    def test_buffer_get_data(self):
        self.dut.append_to_buffer(self.dummy_real, self.video_img)

        returned_real = self.dut.get_real_data(0)
        self.assertTrue(np.allclose(returned_real.to_numpy(), self.dummy_real.to_numpy()))

        returned_colored = self.dut.get_colored_data(0)
        self.assertTrue(np.allclose(returned_colored.to_numpy(), self.video_img.to_numpy()))

    @unittest.skip  # purge throws OSError, further investigate
    def test_buffer_purge(self):
        n = 6
        for i in range(n):
            self.dut.append_to_buffer(self.dummy_real, self.video_img)

        self.assertEqual(self.dut.size(), (n + 1))  # +1 since has entry from test_buffer_get_data still in buffer

        self.dut.purge()  # TODO: throws OSError, further investigate

        self.assertEqual(self.dut.size(), 0)

    @unittest.skip  # has entries from previous test since purge throws OSError, further investigate
    def test_buffer_size(self):
        n = 2
        for i in range(n):
            self.dut.append_to_buffer(self.dummy_real, self.video_img)

        self.assertEqual(self.dut.size(), n)

        self.assertEqual(self.dut.first_index(), 0)

        self.assertEqual(self.dut.last_index(), n)


if __name__ == '__main__':
    unittest.main()
