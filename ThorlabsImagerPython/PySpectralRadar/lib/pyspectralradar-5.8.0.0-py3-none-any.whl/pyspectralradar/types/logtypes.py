from enum import IntEnum


class LogLevel(IntEnum):
    """Select verbosity for logging"""

    TRACE = 0
    """Log everything"""

    DEBUG = 1
    """Log detailed debug information"""

    INFO = 2
    """Log informational messages"""

    WARN = 3
    """Log warnings"""

    ERR = 4
    """Log errors"""

    CRITICAL = 5
    """Log critical errors"""

    OFF = 6
    """Disable logging"""
