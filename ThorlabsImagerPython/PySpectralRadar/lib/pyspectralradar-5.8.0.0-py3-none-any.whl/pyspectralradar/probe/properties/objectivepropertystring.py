from ctypes import c_char_p, c_int
from enum import IntEnum

from pyspectralradar.base.propertygetter import StringPropertyGetter
from pyspectralradar.spectralradar import sr


class PropertyString(IntEnum):
    """Properties of the objective mounted to the scanner such as the name."""

    DISPLAY_NAME = 0
    """Human-readable name of the objective to display in calibration process, or as device info."""

    MOUNT = 1
    """The mount specification is used to find the compatible probes and objectives
    (to be found in .ordf and .prdf files)."""


class ObjectivePropertyString(StringPropertyGetter):

    def __init__(self, handle, objective_name: str):
        super().__init__(handle, sr.getObjectivePropertyString)
        self._objective_name = objective_name
        self._getter.argtypes = [c_char_p, c_int]

    def _get_raw(self, entry: IntEnum, c_res_type):
        self._getter.restype = c_res_type
        res = self._getter(c_char_p(bytes(self._objective_name, encoding="ascii")), c_int(entry))
        return res

    def get_display_name(self) -> str:
        """Human-readable name of the objective to display in calibration process, or as device info."""
        return self._get(PropertyString.DISPLAY_NAME)

    def get_mount(self) -> str:
        """The mount specification is used to find the compatible probes and objectives
        (to be found in .ordf and .prdf files)."""
        return self._get(PropertyString.MOUNT)
