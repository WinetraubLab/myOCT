from pyspectralradar.base.submodule import Submodule
from pyspectralradar.specklevar.properties.specklevarpropertyfloat import SpeckleVariancePropertyFloat
from pyspectralradar.specklevar.properties.specklevarpropertyint import SpeckleVariancePropertyInt


class SpeckleVarianceProperties(Submodule):
    def __init__(self, handle):
        super().__init__(handle)
        self._int = SpeckleVariancePropertyInt(self.handle, self.handle)
        self._float = SpeckleVariancePropertyFloat(self.handle, self.handle)

        # Property int
        self.get_averaging1 = self._int.get_averaging1
        self.set_averaging1 = self._int.set_averaging1
        self.get_averaging2 = self._int.get_averaging2
        self.set_averaging2 = self._int.set_averaging2
        self.get_averaging3 = self._int.get_averaging3
        self.set_averaging3 = self._int.set_averaging3

        # property float
        self.get_threshold = self._float.get_threshold
        self.set_threshold = self._float.set_threshold
