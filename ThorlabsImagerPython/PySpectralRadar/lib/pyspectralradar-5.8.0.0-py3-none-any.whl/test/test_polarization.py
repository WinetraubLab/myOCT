import os
import shutil
import unittest

from pyspectralradar import ComplexData, OCTFile, OCTSystem, Polarization, RawData, RealData, get_config_path, \
    LogLevel, set_log_level
from pyspectralradar.types import *


class TestPolarizationCreation(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def test_polarization_create(self):
        dut = Polarization()
        self.assertIsInstance(dut, Polarization)
        del dut

    def test_polarization_create_from_file(self):
        oct_file = OCTFile(
            '\\\\lbknetapp01\\Public\\Doc\\Software\\Unittests\\PySpectralRadarTests\\Unittest_0001_ModePolarization'
            '.oct')
        dut = Polarization.from_file(oct_file)
        self.assertIsInstance(dut, Polarization)
        del dut


class PolarizationPropertyTestCase(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def setUp(self):
        self._pol_proc = Polarization()

    def tearDown(self):
        del self._pol_proc


class TestPolarizationPropertyFlag(PolarizationPropertyTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self._pol_proc.properties

    def test_polarization_property_flag(self):
        self.dut.set_apply_thresholding(False)
        self.assertFalse(self.dut.get_apply_thresholding())
        self.dut.set_apply_thresholding(True)
        self.assertTrue(self.dut.get_apply_thresholding())

        self.assertFalse(self.dut.get_y_axis_is_frame_axis())
        self.dut.set_y_axis_is_frame_axis(True)
        self.assertTrue(self.dut.get_y_axis_is_frame_axis())


class TestPolarizationPropertyFloat(PolarizationPropertyTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self._pol_proc.properties

    def test_polarization_property_float(self):
        self.assertAlmostEqual(self.dut.get_intensity_threshold_db(), 20.0)
        self.dut.set_intensity_threshold_db(2.0)
        self.assertEqual(self.dut.get_intensity_threshold_db(), 2.0)

        self.assertAlmostEqual(self.dut.get_pmd_correction_angle_rad(), 0.0)
        self.dut.set_pmd_correction_angle_rad(3.0)
        self.assertEqual(self.dut.get_pmd_correction_angle_rad(), 3.0)

        self.assertAlmostEqual(self.dut.get_central_wavelength_nm(), 1310.0, 3)
        self.dut.set_central_wavelength_nm(4.0)
        self.assertAlmostEqual(self.dut.get_central_wavelength_nm(), 4.0, 5)

        self.assertAlmostEqual(self.dut.get_optical_axis_offset_rad(), 0.0)
        self.dut.set_optical_axis_offset_rad(5.0)
        self.assertEqual(self.dut.get_optical_axis_offset_rad(), 5.0)


class TestPolarizationPropertyInt(PolarizationPropertyTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self._pol_proc.properties

    def test_polarization_property_float(self):
        self.assertEqual(self.dut.get_dopu_z(), 3)
        self.dut.set_dopu_z(7)
        self.assertEqual(self.dut.get_dopu_z(), 7)

        self.assertEqual(self.dut.get_dopu_x(), 3)
        self.dut.set_dopu_x(9)
        self.assertEqual(self.dut.get_dopu_x(), 9)

        self.assertEqual(self.dut.get_dopu_y(), 3)
        self.dut.set_dopu_y(11)
        self.assertEqual(self.dut.get_dopu_y(), 11)

        self.assertEqual(self.dut.get_dopu_filter_type(), 1)
        self.dut.set_dopu_filter_type(2)
        self.assertEqual(self.dut.get_dopu_filter_type(), 2)

        self.assertEqual(self.dut.get_bscan_averaging(), 1)
        self.dut.set_bscan_averaging(2)
        self.assertEqual(self.dut.get_bscan_averaging(), 2)

        self.assertEqual(self.dut.get_averaging_z(), 1)
        self.dut.set_averaging_z(2)
        self.assertEqual(self.dut.get_averaging_z(), 2)

        self.assertEqual(self.dut.get_averaging_x(), 1)
        self.dut.set_averaging_x(3)
        self.assertEqual(self.dut.get_averaging_x(), 3)

        self.assertEqual(self.dut.get_averaging_y(), 1)
        self.dut.set_averaging_y(4)
        self.assertEqual(self.dut.get_averaging_y(), 4)

        self.assertEqual(self.dut.get_ascan_averaging(), 1)
        self.dut.set_ascan_averaging(5)
        self.assertEqual(self.dut.get_ascan_averaging(), 5)

        self.assertRaises(NotImplementedError, lambda: self.dut.get_bscan_averaged())
        self.assertRaises(NotImplementedError, lambda: self.dut.set_bscan_averaged(6))


class PolarizationTestCase(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        set_log_level(LogLevel.OFF)

        # Note: requires write permissions on the Config folder
        sr_original_file = os.path.join(os.path.dirname(get_config_path()), 'Config\\SpectralRadar.ini')
        backup_path = os.path.join(os.path.dirname(get_config_path()), 'Config\\SpectralRadar_tmp.ini')

        shutil.copy2(sr_original_file, backup_path)

        with open(sr_original_file, 'r') as file:
            lines = file.readlines()

        with open(sr_original_file, 'w') as file:
            for line in lines:
                if 'HardwareConfig=Dummy_V1' in line:
                    file.write(line.replace('HardwareConfig=Dummy_V1', 'HardwareConfig=Dual_Dummy_V1') + '\n')
                else:
                    file.write(line)

    @classmethod
    def tearDownClass(cls):
        sr_original_file = os.path.join(os.path.dirname(get_config_path()), 'Config\\SpectralRadar.ini')
        backup_path = os.path.join(os.path.dirname(get_config_path()), 'Config\\SpectralRadar_tmp.ini')

        os.remove(sr_original_file)
        shutil.copy2(backup_path, sr_original_file)
        os.remove(backup_path)

    def setUp(self):
        self._system = OCTSystem()
        self.dev = self._system.dev
        self.proc_0 = self._system.processing_factory.from_device()
        self.proc_1 = self._system.processing_factory.from_device(1)
        self.probe = self._system.probe_factory.create_default()
        self.pattern = self.probe.scan_pattern.create_bscan_pattern(10.0, 100)

        self.dut = Polarization()

        self.raw_0 = RawData()
        self.raw_1 = RawData()

        self.complex_0 = ComplexData()
        self.complex_1 = ComplexData()

    def tearDown(self):
        del self.complex_1
        del self.complex_0

        del self.raw_1
        del self.raw_0

        del self.dut

        del self.pattern
        del self.probe
        del self.proc_1
        del self.proc_0
        del self.dev
        del self._system

    def test_polarization_processing(self):
        self.dev.acquisition.start(self.pattern, AcqType.ASYNC_FINITE)
        self.dev.acquisition.get_raw_data(buffer=self.raw_0)
        self.dev.acquisition.get_raw_data(1, self.raw_1)
        self.dev.acquisition.stop()

        self.proc_0.set_data_output(self.complex_0)
        self.proc_1.set_data_output(self.complex_1)

        self.proc_0.execute(self.raw_0)
        self.proc_1.execute(self.raw_1)

        stokes_param_i = RealData()
        stokes_param_q = RealData()
        stokes_param_u = RealData()
        stokes_param_v = RealData()
        retardation = RealData()
        optical_axis = RealData()
        dopu = RealData()

        self.dut.set_data_output(stokes_param_i, PolarizationOutput.INTENSITY)
        self.dut.set_data_output(stokes_param_q, PolarizationOutput.STOKES_Q)
        self.dut.set_data_output(stokes_param_u, PolarizationOutput.STOKES_U)
        self.dut.set_data_output(stokes_param_v, PolarizationOutput.STOKES_V)
        self.dut.set_data_output(retardation, PolarizationOutput.RETARDATION)
        self.dut.set_data_output(optical_axis, PolarizationOutput.OPTIC_AXIS)
        self.dut.set_data_output(dopu, PolarizationOutput.DOPU)

        self.dut.execute(self.complex_0, self.complex_1)

        self.assertEqual(stokes_param_i.shape, (1024, 100, 1))
        self.assertEqual(stokes_param_q.shape, (1024, 100, 1))
        self.assertEqual(stokes_param_u.shape, (1024, 100, 1))
        self.assertEqual(stokes_param_v.shape, (1024, 100, 1))
        self.assertEqual(retardation.shape, (1024, 100, 1))
        self.assertEqual(optical_axis.shape, (1024, 100, 1))
        self.assertEqual(dopu.shape, (1024, 100, 1))

    def test_polarization_metadata(self):
        file = OCTFile()

        self.dev.acquisition.start(self.pattern, AcqType.ASYNC_FINITE)
        self.dev.acquisition.get_raw_data(buffer=self.raw_0)
        self.dev.acquisition.get_raw_data(1, self.raw_1)
        self.dev.acquisition.stop()

        self.proc_0.set_data_output(self.complex_0)
        self.proc_1.set_data_output(self.complex_1)

        self.proc_0.execute(self.raw_0)
        self.proc_1.execute(self.raw_1)

        stokes_param_i = RealData()
        retardation = RealData()

        self.dut.set_data_output(stokes_param_i, PolarizationOutput.INTENSITY)
        self.dut.set_data_output(retardation, PolarizationOutput.RETARDATION)

        self.dut.execute(self.complex_0, self.complex_1)

        file.set_polarization_metadata(self.dut)
        self.dut.set_metadata_to_file(file)


if __name__ == '__main__':
    unittest.main()
