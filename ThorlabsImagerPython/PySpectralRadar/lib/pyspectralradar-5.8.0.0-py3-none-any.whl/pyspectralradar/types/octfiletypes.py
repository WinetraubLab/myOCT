from enum import IntEnum


class FileNames:
    """The following constants are intended to be used as a possible third argument when invoking the
    :func:`~pyspectralradar.octfile.octfile.OCTFile.add_data`.
    It can also be used as the second argument in the :func:`~pyspectralradar.octfile.octfile.OCTFile.find` and
    :func:`~pyspectralradar.octfile.octfile.OCTFile.__contains__`.

    Spectral raw data mus be specified by its index.
    """

    OCT_DATA = "data\\Intensity.data"
    VARIANCE_DATA = "data\\Variance.data"
    PHASE_DATA = "data\\Phase.data"
    SPECTRAL1D_DATA = "data\\SpectralFloat.data"
    ANALOG_INPUT_DATA = "data\\AnalogInput.data"
    FREEFORM_SCAN_POINTS = "data\\CustomScanPoints.data"
    FREEFORM_SCAN_POINTS_INTERP = "data\\CustomScanPointsInterpolated.data"
    COMPLEX_OCT_DATA = "data\\Complex.data"
    VIDEO_IMAGE = "data\\VideoImage.data"
    PREVIEW_IMAGE = "data\\PreviewImage.data"


class Modes:
    """The enum entries are intended to be used as argument when invoking
    :func:`~pyspectralradar.octfile.properties.octfilepropertystring.OCTFilePropertyString.set_acquisition_mode`
    They may also be returned by :func`~pyspectralradar.octfile.properties.octfilepropertystring
    .OCTFilePropertyString.get_acquisition_mode`
    """

    m1d = "Mode1D"
    """The constant identifies the one-dimensional measurement mode (A-Scan)."""

    m2d = "Mode2D"
    """The constant identifies the two-dimensional measurement mode (B-Scan)."""

    m3d = "Mode3D"
    """The constant identifies the three-dimensional measurement mode (Volume)."""

    DOPPLER = "ModeDoppler"
    """The constant identifies the Doppler measurement mode."""

    SPECKLE = "ModeSpeckle"
    """The constant identifies the Speckle Variance measurement mode."""

    POLARIZATION_SENSITIVE = "ModePolarization"
    """The constant identifies the two-dimensional polarization sensitive measurement mode                           
    (only available on Polarization Sensitive OCT systems, check your hardware manual)."""

    POLARIZATION_SENSITIVE_3D = "ModePolarization3D"
    """The constant identifies the three-dimensional polarization sensitive measurement mode
    (only available on Polarization Sensitive OCT systems, check your hardware manual)."""


class ProcessingStates(IntEnum):
    """Enum to specify the processing state of the stored data."""

    RAW_SPECTRA = 0
    """Just the spectra, without any further processing. See also 
    :func:`~pyspectralradar.octfile.octfile.OCTFile.save_calibration` and 
    :func:`~pyspectralradar.octfile.octfile.OCTFile.add_data`."""

    PROCESSED_INTENSITY = 1
    """Just the computed intensity"""

    RAW_AND_PROCESSED = 2
    """Both the spectra and the computed intensity get stored. In the case of polarization-sensitive instruments,
       the complex data of camera 0 and camera 1 are saved."""

    PROCESSED_INTENSITY_AND_PHASE = 3
    """The computed intensity and the computed phase are stored in the OCT file."""

    RAW_AND_PROCESSED_AND_PHASE = 4
    """The spectra, the computed intensity and the computed phase are stored in the OCT file."""

    PS_SPECKLE_VARIANCE = 5
    """Speckle variance data, i.e., averaged intensity and speckle variance contrast is stored in the OCT file."""

    PS_RAW_SPECTRA_AND_SPECKLE_VARIANCE = 6
    """The spectra and speckle variance data, i.e., averaged intensity and speckle variance contrast is stored in the 
    OCT file."""

    PS_COLORED = 7
    """Colored data is stored in the OCT file"""

    PS_UNKNOWN = 999
    """It is unknown what kind of data is stored in the file."""


class FileFormat(IntEnum):
    """Enum identifying possible file formats"""

    OCITY = 0
    """Basic Thorlabs OCT format"""

    IMG = 1
    """Binary IMG format"""

    SDR = 2
    """Legacy Thorlabs OCT SD-OCT files format SDR"""

    SRM = 3
    """SRM"""

    TIFF32 = 4
    """32 bit floating point multi-page TIFF (3D)"""


class DataType(IntEnum):
    """Enum Type selector of data objects stored to the OCT file"""

    REAL = 0
    """Real processed data"""

    COLORED = 1
    """Colored data"""

    COMPLEX = 2
    """Complex data"""

    RAW = 3
    """Raw spectral data"""

    BINARY = 4
    """Binary data"""

    TEXT = 5
    """Text data"""

    REAL_PRECISION = 6
    """Real precision data"""

    UNKNOWN = 999
    """Unknown data"""
