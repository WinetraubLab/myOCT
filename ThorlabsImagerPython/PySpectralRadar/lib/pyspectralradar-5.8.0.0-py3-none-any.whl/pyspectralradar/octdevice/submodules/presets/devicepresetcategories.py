from ctypes import c_char_p, c_int
from typing import Dict, Tuple

from pyspectralradar.base import Submodule
from pyspectralradar.spectralradar import c_handle, get_error, sr


class PresetCategories(Submodule):
    """
    Different devices support different preset categories (gain, speed, etc.). When getting or setting a preset,
    the right category must be provided. To get a dictionary containing the names and indices of all supported
    categories, use the function :func:`~get_available_categories`. To get the index of a supported category,
    provided you know the name, use the function :func:`~get_category_index` (this is the index need when getting or
    setting a preset of a given category).
    """

    def get_available_categories(self) -> Dict[str, int]:
        """Get dictionary of all available category names and their corresponding indices

        Returns:
            A dictionary mapping all available preset categories to their corresponding indices.
        """
        names = self._get_all_category_names()
        category_dict = {names[idx]: idx for idx in range(len(names))}
        return category_dict

    def _get_all_category_names(self) -> Tuple[str]:
        """Get tuple of names of all available device preset categories

        Returns:
            A tuple of all available device preset categories.
        """
        n = self.get_number_of_categories()
        cat_names = tuple([self.get_category_name(idx) for idx in range(n)])
        return cat_names

    def get_number_of_categories(self) -> int:
        """If the hardware supports multiple presets, the function returns the number of categories in which presets
        can be set.

        Returns:
            The number of available categories.
        """
        sr.getNumberOfDevicePresetCategories.argtypes = [c_handle]
        sr.getNumberOfDevicePresetCategories.restype = c_int
        n = sr.getNumberOfDevicePresetCategories(self.handle)
        get_error()
        return n

    def get_category_name(self, category_index: int) -> str:
        """Gets a descriptor/name for the respective preset category

        Args:
            :category_index: An index describing the preset category in the range between 0 and the number of preset
                categories minus 1, given by :func:`~get_number_of_categories`
        Returns:
            The name of the requested device preset category.
        """
        sr.getDevicePresetCategoryName.argtypes = [c_handle, c_int]
        sr.getDevicePresetCategoryName.restype = c_char_p
        raw_name = sr.getDevicePresetCategoryName(self.handle, category_index)
        name = raw_name.decode('ascii')
        get_error()
        return name

    def get_category_index(self, category_name: str) -> int:
        """Gets the index of a preset category from the name of the category.

        Args:
            :name: The name of the device preset category.
            
        Returns:
            An index describing the preset category in the range between 0 and the number of preset categories minus
            1, given by :func:`~get_number_of_categories`.
        """
        sr.getDevicePresetCategoryIndex.argtypes = [c_handle, c_char_p]
        sr.getDevicePresetCategoryIndex.restype = c_int
        index = sr.getDevicePresetCategoryIndex(self.handle, category_name.encode('ascii'))
        get_error()
        return index
