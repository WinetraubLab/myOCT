from ctypes import c_int
from typing import Tuple

from pyspectralradar.base import Submodule
from pyspectralradar.data import RawData, RealData
from pyspectralradar.probe import Probe
from pyspectralradar.processing import Processing
from pyspectralradar.scanpattern import ScanPattern
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import AcqType, CalibrationType


class Acquisition(Submodule):
    def start(self, pattern: ScanPattern, acq_type: AcqType):
        """Starts a measurement using the given scan pattern.

        Args:
            :pattern: A valid (non-null) scan pattern
            :acq_type: This parameter decides whether the acquisition proceeds asynchronous (continuous or finite)
                or synchronous

        Scanning proceeds according to the specified scan pattern handle. In order to retrieve the acquired data,
        refer to the :func:`~pyspectralradar.octdevice.submodules.acquisition.acquisition.Acquisition.get_raw_data`
        function. To stop the measuring process, invoke
        :func:`~pyspectralradar.octdevice.submodules.acquisition.acquisition.Acquisition.stop`. synchronous
        measurements get triggered when the user invokes function that retrieves the data. Asynchronous measurements
        proceed in background, and the retrieving function returns the last available buffer that has been filled
        with fresh data. Asynchronous measurements can acquire a pre-specified number of buffers (finite) or continue
        indefinitely (continuous). If it is not possible to retrieve acquired data for a while, intermediate buffers
        might be skipped.
        """
        sr.startMeasurement.argtypes = [c_handle, c_handle, c_int]
        sr.startMeasurement(self.handle, pattern.handle, acq_type)
        get_error()

    def stop(self):
        """Stops the current measurement."""
        sr.stopMeasurement.argtypes = [c_handle]
        sr.stopMeasurement(self.handle)
        get_error()

    def get_raw_data(self, camera_idx: int = 0, buffer: RawData = None) -> RawData:
        """Acquires data with the specific camera given with camera index and stores the data unprocessed.

        :Warning: Unless the program divides the acquisition in different threads, this function should be invoked
            first for the master camera (``camera_idx = 0``) and only then for the slaves. Otherwise, it will block
            forever.

        Args:
            :camera_idx: The camera index (0-based, i.e. zero for the first = master, one for the second, and so on).
            :buffer: If a pre-allocated object shall be used, a valid (non-None) raw data object the data shall be
                written to is required

        In case of a synchronous measurement, this function will trigger the data acquisition. Otherwise, it will
        return the latest acquired data buffer. In any case, this function will block until a data buffer is
        available (asynchronous measurements may satisfy this requirement immediately if a previously acquired buffer
        has not already been consumed).

        In systems with more than one camera, the hardware connections ensure that all cameras measure
        simultaneously. That is, they have a common trigger. The master camera (``camera_idx`` 0)
        will actually trigger the measurement of all slaves. for this reason, this function should be invoked first for
        the master (``camera_idx`` 0) and only afterward for the slaves (``camera_idx`` greater than 0). If a slave
        triggers first, it will wait for the master (that is, this function call will block the current execution
        thread). If the master triggers first, the buffer for the slave will be ready for pickup by the time the
        slave retrieves (without blocking).

        Notice that raw data refers to the spectra as acquired, without processing of any kind.
        """
        if buffer is None:
            buffer = RawData()
        else:
            assert isinstance(buffer, RawData)
        sr.getRawDataEx.argtypes = [c_handle, c_handle, c_int]
        sr.getRawDataEx(self.handle, buffer.handle, camera_idx)
        get_error()
        return buffer

    def get_analog_input_data(self) -> RealData:
        """Acquires analog data and stores the result floating point voltages.

        Data from apodization and flyback regions will be discarded.

        :func:`~pyspectralradar.octdevice.submodules.acquisition.acquisition.Acquisition.get_raw_data` needs to be
        called before each call to get the analog input data.

        Returns:
            The analog input.
        """
        data = RealData()
        sr.getAnalogInputData.argtypes = [c_handle, c_handle]
        sr.getAnalogInputData(self.handle, data.handle)
        get_error()
        return data

    def get_analog_input_data_ex(self) -> Tuple[RealData, RealData]:
        """Acquires analog data and stores the result floating point voltages.

        Data from flyback regions will be discarded, data from apodization regions will be stored in the returned tuple.

        :func:`~pyspectralradar.octdevice.submodules.acquisition.acquisition.Acquisition.get_raw_data` needs to be
        called before each call to get analog input data.

        Returns:
            A tuple (``data``, ``apo_data``) containing ``data`` as the analog input and ``apo_data`` as the apo
            regions data.
        """
        data = RealData()
        apo_data = RealData()
        sr.getAnalogInputDataEx.argtypes = [c_handle, c_handle, c_handle]
        sr.getAnalogInputDataEx(self.handle, data.handle, apo_data.handle)
        get_error()
        return data, apo_data

    def measure_spectra(self, number_of_spectra: int, camera_idx: int = 0,
                        buffer: RawData | None = None) -> RawData:
        """Acquires the desired number of spectra (raw data without processing) without moving Galvo scanners,
        for the desired camera.

        Args:
            :number_of_spectra: The desired number of spectra
            :camera_idx: The camera index (0-based, i.e. zero for the first = master, one for the second, and so on)
            :buffer: Optional pre-allocated data buffer

        :Warning:
              Unless the program divides the acquisition in different threads, this function should be invoked first
              for the master camera (``camera_idx = 0``) and only then for the slaves. Otherwise, it will block forever.

        This procedure assumes that there is no any ongoing measurement process (started with the function
        :func:`~pyspectralradar.octdevice.submodules.acquisition.acquisition.Acquisition.stop.start`. The indicated
        number of measurements will be
        carried out. The user should not stop the measurement (this function will block till the whole data is ready).

        If the hardware contains more than one camera, all cameras will be triggered together with the first one (the
        master), because the hardware has been set up to do so. If ``camera_idx`` is different from zero, i.e. a slave
        is meant, this function will retrieve the spectra measured together with the master. If those data happen to
        be already consumed, this function will block until the master triggers. Notice that in a single thread
        programming model, the program would stop execution forever. For this reason, it is strongly advised to
        invoke this function first for the master (``camera_idx = 0``) and only then for the slaves.

        This function will retrieve raw data only for the selected camera. The user must invoke this function for
        each camera separately, but in judicious order, as explained before.

        This function blocks till the desired number of spectra get written in the indicated buffer (
        :class:`~pyspectralradar.data.rawdata.RawData`).

        Notice that raw data refers to the spectra as acquired, without processing of any kind.

        Returns:
            The acquired spectra data will be stored in a :class:`~pyspectralradar.data.rawdata.RawData` object. The
            metadata (dimensions, sizes, bytes per pixel, etc.) will be adjusted automatically.
        """
        if buffer is None:
            buffer = RawData()
        sr.measureSpectraEx.argtypes = [c_handle, c_int, c_handle, c_int]
        sr.measureSpectraEx(self.handle, number_of_spectra, buffer.handle, camera_idx)
        get_error()
        return buffer

    def measure_spectra_continuous(self, number_of_spectra: int, camera_idx: int = 0,
                                   buffer: RawData | None = None) -> RawData:
        """Acquires the desired number of spectra (raw data without processing) without moving Galvo scanners,
        for the desired camera.

        Starts a continuous acquisition in the background and uses ongoing acquisition if possible, to avoid latency
        from start/stop measurement.

        Args:
            :number_of_spectra: The desired number of spectra
            :camera_idx: The camera index (0-based, i.e. zero for the first = master, one for the second, and so on)
            :buffer: Optional pre-allocated data buffer

        Warning:
            Unless the program divides the acquisition in different threads, this function
            should be invoked first for the master camera (``camera_idx = 0``) and only then for the slaves. Otherwise,
            it will block forever.

        Note that calling this function will leave the device with a running acquisition. This means, that trigger
        signals will be generated continuously and any kind of device configuration that is not supported during an
        acquisition will fail. To restore the device to a default state,
        call :func:`~pyspectralradar.octdevice.submodules.acquisition.acquisition.Acquisition.stop`. Additionally,
        this method may not support acquiring an arbitrary number of spectra, depending on the device. Use
        :func:`~pyspectralradar.octdevice.properties.devicepropertyint.DevicePropertyInt.get_min_spectra_per_buffer`
        to query the minimum buffer size. If less than the minimum number of buffers are requested, the device will
        discard the additional spectra.

        Returns:
           The acquired spectra data will be stored in a :class:`~pyspectralradar.data.rawdata.RawData` object. The
           metadata (dimensions, sizes, bytes per pixel, etc.) will be adjusted automatically.


        """
        if buffer is None:
            buffer = RawData()
        sr.measureSpectraContinuousEx.argtypes = [c_handle, c_int, c_handle, c_int]
        sr.measureSpectraContinuousEx(self.handle, number_of_spectra, buffer.handle, camera_idx)
        get_error()
        return buffer

    def measure_calibration(self, processing: Processing, selection: CalibrationType, camera_idx: int = 0):
        """Measures the specified calibration parameters and uses them in subsequent processing.

        Args:
            :processing: A valid (non-null) processing routines object
            :selection: Indicates the calibration that will be measured
            :camera_idx: The camera index (0-based, i.e. zero for the first = master, one for the second, and so on).

        If the hardware contains more than one camera, all cameras will be triggered, because the hardware has been
        set up to do so. This function will return raw data only for the first camera (the master). The raw data
        for the slaves, acquired simultaneously, will be available for retrieval any time afterward.

        Using the parameters ``APO_SPECTRUM`` or ``APO_VECTOR`` will acquire the apodization spectra without moving
        the mirrors to the apodization position. To acquire the spectra used for the processing in the apodization
        position use
        :func:`~pyspectralradar.octdevice.submodules.acquisition.acquisition.Acquisition.measure_apo_spectra`. Please
        note that the apodization spectra will not be acquired in the specified apodization position from the
        :class:`~pyspectralradar.probe.probe.Probe`.
        """
        sr.measureCalibrationEx.argtypes = [c_handle, c_handle, c_int, c_int]
        sr.measureCalibrationEx(self.handle, processing.handle, selection, camera_idx)
        get_error()

    def measure_apo_spectra(self, probe: Probe, processing: Processing):
        """Measures the apodization spectra in the defined apodization position and size and uses them in subsequent
        processing.

        Args:
            :probe: The probe to be used.
            :processing: The processing to be used.

        If the hardware contains more than one camera, all cameras will be triggered, because the hardware has been
        set up to do so. This function will return raw data only for the first camera (the master). The raw data for
        the slaves, acquired simultaneously, will be available for retrieval any time afterward (the function
        :func:`~pyspectralradar.octdevice.submodules.acquisition.acquisition.Acquisition.measure_calibration` should
        be used).
        """
        sr.measureApodizationSpectra.argtypes = [c_handle, c_handle, c_handle]
        sr.measureApodizationSpectra(self.handle, probe.handle, processing.handle)
        get_error()
