import unittest
from os import remove
from os.path import exists

import numpy as np

from pyspectralradar import ColoredData, Coloring, ComplexData, OCTFile, OCTSystem, Processing, RealData, \
    LogLevel, set_log_level
from pyspectralradar.spectralradar import SpectralRadarException
from pyspectralradar.types import ApoWindowParameter, ApoWindowType, AvgAlgorithm, CalibrationType, ColorScheme, \
    DispersionCorrectionType, FFTType, SpectrumType
from pyspectralradar.processing.staticmethods import *

class TestProcessingFactory(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def setUp(self):
        self.sys = OCTSystem()
        self.dut = self.sys.processing_factory

    def tearDown(self):
        del self.dut
        del self.sys

    def test_factory_from_file(self):
        oct_file = OCTFile("\\\\lbknetapp01\\Public\\Doc\\Software\\Unittests\\PySRDemo\\PyDemo_0001_Mode2D.oct")
        self.assertIsInstance(self.dut.from_oct_file(oct_file), Processing)
        del oct_file

    def test_factory_from_device(self):
        self.assertIsInstance(self.dut.from_device(), Processing)

    def test_factory_create(self):
        self.assertIsInstance(self.dut.create(2048, 2, False, 1.0, 1000, FFTType.STANDARD_FFT, 3.1), Processing)


class TestProcessingProperties(unittest.TestCase):
    def setUp(self):
        self.sys = OCTSystem()
        self.proc = self.sys.processing_factory.from_device()
        self.props = self.proc.properties

    def tearDown(self):
        del self.sys

    def test_property_float(self):
        pp = self.props

        self.assertIsInstance(pp.get_fft_oversampling(), float)
        self.assertEqual(pp.get_fft_oversampling(), 0.0)
        # pp.set_fft_oversampling(2.1)
        # self.assertAlmostEqual(pp.get_fft_oversampling(), 2.1, places=4)
        # pp.set_fft_oversampling(0.0)
        # self.assertEqual(pp.get_fft_oversampling(), 0.0)

        self.assertIsInstance(pp.get_max_sensor_value(), float)
        self.assertEqual(pp.get_max_sensor_value(), 0.0)
        pp.set_max_sensor_value(0.1)
        self.assertAlmostEqual(pp.get_max_sensor_value(), 0.1)
        pp.set_max_sensor_value(0.0)
        self.assertEqual(pp.get_max_sensor_value(), 0.0)
        #
        self.assertIsInstance(pp.get_min_electrons(), float)
        self.assertEqual(pp.get_min_electrons(), 447.2135925292969)
        pp.set_min_electrons(447.3135925292969)
        self.assertAlmostEqual(pp.get_min_electrons(), 447.3135925292969, places=4)
        pp.set_min_electrons(447.2135925292969)
        self.assertEqual(pp.get_min_electrons(), 447.2135925292969)
        #

    def test_property_int(self):
        pp = self.props

        self.assertIsInstance(pp.get_ascan_avg(), int)
        self.assertEqual(pp.get_ascan_avg(), 1)
        pp.set_ascan_avg(2)
        self.assertEqual(pp.get_ascan_avg(), 2)
        pp.set_ascan_avg(1)
        self.assertEqual(pp.get_ascan_avg(), 1)
        #
        self.assertIsInstance(pp.get_bscan_avg(), int)
        self.assertEqual(pp.get_bscan_avg(), 1)
        pp.set_bscan_avg(2)
        self.assertEqual(pp.get_bscan_avg(), 2)
        pp.set_bscan_avg(1)
        self.assertEqual(pp.get_bscan_avg(), 1)
        #
        self.assertIsInstance(pp.get_fourier_avg(), int)
        self.assertEqual(pp.get_fourier_avg(), 1)
        pp.set_fourier_avg(2)
        self.assertEqual(pp.get_fourier_avg(), 2)
        pp.set_fourier_avg(1)
        self.assertEqual(pp.get_fourier_avg(), 1)
        #
        self.assertIsInstance(pp.get_number_of_threads(), int)
        self.assertEqual(pp.get_number_of_threads(), 0)
        pp.set_number_of_threads(1)
        self.assertEqual(pp.get_number_of_threads(), 1)
        pp.set_number_of_threads(0)
        self.assertEqual(pp.get_number_of_threads(), 0)
        #
        self.assertIsInstance(pp.get_spectrum_avg(), int)
        self.assertEqual(pp.get_spectrum_avg(), 1)
        pp.set_spectrum_avg(2)
        self.assertEqual(pp.get_spectrum_avg(), 2)
        pp.set_spectrum_avg(1)
        self.assertEqual(pp.get_spectrum_avg(), 1)
        #
        self.assertIsInstance(pp.get_zero_padding(), int)
        self.assertEqual(pp.get_zero_padding(), 1)
        pp.set_zero_padding(2)
        self.assertEqual(pp.get_zero_padding(), 2)
        pp.set_zero_padding(1)
        self.assertEqual(pp.get_zero_padding(), 1)

        #

    def test_property_flag(self):
        pp = self.props

        val = pp.get_remove_dc()
        self.assertIsInstance(val, bool)
        self.assertTrue(val)
        pp.set_remove_dc(False)
        val = pp.get_remove_dc()
        self.assertFalse(val)
        pp.set_remove_dc(True)
        val = pp.get_remove_dc()
        self.assertTrue(val)
        #
        val = pp.get_remove_dc_adv()
        self.assertIsInstance(val, bool)
        self.assertTrue(val)
        pp.set_remove_dc_adv(False)
        val = pp.get_remove_dc_adv()
        self.assertFalse(val)
        pp.set_remove_dc_adv(True)
        val = pp.get_remove_dc_adv()
        self.assertTrue(val)
        #
        val = pp.get_apodization()
        self.assertIsInstance(val, bool)
        self.assertTrue(val)
        pp.set_apodization(False)
        val = pp.get_apodization()
        self.assertFalse(val)
        pp.set_apodization(True)
        val = pp.get_apodization()
        self.assertTrue(val)
        #
        val = pp.get_autocorr_corr()
        self.assertIsInstance(val, bool)
        self.assertFalse(val)
        pp.set_autocorr_corr(True)
        val = pp.get_autocorr_corr()
        self.assertTrue(val)
        pp.set_autocorr_corr(False)
        val = pp.get_autocorr_corr()
        self.assertFalse(val)
        #
        val = pp.get_dechirp()
        self.assertIsInstance(val, bool)
        self.assertTrue(val)
        pp.set_dechirp(False)
        val = pp.get_dechirp()
        self.assertFalse(val)
        pp.set_dechirp(True)
        val = pp.get_dechirp()
        self.assertTrue(val)
        #
        val = pp.get_defr()
        self.assertIsInstance(val, bool)
        self.assertFalse(val)
        pp.set_defr(True)
        val = pp.get_defr()
        self.assertTrue(val)
        pp.set_defr(False)
        val = pp.get_defr()
        self.assertFalse(val)
        #
        val = pp.get_dispersion()
        self.assertIsInstance(val, bool)
        self.assertFalse(val)
        pp.set_dispersion(True)
        val = pp.get_dispersion()
        self.assertTrue(val)
        pp.set_dispersion(False)
        val = pp.get_dispersion()
        self.assertFalse(val)
        #
        val = pp.get_ext_adjust()
        self.assertIsInstance(val, bool)
        self.assertFalse(val)
        pp.set_ext_adjust(True)
        val = pp.get_ext_adjust()
        self.assertTrue(val)
        pp.set_ext_adjust(False)
        val = pp.get_ext_adjust()
        self.assertFalse(val)
        #
        val = pp.get_filter_dc()
        self.assertIsInstance(val, bool)
        self.assertFalse(val)
        pp.set_filter_dc(True)
        val = pp.get_filter_dc()
        self.assertTrue(val)
        pp.set_filter_dc(False)
        val = pp.get_filter_dc()
        self.assertFalse(val)
        #
        val = pp.get_fixed_pattern()
        self.assertIsInstance(val, bool)
        self.assertFalse(val)
        pp.set_fixed_pattern(True)
        val = pp.get_fixed_pattern()
        self.assertTrue(val)
        pp.set_fixed_pattern(False)
        val = pp.get_fixed_pattern()
        self.assertFalse(val)
        #
        val = pp.get_full_range()
        self.assertIsInstance(val, bool)
        self.assertFalse(val)
        pp.set_full_range(True)
        val = pp.get_full_range()
        self.assertTrue(val)
        pp.set_full_range(False)
        val = pp.get_full_range()
        self.assertFalse(val)
        #
        val = pp.get_only_win()
        self.assertIsInstance(val, bool)
        self.assertFalse(val)
        pp.set_only_win(True)
        val = pp.get_only_win()
        self.assertTrue(val)
        pp.set_only_win(False)
        val = pp.get_only_win()
        self.assertFalse(val)
        #
        val = pp.get_saturation()
        self.assertIsInstance(val, bool)
        self.assertFalse(val)
        pp.set_saturation(True)
        val = pp.get_saturation()
        self.assertTrue(val)
        pp.set_saturation(False)
        val = pp.get_saturation()
        self.assertFalse(val)
        #
        val = pp.get_scan_for_apo()
        self.assertIsInstance(val, bool)
        self.assertFalse(val)
        pp.set_scan_for_apo(True)
        val = pp.get_scan_for_apo()
        self.assertTrue(val)
        pp.set_scan_for_apo(False)
        val = pp.get_scan_for_apo()
        self.assertFalse(val)
        #
        val = pp.get_undersampling_filter()
        self.assertIsInstance(val, bool)
        self.assertFalse(val)
        pp.set_undersampling_filter(True)
        val = pp.get_undersampling_filter()
        self.assertTrue(val)
        pp.set_undersampling_filter(False)
        val = pp.get_undersampling_filter()
        self.assertFalse(val)
        #
        val = pp.get_use_offset()
        self.assertIsInstance(val, bool)
        self.assertTrue(val)
        pp.set_use_offset(False)
        val = pp.get_use_offset()
        self.assertFalse(val)
        pp.set_use_offset(True)
        val = pp.get_use_offset()
        self.assertTrue(val)
        #


class ProcessingTestCase(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def setUp(self):
        self.sys = OCTSystem()
        self.proc = self.sys.processing_factory.from_device()
        self.props = self.proc.properties
        self.probe = self.sys.probe_factory.create_default(
            '\\\\lbknetapp01\\Public\\Doc\\Software\\Unittests\\PySpectralRadarTests\\Probe.ini')

    def tearDown(self):
        del self.sys


class TestProcessingApodization(ProcessingTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self.proc.apo

    def test_window_type(self):
        self.assertEqual(self.dut.get_window_type(), ApoWindowType.HANN)
        self.dut.set_window_type(ApoWindowType.GAUSS)
        self.assertEqual(self.dut.get_window_type(), ApoWindowType.GAUSS)

    def test_window_parameter(self):
        self.dut.set_window_parameter(ApoWindowParameter.SIGMA, 5.0)
        self.assertEqual(self.dut.get_window_parameter(ApoWindowParameter.SIGMA), 5.0)
        self.dut.set_window_parameter(ApoWindowParameter.RATIO, 5.0)
        self.assertEqual(self.dut.get_window_parameter(ApoWindowParameter.RATIO), 5.0)
        self.dut.set_window_parameter(ApoWindowParameter.FREQUENCY, 5.0)
        self.assertEqual(self.dut.get_window_parameter(ApoWindowParameter.FREQUENCY), 5.0)

    def test_edge_channel(self):
        self.assertEqual(self.dut.get_edge_channels(), (0, 0))


class TestProcessingCalibration(ProcessingTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self.proc.calibration

    def test_getset_calibration(self):
        dummy_data = np.linspace(0, 2047, 2048)
        dummy_real_data = RealData.from_numpy(dummy_data)

        self.assertIsInstance(self.dut.get(CalibrationType.OFFSET_ERRORS), RealData)
        self.dut.set(CalibrationType.OFFSET_ERRORS, dummy_real_data)
        off_err = self.dut.get(CalibrationType.OFFSET_ERRORS)
        self.assertTrue(np.all(off_err.to_numpy() == dummy_real_data.to_numpy()))

        self.assertIsInstance(self.dut.get(CalibrationType.APO_SPECTRUM), RealData)
        self.dut.set(CalibrationType.APO_SPECTRUM, dummy_real_data)

        self.assertTrue(np.all(self.dut.get(CalibrationType.APO_SPECTRUM).to_numpy() == dummy_real_data.to_numpy()))

        self.assertIsInstance(self.dut.get(CalibrationType.APO_VECTOR), RealData)
        self.dut.set(CalibrationType.APO_VECTOR, dummy_real_data)
        self.assertTrue(np.all(self.dut.get(CalibrationType.APO_VECTOR).to_numpy() == dummy_real_data.to_numpy()))

        self.assertIsInstance(self.dut.get(CalibrationType.DISPERSION), RealData)
        self.dut.set(CalibrationType.DISPERSION, dummy_real_data)
        self.assertTrue(np.all(self.dut.get(CalibrationType.DISPERSION).to_numpy() == dummy_real_data.to_numpy()))

        self.assertIsInstance(self.dut.get(CalibrationType.CHIRP), RealData)
        self.dut.set(CalibrationType.CHIRP, dummy_real_data)
        self.assertTrue(np.all(self.dut.get(CalibrationType.CHIRP).to_numpy() == dummy_real_data.to_numpy()))

        self.assertIsInstance(self.dut.get(CalibrationType.EXT_ADJUST), RealData)
        self.assertRaises(SpectralRadarException,
                          lambda: self.dut.set(CalibrationType.EXT_ADJUST, dummy_real_data))

        self.assertRaises(SpectralRadarException,
                          lambda: self.assertIsInstance(self.dut.get(CalibrationType.FIXED_PATTERN),
                                                        RealData))

    def test_save_load_calibration(self):
        file_path = "C:\\tmp\\test_chirp.dat"
        self.dut.save(CalibrationType.CHIRP, path=file_path)

        oct_file = OCTFile(
            '\\\\lbknetapp01\\Public\\Doc\\Software\\Unittests\\PySpectralRadarTests\\Unittest_0001_Mode2D.oct')
        self.dut.load_from_oct_file(oct_file)

        self.assertTrue(exists(file_path))
        if exists(file_path):
            self.dut.load(CalibrationType.CHIRP, file_path)
            remove(file_path)

        new_file = OCTFile()
        self.dut.save_to_oct_file(new_file)
        del new_file


class TestProcessingDispersion(ProcessingTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self.proc.dispersion

    def test_set_preset(self):
        self.dut.set_presets_from_probe(self.probe)

        self.dut.set_preset(0)
        self.assertEqual(self.dut.get_current_preset_name(), 'Dispersion_Probe')

        self.dut.set_preset('Dispersion_Probe')
        self.assertEqual(self.dut.get_current_preset_name(), 'Dispersion_Probe')

        self.assertEqual(self.dut.get_presets(), ['Dispersion_Probe'])

    def test_quadratic_coeff(self):
        print(self.dut.get_quadratic_coeff())
        self.dut.set_quadratic_coeff(2000)
        self.assertEqual(self.dut.get_quadratic_coeff(), 2000)

    def test_correction_type(self):
        print(self.dut.get_correction_type())
        self.dut.set_correction_type(DispersionCorrectionType.QUADRATIC)
        self.assertEqual(self.dut.get_correction_type(), DispersionCorrectionType.QUADRATIC)


class TestProcessing(ProcessingTestCase):
    def setUp(self):
        super().setUp()
        self.dev = self.sys.dev
        self.raw = self.dev.acquisition.measure_spectra(100)

    def tearDown(self):
        del self.dev
        super().tearDown()

    def test_set_data_output(self):
        real = RealData()
        cmplx = ComplexData()
        colored = ColoredData()

        self.proc.set_data_output(real)
        self.proc.set_data_output(cmplx)

        color = Coloring(ColorScheme.BLACK_AND_RED_YELLOW)
        self.proc.set_colored_data_output(colored, color)

        spectrum_raw = RealData()
        offsets = RealData()
        dc_corrected = RealData()
        apo = RealData()
        self.proc.set_spectrum_output(spectrum_raw, SpectrumType.RAW)
        self.proc.set_spectrum_output(offsets, SpectrumType.OFFSET_CORRECTED)
        self.proc.set_spectrum_output(dc_corrected, SpectrumType.DC_CORRECTED)
        self.proc.set_spectrum_output(apo, SpectrumType.APODIZED)

        print(real.shape)
        print(cmplx.shape)
        print(colored.shape)
        print(spectrum_raw.shape)
        print(offsets.shape)
        print(dc_corrected.shape)
        print(apo.shape)

        self.proc.execute(self.raw)

        self.assertTrue(real.shape == (1024, 100, 1))
        self.assertTrue(cmplx.shape == (1024, 100, 1))
        self.assertTrue(colored.shape == (1024, 100, 1))
        self.assertTrue(spectrum_raw.shape == (2048, 100, 1))
        self.assertTrue(offsets.shape == (2048, 100, 1))
        self.assertTrue(dc_corrected.shape == (2048, 100, 1))
        self.assertTrue(apo.shape == (2048, 100, 1))

        self.proc.finish(cmplx)

        print(real.shape)
        print(cmplx.shape)
        print(colored.shape)
        print(spectrum_raw.shape)
        print(offsets.shape)
        print(dc_corrected.shape)
        print(apo.shape)

    def test_sizes(self):
        print(self.proc.get_input_size())
        self.assertEqual(self.proc.get_input_size(), 2048)
        print(self.proc.get_a_scan_size())
        self.assertEqual(self.proc.get_a_scan_size(), 1024)

    def test_algorithms(self):
        self.proc.execute(self.raw)
        print(self.proc.get_fft_type())

        self.proc.set_dechirp_algorithm(FFTType.STANDARD_FFT, 3.5)
        self.proc.set_averaging_algorithm(AvgAlgorithm.FOURIER_MAX)

    def test_reference_intensity(self):
        # this is 0.0 since we are working with the dummy
        self.assertEqual(self.proc.get_ref_intensity(), 0.0)
        self.assertEqual(self.proc.get_relative_ref_intensity(self.dev), 0.0)

    def test_saturation(self):
        self.proc.properties.set_max_sensor_value(100)
        self.proc.properties.set_saturation(True)
        self.proc.execute(self.raw)
        self.assertEqual(self.proc.get_relative_saturation(), 1.0)

    @unittest.skip  # TODO: only available in experimental branch
    def test_interference_ampl(self):
        # self.proc.properties.set_calculate_rel_interference_amp(True)
        print(self.proc.get_relative_interference_amplitude())

    def test_expected_hann_fwhm(self):
        print(self.proc.get_expected_hann_fwhm(self.dev))

    def test_calc_contrast(self):
        apo = RealData()
        self.proc.set_spectrum_output(apo, SpectrumType.APODIZED)
        self.proc.execute(self.raw)

        self.assertIsInstance(self.proc.calc_contrast(apo), RealData)

    def test_compute_phase(self):
        processed_complex = ComplexData()
        processed = RealData()

        self.proc.set_data_output(processed)
        self.proc.set_data_output(processed_complex)
        self.proc.execute(self.raw)

        amp, phase = compute_amplitude_and_phase(processed_complex)
        self.assertEqual(processed_complex.shape, amp.shape)
        self.assertEqual(processed_complex.shape, phase.shape)
        self.assertEqual(processed.shape, amp.shape)

        result_delta = np.sum(np.abs(processed.to_numpy() - amp.to_numpy()))
        self.assertLess(result_delta, 10)
        

if __name__ == '__main__':
    unittest.main()
