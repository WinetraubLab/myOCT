from ctypes import c_bool, c_char_p, c_int

from pyspectralradar.spectralradar import get_error, sr
from pyspectralradar.types import LogLevel


def set_log_level(log_level: LogLevel):
    """Specifies verbosity of logging. All messages more critical than the selected log level will be logged.
    I.e. if ``LogLevel.WARN`` is selected, warnings, errors and critical errors will be logged.
    Note: :func:`~set_log_level` MUST be called before a :class:`~pyspectralradar.octdevice.octdevice.OCTDevice`
    object was created, any subsequent changes will be ignored.

    Args:
        :log_level: Logging verbosity
    """
    sr.setLogLevel.argtypes = [c_int]
    sr.setLogLevel(log_level)
    get_error()


def set_log_output_file(file: str, overwrite: bool):
    """Direct log output to file, optionally overwriting the existing file

    Args:
        :file: Path of logfile
        :overwrite: If ``True``, existing log file will be overwritten
    """
    sr.setLogOutputFile.argtypes = [c_char_p, c_bool]
    sr.setLogOutputFile(file.encode('ascii'), overwrite)
    get_error()


def set_log_output_rotating_file(file: str, max_file_size: int, max_file_number: int):
    """Direct log output to rotating logfile. Once the logfile exceeds the specified maximum size, the file will be
    renamed and logging continues in a new, empty file.

    Args:
        :file: Path base of logfile, individual files will get a numerical suffix
        :max_file_size: Maximum size in bytes of logfiles
        :max_file_number: Maximum number of logfiles to maintain
    """
    sr.setLogOutputRotatingFile.argtypes = [c_char_p, c_int, c_int]
    sr.setLogOutputRotatingFile(file.encode('ascii'), max_file_size, max_file_number)
    get_error()


def set_log_output_console():
    """Direct log output to text console"""
    sr.setLogOutputRotatingFile()
    get_error()
