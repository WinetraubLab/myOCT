import unittest
from os import remove
from os.path import exists

import numpy as np
from matplotlib import pyplot as plt

from pyspectralradar import ImageField, OCTSystem, RealData, LogLevel, set_log_level
from pyspectralradar.types import AcqType, AcquisitionOrder, ApodizationType

ENABLE_PLOTS = False


class ImageFieldTestCase(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def setUp(self):
        sys = OCTSystem()
        self.probe = sys.probe_factory.create_default()
        dev = sys.dev
        proc = sys.processing_factory.from_device()
        self.pattern = self.probe.scan_pattern.create_volume_pattern(5, 100, 5, 100, ApodizationType.ONE_FOR_ALL,
                                                                     AcquisitionOrder.ACQ_ORDER_ALL)

        dev.acquisition.start(self.pattern, AcqType.ASYNC_FINITE)
        raw = dev.acquisition.get_raw_data()
        self.volume = RealData()
        proc.set_data_output(self.volume)
        proc.execute(raw)
        dev.acquisition.stop()

        self.surface = self.volume.analysis.determine_surface()
        self.dut = ImageField()


class TestImageField(ImageFieldTestCase):

    def test_create(self):
        self.assertIsInstance(ImageField(), ImageField)

    def test_from_probe(self):
        self.assertIsInstance(ImageField.from_probe(self.probe), ImageField)

    def test_determine(self):
        self.dut.determine(self.pattern, self.surface)

        mask = RealData.from_numpy(np.ones((100, 100)))
        self.dut.determine_with_mask(self.pattern, self.surface, mask)

    def test_apply(self):
        self.dut.determine(self.pattern, self.surface)
        volume_clone = self.volume.clone()
        self.dut.apply(self.pattern, volume_clone)
        surface_clone = self.surface.clone()
        self.dut.apply_on_surface(self.pattern, surface_clone)

        if ENABLE_PLOTS:
            plt.figure()
            plt.subplot(1, 2, 1)
            plt.imshow(self.volume.to_numpy()[:, 0, :])
            plt.title(f'Original Volume)')
            plt.subplot(1, 2, 2)
            plt.imshow(volume_clone.to_numpy()[:, 0, :])
            plt.title(f'Corrected Volume)')

            plt.figure()
            plt.subplot(1, 2, 1)
            plt.imshow(self.surface.to_numpy()[:, 0, :])
            plt.title(f'Original Surface)')
            plt.subplot(1, 2, 2)
            plt.imshow(surface_clone.to_numpy()[:, 0, :])
            plt.title(f'Corrected Surface)')

            plt.show()

    def test_set_to_probe(self):
        self.dut.set_in_probe(self.probe)

    def test_save_load(self):
        self.dut.determine(self.pattern, self.surface)

        file_path = 'C:\\tmp\\imagefield_ut.dat'
        self.dut.save(file_path)

        self.assertTrue(exists(file_path))
        if exists(file_path):
            loaded_imagefield = ImageField()
            loaded_imagefield.load(file_path)
            remove(file_path)


if __name__ == '__main__':
    unittest.main()
