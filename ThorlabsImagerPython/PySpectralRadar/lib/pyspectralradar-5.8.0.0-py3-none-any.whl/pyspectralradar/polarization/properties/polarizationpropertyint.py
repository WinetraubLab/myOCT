from enum import IntEnum

from pyspectralradar.base.propertygetter import IntPropertyGetter
from pyspectralradar.base.propertysetter import IntPropertySetter
from pyspectralradar.spectralradar import sr


class PropertyInt(IntEnum):
    """Enum Values that determine the behaviour of the :class:`Polarization` processing routines."""

    DOPU_Z = 0
    """Number of pixels for DOPU averaging in the z-direction."""

    DOPU_X = 1
    """Number of pixels for DOPU averaging in the x-direction."""

    DOPU_Y = 2
    """Number of pixels for DOPU averaging in the y-direction."""

    DOPU_FILTER_TYPE = 3
    """DOPU filter specification. See #PolarizationDOPUFilterType."""

    BSCAN_AVERAGING = 4
    """Number of frames for averaging."""

    AVERAGING_Z = 5
    """Number of pixels for averaging along the z-axis."""

    AVERAGING_X = 6
    """Number of pixels for averaging along the x-axis."""

    AVERAGING_Y = 7
    """Number of pixels for averaging along the y-axis."""

    ASCAN_AVERAGING = 8
    """A-Scan averaging. This parameter influences the way data get acquired, it cannot be changed for offline
       processing."""

    BSCAN_AVERAGED = 9
    """Number of frames actually averaged (transiently different from #PolarizationProcessing_BScanAveraging until
       enough frames are available)."""


class PolarizationPropertyInt(IntPropertyGetter, IntPropertySetter):
    def __init__(self, handle):
        IntPropertyGetter.__init__(self, handle, sr.getPolarizationPropertyInt)
        IntPropertySetter.__init__(self, handle, sr.setPolarizationPropertyInt)

    def get_dopu_z(self) -> int:
        """Number of pixels for DOPU averaging in the z-direction. 1 + 2 * DOPU_avg_z"""
        return self._get(PropertyInt.DOPU_Z)

    def set_dopu_z(self, value: int):
        """Number of pixels for DOPU averaging in the z-direction. DOPU_Z-Averaging = ( value - 1 ) / 2."""
        self._set(PropertyInt.DOPU_Z, value)

    def get_dopu_x(self) -> int:
        """Number of pixels for DOPU averaging in the x-direction. 1 + 2 * DOPU_avg_x"""
        return self._get(PropertyInt.DOPU_X)

    def set_dopu_x(self, value: int):
        """Number of pixels for DOPU averaging in the x-direction. DOPU_X-Averaging = ( pixels - 1 ) / 2."""
        self._set(PropertyInt.DOPU_X, value)

    def get_dopu_y(self) -> int:
        """Number of pixels for DOPU averaging in the y-direction. 1 + 2 * DOPU_avg_y"""
        return self._get(PropertyInt.DOPU_Y)

    def set_dopu_y(self, value: int):
        """Number of pixels for DOPU averaging in the y-direction. DOPU_Y-Averaging = ( value - 1 ) / 2."""
        self._set(PropertyInt.DOPU_Y, value)

    def get_dopu_filter_type(self) -> int:
        """DOPU filter specification. See #PolarizationDOPUFilterType."""
        return self._get(PropertyInt.DOPU_FILTER_TYPE)

    def set_dopu_filter_type(self, value: int):
        """DOPU filter specification. See #PolarizationDOPUFilterType."""
        self._set(PropertyInt.DOPU_FILTER_TYPE, value)

    def get_bscan_averaging(self) -> int:
        """Number of frames for averaging."""
        return self._get(PropertyInt.BSCAN_AVERAGING)

    def set_bscan_averaging(self, value: int):
        """Number of frames for averaging."""
        self._set(PropertyInt.BSCAN_AVERAGING, value)

    def get_averaging_z(self) -> int:
        """Number of pixels for averaging along the z-axis."""
        return self._get(PropertyInt.AVERAGING_Z)

    def set_averaging_z(self, value: int):
        """Number of pixels for averaging along the z-axis."""
        self._set(PropertyInt.AVERAGING_Z, value)

    def get_averaging_x(self) -> int:
        """Number of pixels for averaging along the x-axis."""
        return self._get(PropertyInt.AVERAGING_X)

    def set_averaging_x(self, value: int):
        """Number of pixels for averaging along the x-axis."""
        self._set(PropertyInt.AVERAGING_X, value)

    def get_averaging_y(self) -> int:
        """Number of pixels for averaging along the y-axis."""
        return self._get(PropertyInt.AVERAGING_Y)

    def set_averaging_y(self, value: int):
        """Number of pixels for averaging along the y-axis."""
        self._set(PropertyInt.AVERAGING_Y, value)

    def get_ascan_averaging(self) -> int:
        """A-Scan averaging. This parameter influences the way data get acquired, it cannot be changed for offline
        processing."""
        return self._get(PropertyInt.ASCAN_AVERAGING)

    def set_ascan_averaging(self, value: int):
        """A-Scan averaging. This parameter influences the way data get acquired, it cannot be changed for offline
        processing."""
        self._set(PropertyInt.ASCAN_AVERAGING, value)

    def get_bscan_averaged(self) -> int:
        """Number of frames actually averaged (transiently different from #PolarizationProcessing_BScanAveraging until
        enough frames are available)."""
        # return self._get(PropertyInt.BSCAN_AVERAGED)
        raise NotImplementedError('Still under development')

    def set_bscan_averaged(self, value: int):
        """Number of frames actually averaged (transiently different from #PolarizationProcessing_BScanAveraging until
        enough frames are available)."""
        # self._set(PropertyInt.BSCAN_AVERAGED, value)
        raise NotImplementedError('Still under development')
