from ctypes import POINTER, c_double, c_int
from typing import Tuple

import numpy as np

from pyspectralradar.base import Submodule
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import AScanAnalysis, AnalysisTypes


class DataAnalysis(Submodule):
    def __init__(self, handle, container_type):
        super().__init__(handle)
        self._container_type = container_type

    def analyze(self, selection: AnalysisTypes) -> float:
        """Analyzes the given data, extracts the selected feature, and returns the computed value.

        Args:
            :selection: The desired feature that should be computed.

        Returns:
            The value of the desired feature.
        """
        assert isinstance(selection, AnalysisTypes)
        sr.analyzeData.restype = c_double
        sr.analyzeData.argtypes = [c_handle, c_int]
        res = sr.analyzeData(self.handle, selection)
        get_error()
        return res

    def analyze_ascan(self, selection: AScanAnalysis) -> float:
        """Analyzes the given A-scan data, extracts the selected feature, and returns the computed value.

        If the given data is multidimensional, only the first A-scan will be analyzed.

        Args:
            :selection: The desired feature that should be computed.

        Returns:
            The computed feature.
        """
        assert isinstance(selection, AScanAnalysis)
        sr.analyzeAScan.restype = c_double
        sr.analyzeAScan.argtypes = [c_handle, c_int]
        res = sr.analyzeAScan(self.handle, selection)
        get_error()
        return res

    def analyze_peaks_in_ascan(self, selection: AScanAnalysis, number_of_peaks: int, min_dist: int) -> np.ndarray:
        """Analyzes the given A-scan data, extracts the selected feature, and returns the computed value.

        It returns the result of multiple peaks compared to the function
        :func:`~pyspectralradar.data.analysis.dataanalysis.DataAnalysis.analyze_ascan`.

        If the given data is multidimensional, only the first A-scan will be analyzed.

        Args:
            :selection: The desired feature that should be computed
            :number_of_peaks: The number of peaks which should be analyzed
            :min_dist: The minimum distance between the peaks in pixel

        Returns:
            An array of size ``number_of_peaks`` which contains the computed result.
        """
        res = np.empty(number_of_peaks, dtype=np.float64)
        sr.analyzePeaksInAScan.argtypes = [c_handle,
                                           c_int,
                                           c_int,
                                           c_int,
                                           np.ctypeslib.ndpointer(dtype=c_double, flags='C_CONTIGUOUS')]
        sr.analyzePeaksInAScan(self.handle, selection, number_of_peaks, min_dist, res)
        get_error()
        return res

    def determine_surface(self):
        """Performs a minimal segmentation of the data, by finding a surface that is compromised of the highest signals
        from each A-scan.

        Returns:
            From the 3D input data, the output data will contain 2D data, where each data pixel contains the
            depth of the respective surface as a function of the x- and y-pixel position.
        """
        data_out = self._container_type()
        sr.determineSurface.argtypes = [c_handle, c_handle]
        sr.determineSurface(self.handle, data_out.handle)
        get_error()
        return data_out

    def determine_dynamic_range_db(self) -> Tuple[float, float]:
        """Gives a rough estimation of the dynamic range of the specified data object.

        Returns:
            A tuple(``min_range_dB``, ``max_range_db``) containing ``min_range_dB`` as the lower bound and
            ``max_range_db`` as the upper bound of the dynamic range
        """
        min_range_db = c_double()
        max_range_db = c_double()
        sr.determineDynamicRange_dB.argtypes = [c_handle, POINTER(c_double), POINTER(c_double)]
        sr.determineDynamicRange_dB(self.handle, min_range_db, max_range_db)
        get_error()
        return min_range_db.value, max_range_db.value

    def determine_dynamic_range_with_min_range_db(self, min_dynamic_range_db: float) -> Tuple[float, float]:
        """Gives a rough estimation of the dynamic range of the specified data object.

        Args:
            :min_dynamic_range_db: Minimal size of the returned dynamic range interval in dB

        Returns:
            A tuple(``min_range_dB``, ``max_range_db``) containing ``min_range_dB`` as the lower bound and
            ``max_range_db`` as the upper bound of the dynamic range
        """
        min_range_db = c_double()
        max_range_db = c_double()
        sr.determineDynamicRangeWithMinRange_dB.argtypes = [c_handle, POINTER(c_double), POINTER(c_double), c_double]
        sr.determineDynamicRangeWithMinRange_dB(self.handle, min_range_db, max_range_db, min_dynamic_range_db)
        get_error()
        return min_range_db.value, max_range_db.value
