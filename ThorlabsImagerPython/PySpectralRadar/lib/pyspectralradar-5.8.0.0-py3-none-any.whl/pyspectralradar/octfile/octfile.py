from __future__ import annotations

from ctypes import ArgumentError, c_bool, c_char_p, c_float, c_int, c_int64, c_size_t, create_string_buffer
from typing import TYPE_CHECKING, Tuple

from pyspectralradar.base import HandleManager
from pyspectralradar.data import ColoredData, ComplexData, RawData, RealData
from pyspectralradar.doppler import Doppler
from pyspectralradar.octfile.properties import OCTFileProperties
from pyspectralradar.octfile.properties.octfilepropertyflag import MetadataFlag
from pyspectralradar.octfile.properties.octfilepropertyfloat import MetadataFloat
from pyspectralradar.octfile.properties.octfilepropertyint import MetadataInt
from pyspectralradar.octfile.properties.octfilepropertystring import MetadataString
from pyspectralradar.polarization import Polarization
from pyspectralradar.specklevar import SpeckleVariance
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types.octfiletypes import *

if TYPE_CHECKING:
    from pyspectralradar.octdevice import OCTDevice
    from pyspectralradar.processing import Processing
    from pyspectralradar.probe import Probe
    from pyspectralradar.scanpattern import ScanPattern
    from pyspectralradar.data.precisiondata import PrecisionData


class OCTFile(HandleManager):
    """Class containing Functions for File Handling."""

    def __init__(self, filename: str = "", filetype: FileFormat = FileFormat.OCITY):
        """Creates an :class:`~pyspectralradar.octfile.octfile.OCTFile` object owning the handle of an OCT file of
        the given format. If a ``filename`` is passed, :func:`~pyspectralradar.octfile.octfile.OCTFile.load` will be
        called to load an exiting ``.oct`` file into the handle.

        Args:
            :filename: Name of the data file to load.
            :filetype: Type selector of the :class:`~pyspectralradar.octfile.octfile.OCTFile` object that will be
                created.
        """
        sr.createOCTFile.restype = c_handle
        sr.createOCTFile.argtypes = [c_int]
        handle = sr.createOCTFile(c_int(filetype))
        get_error()
        super().__init__(handle)
        if filename:
            self.load(filename)
        self.properties: OCTFileProperties = OCTFileProperties(self.handle)

    @property
    def _del_func(self):
        return sr.clearOCTFile

    def load(self, filename: str):
        """Loads the actual OCT data file from a file system. The file must have the format specified during
        initialization

        Args:
            :filename: Name of the data file to load.
        """
        sr.loadFile.argtypes = [c_handle, c_char_p]
        sr.loadFile(self.handle, c_char_p(bytes(filename, encoding="ascii")))
        get_error()

    def save(self, filename: str):
        """Saves the OCT data file in the given fully qualified path name.

        Args:
            :filename: Name to which the OCT data file will be written.
        """
        sr.saveFile.argtypes = [c_handle, c_char_p]
        sr.saveFile(self.handle, c_char_p(bytes(filename, encoding="ascii")))
        get_error()

    def save_changes(self):
        """Saves the OCT data file in the file previously opened with
        :func:`~pyspectralradar.octfile.octfile.OCTFile.load`. Only changes will be saved."""
        sr.saveChangesToFile.argtypes = [c_handle]
        sr.saveChangesToFile(self.handle)
        get_error()

    def add_data(self, data_obj: RealData | RawData | ColoredData | ComplexData, name: str):
        """Adds a data (:class:`~pyspectralradar.data.realdata.RealData`,
        :class:`~pyspectralradar.data.rawdata.RawData`, :class:`~pyspectralradar.data.coloreddata.ColoredData` or
        :class:`~pyspectralradar.data.complexdata.ComplexData`) object to the OCT file;

        The object that the datas handle refers to must live until after
        :func:`~pyspectralradar.octfile.octfile.OCTFile.save` has been called.

        Args:
            :data_obj: Data object that will be added to the OCT file
            :name: Will be the data name inside the OCT file, if applicable.
        """
        if isinstance(data_obj, RealData):
            c_function = sr.addFileRealData
        elif isinstance(data_obj, RawData):
            c_function = sr.addFileRawData
        elif isinstance(data_obj, ColoredData):
            c_function = sr.addFileColoredData
        elif isinstance(data_obj, ComplexData):
            c_function = sr.addFileComplexData
        else:
            raise ArgumentError('data_obj is currently not supported by the SDKs python wrapper.')

        c_function.argtypes = [c_handle, c_handle, c_char_p]
        c_function(self.handle, data_obj.handle, name.encode('ascii'))
        get_error()

    def add_text(self, filename_on_disk: str, data_object_name: str):
        """Adds a text object read from ``filename_on_disk`` to the OCT file; ``data_object_name`` will be
        its name inside the OCT file, if applicable. The file identified by ``filename_on_disk`` must exist until
        after :func:`~pyspectralradar.octfile.octfile.OCTFile.save` has been called.

        Args:
            :filename_on_disk: Filename from which text file will be read
            :data_object_name: Name that will be assigned to the object in the OCT file
        """
        sr.addFileText.argtypes = [c_handle, c_char_p, c_char_p]
        sr.addFileText(self.handle, c_char_p(bytes(filename_on_disk, encoding="ascii")),
                       c_char_p(bytes(data_object_name, encoding="ascii")))
        get_error()

    def set_metadata(self, device: OCTDevice = None, processing: Processing = None, probe: Probe = None,
                     pattern: ScanPattern = None):
        """Saves meta information from the given device, processing, probe and scan pattern instances in the metadata
        block of the given file handle.

        This information will be available in files of type :obj:`~pyspectralradar.types.octfiletypes.FileFormat`;
        mileage on other formats may vary according to their description.

        Args:
            :device: The OCT device that the metadate shall be set from
            :processing: The processing that the processing routines shall be set from
            :probe: The probe that the meat data should be set from
            :pattern: The scan pattern that the metadata shall be set from
        """
        sr.saveFileMetadata.argtypes = [c_handle, c_handle, c_handle, c_handle, c_handle]
        sr.saveFileMetadata(self.handle,
                            None if device is None else device.handle,
                            None if processing is None else processing.handle,
                            None if probe is None else probe.handle,
                            None if pattern is None else pattern.handle)
        get_error()

    def save_calibration(self, processing: Processing, camera_idx: int = 0):
        """Saves Chirp, Offset, and Apodization vectors from the given processing object into the given OCT file.

        Args:
            :processing: Containing the processing routines
            :camera_idx: The camera index (0-based, i.e. zero for the first, one for the second, and so on).
        """
        sr.saveCalibrationToFileEx.argtypes = [c_handle, c_handle, c_int]
        sr.saveCalibrationToFileEx(self.handle, processing.handle, camera_idx)
        get_error()

    def set_doppler_metadata(self, doppler: Doppler):
        """Saves meta information from the given :class:`~pyspectralradar.doppler.doppler.Doppler` object.
        A corresponding :class:`~pyspectralradar.doppler.doppler.Doppler` object can then be recreated using
        :func:`~pyspectralradar.doppler.doppler.Doppler.from_file`.

        Args:
            :doppler: The :class:`~pyspectralradar.doppler.doppler.Doppler` processing object whose data is stored.
        """
        assert isinstance(doppler, Doppler)
        sr.saveFileMetadataDoppler.argtypes = [c_handle, c_handle]
        sr.saveFileMetadataDoppler(self.handle, doppler.handle)
        get_error()

    def set_speckle_metadata(self, speckle: SpeckleVariance):
        """Saves meta information from the given :class:`~pyspectralradar.specklevar.specklevar.SpeckleVariance`
        object. A corresponding :class:`~pyspectralradar.specklevar.specklevar.SpeckleVariance` object can then be
        recreated using :func:`~pyspectralradar.specklevar.specklevar.SpeckleVariance.from_file`.

        Args:
            :speckle: This is the object whose data is stored.

        """
        assert isinstance(speckle, SpeckleVariance)
        sr.saveFileMetadataSpeckle.argtypes = [c_handle, c_handle]
        sr.saveFileMetadataSpeckle(self.handle, speckle.handle)
        get_error()

    def set_polarization_metadata(self, polarization: Polarization):
        """Saves meta information from the given :class`~pyspectralradar.polarization.polarization.Polarization` to
        the specified file. These metadata specify the operational arguments needed by the polarization processing
        routines to redo the polarization-analysis starting from two
        :class:`~pyspectralradar.data.complexdata.ComplexData` objects delivered by
        :func:`~pyspectralradar.processing.processing.Processing.execute` of camera 0 and camera 1.

        Args:
            :polarization: Polarization-processing handle to the processing routines for polarization analysis.
        """
        assert isinstance(polarization, Polarization)
        sr.saveFileMetadataPolarization.argtypes = [c_handle, c_handle]
        sr.saveFileMetadataPolarization(self.handle, polarization.handle)
        get_error()

    def copy_metadata_from(self, oct_file_in: OCTFile):
        """Copies metadata from one OCT file to another.

        Args:
            :oct_file_in: This is the source and will not be altered by this function in any way.
        """
        sr.copyFileMetadata.argtypes = [c_handle, c_handle]
        sr.copyFileMetadata(oct_file_in.handle, self.handle)
        get_error()

    @staticmethod
    def get_spectral_data_name(index: int) -> str:
        """Returns the filename of the spectral-data object with the specified index.

        Args:
            :index: Index of spectral-data object to return

        Returns:
            Filename of the specified data object.
        """
        sr.DataObjectName_SpectralData.argtypes = [c_int]
        sr.DataObjectName_SpectralData.restype = c_char_p
        res = sr.DataObjectName_SpectralData(index).decode('ascii')
        get_error()
        return res

    def get_data_type(self, index: int) -> Tuple[str, int]:
        """Returns the type of the data object at the given ``index`` in the OCT file.

        Args:
            :index: Index of the data inside the OCT file, e.g. returned by
                :func:`~pyspectralradar.octfile.octfile.OCTFile.find`.

        Returns:
            A tuple containing the selected data object name as string (or ``UNKNOWN`` in case of an error) and integer.
        """
        if isinstance(index, str):
            index = self.find(index)

        sr.getFileDataObjectType.restype = c_int
        sr.getFileDataObjectType.argtypes = [c_handle, c_int]
        res = sr.getFileDataObjectType(self.handle, c_int(index))
        get_error()
        return DataType(res).name, res

    def get_data_name(self, index: int) -> str:
        """Returns the name of the data object at the given ``index`` in the OCT file.

        Args:
            :index: Index of the data inside the OCT file, 0 <= ``index`` <
                :func:`~pyspectralradar.octfile.octfile.OCTFile.count`

        Returns:
            The name of the data object.
        """
        name_string_size = 1024
        name = create_string_buffer(name_string_size)
        sr.getFileDataObjectName.argtypes = [c_handle, c_int, c_char_p, c_int]
        sr.getFileDataObjectName(self.handle, index, name, name_string_size)
        get_error()
        return name.value.decode('UTF-8')

    def find(self, name: str) -> int:
        """Searches for a data object name of which contains the given string and returns its index, -1 if not found.

        Args:
            :name: Data object name to find in OCT file.

        Returns:
            Index of the searched data object
        """
        sr.findFileDataObject.restype = c_int
        sr.findFileDataObject.argtypes = [c_handle, c_char_p]
        return sr.findFileDataObject(self.handle, c_char_p(bytes(name, encoding="ascii")))

    def get_data_object(self, index: int | str) -> RealData | RawData | ColoredData | ComplexData | PrecisionData:
        """Retrieves a data object from the OCT file at the given index with 0 <= ``index`` <
        :func:`~pyspectralradar.octfile.octfile.OCTFile.count`. Users must ensure that the data handle is properly
        prepared and destroyed.

        Args:
            :index: Index of the data inside the OCT file, e.g. returned by
                :func:`~pyspectralradar.octfile.octfile.OCTFile.find`.

        Returns:
            The indexed data object.
        """
        if isinstance(index, str):
            index = self.find(index)

        data = 0
        data_type = self.get_data_type(index)[1]
        if data_type == DataType.REAL:
            data = RealData()
            sr.getFileRealData.argtypes = [c_handle, c_handle, c_int]
            sr.getFileRealData(self.handle, data.handle, c_int(index))
        elif data_type == DataType.RAW:
            data = RawData()
            sr.getFileRawData.argtypes = [c_handle, c_handle, c_size_t]
            sr.getFileRawData(self.handle, data.handle, c_size_t(index))
        elif data_type == DataType.COLORED:
            data = ColoredData()
            sr.getFileColoredData.argtypes = [c_handle, c_handle, c_int]
            sr.getFileColoredData(self.handle, data.handle, c_int(index))
        elif data_type == DataType.COMPLEX:
            data = ComplexData()
            sr.getFileComplexData.argtypes = [c_handle, c_handle, c_int]
            sr.getFileComplexData(self.handle, data.handle, c_int(index))
        elif data_type == DataType.REAL_PRECISION:
            data = PrecisionData()
            sr.getFilePrecisionRealData.argtypes = [c_handle, c_handle, c_int]
            sr.getFilePrecisionRealData(self.handle, data.handle, c_int(index))
        else:
            ArgumentError("Data type not yet supported. {}".format(self.get_data_type(index)))

        get_error()
        return data

    def get_data_size(self, index: int | str) -> Tuple[int, int, int]:
        """Returns the pixel counts of the data object at the given ``index`` in the OCT file.

        Args:
            :index: Index of the data inside the OCT file, e.g. returned by
                :func:`~pyspectralradar.octfile.octfile.OCTFile.find` or data object name.

        Returns:
            A tuple (``size_z``, ``size_x``, ``size_y``) containing the pixel counts with ``size_z`` for the counts
            along first axis, ``size_x`` for the second and ``size_y`` for the count along the third axis.
        """
        if isinstance(index, str):
            index = self.find(index)

        sr.getFileDataSizeX.argtypes = [c_handle, c_size_t]
        sr.getFileDataSizeX.restype = c_int
        size_x = sr.getFileDataSizeX(self.handle, index)

        sr.getFileDataSizeY.argtypes = [c_handle, c_size_t]
        sr.getFileDataSizeY.restype = c_int
        size_y = sr.getFileDataSizeY(self.handle, index)

        sr.getFileDataSizeZ.argtypes = [c_handle, c_size_t]
        sr.getFileDataSizeZ.restype = c_int
        size_z = sr.getFileDataSizeZ(self.handle, index)

        return size_z, size_x, size_y

    def get_data_ranges(self, index: int | str) -> Tuple[float, float, float]:
        """Returns the ranges (usually in mm) in Z, X, Y order of the data object at the given ``index`` in the OCT
        file.

        Args:
            :index: Index of the data inside the OCT file, e.g. returned by
                :func:`~pyspectralradar.octfile.octfile.OCTFile.find` or data object name.

        Returns:
            A tuple (``range_z``, ``range_x``, ``range_y``) containing the ranges in mm with ``range_z`` for the mm
            along first axis, ``range_x`` for the second and ``range_y`` for the range along the third axis.
        """
        if isinstance(index, str):
            index = self.find(index)

        sr.getFileDataRangeX.argtypes = [c_handle, c_size_t]
        sr.getFileDataRangeX.restype = c_float
        range_x = sr.getFileDataRangeX(self.handle, index)

        sr.getFileDataRangeY.argtypes = [c_handle, c_size_t]
        sr.getFileDataRangeY.restype = c_float
        range_y = sr.getFileDataRangeY(self.handle, index)

        sr.getFileDataRangeZ.argtypes = [c_handle, c_size_t]
        sr.getFileDataRangeZ.restype = c_float
        range_z = sr.getFileDataRangeZ(self.handle, index)
        return range_z, range_x, range_y

    def count(self) -> int:
        """Returns the number of data objects in the OCT file.

        This number will vary depending on the file's format and contents (Files with the .oct extension may contain
        multiple OCT data objects depending on their internal structure).

        Returns:
            The number of data objects in the OCT file
        """
        if self.handle != c_handle(0):
            sr.getFileDataObjectCount.restype = c_int
            sr.getFileDataObjectCount.argtypes = [c_handle]
            res = sr.getFileDataObjectCount(self.handle)
            get_error()
            return res
        else:
            return 0

    def __len__(self):
        return self.count()

    def __contains__(self, item: MetadataFloat | MetadataInt | MetadataString | MetadataFlag | str):
        """Searches for the name of a data object which contains the given string and returns true if at least one data
        object name matches.

        Also used to check if given metadata field is present in the file.

        Args:
            :item: Data object name to find in OCT file or Metadata field to test.

        Returns:
            ``True`` if object is contained.
        """
        c_func = None
        if isinstance(item, str):
            sr.containsFileDataObject.argtypes = [c_handle, c_char_p]
            sr.containsFileDataObject.restype = c_bool
            res = sr.containsFileDataObject(self.handle, c_char_p(bytes(item, encoding="ascii")))
            get_error()
            return res
        elif isinstance(item, MetadataFloat):
            c_func = sr.containsFileMetadataFloat
        elif isinstance(item, MetadataInt):
            c_func = sr.containsFileMetadataInt
        elif isinstance(item, MetadataString):
            c_func = sr.containsFileMetadataString
        elif isinstance(item, MetadataFlag):
            c_func = sr.containsFileMetadataFlag

        c_func.argtypes = [c_handle, c_int]
        c_func.restype = c_bool
        res = c_func(self.handle, item.value)
        get_error()
        return res

    def contains_raw(self) -> bool:
        """Returns true if the file contains raw data objects.

        Notice that raw data refers to the spectra as acquired, without processing of any kind.

        Returns:
            ``True`` if the file contains raw data objects.
        """
        sr.containsFileRawData.argtypes = [c_handle]
        sr.containsFileRawData.restype = c_bool
        res = sr.containsFileRawData(self.handle)
        get_error()
        return res

    def get_timestamp(self) -> int:
        """Returns the specified timestamp from the meta information of the given file handle.

        This information will be available in files of type
        :class:`~pyspectralradar.types.octfiletypes.FileFormat`. ``OCITY``; mileage on other formats may vary
        according to their description.

        Returns:
            The specified timestamp.
        """
        sr.getFileMetadataTimestamp.argtypes = [c_handle]
        sr.getFileMetadataTimestamp.restype = c_int64
        time = sr.getFileMetadataTimestamp(self.handle)
        get_error()
        return time

    def set_timestamp(self, value: int):
        """Saves provided timestamp to meta information to the given file handle. This information will be available
        in files of type :class:`~pyspectralradar.types.octfiletypes.FileFormat`. ``OCITY``; mileage on other formats
        may vary according to their description.

        Args:
            :value: The specified timestamp
        """
        casted_value = c_int64(value)
        sr.setFileMetadataTimestamp.argtypes = [c_handle, c_int64]
        sr.setFileMetadataTimestamp(self.handle, casted_value)
        get_error()

    def get_presets(self) -> list[Tuple[str, str]]:
        """Gets the number of presets that were set during the acquisition, the preset category belonging to the
        preset with given ``index`` and the preset description belonging to the preset with given ``index``.

        Returns:
            A tuple (``categories``, ``description``) containing the ``categories`` belonging to the preset and
            ``description`` as the preset description belonging to the preset.
        """
        sr.getFileMetadataNumberOfPresets.restype = c_int
        sr.getFileMetadataNumberOfPresets.argtypes = [c_handle]
        presets = sr.getFileMetadataNumberOfPresets(self.handle)
        get_error()

        sr.getFileMetadataPresetCategory.restype = c_char_p
        sr.getFileMetadataPresetCategory.argtypes = [c_handle, c_int]
        categories = []
        for i in range(presets):
            categories.append(sr.getFileMetadataPresetCategory(self.handle, i).decode('UTF-8'))
        get_error()

        sr.getFileMetadataPresetDescription.restype = c_char_p
        sr.getFileMetadataPresetDescription.argtypes = [c_handle, c_int]
        descriptions = []
        for i in range(presets):
            descriptions.append(sr.getFileMetadataPresetDescription(self.handle, i).decode('UTF-8'))
        get_error()

        res = [(categories[i], descriptions[i]) for i in range(presets)]
        return res

    def add_presets(self, category: str, preset_description: str):
        """Adds one of the presets set during acquisition for the :class:`~pyspectralradar.octfile.octfile.OCTFile`.

        Args:
            :category: Name of the category of the added preset
            :preset_description: Description for the added preset
        """
        sr.addFileMetadataPreset.argtypes = [c_handle, c_char_p, c_char_p]
        sr.addFileMetadataPreset(self.handle,
                                 c_char_p(bytes(category, encoding="ascii")),
                                 c_char_p(bytes(preset_description, encoding="ascii")))
        get_error()

    def clear_markers(self):
        """Clears the marker list of a given OCT file. This removes all line and point markers from the file."""
        sr.clearMarkerList.argtypes = [c_handle]
        sr.clearMarkerList(self.handle)
        get_error()

    def copy_markers_from_data(self, data: RealData):
        """Copies the marker list from the given data handle into the metadata block of the given OCT file handle.

        Markers are a visual help, that can be created or manipulated by ThorImage-OCT. Markers are always expressed in
        physical coordinates, so re-use is possible.

        If no markers are present, this function does nothing.

        Args:
            :data: Data object that the markers should be copied from.
        """
        assert isinstance(data, RealData)
        sr.copyMarkerListFromRealData.argtypes = [c_handle, c_handle]
        sr.copyMarkerListFromRealData(self.handle, data.handle)
        get_error()

    #
    def copy_markers_to_data(self, data: RealData):
        """Copies the marker list from the metadata block of the given file handle to the given data handle.

        Markers are a visual help, that can be created or manipulated by ThorImage-OCT. Markers are always expressed in
        physical coordinates, so re-use is possible.

        If no markers are present, this function does nothing.

        Args:
            :data: Data object that the markers should be copied to.
        """
        assert isinstance(data, RealData)
        sr.copyMarkerListToRealData.argtypes = [c_handle, c_handle]
        sr.copyMarkerListToRealData(self.handle, data.handle)
        get_error()
