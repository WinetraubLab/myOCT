from pyspectralradar.base.submodule import Submodule
from pyspectralradar.doppler.properties.dopplerpropertyflag import DopplerPropertyFlag
from pyspectralradar.doppler.properties.dopplerpropertyfloat import DopplerPropertyFloat
from pyspectralradar.doppler.properties.dopplerpropertyint import DopplerPropertyInt


class DopplerProperties(Submodule):
    def __init__(self, handle):
        super().__init__(handle)
        self._int = DopplerPropertyInt(self.handle, self.handle)
        self._float = DopplerPropertyFloat(self.handle, self.handle)
        self._flag = DopplerPropertyFlag(self.handle)

        # int
        self.get_averaging_1 = self._int.get_averaging_1
        self.set_averaging_1 = self._int.set_averaging_1
        self.get_averaging_2 = self._int.get_averaging_2
        self.set_averaging_2 = self._int.set_averaging_2
        self.get_stride_1 = self._int.get_stride_1
        self.set_stride_1 = self._int.set_stride_1
        self.get_stride_2 = self._int.get_stride_2
        self.set_stride_2 = self._int.set_stride_2

        # float
        self.get_refractive_index = self._float.get_refractive_index
        self.set_refractive_index = self._float.set_refractive_index
        self.get_scan_rate_hz = self._float.get_scan_rate_hz
        self.set_scan_rate_hz = self._float.set_scan_rate_hz
        self.get_center_wavelength_nm = self._float.get_center_wavelength_nm
        self.set_center_wavelength_nm = self._float.set_center_wavelength_nm
        self.get_doppler_angle_deg = self._float.get_doppler_angle_deg
        self.set_doppler_angle_deg = self._float.set_doppler_angle_deg

        # flag
        self.get_doppler_velocity_scaling = self._flag.get_doppler_velocity_scaling
        self.set_doppler_velocity_scaling = self._flag.set_doppler_velocity_scaling
