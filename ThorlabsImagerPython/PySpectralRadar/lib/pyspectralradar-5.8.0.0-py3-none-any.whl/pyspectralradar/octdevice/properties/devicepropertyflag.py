from enum import IntEnum

from pyspectralradar.base.propertygetter import FlagPropertyGetter
from pyspectralradar.spectralradar import sr


class Flags(IntEnum):
    """Boolean properties of the device that can be retrieved with the function #getDeviceFlag."""

    ON = 0
    """The type name of the device."""

    CAMERA_AVAIL = 1
    """Specifies if there is a video camera available"""

    SLD_AVAIL = 2
    """Specifies if there is a SLD available"""

    SLD_STATUS = 3
    """Status of the SLD, either on (true) or off (false)"""

    LASER_DIODE_STATUS = 4  # TODO: not available in current release
    """Status of the laser diode, either on (true) or off (false). Warning: Not all devices are equipped with this 
    feature."""

    CAMERA_SHOW_SCAN_PATTERN = 5  # TODO: not available in current release
    """Parameter for the overlay of the video camera which shows the scan pattern in red."""

    PROBE_CONTROLLER_AVAIL = 6
    """Gives information whether a probe controller (with buttons) is available"""

    DATA_SIGNED = 7
    """Flag indicating if the data is signed"""

    SWEPT_SOURCE = 8
    """Flag indicating whether system is a swept source (or spectral domain) system."""

    ANALOG_IN_AVAIL = 9
    """Flag indicating if the system offers analog input capabilities"""

    HAS_MASTER_BOARD = 10
    """Flag indicating if the hardware contains a control board."""

    HAS_CONTROL_BOARD = 11
    """Flag indicating if the hardware contains a control board. A system may contain either a master or a control 
    board, but not both."""

    SLD_STATUS_QUICK = 12
    """SLD activation without delay"""


class DevicePropertyFlag(FlagPropertyGetter):
    """Boolean properties of the device that can be retrieved with the function #getDeviceFlag.
    """

    def __init__(self, handle):
        super().__init__(handle, sr.getDeviceFlag)

    def get_on(self) -> int:
        """The type name of the device."""
        return self._get(Flags.ON)

    def get_camera_avail(self) -> int:
        """Specifies if there is a video camera available"""
        return self._get(Flags.CAMERA_AVAIL)

    def get_sld_avail(self) -> int:
        """Specifies if there is a SLD available"""
        return self._get(Flags.SLD_AVAIL)

    def get_sld_status(self) -> int:
        """Status of the SLD, either on (true) or off (false)"""
        return self._get(Flags.SLD_STATUS)

    def get_laser_diode_status(self) -> int:
        """Status of the laser diode, either on (true) or off (false).
        Warning: Not all devices are equipped with this feature."""
        return self._get(Flags.LASER_DIODE_STATUS)

    def get_camera_show_scan_pattern(self) -> int:
        """Parameter for the overlay of the video camera which shows the scan pattern in red."""
        return self._get(Flags.CAMERA_SHOW_SCAN_PATTERN)

    def get_probe_controller_avail(self) -> int:
        """Gives information whether a probe controller (with buttons) is available"""
        return self._get(Flags.PROBE_CONTROLLER_AVAIL)

    def get_data_signed(self) -> int:
        """Flag indicating if the data is signed"""
        return self._get(Flags.DATA_SIGNED)

    def get_swept_source(self) -> int:
        """Flag indicating whether system is a swept source (or spectral domain) system."""
        return self._get(Flags.SWEPT_SOURCE)

    def get_analog_in_avail(self) -> int:
        """Flag indicating if the system offers analog input capabilities"""
        return self._get(Flags.ANALOG_IN_AVAIL)

    def get_has_master_board(self) -> int:
        """Flag indicating if the hardware contains a control board."""
        return self._get(Flags.HAS_MASTER_BOARD)

    def get_has_control_board(self) -> int:
        """Flag indicating if the hardware contains a control board.
        A system may contain either a master or a control board, but not both."""
        return self._get(Flags.HAS_CONTROL_BOARD)

    def get_sld_status_quick(self) -> int:
        """SLD activation without delay"""
        return self._get(Flags.SLD_STATUS_QUICK)
