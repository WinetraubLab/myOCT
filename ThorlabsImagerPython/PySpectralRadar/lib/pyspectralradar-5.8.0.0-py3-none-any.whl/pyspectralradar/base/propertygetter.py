import abc
from ctypes import c_bool, c_char_p, c_double, c_int, create_string_buffer
from enum import IntEnum

from pyspectralradar.spectralradar import c_handle, get_error


class PropertyGetter:
    def __init__(self, handle, getter):
        self._handle = handle
        self._getter = getter
        self._getter.argtypes = [c_handle, c_int]

    def _get_raw(self, entry: IntEnum, c_res_type):
        self._getter.restype = c_res_type
        res = self._getter(self._handle, c_int(entry))
        get_error()
        return res

    def _get_raw_indexed(self, entry: IntEnum, c_res_type, index: int):
        self._getter.restype = c_res_type
        res = self._getter(self._handle, c_int(entry), index)
        get_error()
        return res

    def _get_raw_ptr(self, entry: IntEnum, c_res_type):
        size = 1024
        if c_res_type == c_char_p:
            entry_value = create_string_buffer(size)
        else:
            entry_value = c_res_type(size)
        self._getter(self._handle, c_int(entry), entry_value, size)
        get_error()
        return entry_value.value

    def _get_raw_indexed_ptr(self, entry: IntEnum, index: int, c_res_type):
        size = 1024
        if c_res_type == c_char_p:
            entry_value = create_string_buffer(size)
        else:
            entry_value = c_res_type(size)
        self._getter(self._handle, c_int(entry), index, entry_value, size)
        get_error()
        return entry_value.value

    @abc.abstractmethod
    def _get(self, entry: IntEnum):
        raise NotImplementedError


class StringPropertyGetter(PropertyGetter):
    def _get(self, entry: IntEnum) -> str:
        res = self._get_raw(entry, c_char_p)
        return res.decode("utf-8")

    def _get_ptr(self, entry: IntEnum) -> str:
        res = self._get_raw_ptr(entry, c_char_p)
        return res.decode("utf-8")

    def _get_indexed_ptr(self, entry: IntEnum, index: int) -> str:
        res = self._get_raw_indexed_ptr(entry, index, c_char_p)
        return res.decode("utf-8")


class IntPropertyGetter(PropertyGetter):
    def _get(self, entry: IntEnum) -> int:
        return self._get_raw(entry, c_int)

    def _get_indexed(self, entry: IntEnum, index: int) -> int:
        return self._get_raw_indexed(entry, c_int, index)


class FloatPropertyGetter(PropertyGetter):
    def _get(self, entry: IntEnum) -> float:
        return self._get_raw(entry, c_double)

    def _get_indexed(self, entry: IntEnum, index: int) -> float:
        return self._get_raw_indexed(entry, c_double, index)


class FlagPropertyGetter(PropertyGetter):
    def _get(self, entry: IntEnum) -> bool:
        return self._get_raw(entry, c_bool)

    def _get_indexed(self, entry: IntEnum, index: int) -> bool:
        return self._get_raw_indexed(entry, c_bool, index)


class StaticFlagGetter:
    @staticmethod
    @abc.abstractmethod
    def _get_getter():
        raise NotImplementedError

    @classmethod
    def _get_raw(cls, entry: IntEnum):
        _getter = cls._get_getter()
        _getter.argtypes = [c_int]
        _getter.restype = c_bool
        return _getter(entry)


class StaticFlagSetter:
    @staticmethod
    @abc.abstractmethod
    def _get_setter():
        raise NotImplementedError

    @classmethod
    def _set_raw(cls, entry: IntEnum, value: bool):
        _setter = cls._get_setter()
        _setter.argtypes = [c_int, c_bool]
        return _setter(entry, value)
