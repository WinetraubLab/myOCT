from enum import IntEnum

from pyspectralradar.base.propertygetter import FloatPropertyGetter
from pyspectralradar.base.propertysetter import FloatPropertySetter
from pyspectralradar.spectralradar import sr


class PropertyFloat(IntEnum):
    """Parameters describing the behaviour of the Probe, such as calibration factors and scan parameters.
    Computation of physical position and raw values for the scanner is done by
    PhysicalPosition = Factor * RawValue + Offset"""

    FACTOR_X = 0
    """Factor for the x axis."""

    OFFSET_X = 1
    """Offset for the x axis."""

    FACTOR_Y = 2
    """Factor for the y axis."""

    OFFSET_Y = 3
    """Offset for the y axis."""

    FLYBACK_TIME_SEC = 4
    """Flyback time of the system. This time is usually needed to get from an apodization position to scan position
    and vice versa."""

    EXPANSION_TIME_SEC = 5
    """The scanning range is extended by a number of A-scans equivalent to the expansion time."""

    ROTATION_TIME_SEC = 6
    """The scan pattern is usually shifted by a number of A-scans equivalent to the rotation time."""

    EXPECTED_SCAN_RATE_HZ = 7
    """The expected scan rate. Warning: In general the expected scan rate is set during initialization of the probe
    with respect to the attached device. In most cases it should not be altered manually."""

    CAMERA_SCALING_X = 8
    """The px/mm ratio in X direction for the BScan overlay on the video image."""

    CAMERA_OFFSET_X = 9
    """The BScan overlay X offset in pixels."""

    CAMERA_SCALING_Y = 10
    """The px/mm ratio in Y direction for the BScan overlay on the video image."""

    CAMERA_OFFSET_Y = 11
    """The BScan overlay Y offset in pixels."""

    CAMERA_ANGLE = 12
    """Corrective rotation angle for the BScan overlay."""

    RANGE_MAX_X = 13
    """Maximum scan range in X direction"""

    RANGE_MAX_Y = 14
    """Maximum scan range in Y direction"""

    MAX_SLOPE_XY = 15
    """Maximum Galvo slope (accounting for the distortion capabilities of different Galvo types)"""

    SPECKLE_SIZE = 16
    """Speckle size to be used for scan pattern computation if speckle reduction is switched on."""

    APO_VOLT_X = 17
    """X-voltage used to acquire the apodization spectrum"""

    APO_VOLT_Y = 18
    """Y-voltage used to acquire the apodization spectrum"""

    REF_STAGE_OFFSET = 19
    """Offset for reference stage marking the zero delay line"""

    FIBER_OPL_MM = 20
    """Optical path length, in millimeter (fiber length up to the scanner, multiplied by the refractive index)"""

    PROBE_OPL_MM = 21
    """Optical path length, in millimeter (from scanner input to objective mount, multiplied by the refractive index)"""

    OBJECTIVE_OPL_MM = 22
    """Optical path length, in millimeter (without counting the focal length, multiplied by the equivalent
    # refractive index)"""

    OBJECTIVE_FOCAL_LENGTH_MM = 23
    """Optical focal length, in millimeter"""


class ProbePropertyFloat(FloatPropertyGetter, FloatPropertySetter):

    def __init__(self, handle):
        FloatPropertyGetter.__init__(self, handle, sr.getProbeParameterFloat)
        FloatPropertySetter.__init__(self, handle, sr.setProbeParameterFloat)

    def get_factor_x(self) -> float:
        """Factor for the x-axis."""
        return self._get(PropertyFloat.FACTOR_X)

    def set_factor_x(self, value: float):
        """Factor for the x-axis."""
        self._set(PropertyFloat.FACTOR_X, value)

    def get_offset_x(self) -> float:
        """Offset for the x-axis."""
        return self._get(PropertyFloat.OFFSET_X)

    def set_offset_x(self, value: float):
        """Offset for the x-axis."""
        self._set(PropertyFloat.OFFSET_X, value)

    def get_factor_y(self) -> float:
        """Factor for the y-axis."""
        return self._get(PropertyFloat.FACTOR_Y)

    def set_factor_y(self, value: float):
        """Factor for the y-axis."""
        self._set(PropertyFloat.FACTOR_Y, value)

    def get_offset_y(self) -> float:
        """Offset for the y-axis."""
        return self._get(PropertyFloat.OFFSET_Y)

    def set_offset_y(self, value: float):
        """Offset for the y-axis."""
        self._set(PropertyFloat.OFFSET_Y, value)

    def get_flyback_time_sec(self) -> float:
        """Flyback time of the system. This time is usually needed to get from an apodization position to scan position
        and vice versa."""
        return self._get(PropertyFloat.FLYBACK_TIME_SEC)

    def set_flyback_time_sec(self, value: float):
        """Flyback time of the system. This time is usually needed to get from an apodization position to scan position
        and vice versa."""
        self._set(PropertyFloat.FLYBACK_TIME_SEC, value)

    def get_expansion_time_sec(self) -> float:
        """The scanning range is extended by a number of A-scans equivalent to the expansion time."""
        return self._get(PropertyFloat.EXPANSION_TIME_SEC)

    def set_expansion_time_sec(self, value: float):
        """The scanning range is extended by a number of A-scans equivalent to the expansion time."""
        self._set(PropertyFloat.EXPANSION_TIME_SEC, value)

    def get_rotation_time_sec(self) -> float:
        """The scan pattern is usually shifted by a number of A-scans equivalent to the rotation time."""
        return self._get(PropertyFloat.ROTATION_TIME_SEC)

    def set_rotation_time_sec(self, value: float):
        """The scan pattern is usually shifted by a number of A-scans equivalent to the rotation time."""
        self._set(PropertyFloat.ROTATION_TIME_SEC, value)

    def get_expected_scan_rate_hz(self) -> float:
        """The expected scan rate. Warning: In general the expected scan rate is set during initialization of the probe
        with respect to the attached device. In most cases it should not be altered manually."""
        return self._get(PropertyFloat.EXPECTED_SCAN_RATE_HZ)

    def set_expected_scan_rate_hz(self, value: float):
        """The expected scan rate. Warning: In general the expected scan rate is set during initialization of the probe
        with respect to the attached device. In most cases it should not be altered manually."""
        self._set(PropertyFloat.EXPECTED_SCAN_RATE_HZ, value)

    def get_camera_scaling_x(self) -> float:
        """The px/mm ratio in X direction for the BScan overlay on the video image."""
        return self._get(PropertyFloat.CAMERA_SCALING_X)

    def set_camera_scaling_x(self, value: float):
        """The px/mm ratio in X direction for the BScan overlay on the video image."""
        self._set(PropertyFloat.CAMERA_SCALING_X, value)

    def get_camera_offset_x(self) -> float:
        """The BScan overlay X offset in pixels."""
        return self._get(PropertyFloat.CAMERA_OFFSET_X)

    def set_camera_offset_x(self, value: float):
        """The BScan overlay X offset in pixels."""
        self._set(PropertyFloat.CAMERA_OFFSET_X, value)

    def get_camera_scaling_y(self) -> float:
        """The px/mm ratio in Y direction for the BScan overlay on the video image."""
        return self._get(PropertyFloat.CAMERA_SCALING_Y)

    def set_camera_scaling_y(self, value: float):
        """The px/mm ratio in Y direction for the BScan overlay on the video image."""
        self._set(PropertyFloat.CAMERA_SCALING_Y, value)

    def get_camera_offset_y(self) -> float:
        """The BScan overlay Y offset in pixels."""
        return self._get(PropertyFloat.CAMERA_OFFSET_Y)

    def set_camera_offset_y(self, value: float):
        """The BScan overlay Y offset in pixels."""
        self._set(PropertyFloat.CAMERA_OFFSET_Y, value)

    def get_camera_angle(self) -> float:
        """Corrective rotation angle for the BScan overlay."""
        return self._get(PropertyFloat.CAMERA_ANGLE)

    def set_camera_angle(self, value: float):
        """Corrective rotation angle for the BScan overlay."""
        self._set(PropertyFloat.CAMERA_ANGLE, value)

    def get_range_max_x(self) -> float:
        """Maximum scan range in X direction"""
        return self._get(PropertyFloat.RANGE_MAX_X)

    def set_range_max_x(self, value: float):
        """Maximum scan range in X direction"""
        self._set(PropertyFloat.RANGE_MAX_X, value)

    def get_range_max_y(self) -> float:
        """Maximum scan range in Y direction"""
        return self._get(PropertyFloat.RANGE_MAX_Y)

    def set_range_max_y(self, value: float):
        """Maximum scan range in Y direction"""
        self._set(PropertyFloat.RANGE_MAX_Y, value)

    def get_max_slope_xy(self) -> float:
        """Maximum Galvo slope (accounting for the distortion capabilities of different Galvo types)"""
        return self._get(PropertyFloat.MAX_SLOPE_XY)

    def set_max_slope_xy(self, value: float):
        """Maximum Galvo slope (accounting for the distortion capabilities of different Galvo types)"""
        self._set(PropertyFloat.MAX_SLOPE_XY, value)

    def get_speckle_size(self) -> float:
        """Speckle size to be used for scan pattern computation if speckle reduction is switched on."""
        return self._get(PropertyFloat.SPECKLE_SIZE)

    def set_speckle_size(self, value: float):
        """Speckle size to be used for scan pattern computation if speckle reduction is switched on."""
        self._set(PropertyFloat.SPECKLE_SIZE, value)

    def get_apo_volt_x(self) -> float:
        """X-voltage used to acquire the apodization spectrum"""
        return self._get(PropertyFloat.APO_VOLT_X)

    def set_apo_volt_x(self, value: float):
        """X-voltage used to acquire the apodization spectrum"""
        self._set(PropertyFloat.APO_VOLT_X, value)

    def get_apo_volt_y(self) -> float:
        """Y-voltage used to acquire the apodization spectrum"""
        return self._get(PropertyFloat.APO_VOLT_Y)

    def set_apo_volt_y(self, value: float):
        """Y-voltage used to acquire the apodization spectrum"""
        self._set(PropertyFloat.APO_VOLT_Y, value)

    def get_ref_stage_offset(self) -> float:
        """Offset for reference stage marking the zero delay line"""
        return self._get(PropertyFloat.REF_STAGE_OFFSET)

    def set_ref_stage_offset(self, value: float):
        """Offset for reference stage marking the zero delay line"""
        self._set(PropertyFloat.REF_STAGE_OFFSET, value)

    def get_fiber_opl_mm(self) -> float:
        """Optical path length, in millimeter (fiber length up to the scanner, multiplied by the refractive index)"""
        return self._get(PropertyFloat.FIBER_OPL_MM)

    def set_fiber_opl_mm(self, value: float):
        """Optical path length, in millimeter (fiber length up to the scanner, multiplied by the refractive index)"""
        self._set(PropertyFloat.FIBER_OPL_MM, value)

    def get_probe_opl_mm(self) -> float:
        """Optical path length, in millimeter (from scanner input to objective mount, multiplied by the refractive
        index)"""
        return self._get(PropertyFloat.PROBE_OPL_MM)

    def set_probe_opl_mm(self, value: float):
        """Optical path length, in millimeter (from scanner input to objective mount, multiplied by the refractive
        index)"""
        self._set(PropertyFloat.PROBE_OPL_MM, value)

    def get_objective_opl_mm(self) -> float:
        """Optical path length, in millimeter (without counting the focal length, multiplied by the equivalent
        refractive index)"""
        return self._get(PropertyFloat.OBJECTIVE_OPL_MM)

    def set_objective_opl_mm(self, value: float):
        """Optical path length, in millimeter (without counting the focal length, multiplied by the equivalent
        refractive index)"""
        self._set(PropertyFloat.OBJECTIVE_OPL_MM, value)

    def get_objective_focal_length_mm(self) -> float:
        """Optical focal length, in millimeter"""
        return self._get(PropertyFloat.OBJECTIVE_FOCAL_LENGTH_MM)

    def set_objective_focal_length_mm(self, value: float):
        """Optical focal length, in millimeter"""
        self._set(PropertyFloat.OBJECTIVE_FOCAL_LENGTH_MM, value)
