import abc
from ctypes import c_void_p

import numpy as np

from pyspectralradar.data.utility import IShapeProperties
from pyspectralradar.data.utility.resizable import Resizable
from pyspectralradar.spectralradar import c_handle, get_error


class NumpyConvertible(IShapeProperties, Resizable):
    def to_numpy(self):
        res = np.empty(self.shape, dtype=self._np_data_type, order="F")

        data_ptr = np.ctypeslib.ndpointer(dtype=self._np_data_type, ndim=3, flags='F_CONTIGUOUS')
        self._copy_content_func.argtypes = [c_handle, data_ptr]
        self._copy_content_func(self.handle, res)

        get_error()

        return res

    @classmethod
    def from_numpy(cls, array):
        res = cls()
        if array.ndim == 1:
            res.resize(array.shape[0], 1, 1)
        if array.ndim == 2:
            dim1, dim2 = array.shape
            res.resize(dim1, dim2, 1)
        if array.ndim == 3:
            dim1, dim2, dim3 = array.shape
            res.resize(dim1, dim2, dim3)
        res._wrap_numpy_array(array)
        return res

    def _wrap_numpy_array(self, array):
        if not array.dtype == self._np_data_type:
            array = array.astype(self._np_data_type)
        if not array.flags['C_CONTIGUOUS']:
            array = np.ascontiguousarray(array, dtype=self._np_data_type)
        self._set_data_content_func.argtypes = [c_handle, c_void_p]
        self._set_data_content_func(self.handle, c_void_p(array.ctypes.data))

    @abc.abstractmethod
    def _construct_empty_handle(self):
        raise NotImplementedError

    @property
    @abc.abstractmethod
    def _set_data_content_func(self):
        raise NotImplementedError

    @property
    @abc.abstractmethod
    def _copy_content_func(self):
        raise NotImplementedError

    @property
    @abc.abstractmethod
    def _np_data_type(self) -> np.dtype:
        raise NotImplementedError
