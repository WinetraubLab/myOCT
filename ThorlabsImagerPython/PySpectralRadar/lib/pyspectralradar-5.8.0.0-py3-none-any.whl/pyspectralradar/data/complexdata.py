import numpy as np

from pyspectralradar.data.analysis import ComplexDataAnalysis
from pyspectralradar.data.base import AbstractProcessedData
from pyspectralradar.data.filter import ComplexFilter
from pyspectralradar.data.realdata import RealData
from pyspectralradar.data.utility import ComplexDataFileIo
from pyspectralradar.spectralradar import c_handle, get_error, sr


class ComplexData(AbstractProcessedData, ComplexDataFileIo):
    def __init__(self):
        super().__init__()
        self.filter = ComplexFilter(self.handle)
        self.analysis = ComplexDataAnalysis(self.handle)

    def abs(self) -> RealData:
        """Converts the complex values from the :class:`~pyspectralradar.data.complexdata.ComplexData` object to its
        absolute values and writes them to :class:`~pyspectralradar.data.realdata.RealData` object.

        Returns:
            The absolute values as :class:`~pyspectralradar.data.realdata.RealData` object.
        """
        abs_data = RealData()
        sr.absComplexData.argtypes = [c_handle, c_handle]
        sr.absComplexData(self.handle, abs_data.handle)
        get_error()
        return abs_data

    def log_abs(self) -> RealData:
        """Converts the complex values from the :class:`~pyspectralradar.data.complexdata.ComplexData` object to its
        dB values and writes them into a :class:`~pyspectralradar.data.realdata.RealData` object.

        Returns:
            The dB values as :class:`~pyspectralradar.data.realdata.RealData` object.
        """
        log_abs_data = RealData()
        sr.logAbsComplexData.argtypes = [c_handle, c_handle]
        sr.logAbsComplexData(self.handle, log_abs_data.handle)
        get_error()
        return log_abs_data

    def arg(self) -> RealData:
        """Converts the complex values from the :class:`~pyspectralradar.data.complexdata.ComplexData` object to its
        phase angle values and writes them into a :class:`~pyspectralradar.data.realdata.RealData` object.

        Returns:
            The phase angle values as :class:`~pyspectralradar.data.realdata.RealData` object.
        """
        arg_data = RealData()
        sr.argComplexData.argtypes = [c_handle, c_handle]
        sr.argComplexData(self.handle, arg_data.handle)
        get_error()
        return arg_data

    def real(self) -> RealData:
        """Writes the real part of the complex values from the :class:`~pyspectralradar.data.complexdata.ComplexData`
        into a :class:`~pyspectralradar.data.realdata.RealData` object.

        Returns:
            The amplitude/real part values as :class:`~pyspectralradar.data.realdata.RealData` object.
        """
        real_data = RealData()
        sr.realComplexData.argtypes = [c_handle, c_handle]
        sr.realComplexData(self.handle, real_data.handle)
        get_error()
        return real_data

    def imag(self) -> RealData:
        """Writes the imaginary part of the complex values from the
        :class:`~pyspectralradar.data.complexdata.ComplexData` into a
        :class:`~pyspectralradar.data.realdata.RealData` object.

        Returns:
            The imaginary part values as :class:`~pyspectralradar.data.realdata.RealData` object.
        """
        imag_data = RealData()
        sr.imagComplexData.argtypes = [c_handle, c_handle]
        sr.imagComplexData(self.handle, imag_data.handle)
        get_error()
        return imag_data

    @property
    def _orientation_get(self):
        raise NotImplementedError

    @property
    def _orientation_set(self):
        raise NotImplementedError

    @property
    def _create_handle_func(self):
        return sr.createComplexData

    @property
    def _del_func(self):
        return sr.clearComplexData

    @property
    def _int_get(self):
        return sr.getComplexDataPropertyInt

    @property
    def _float_get(self):
        return sr.getComplexDataPropertyFloat

    @property
    def _c_crop_func(self):
        return sr.cropComplexData

    @property
    def _c_append_func(self):
        return sr.appendComplexData

    @property
    def _resize_func(self):
        return sr.resizeComplexData

    @property
    def _set_data_range_func(self):
        return sr.setComplexDataRange

    @property
    def _set_data_content_func(self):
        return sr.setComplexDataContent

    @property
    def _copy_func(self):
        return sr.copyComplexData

    @property
    def _copy_content_func(self):
        return sr.copyComplexDataContent

    @property
    def _np_data_type(self):
        return np.csingle

    @property
    def _pointer_func(self):
        return sr.getComplexDataPtr

    @property
    def _reserve_func(self):
        return sr.reserveComplexData

    @property
    def _get_slice_at_pos_func(self):
        return sr.getComplexDataSlicePos

    @property
    def _get_slice_at_index_func(self):
        return sr.getComplexDataSliceIndex

    @property
    def _separate_func(self):
        return sr.separateComplexData

    @property
    def _flip_func(self):
        return sr.flipComplexData
