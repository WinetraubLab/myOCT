import unittest

import numpy as np

import pyspectralradar.types as pt
from pyspectralradar import OCTSystem, RawData, LogLevel, set_log_level


class TestRawDataConstruction(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def test_from_numpy(self):
        np_dat = np.ones((3, 4), dtype=np.uint16)
        raw_dat = RawData.from_numpy(np_dat)
        self.assertEqual(raw_dat.shape, (3, 4, 1))
        self.assertEqual(raw_dat.dtype, np.uint16)
        self.assertEqual(raw_dat.size, 12)
        self.assertEqual(raw_dat.bytes_per_element, 2)
        # raw_dat.range  # TODO


class RawDataTestCase(unittest.TestCase):
    dut = RawData()

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

        sys = OCTSystem()
        dev = sys.dev
        probe = sys.probe_factory.create_default()
        pattern = probe.scan_pattern.create_bscan_pattern(10.0, 128)

        dev.acquisition.start(pattern, pt.AcqType.ASYNC_FINITE)
        dev.acquisition.get_raw_data(buffer=cls.dut)

        dev.acquisition.stop()

        del pattern
        del probe
        del dev
        del sys

    @classmethod
    def tearDownClass(cls):
        del cls.dut

    def test_slice(self):
        dut = self.dut.clone()
        idx = 33
        sliced = dut.get_slice_at_index(pt.DataDirection.DIR2, idx)
        self.assertIsInstance(sliced, RawData)

        print(dut.shape, dut.to_numpy().shape)
        print(sliced.shape, sliced.to_numpy().shape)

        print(dut.to_numpy()[:, idx, 0] - sliced.to_numpy()[:, 0, 0])

        self.assertTrue(np.allclose(sliced.to_numpy()[:, 0, 0], dut.to_numpy()[:, idx, 0]))

    def test_apo_scans(self):
        default_apo_region = np.array([20, 45])

        self.assertEqual(self.dut.get_number_of_apodization_regions(), 1)
        self.assertTrue(np.all(self.dut.get_apo_scans() == default_apo_region))

        new_apo_region = np.array([20, 75])
        self.dut.set_apo_scans(1, new_apo_region)
        self.assertTrue(np.all(self.dut.get_apo_scans() == new_apo_region))

    def test_scans(self):
        default_scan_region = np.array([65, 193])

        self.assertEqual(self.dut._get_number_of_scan_regions(), 1)
        self.assertTrue(np.all(self.dut.get_scans() == default_scan_region))

        new_scan_regions = np.array([143, 193])
        self.dut.set_scans(1, new_scan_regions)
        self.assertTrue(np.all(self.dut.get_scans() == new_scan_regions))

    def test_dtype(self):
        self.assertTrue(self.dut.dtype == np.uint16)


if __name__ == '__main__':
    unittest.main()
