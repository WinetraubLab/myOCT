from enum import IntEnum

from pyspectralradar.base.propertygetter import StringPropertyGetter
from pyspectralradar.base.propertysetter import StringPropertySetter
from pyspectralradar.spectralradar import sr


class PropertyString(IntEnum):
    """Parameters describing the composition of the probe. These properties refer to a probe that has
    already been created and for which a valid Probe handle has been obtained."""

    NAME = 0
    """The filename. Just Probe.ini, or some other name."""

    SERIAL_NUMBER = 1
    """Serial number of the probe."""

    DESCRIPTION = 2
    """Name of the probe. From this name it is possible to find out the probe definition file. A version
    suffix (e.g. "_V2") might be part of it. The termination ".prdf" is not part of the name."""

    OBJECTIVE = 3
    """Objective from the probe.  From this string it is possible to find out the objective definition file.
    A version suffix (e.g. "_V2") might be part of it. The termination ".odf" is not part of the name."""


class ProbePropertyString(StringPropertyGetter, StringPropertySetter):
    """Parameters describing the composition of the probe. These properties refer to a probe that has
    already been created and for which a valid probe handle has been obtained."""

    def __init__(self, handle):
        StringPropertyGetter.__init__(self, handle, sr.getProbeParameterString)
        StringPropertySetter.__init__(self, handle, sr.setProbeParameterString)

    def get_name(self) -> str:
        """The filename. Just Probe.ini, or some other name."""
        return self._get(PropertyString.NAME)

    def set_name(self, value: str):
        """The filename. Just Probe.ini, or some other name."""
        self._set(PropertyString.NAME, value)

    def get_serial_number(self) -> str:
        """Serial number of the probe."""
        return self._get(PropertyString.SERIAL_NUMBER)

    def set_serial_number(self, value: str):
        """Serial number of the probe."""
        self._set(PropertyString.SERIAL_NUMBER, value)

    def get_description(self) -> str:
        """Name of the probe. From this name it is possible to find out the probe definition file. A version
            suffix (e.g. "_V2") might be part of it. The termination ".prdf" is not part of the name."""
        return self._get(PropertyString.DESCRIPTION)

    def set_description(self, value: str):
        """Name of the probe. From this name it is possible to find out the probe definition file. A version
            suffix (e.g. "_V2") might be part of it. The termination ".prdf" is not part of the name."""
        self._set(PropertyString.DESCRIPTION, value)

    def get_objective(self) -> str:
        """Objective from the probe.  From this string it is possible to find out the objective definition file.
            A version suffix (e.g. "_V2") might be part of it. The termination ".odf" is not part of the name."""
        return self._get(PropertyString.OBJECTIVE)

    def set_objective(self, value: str):
        """Objective from the probe.  From this string it is possible to find out the objective definition file.
            A version suffix (e.g. "_V2") might be part of it. The termination ".odf" is not part of the name."""
        self._set(PropertyString.OBJECTIVE, value)
