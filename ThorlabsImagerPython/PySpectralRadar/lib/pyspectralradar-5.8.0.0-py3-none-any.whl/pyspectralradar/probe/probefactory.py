from __future__ import annotations

from ctypes import c_char_p
from typing import TYPE_CHECKING

from pyspectralradar.base import Submodule
from pyspectralradar.octfile import OCTFile
from pyspectralradar.probe import Probe
from pyspectralradar.spectralradar import c_handle, get_error, sr

if TYPE_CHECKING:
    from pyspectralradar.octdevice import OCTDevice


class ProbeFactory(Submodule):
    def __init__(self, oct_dev: OCTDevice):
        super().__init__(oct_dev.handle)

    def create_default(self, probe_file: str = 'Probe') -> Probe:
        """Initializes a probe specified by ``probe_file``.

        Args:
            :probe_file: The filename of the .ini. If the path is not given, it will be assumed that this file is in
                the configuration directory (typically "C:/Program Files/Thorlabs/SpectralRadar/Config"). To
                indicate that file is in the current working directory, prepend a "~\" before the name. If a
                termination ".ini" is not there, it will be appended.

        Returns:
            A valid probe handle.

        In older systems up until a manufacturing date of May 2011 either ``Handheld`` or ``Microscope`` are used. An
        according .ini file (i.e. ``Handheld.ini`` or ``Microscope.ini``) will be loaded from the config path of the
        SpectralRadar installation containing all necessary information.

        With systems manufactured after May 2011 ``Probe`` should be used.
        """
        sr.initProbe.argtypes = [c_handle, c_char_p]
        sr.initProbe.restype = c_handle
        handle = sr.initProbe(self.handle, probe_file.encode('ascii'))
        get_error()
        res = Probe(handle)
        return res

    def create_new(self, probe_type: str, objective: str) -> Probe:
        """Creates a standard probe using standard parameters for the specified probe type.

        Args:
            :probe_type: A zero terminated string with the probe type name (one of ``Standard_OCTG``,
                ``UserCustomizable_OCTP``, ``Handheld_OCTH``).
            :objective: A zero terminated string with the objective name (e.g. ``LSM03``).

        Returns:
            A valid probe object.
        """
        sr.initDefaultProbe.argtypes = [c_handle, c_char_p, c_char_p]
        sr.initDefaultProbe.restype = c_handle
        handle = sr.initDefaultProbe(self.handle, probe_type.encode('ascii'), objective.encode('ascii'))
        get_error()
        res = Probe(handle)
        return res

    def from_gui_settings(self) -> Probe:
        """Initializes the probe that is currently selected in the GUI. If no probe is configured, an error is raised.

        Returns:
            A valid probe object using the currently stored settings.
        """
        sr.initCurrentProbe.argtypes = [c_handle]
        sr.initCurrentProbe.restype = c_handle
        handle = sr.initCurrentProbe(self.handle)
        get_error()
        res = Probe(handle)
        return res

    def from_oct_file(self, oct_file: OCTFile) -> Probe:
        """Creates a probe using the parameters from the specified OCT file.

        Args:
            :oct_file: OCT file from which the probe should be loaded.

        Returns:
            A valid probe object.
        """
        sr.initProbeFromOCTFile.argtypes = [c_handle, c_handle]
        sr.initProbeFromOCTFile.restype = c_handle
        handle = sr.initProbeFromOCTFile(self.handle, oct_file.handle)
        get_error()
        res = Probe(handle)
        return res
