import numpy as np

from pyspectralradar import LogLevel, set_log_level
from pyspectralradar.octsystem import OCTSystem

set_log_level(LogLevel.OFF)

sys = OCTSystem()
proc = sys.processing_factory.from_device()
pp = proc.properties

setter_names = np.array([p for p in dir(pp) if p.startswith("set_")])
getter_names = np.array([p for p in dir(pp) if p.startswith("get_")])
getter = np.array([getattr(pp, g) for g in getter_names])
setter = [getattr(pp, g) for g in setter_names]
types = []
values = []
for g, n in zip(getter, getter_names):
    try:
        val = g()
        print(f"{n} = {val}")
        values.append(val)
        types.append(type(val))
    except:
        print(f"Error evaluating {n}")
        raise
types = np.array(types)
values = np.array(values, dtype=object)

inds = np.where(types == bool)
for g_name, s_name, default_value in zip(getter_names[inds], setter_names[inds], values[inds]):
    print(f"val = pp.{g_name}()")
    print(f"self.assertIsInstance(val, bool)")
    if default_value:
        print(f"self.assertTrue(val)")
    else:
        print(f"self.assertFalse(val)")
    # toggle value
    print(f"pp.{s_name}({not default_value})")
    print(f"val = pp.{g_name}()")
    if not default_value:
        print(f"self.assertTrue(val)")
    else:
        print(f"self.assertFalse(val)")
    # toggle back
    print(f"pp.{s_name}({default_value})")
    print(f"val = pp.{g_name}()")
    if default_value:
        print(f"self.assertTrue(val)")
    else:
        print(f"self.assertFalse(val)")
    print("#")

inds = np.where(types == int)
for g_name, s_name, default_value in zip(getter_names[inds], setter_names[inds], values[inds]):
    print(f"self.assertIsInstance(pp.{g_name}(), int)")
    print(f"self.assertEqual(pp.{g_name}(), {default_value})")
    print(f"pp.{s_name}({default_value + 1})")
    print(f"self.assertEqual(pp.{g_name}(), {default_value + 1})")
    print(f"pp.{s_name}({default_value})")
    print(f"self.assertEqual(pp.{g_name}(), {default_value})")
    print("#")

inds = np.where(types == float)
for g_name, s_name, default_value in zip(getter_names[inds], setter_names[inds], values[inds]):
    print(f"self.assertIsInstance(pp.{g_name}(), float)")
    print(f"self.assertEqual(pp.{g_name}(), {default_value})")
    print(f"pp.{s_name}({default_value + .1})")
    print(f"self.assertEqual(pp.{g_name}(), {default_value + .1})")
    print(f"pp.{s_name}({default_value})")
    print(f"self.assertEqual(pp.{g_name}(), {default_value})")
    print("#")
