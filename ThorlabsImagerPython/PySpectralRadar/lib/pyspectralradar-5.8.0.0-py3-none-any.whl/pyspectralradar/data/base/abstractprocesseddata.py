import abc
from ctypes import c_double, c_int
from typing import Self, Tuple

from pyspectralradar.data.base import AbstractData
from pyspectralradar.data.properties import DataPropertyExposer
from pyspectralradar.spectralradar import c_handle, get_error
from pyspectralradar.types import DataDirection, DataOrientation


class AbstractProcessedData(AbstractData, DataPropertyExposer):
    """Abstract base class for processed OCT data structures"""

    def __init__(self, handle: c_handle = None):
        super().__init__(handle)
        DataPropertyExposer.__init__(self, self.handle)

    def set_range(self, range1: float, range2: float, range3: float):
        """Sets the range in mm in the 3 axes represented in the :class:`~pyspectralradar.data.realdata.RealData`
        buffer.

        Args:
            :range1: The desired physical extension, in mm, along the first axis (``z`` in the default orientation).
            :range2: The desired physical extension, in mm, along the second axis (``x`` in the default orientation).
            :range3: The desired physical extension, in mm, along the third axis (``y`` in the default orientation).
        """
        func = self._set_data_range_func
        func.argtypes = [c_handle, c_double, c_double, c_double]
        func(self.handle, range1, range2, range3)
        get_error()

    def crop(self, direction: DataDirection, minimum: int, maximum: int):
        """Crops the data along the desired direction at the given indices.

        Upon return the data will only contain those slices whose indices where in the interval [``minimum``,
        ``maximum``], counted along the cropping direction. If ``minimum`` ist not the smaller of the two indices,
        they will be automatically switched.

        Args:
            :direction: The physical direction along which the existing data will be cropped.
            :minimum: The first slice that will be kept. This index is zero-based.
            :maximum: One-past-the-last slice that will be kept. This index is zero-based."""

        crop_func = self._c_crop_func
        crop_func.argtypes = [c_handle, c_int, c_int, c_int]
        crop_func(self.handle, c_int(direction), c_int(minimum), c_int(maximum))
        get_error()

    def get_orientation(self) -> DataOrientation:
        """Get the data orientation of the data object."""
        func = self._orientation_get
        func.argtypes = [c_handle]
        func.restype = c_int
        res = func(self.handle)
        get_error()
        return DataOrientation(res)

    def set_orientation(self, selection: DataOrientation):
        """Set the data orientation of the data object to the given orientation.

        Args:
            :selection: The desired orientation.
        """
        assert isinstance(selection, DataOrientation)
        func = self._orientation_set
        func.argtypes = [c_handle]
        func(self.handle, selection)
        get_error()

    def get_slice_at_pos(self, direction: DataDirection, pos_mm: float) -> Self:
        """Returns a slice of data perpendicular to the specified direction at the specified position.

        The data that will be sliced should be three-dimensional, e.g., a sequence of B-scans. A slice is
        one of the B-scans, perpendicular to the specified ``direction``. If a position intermediate between two
        measured B-scans is given, this function will pick the closest; no interpolation will take place.

        Args:
            :direction: The physical direction in which the existing data will be sliced. Currently only the
                :class:`~pyspectralradar.types.datatypes.DataDirection`. ``DIR3`` (usually the Y-axis) is supported
            :pos_mm: The position of the desired slice along the ``direction``, expressed in millimeter.
                The total range of positions can be inquired with the data objects property ``range``. If the scan
                pattern has not been manipulated, e.g. shifted, the center position is 0 mm.

        Returns:
            A data object, where the data of the slice will be written.
        """
        self._check_slice_op_requirements(direction)
        data_slice = type(self)()
        func = self._get_slice_at_index_func
        func.argtypes = [c_handle, c_handle, c_int, c_double]
        func(self.handle, data_slice.handle, direction, pos_mm)
        get_error()
        return data_slice

    def get_slice_at_index(self, direction: DataDirection, idx: int) -> Self:
        """Returns a slice of data perpendicular to the specified direction at the specified index.

        The data that will be sliced should be three-dimensional, e.g., a sequence of B-scans. A slice is
        one of the B-scans, perpendicular to the specified ``direction``. If a position intermediate between two
        measured B-scans is given, this function will pick the closest; no interpolation will take place.

        Args:
            :direction: The physical direction in which the existing data will be sliced. Currently only the
                :class:`~pyspectralradar.types.datatypes.DataDirection`. ``DIR3`` (usually the Y-axis) is supported
            :idx: Index of the desired slice along the ``direction`` (zero-based, that is, the first slice is 0). The
                total number of slices can be obtained with the data objects property ``shape``.

        Returns:
            A data object, where the data of the slice will be written.
        """
        assert isinstance(direction, DataDirection)
        data_slice = type(self)()
        func = self._get_slice_at_index_func
        func.argtypes = [c_handle, c_handle, c_int, c_int]
        func(self.handle, data_slice.handle, direction, idx)
        get_error()
        return data_slice

    def _check_slice_op_requirements(self, direction):
        """Helper function"""
        assert isinstance(direction, DataDirection)
        if not direction == DataDirection.DIR3:
            raise NotImplementedError("Currently only the DIR3 (usually the Y-axis) is supported.")
        if not self.ndim == 3:
            raise NotImplementedError("Only 3-dimensional data can be sliced yet")

    def separate(self, direction: DataDirection, separation_idx: int) -> Tuple[Self, Self]:
        """Separates the data at the given index at specific separation ``direction``.
        The first part of the separated data will remain in ``data1``, the second separated in ``data2``.

        Args:
            :direction: The physical direction along which the separation will take place
            :separation_idx: The first slice of the second part, or one-past-the-last slice kept in the first part

        Returns:
            :data1, data2: Valid (non-null) data objects to the first- and second part of the data.
        """
        func = self._separate_func
        data1 = self.clone()
        data2 = type(self)()
        func.argtypes = [c_handle, c_handle, c_int, c_int]
        func(data1.handle, data2.handle, separation_idx, direction)
        get_error()
        return data1, data2

    def flip(self, flipping_direction: DataDirection):
        """Mirrors the data across a plane perpendicular to the given direction.

        Args:
            :flipping_direction: The physical direction along which the existing data will be flipped.
        """
        func = self._flip_func
        func.argtypes = [c_handle, c_int]
        func(self.handle, flipping_direction)
        get_error()

    def copy(self) -> Self:
        """Creates a copy of the current data

        Returns:
            A copy of the data object.
        """
        dst = type(self)()
        fun = self._copy_func
        fun.argtypes = [c_handle, c_handle]
        fun(self.handle, dst.handle)
        get_error()
        return dst

    @property
    @abc.abstractmethod
    def _set_data_range_func(self):
        raise NotImplementedError

    @property
    @abc.abstractmethod
    def _c_crop_func(self):
        raise NotImplementedError

    @property
    @abc.abstractmethod
    def _orientation_get(self):
        raise NotImplementedError

    @property
    @abc.abstractmethod
    def _orientation_set(self):
        raise NotImplementedError

    @property
    @abc.abstractmethod
    def _get_slice_at_pos_func(self):
        raise NotImplementedError

    @property
    @abc.abstractmethod
    def _get_slice_at_index_func(self):
        raise NotImplementedError

    @property
    @abc.abstractmethod
    def _separate_func(self):
        raise NotImplementedError

    @property
    @abc.abstractmethod
    def _flip_func(self):
        raise NotImplementedError

    @property
    @abc.abstractmethod
    def _copy_func(self):
        raise NotImplementedError
