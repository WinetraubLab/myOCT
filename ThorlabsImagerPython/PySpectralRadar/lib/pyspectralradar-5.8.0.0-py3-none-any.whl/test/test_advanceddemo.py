import unittest

from examples import advanced_demo as ad
from pyspectralradar import LogLevel, set_log_level

HARDWARE_CONNECTED = False
SHOW_PLOT = False


class AdvancedDemoTestCase(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def test_write_oct_file(self):
        self.assertTrue(ad.write_oct_file())

    def test_read_oct_file(self):
        self.assertTrue(ad.read_oct_file())

    @unittest.skipUnless(SHOW_PLOT, "Uses plt.show")
    def test_read_sdr_file(self):
        self.assertTrue(ad.read_sdr_file())

    def test_processing_chain(self):
        self.assertTrue(ad.processing_chain())

    def test_read_and_process_raw_data_from_file(self):
        self.assertTrue(ad.read_and_process_raw_data_from_file())

    def test_advanced_modification_of_scan_pattern(self):
        self.assertTrue(ad.advanced_modification_of_scan_pattern())

    def test_freeform_scanpatterns(self):
        self.assertTrue(ad.freeform_scanpatterns())

    @unittest.skip  # user keypress required
    def test_removing_apo_from_scan_pattern(self):
        self.assertTrue(ad.removing_apo_from_scan_pattern())

    def test_doppler_oct(self):
        self.assertTrue(ad.doppler_oct())

    def test_speckle_variance_oct(self):
        self.assertTrue(ad.speckle_variance_oct())

    @unittest.skipUnless(HARDWARE_CONNECTED, "Requires hardware")
    def test_external_trigger_modus(self):
        self.assertTrue(ad.external_trigger_modus())

    @unittest.skipUnless(HARDWARE_CONNECTED, "Requires hardware")
    def test_batch_measurement_with_polarization_adjustment(self):
        self.assertTrue(ad.batch_measurement_with_polarization_adjustment())

    @unittest.skipUnless(HARDWARE_CONNECTED, "Requires hardware")
    def test_automatic_reference_and_amplification_adjustment(self):
        self.assertTrue(ad.automatic_reference_and_amplification_adjustment())

    def test_image_field_calibration(self):
        self.assertTrue(ad.image_field_calibration())

    def test_write_oct_file_with_freeform_scan_pattern(self):
        self.assertTrue(ad.write_oct_file_with_freeform_scan_pattern())

    @unittest.skip  # user keypress required
    def test_ring_light_adjustment(self):
        self.assertTrue(ad.ring_light_adjustment())

    @unittest.skip  # requires dual dummy
    def test_write_ps_oct_file(self):
        self.assertTrue(ad.write_ps_oct_file())


if __name__ == '__main__':
    unittest.main()
