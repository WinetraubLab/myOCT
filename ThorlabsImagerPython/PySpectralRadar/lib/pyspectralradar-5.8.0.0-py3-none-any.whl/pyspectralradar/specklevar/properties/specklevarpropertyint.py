from enum import IntEnum

from pyspectralradar.base.propertygetter import IntPropertyGetter
from pyspectralradar.base.propertysetter import IntPropertySetter
from pyspectralradar.spectralradar import sr


class PropertyInt(IntEnum):
    """Enum identifying different properties of typ int for speckle variance processing."""

    AVERAGING1 = 0
    """Averaging on Z-Axis"""

    AVERAGING2 = 1
    """Averaging on X-Axis"""

    AVERAGING3 = 2
    """Averaging on Y-Axis"""


class SpeckleVariancePropertyInt(IntPropertyGetter, IntPropertySetter):

    def __init__(self, handle_get, handle_set):
        IntPropertyGetter.__init__(self, handle_get, sr.getSpeckleVariancePropertyInt)
        IntPropertySetter.__init__(self, handle_set, sr.setSpeckleVariancePropertyInt)

    def get_averaging1(self) -> int:
        """Averaging on Z-Axis"""
        return self._get(PropertyInt.AVERAGING1)

    def set_averaging1(self, value: int):
        """Averaging on Z-Axis"""
        self._set(PropertyInt.AVERAGING1, value)

    def get_averaging2(self) -> int:
        """Averaging on X-Axis"""
        return self._get(PropertyInt.AVERAGING2)

    def set_averaging2(self, value: int):
        """Averaging on X-Axis"""
        self._set(PropertyInt.AVERAGING2, value)

    def get_averaging3(self) -> int:
        """Averaging on Y-Axis"""
        return self._get(PropertyInt.AVERAGING3)

    def set_averaging3(self, value: int):
        """Averaging on Y-Axis"""
        self._set(PropertyInt.AVERAGING3, value)
