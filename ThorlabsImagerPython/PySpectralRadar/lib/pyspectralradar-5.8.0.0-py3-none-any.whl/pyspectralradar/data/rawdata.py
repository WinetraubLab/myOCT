from ctypes import ArgumentError, POINTER, c_bool, c_int
from typing import Self

import numpy as np

from pyspectralradar.data.base import AbstractData
from pyspectralradar.data.properties import RawDataPropertyExposer
from pyspectralradar.data.utility import RawDataFileIo
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import DataDirection


class RawData(AbstractData, RawDataPropertyExposer, RawDataFileIo):
    def __init__(self):
        super().__init__()
        RawDataPropertyExposer.__init__(self, self.handle)

    def get_apo_scans(self) -> np.ndarray:
        """Returns the indices of regions in the raw data containing spectra that are supposed to be used for
        apodization.

        During the scanning, the light spot travels along a curve, also known as scan pattern. At each of the points
        of the curve, spectra are measured. Some spectra are acquired at points where an A-Scans are desired (the
        scan region(s)), some others where an Apodization is desired (apodization region(s)), and some others at less
        than interesting positions. Notice that raw data refers to the spectra as acquired, without processing of
        any kind.

        Returns:
            The indices of apodization regions (each region may contain several apodizations).
        """
        return self._get_apodization_spectra()

    def get_number_of_apodization_regions(self) -> int:
        """Returns the number of regions in the raw data containing spectra that are supposed to be used for
        apodization.

        During the scanning, the light spot travels along a curve, also known as scan pattern. At each of the
        points of the curve, spectra are measured. Some spectra are acquired at points where an A-Scans are
        desired (the scan region(s)), some others where an Apodization is desired (apodization region(s)),
        and some others at less than interesting positions. Notice that raw data refers to the spectra as
        acquired, without processing of any kind.

        Returns:
            The number of apodization regions (each region may contain several apodizations).
        """
        sr.getNumberOfApodizationRegions.restype = c_int
        sr.getNumberOfApodizationRegions.argtypes = [c_handle]
        regions = sr.getNumberOfApodizationRegions(self.handle)
        get_error()
        return regions

    def _get_apodization_spectra(self) -> np.ndarray:
        """Returns the number of regions in the raw data containing spectra that are supposed to be used for
        apodization.

        Returns:
            The number of apodization regions (each region may contain several apodizations).

        During the scanning, the light spot travels along a curve, also known as scan pattern. At each of the
        points of the curve, spectra are measured. Some spectra are acquired at points where an A-Scans are
        desired (the scan region(s)), some others where an Apodization is desired (apodization region(s)),
        and some others at less than interesting positions.\n Notice that raw data refers to the spectra as
        acquired, without processing of any kind.
        """
        indices = np.ndarray(2 * self.get_number_of_apodization_regions(), dtype=c_int)
        sr.getApodizationSpectra.argtypes = [c_handle, np.ctypeslib.ndpointer(dtype=c_int, flags='C_CONTIGUOUS')]
        sr.getApodizationSpectra(self.handle, indices)
        get_error()
        return indices

    def set_apo_scans(self, number_of_regions: int, regions: np.ndarray):
        """Sets the number of the spectra in the raw data that contain data useful as apodization spectra.

        During the scanning, the light spot travels along a curve, also known as scan pattern. At each of the points
        of the curve, spectra are measured. Some spectra are acquired at points where an A-Scans are desired (the
        scan region(s)), some others where an Apodization is desired (apodization region(s)), and some others at less
        than interesting positions. This function sets the regions where apodization spectra will be measured. The
        supplied array must contain an even number of indices. The even indices give the start of a region,
        and the odd indices give the end of the regions (actually, one point past-the-end). In other words,
        the index pair at position (2n,2n+1) in the array (third argument) gives the n-th region, starting at point
        ApodizationRegions[2n] and ending at (but not including) the point ApodizationRegions[2*n+1]. Here 0 <= n <
        ``number_of_regions``. Notice that raw data refers to the spectra as acquired, without processing of any kind.

        indices = np.ndarray(2 * ``regions``, dtype=int)

        Args:
            :number_of_regions: is the number of desired apodization regions.
            :regions: is an array containing 2* ``number_of_regions`` elements that delimit the regions.
        """

        if isinstance(regions, (list, tuple, np.ndarray)):
            casted_indices = np.asarray(regions, dtype=c_int)
        else:
            raise ValueError("Indices must be a list, tuple, or NumPy array.")
        sr.setApodizationSpectra.argtypes = [c_handle,
                                             c_int,
                                             np.ctypeslib.ndpointer(dtype=c_int, flags='C_CONTIGUOUS')]
        sr.setApodizationSpectra(self.handle, number_of_regions, casted_indices)
        get_error()

    def get_scans(self) -> np.ndarray:
        """Returns the indices of spectra that contain scan data, i.e. spectra that are supposed to be used to
        compute A-scans.

        During the scanning, the light spot travels along a curve, also known as scan pattern. At each of the points
        of the curve, spectra are measured. Some spectra are acquired at points where an A-Scans are desired (the
        scan region(s)), some others where an Apodization is desired (apodization region(s)), and some others at less
        than interesting positions. Notice that raw data refers to the spectra as acquired, without processing of
        any kind.

        Returns:
            The array of indices delimiting the scan regions.
        """
        _regions = self._get_number_of_scan_regions()
        indices = np.ndarray(2 * _regions, dtype=c_int)
        sr.getScanSpectra.argtypes = [c_handle, np.ctypeslib.ndpointer(dtype=c_int, flags='C_CONTIGUOUS')]
        sr.getScanSpectra(self.handle, indices)
        get_error()
        return indices

    def _get_number_of_scan_regions(self) -> int:
        """Returns the number of regions that have been acquired that contain scan data, i.e. spectra that are used
        to compute A-scans.

        During the scanning, the light spot travels along a curve, also known as scan pattern. At each of the points
        of the curve, spectra are measured. Some spectra are acquired at points where an A-Scans are desired (the
        scan region(s)), some others where an Apodization is desired (apodization region(s)), and some others at less
        than interesting positions. Notice that raw data refers to the spectra as acquired, without processing of
        any kind.

        Returns:
            The number of scan regions (each region may contain several scans).
        """
        sr.getNumberOfScanRegions.restype = c_int
        sr.getNumberOfScanRegions.argtypes = [c_handle]
        regions = sr.getNumberOfScanRegions(self.handle)
        get_error()
        return regions

    def set_scans(self, number_of_scan_regions: int, scan_regions: np.ndarray):
        """Sets the number of the spectra in the raw data that are used for creating A-scan/B-scan data.

        During the scanning, the light spot travels along a curve, also known as scan pattern. At each of the points
        of the curve, spectra are measured. Some spectra are acquired at points where A-Scans are desired (the
        scan region(s)), some others where an Apodization is desired (apodization region(s)), and some others at less
        than interesting positions.
        This function sets the regions where A-Scan computation is desired. The supplied array must contain an even
        number of indices. The even indices give the start of a region, and the odd indices give the end of the
        regions (actually, one point past-the-end). In other words, the index pair at position (2n,2n+1) in the array
        (third argument) gives the n-th region, starting at point ``scan_regions[2n]`` and ending at (but not including)
        the point ``scan_regions[2*n+1]``. Here ``0 <= n < number_of_scan_regions``. Notice that raw data refers to the
        spectra as acquired, without processing of any kind.

        indices = np.ndarray(2 * number_of_scan_regions, dtype=int)

        Args:
            :number_of_scan_regions: is the number of desired scan regions
            :scan_regions: is an array containing ``2 * number_of_scan_regions`` elements that delimit the regions
        """
        scan_regions = scan_regions.astype(np.int32)
        scan_regions_array = (c_int * len(scan_regions))(*scan_regions)

        sr.setScanSpectra.argtypes = [c_handle, c_int, POINTER(c_int)]
        sr.setScanSpectra(self.handle, number_of_scan_regions, scan_regions_array)
        get_error()

    @classmethod
    def from_numpy(cls, array):
        res = cls()
        if array.ndim == 1:
            res.resize(array.shape[0], 1, 1)
        if array.ndim == 2:
            dim1, dim2 = array.shape
            res.resize(dim1, dim2, 1)
        if array.ndim == 3:
            dim1, dim2, dim3 = array.shape
            res.resize(dim1, dim2, dim3)
        res.dtype = array.dtype
        res._wrap_numpy_array(array)
        return res

    @property
    def dtype(self):
        return self._np_data_type

    @dtype.setter
    def dtype(self, value):
        if value == np.single:
            self._set_bytes_per_pixel(4)
            raise NotImplementedError("Signed not supported yet")
            # self._set_signed(True)
        elif value == np.uint16:
            self._set_bytes_per_pixel(2)
            # self._set_signed(False)
        elif value == np.int16:
            self._set_bytes_per_pixel(2)
            raise NotImplementedError("Signed not supported yet")
            # self._set_signed(True)
        elif value == np.uint8:
            self._set_bytes_per_pixel(1)
            # self._set_signed(False)
        else:
            raise ArgumentError('dtype not supported. ')

    def _set_bytes_per_pixel(self, value: int):
        """Sets the bytes per pixel for raw data.

        If the raw data are retrieved using
        :func:`~pyspectralradar.octdevice.submodules.acquisition.acquisition.Acquisition.get_raw_data`,
        this parameter is automatically set to the right value. Notice that raw data refers to the spectra as
        acquired, without processing of any kind.

        Args:
            :value: The number of bytes per pixel supported by the camera or sensor.
        """

        sr.setRawDataBytesPerPixel.argtypes = [c_handle, c_int]
        sr.setRawDataBytesPerPixel(self.handle, value)
        get_error()

    def _set_signed(self, signed: bool):
        """Sets the bytes per pixel for raw data.

        If the raw data are retrieved using
        :func:`~pyspectralradar.octdevice.submodules.acquisition.acquisition.Acquisition.get_raw_data`,
        this parameter is automatically set to the right value. Notice that raw data refers to the spectra as
        acquired, without processing of any kind.

        Args:
            :signed: Specifies whether the available raw data is signed.
        """
        try:
            # TODO: this method does not seem to be available
            sr.setRawDataIsSigned.argtypes = [c_handle, c_bool]
            sr.setRawDataIsSigned(self.handle, signed)
            get_error()
        except ():
            raise NotImplementedError("Signed not supported yet")

    @property
    def _np_data_type(self):
        if self.bytes_per_element == 4:
            return np.single
        elif self.bytes_per_element == 2:
            return np.uint16
        # currently not usable, since getRawDataFlag is not included to .dll
        # elif self.bytes_per_element == 2 and self.is_signed:
        #    return np.int16
        # elif self.bytes_per_element == 2 and not self.is_signed:
        #    return np.uint16
        elif self.bytes_per_element == 1:
            return np.uint8
        else:
            raise ArgumentError('Invalid dtype')

    def get_slice_at_index(self, slice_normal_direction: DataDirection, idx: int) -> Self:
        """Returns a slice of raw data perpendicular to the specified direction at the specified index.

        The raw data that will be sliced should be three-dimensional, that is, a sequence of B-scans. A slice
        is one of the B-scans, perpendicular to the third direction (usually the Y-axis). Notice that raw data
        refers to the spectra as acquired, without processing of any kind.

        Args:
            :slice_normal_direction: The physical direction in which the existing data will be sliced. Currently only
                the ``DIR3`` (usually the Y-axis) is supported.
            :idx: The desired slice number in the direction of ``slice_normal_direction``.

        Returns:
            The raw data of the slice.
        """
        data_slice = RawData()
        sr.getRawDataSliceAtIndex.argtypes = [c_handle, c_handle, c_int, c_int]
        sr.getRawDataSliceAtIndex(self.handle, data_slice.handle, slice_normal_direction, idx)
        get_error()
        return data_slice

    @property
    def _resize_func(self):
        return sr.resizeRawData

    @property
    def _set_data_content_func(self):
        return sr.setRawDataContent

    @property
    def _copy_content_func(self):
        return sr.copyRawDataContent

    @property
    def _copy_func(self):
        return sr.copyRawData

    @property
    def _pointer_func(self):
        return sr.getRawDataPtr

    @property
    def _reserve_func(self):
        return sr.reserveRawData

    @property
    def _create_handle_func(self):
        return sr.createRawData

    @property
    def _del_func(self):
        return sr.clearRawData

    @property
    def _c_append_func(self):
        return sr.appendRawData
