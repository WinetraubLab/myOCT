from enum import IntEnum

from pyspectralradar.base.propertygetter import FloatPropertyGetter


class DataPropertyFloat(IntEnum):
    SPACING1 = 0
    """Spacing between two subsequent data elements in direction of the first axis in physical units (millimeter)."""

    SPACING2 = 1
    """Spacing between two subsequent data elements in direction of the second axis in physical units (millimeter)."""

    SPACING3 = 2
    """Spacing between two subsequent data elements in direction of the third axis in physical units (millimeter)."""

    RANGE1 = 3
    """Total range of the data in direction of the first axis in physical units (millimeter)."""

    RANGE2 = 4
    """Total range of the data in direction of the second axis in physical units (millimeter)."""

    RANGE3 = 5
    """Total range of the data in direction of the third axis in physical units (millimeter)."""


class DataPropertyFloatGetter(FloatPropertyGetter):
    def get_spacing1(self) -> float:
        """Spacing between two subsequent data elements in direction of the first axis in physical units
        (millimeter)."""
        return self._get(DataPropertyFloat.SPACING1)

    def get_spacing2(self) -> float:
        """Spacing between two subsequent data elements in direction of the second axis in physical units
        (millimeter)."""
        return self._get(DataPropertyFloat.SPACING2)

    def get_spacing3(self) -> float:
        """Spacing between two subsequent data elements in direction of the third axis in physical units
        (millimeter)."""
        return self._get(DataPropertyFloat.SPACING3)

    def get_range1(self) -> float:
        """Total range of the data in direction of the first axis in physical units (millimeter)."""
        return self._get(DataPropertyFloat.RANGE1)

    def get_range2(self) -> float:
        """Total range of the data in direction of the second axis in physical units (millimeter)."""
        return self._get(DataPropertyFloat.RANGE2)

    def get_range3(self) -> float:
        """Total range of the data in direction of the third axis in physical units (millimeter)."""
        return self._get(DataPropertyFloat.RANGE3)
