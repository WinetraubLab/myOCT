from ctypes import c_bool, c_int, c_int64

from pyspectralradar.base import Submodule
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import TriggerIoMode


class DeviceTriggerIoMode(Submodule):
    def get(self) -> TriggerIoMode:
        """Returns the trigger IO mode used for acquisition.

        Returns:
            Current trigger mode.
        """
        sr.getTriggerIOMode.restype = c_int
        sr.getTriggerIOMode.argtypes = [c_handle]
        res = sr.getTriggerIOMode(self.handle)
        get_error()
        return TriggerIoMode(res)

    def set(self, mode: TriggerIoMode):
        """Sets the trigger mode for the trigger IO channel of the OCT device.

        :Warning: Not all systems support trigger IO. To check if the system supports trigger IO, please use
            :func:`~is_available`.

        Args:
            :mode: Trigger mode to use
        """
        sr.setTriggerIOMode.argtypes = [c_handle, c_int]
        sr.setTriggerIOMode(self.handle, mode)
        get_error()

    def is_available(self, mode: TriggerIoMode) -> bool:
        """Returns whether the specified trigger IO mode is possible or not for the used device.

        Returns:
            ``True`` if the specified trigger IO mode is available, ``False`` else
        """
        sr.isTriggerIOModeAvailable.restype = c_bool
        sr.isTriggerIOModeAvailable.argtypes = [c_handle, c_int]
        res = sr.isTriggerIOModeAvailable(self.handle, mode)
        get_error()
        return res

    def set_config(self, offset: int, divider: int):
        """Configures the parameters for trigger mode for the trigger IO channel of the OCT device.

        If the trigger IO channel is set to output, it will start generating a pulses after n= ``offset`` A-Scans. It
        will then generate a pulse every after d= ``divider`` A-Scans. If the trigger IO channel is set to input,
        Offset is ignored. Whenever a trigger pulse is received on the trigger IO channel, the system will perform
        d= ``divider`` A-Scans and wait for the next trigger.

        Args:
            :offset: Number of A-Scans to wait before first trigger
            :divider: Number of A-Scans to wait before each subsequent trigger IO pulse
        """
        sr.setTriggerIOConfiguration.argtypes = [c_handle, c_int64, c_int64]
        sr.setTriggerIOConfiguration(self.handle, offset, divider)
        get_error()
