from __future__ import annotations

from ctypes import POINTER, c_double, c_float, c_int
from typing import Optional, Tuple

import numpy as np

from pyspectralradar.data.analysis import DataAnalysis
from pyspectralradar.data.base import AbstractProcessedData
from pyspectralradar.data.filter import Filter
from pyspectralradar.data.utility import RealDataFileIo
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import AnalysisTypes, DataDirection


class RealData(AbstractProcessedData, RealDataFileIo):

    def __init__(self, handle: c_handle = None):
        super().__init__(handle)
        self.filter = Filter(self.handle, type(self))
        self.analysis = DataAnalysis(self.handle, type(self))

    @classmethod
    def from_scan_points(cls, x_pos_mm: np.ndarray, y_pos_mm: np.ndarray, scan_indices: np.ndarray) -> RealData:
        """Creates a :class:`~pyspectralradar.data.realdata.RealData` from the specified scan points and
        corresponding indices.

        Args:
            :x_pos_mm: Array of X-coordinates of the scan pattern
            :y_pos_mm: Array of Y-coordinates of the scan pattern, must be of same length as ``x_pos_mm``
            :scan_indices: The array specifies the assignment of each point to its B-scan, must be of same length as
                ``x_pos_mm`` and ``y_pos_mm``. The entries need to go from 0 to number of B-scans - 1) The number of
                B-scans is defined with the entries of ``scan_indices``. To save scan points for a 2D-pattern set all
                entries to zero.

        Returns:
            A :class:`~pyspectralradar.data.realdata.RealData` object containing the scan points and indices.
        """
        assert x_pos_mm.size == y_pos_mm.size == scan_indices.size
        number_of_scan_points = scan_indices.size

        x_pos_mm_ptr = x_pos_mm.ctypes.data_as(POINTER(c_double))
        y_pos_mm_ptr = y_pos_mm.ctypes.data_as(POINTER(c_double))
        scan_indices_ptr = scan_indices.ctypes.data_as(POINTER(c_int))

        sr.createDataHandleFromScanPoints.argtypes = [POINTER(c_double),
                                                      POINTER(c_double),
                                                      POINTER(c_int),
                                                      c_int]
        sr.createDataHandleFromScanPoints.restype = c_handle
        handle = c_handle(
            sr.createDataHandleFromScanPoints(x_pos_mm_ptr, y_pos_mm_ptr, scan_indices_ptr, number_of_scan_points))
        get_error()
        return cls(handle)

    def compute_projection(self, direction: DataDirection, selection: AnalysisTypes) -> RealData:
        """Returns a single slice of data, in which each pixel value is the feature extracted through an analysis
        along the specified direction.

        Args:
            :direction: The physical direction along which the provided data will be analyzed.
            :selection: The desired feature that should be extracted from the data along the specified direction.

        Returns:
            A :class:`~pyspectralradar.data.realdata.RealData` object containing, where the data of the slice will be
            hold. Geometrically, this slice is situated perpendicular to the specified #Direction.
        """
        assert isinstance(direction, DataDirection)
        assert isinstance(selection, AnalysisTypes)
        res = RealData()
        sr.computeDataProjection.argtypes = [c_handle, c_handle, c_int, c_int]
        sr.computeDataProjection(self.handle, res.handle, direction, selection)
        get_error()
        return res

    def transpose(self, inplace=False) -> Optional[RealData]:
        """Transposes the given data and returns the result.

        First and second axes will be swapped.

        Args:
            :inplace: Identifier to select if data shall be transposed in place or create a transposed copy of the
                current object.

        Returns:
            If ``inplace`` is ``True``, these data will be a copy of the input data, except that the first and the
            second axes will be swapped (usually Z- and X-axes).
        """
        if inplace:
            sr.transposeDataInplace.argtypes = [c_handle]
            sr.transposeDataInplace(self.handle)
            get_error()
            return None
        else:
            data_out = RealData()
            sr.transposeData.argtypes = [c_handle, c_handle]
            sr.transposeData(self.handle, data_out.handle)
            get_error()
            return data_out

    def transpose_and_scale(self, lower_bound: float, upper_bound: float) -> RealData:
        """Returns the transposed and scaled data.

        First and second axes will be swapped, and the range of the entries will be scaled in such a way,
        that the range [``lower_bound``, ``upper_bound``] will be mapped onto the range [0, 1].

        Args:
            :lower_bound: The lower bound of the data that will be mapped to 0
            :upper_bound: The upper bound of the data that will be mapped to 1

        Returns:
            The transposed and scaled data as :class:`~pyspectralradar.data.realdata.RealData`. These data will be a
            scaled and transposed copy of the input data, that is, the first and the second axes will be swapped (
            usually Z- and X-axes).

        """
        data_out = RealData()
        sr.transposeAndScaleData.argtypes = [c_handle, c_handle, c_float, c_float]
        sr.transposeAndScaleData(self.handle, data_out.handle, lower_bound, upper_bound)
        get_error()
        return data_out

    def normalize(self, lower_bound: float, upper_bound: float):
        """Scales the given data in such a way, that the range [``lower_bound``, ``upper_bound``] is mapped onto the
        range [0,1].

        Args:
            :lower_bound: The lower bound of the data that will be mapped to 0
            :upper_bound: The upper bound of the data that will be mapped to 1
        """
        sr.normalizeData.argtypes = [c_handle, c_float, c_float]
        sr.normalizeData(self.handle, lower_bound, upper_bound)
        get_error()

    def cross_correlated_projection(self) -> RealData:
        """Returns an average of all B-Scans in the current data
        .
        Right before averaging, the datasets are cross correlated to eliminate registration errors.

        Returns:
             Data containing an average of all B-Scans.
        """
        data_out = RealData()
        sr.crossCorrelatedProjection.argtype = [c_handle, c_handle]
        sr.crossCorrelatedProjection(self.handle, data_out.handle)
        get_error()
        return data_out

    def extract_line(self, p1_1_mm: float, p1_2_mm: float, p2_1_mm: float, p2_2_mm: float) -> RealData:
        """Extract 1D data from 2D along a specified line

        :Warning: Experimental: This function may change in its interface and behaviour, or even disappear in future
            versions.

        Args:
            :p1_1_mm: Start of line on axis 1 in mm
            :p1_2_mm: Start of line on axis 2 in mm
            :p2_1_mm: End of line on axis 1 in mm
            :p2_2_mm: End of line on axis 2 in mm

        Returns:
            The 1D specified line data.
        """
        res = RealData()
        sr.extractLine.argtypes = [c_handle, c_handle, c_double, c_double, c_double, c_double]
        sr.extractLine(self.handle, res.handle, p1_1_mm, p1_2_mm, p2_1_mm, p2_2_mm)
        get_error()
        return res

    def extract_local_maximum(self, number_of_maxima: int, min_dist=0.0) -> Tuple[int, np.ndarray, np.ndarray]:
        """Extract multiple local maxima from 1D data while maintaining a minimum distance between peaks

        :Warning: Experimental: This function may change in its interface and behaviour, or even disappear in future
            versions.

        Args:
            :number_of_maxima: Maximum number of maxima to find
            :min_dist: Minimum distance between each maximum

        Returns:
            A tuple containing the actual number of maxima found, an array containing the locations of the maxima and
            an array containing the values of the maxima.
        """
        data_pos_mm = np.empty(number_of_maxima)
        data_height = np.empty(number_of_maxima)
        sr.extractLocalMaximaEx.argtypes = [c_handle, c_int, c_double,
                                            np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                            np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS')]
        sr.extractLocalMaximaEx.restype = c_int
        res = sr.extractLocalMaximaEx(self.handle, number_of_maxima, min_dist, data_pos_mm, data_height)
        get_error()
        return res, data_pos_mm, data_height

    def extract_ascan(self, x0: int, y0: int) -> RealData:
        """Extracts an Ascan at a given x and y coordinates and stores it in a different data handle.

        :Warning: Experimental: This function may change in its interface and behaviour, or even disappear in future
            versions.

        Args:
            :x0: x-index of the A-scan to extract
            :y0: y-index of the A-scan to extract

        Returns:
            An A-scan that was extracted at the location (``x0``, ``y0``)
        """
        res = RealData()
        sr.extractAScan.argtypes = [c_handle, c_handle, c_int, c_int]
        sr.extractAScan(self.handle, res.handle, x0, y0)
        get_error()
        return res

    @property
    def _set_data_range_func(self):
        return sr.setDataRange

    @property
    def _int_get(self):
        return sr.getDataPropertyInt

    @property
    def _float_get(self):
        return sr.getDataPropertyFloat

    @property
    def _c_crop_func(self):
        return sr.cropData

    @property
    def _orientation_get(self):
        return sr.getDataOrientation

    @property
    def _orientation_set(self):
        return sr.setDataOrientation

    @property
    def _get_slice_at_pos_func(self):
        return sr.getDataSliceAtPos

    @property
    def _get_slice_at_index_func(self):
        return sr.getDataSliceAtIndex

    @property
    def _separate_func(self):
        return sr.separateData

    @property
    def _flip_func(self):
        return sr.flipData

    @property
    def _copy_func(self):
        return sr.copyData

    @property
    def _resize_func(self):
        return sr.resizeData

    @property
    def _c_append_func(self):
        return sr.appendData

    @property
    def _set_data_content_func(self):
        return sr.setDataContent

    @property
    def _copy_content_func(self):
        return sr.copyDataContent

    @property
    def _pointer_func(self):
        return sr.getDataPtr

    @property
    def _reserve_func(self):
        return sr.reserveData

    @property
    def _np_data_type(self):
        return np.single

    @property
    def _create_handle_func(self):
        return sr.createData

    @property
    def _del_func(self):
        return sr.clearData
