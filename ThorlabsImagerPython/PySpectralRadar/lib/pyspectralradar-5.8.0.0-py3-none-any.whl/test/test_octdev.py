import unittest

from pyspectralradar import ColoredData, OCTSystem, RawData, RealData, LogLevel, set_log_level
from pyspectralradar.spectralradar import SpectralRadarException
from pyspectralradar.types import AcqType, ApoWindowType, CalibrationType, DevState, FFTType, PolarizationRetarder, \
    RefStageMovementDirection, RefStageSpeed, RefStageWaitForMovement, TriggerIoMode, TriggerMode, WaitForCompletion

HARDWARE_CONNECTED = False


class OctTestCase(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def setUp(self):
        self.sys = OCTSystem()
        self._oct_dev = self.sys.dev

    def tearDown(self):
        del self._oct_dev
        del self.sys


class TestOctDev(OctTestCase):

    def test_static_methods(self):
        self.assertEqual(self._oct_dev.get_device_error(), "")
        self.assertEqual(self._oct_dev.available(), True)
        self.assertIsInstance(self._oct_dev.get_device_state(), DevState)
        self._oct_dev.set_required_SLD_on_time(1)

    def test_get_calibration(self):
        (offset, apo, chirp,
         spectrum_size, bytes_per_raw_pixel, signed,
         scaling_factor, min_electrons, fft_type,
         fft_oversampling, apo_window) = self._oct_dev.get_calibration()

        self.assertIsInstance(offset, RealData)
        self.assertEqual(offset.shape, (2048, 1, 1))
        self.assertIsInstance(apo, RealData)
        self.assertIsInstance(chirp, RealData)
        self.assertEqual(chirp.shape, (2048, 1, 1))

        self.assertEqual(spectrum_size, 2048)
        self.assertEqual(bytes_per_raw_pixel, 2)
        self.assertFalse(signed)

        self.assertIsInstance(scaling_factor, float)
        self.assertIsInstance(min_electrons, float)
        self.assertIsInstance(fft_type, FFTType)
        self.assertEqual(fft_type, FFTType.STANDARD_FFT)

        self.assertIsInstance(fft_oversampling, float)
        self.assertIsInstance(apo_window, ApoWindowType)
        self.assertEqual(apo_window, ApoWindowType.HANN)


class TestDevicePropertyString(OctTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self._oct_dev.properties

    def test_property_string(self):
        if self.dut.get_type() == "DUM100":
            self.assertEqual(self.dut.get_type(), "DUM100")
            self.assertEqual(self.dut.get_hardware_config(), 'Dummy_V1')
        elif self.dut.get_type() == 'Dummy (Polarization Sensitive)':
            self.assertEqual(self.dut.get_type(), 'Dummy (Polarization Sensitive)')
            self.assertEqual(self.dut.get_hardware_config(), 'Dual_Dummy_V1')
        self.assertEqual(self.dut.get_series(), "Dummy")
        self.assertEqual(self.dut.get_serial_number(), '0123456789')


class TestDevicePropertyInt(OctTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self._oct_dev.properties

    def test_property_int(self):
        self.assertEqual(self.dut.get_spectrum_elements(), 2048)
        self.assertEqual(self.dut.get_bytes_per_element(), 2)
        self.assertEqual(self.dut.get_max_live_vol_scans(), 256)
        self.assertEqual(self.dut.get_rev_number(), 1)
        self.assertEqual(self.dut.get_num_analog_input_channels(), 4)
        self.assertEqual(self.dut.get_min_spectra_per_buffer(), 10)


class TestDevicePropertyFloat(OctTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self._oct_dev.properties

    def test_property_float(self):
        self.assertAlmostEqual(self.dut.get_full_well_capacity(), 200000.0)
        self.assertAlmostEqual(self.dut.get_z_spacing(), 0.005)
        self.assertAlmostEqual(self.dut.get_z_range(), 5.12)
        self.assertAlmostEqual(self.dut.get_signal_min_db(), -20.0)
        self.assertAlmostEqual(self.dut.get_signal_low_db(), 10.0)
        self.assertAlmostEqual(self.dut.get_signal_high_db(), 70.0)
        self.assertAlmostEqual(self.dut.get_signal_max_db(), 150.0)
        self.assertAlmostEqual(self.dut.get_bin_electron_scaling(), 3.0517578125)
        # self.assertAlmostEqual(self.dev.get_temperature(), VAL)  # dummy has not temp sensor
        # self.assertAlmostEqual(self.dev.get_sld_on_time_sec(), VAL)  # no RTC available
        self.assertAlmostEqual(self.dut.get_center_wavelength_nm(), 930.0)
        self.assertAlmostEqual(self.dut.get_spectral_width_nm(), 86.48999999999998)
        self.assertAlmostEqual(self.dut.get_max_trigger_freq_hz(), 0.0)
        self.assertAlmostEqual(self.dut.get_line_rate_hz(), 10000.0)


class TestDevicePropertyFlag(OctTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self._oct_dev.properties

    def test_property_flag(self):
        self.assertEqual(self.dut.get_on(), True)
        self.assertEqual(self.dut.get_sld_avail(), True)
        self.assertEqual(self.dut.get_sld_status(), True)
        # self.assertEqual(self.dev.get_laser_diode_status(), VAL)  # Flag 4 is not supported
        # self.assertEqual(self.dev.get_camera_show_scan_pattern(), VAL)  # Flag 5 is not supported
        self.assertEqual(self.dut.get_probe_controller_avail(), True)
        self.assertEqual(self.dut.get_data_signed(), False)
        self.assertEqual(self.dut.get_swept_source(), False)
        self.assertEqual(self.dut.get_analog_in_avail(), True)
        self.assertEqual(self.dut.get_has_master_board(), True)
        self.assertEqual(self.dut.get_has_control_board(), True)
        self.assertEqual(self.dut.get_sld_status_quick(), True)


class TestDeviceStaticProperties(OctTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self._oct_dev.properties

    def test_static_properties(self):
        if self._oct_dev.properties.get_type() == "DUM100":
            self.assertEqual(self.dut.get_power_control_avail(), True)
            self.dut.set_power_on(True)
        elif self._oct_dev.properties.get_type() == 'Dummy (Polarization Sensitive)':
            self.assertEqual(self.dut.get_power_control_avail(), False)


class TestAcquisition(OctTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self._oct_dev.acquisition

    def test_acquisition(self):
        probe = self.sys.probe_factory.create_default()
        pattern = probe.scan_pattern.create_no_scan_pattern(128, 1)
        self.dut.start(pattern, AcqType.ASYNC_FINITE)
        raw = self.dut.get_raw_data()
        self.dut.stop()

        self.assertIsInstance(raw, RawData)
        self.assertTrue(raw.shape == (2048, 128, 1))

    @unittest.skipUnless(HARDWARE_CONNECTED, "Requires hardware")
    def test_analog_inputs(self):
        analog_input = self.dut.get_analog_input_data()
        self.assertIsInstance(analog_input, RealData)

    @unittest.skipUnless(HARDWARE_CONNECTED, "Requires hardware")
    def test_analog_inputs_ex(self):
        analog_input, apo_data = self.dut.get_analog_input_data_ex()
        self.assertIsInstance(analog_input, RealData)
        self.assertIsInstance(apo_data, RealData)

    def test_measure_spectra(self):
        raw = self.dut.measure_spectra(128)

        self.assertIsInstance(raw, RawData)
        self.assertTrue(raw.shape == (2048, 128, 1))

    def test_measure_spectra_continuous(self):
        raw = self.dut.measure_spectra_continuous(128)

        self.assertIsInstance(raw, RawData)
        self.assertTrue(raw.shape == (2048, 128, 1))

    def test_measure_calibration(self):
        proc = self.sys.processing_factory.from_device()
        self.dut.measure_calibration(proc, CalibrationType.OFFSET_ERRORS)
        self.dut.measure_calibration(proc, CalibrationType.APO_SPECTRUM)
        self.dut.measure_calibration(proc, CalibrationType.APO_VECTOR)
        # self.assertRaises(SpectralRadarException, lambda: self.dut.measure_calibration(proc,
        # CalibrationType.DISPERSION))
        self.dut.measure_calibration(proc, CalibrationType.CHIRP)
        self.assertRaises(SpectralRadarException,
                          lambda: self.dut.measure_calibration(proc, CalibrationType.EXT_ADJUST))
        self.dut.measure_calibration(proc, CalibrationType.FIXED_PATTERN)

    def test_measure_apo_spectra(self):
        proc = self.sys.processing_factory.from_device()
        probe = self.sys.probe_factory.create_default()
        self.dut.measure_apo_spectra(probe, proc)


class TestAmplification(OctTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self._oct_dev.amplification

    def test_availability(self):
        self.assertFalse(self.dut.is_available())

    def test_get_max(self):
        self.assertRaises(SpectralRadarException, lambda: self.dut.get_max())

    def test_getset(self):
        self.assertRaises(SpectralRadarException, lambda: self.dut.set(2))
        self.assertRaises(SpectralRadarException, lambda: self.dut.get())


class TestAnalogInputChannel(OctTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self._oct_dev.analog_input_channel

    def test_analog_input_channel(self):
        self.dut.set_enabled(0, True)
        self.assertTrue(self.dut.get_enabled(0))
        self.assertEqual(self.dut.get_name(0), 'Channel 1')


class TestCameraProperties(OctTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self._oct_dev.camera

    def test_camera_props(self):
        self.assertFalse(self.dut.is_available())
        probe = self.sys.probe_factory.create_default()  # required for camera availability
        print(probe.display_name)
        self.assertTrue(self.dut.is_available())
        self.assertEqual(self.dut.get_bit_depth(), 16)


class TestCamera(OctTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self._oct_dev.camera

    def tearDown(self):
        del self.dut
        super().tearDown()

    def test_max_size(self):
        self.assertEqual(self.dut.get_max_image_size(), (1024, 768))

    def test_availability(self):
        self.assertFalse(self.dut.is_available())
        probe = self.sys.probe_factory.create_default()  # required for camera availability
        print(probe.display_name)
        self.assertTrue(self.dut.is_available())

    def test_get_image_in_buffer(self):
        buffer = ColoredData()
        probe = self.sys.probe_factory.create_default()  # required for camera availability
        print(probe.display_name)
        self.dut.get_image(buffer)
        self.assertEqual(buffer.shape, (1024, 768, 1))

    def test_get_image(self):
        probe = self.sys.probe_factory.create_default()  # required for camera availability
        print(probe.display_name)
        img = self.dut.get_image()
        self.assertEqual(img.shape, (1024, 768, 1))

    @unittest.skip  # TODO: not available in current release
    def test_show_scan_pattern(self):
        self.assertTrue(self.dut.show_scan_pattern())

    def test_bit_depth(self):
        self.assertEqual(self.dut.get_bit_depth(), 16)


class TestDevicePresets(OctTestCase):
    def setUp(self):
        super().setUp()
        self.presets = self._oct_dev.presets

    def test_get_categories(self):
        cats = self.presets.get_available_categories()
        self.assertEqual(list(cats.keys())[0], 'Speed/Sensitivity')
        self.assertEqual(cats['Speed/Sensitivity'], 0)

    def test_preset_dict(self):
        prs = self.presets.get_presets_in_category(0)
        self.assertEqual(prs, {'Default (10 kHz)': 0, 'Low Speed (1 kHz)': 1,
                               'Medium Speed (10 kHz)': 2, 'High Speed (100 kHz)': 3})

    def test_active_preset(self):
        assumed_initial_preset = 0
        temp_preset = 3
        self.assertEqual(self.presets.get_active_preset(0), assumed_initial_preset)
        self.presets.set_active_preset(0, temp_preset)
        self.assertEqual(self.presets.get_active_preset(0), temp_preset)
        self.presets.set_active_preset(0, assumed_initial_preset)
        self.assertEqual(self.presets.get_active_preset(0), assumed_initial_preset)


class TestDeviceTrigger(OctTestCase):
    def setUp(self):
        super().setUp()
        self.trigger = self._oct_dev.trigger_mode

    def test_get(self):
        mode = self.trigger.get()
        self.assertEqual(mode, TriggerMode.FREE_RUNNING)

    def test_set(self):
        self.trigger.set(TriggerMode.FREE_RUNNING)
        self.assertRaises(SpectralRadarException,
                          lambda: self.trigger.set(TriggerMode.EXTERNAL_ASCAN))
        self.assertRaises(SpectralRadarException,
                          lambda: self.trigger.set(TriggerMode.EXTERNAL_START))

    def test_is_available(self):
        self.assertTrue(self.trigger.is_available(TriggerMode.FREE_RUNNING))
        self.assertFalse(self.trigger.is_available(TriggerMode.EXTERNAL_ASCAN))
        self.assertFalse(self.trigger.is_available(TriggerMode.EXTERNAL_START))

    def test_timeout(self):
        assumed_dummy_default = 10
        self.assertEqual(self.trigger.get_timeout(), assumed_dummy_default)
        self.assertRaises(SpectralRadarException,
                          lambda: self.trigger.set_timeout(assumed_dummy_default))


class TestDeviceTriggerIo(OctTestCase):
    def setUp(self):
        super().setUp()
        self.trigger_io = self._oct_dev.trigger_io_mode

    def test_get(self):
        mode = self.trigger_io.get()
        self.assertEqual(mode, TriggerIoMode.DISABLED)

    def test_set(self):
        self.trigger_io.set(TriggerIoMode.DISABLED)
        self.assertRaises(SpectralRadarException,
                          lambda: self.trigger_io.set(TriggerIoMode.INPUT))
        self.assertRaises(SpectralRadarException,
                          lambda: self.trigger_io.set(TriggerIoMode.OUTPUT))

    def test_is_available(self):
        self.assertTrue(self.trigger_io.is_available(TriggerIoMode.DISABLED))
        self.assertFalse(self.trigger_io.is_available(TriggerIoMode.INPUT))
        self.assertFalse(self.trigger_io.is_available(TriggerIoMode.OUTPUT))

    def test_config(self):
        self.trigger_io.set_config(0, 1)


class TestInternalDevice(OctTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self._oct_dev.internal_devices

    def test_get_names_and_units(self):
        names, units = self.dut.get_names_and_units()
        self.assertEqual(names, {'SLD 1 Current': 0, 'SLD 1 Peltier': 1, 'SLD 1 Power': 2,
                                 'SLD 2 Current': 3, 'SLD 2 Peltier': 4, 'SLD 2 Power': 5})
        self.assertEqual(units, {0: 'A', 1: 'A', 2: 'A', 3: 'A', 4: 'A', 5: 'A'})

    def test_set_get_value(self):
        test_val = 1.2
        self.dut.set_value_by_index(0, test_val)  # Does nothing for Dummy plugin
        self.assertAlmostEqual(self.dut.get_value_by_index(0), 0.0)

    def test_get_value_by_name(self):
        val = self.dut.get_value_by_index(0)
        self.assertEqual(val, self.dut.get_value_by_name("SLD 1 Current"))
        self.assertEqual(self.dut.get_value_by_name("FOO"), 0.0)


class TestLightSource(OctTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self._oct_dev.light_source

    def test_setget_timeout(self):
        print(self.dut.get_timeout())
        self.dut.set_timeout(3.23)
        self.assertAlmostEqual(self.dut.get_timeout(), 3.0)  # handled internally as long-long
        self.dut.set_timeout(144.6)
        self.assertAlmostEqual(self.dut.get_timeout(), 144.0)


class TestOutputDevice(OctTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self._oct_dev.output_device

    def test_get_names_and_units(self):
        names, units = self.dut.get_names_and_units()
        self.assertEqual(names, {'Laser Diode': 0, 'Ring Light': 1})
        self.assertEqual(units, {0: 'A', 1: 'A'})

    def test_val_exist(self):
        self.assertFalse(self.dut.does_value_exist("FooBar"))
        self.assertFalse(self.dut.does_value_exist(""))
        self.assertTrue(self.dut.does_value_exist("Laser Diode"))
        self.assertTrue(self.dut.does_value_exist("Ring Light"))

    def test_get_value_range_by_name(self):
        assumed_dummy_default = (0.0, 1.0)
        self.assertEqual(self.dut.get_value_range_by_name("Laser Diode"), assumed_dummy_default)

    def test_get_value_range_by_idx(self):
        assumed_dummy_default = (0.0, 1.0)
        self.assertEqual(self.dut.get_value_range_by_index(0), assumed_dummy_default)

    def test_set_value(self):
        self.dut.set_value_by_name("Laser Diode", 3)  # setter does nothing for dummy plugin
        self.dut.set_value_by_index(0, 0.2)
        self.assertRaises(SpectralRadarException, lambda: self.dut.set_value_by_name("FOO", 12))


class TestPolarizationAdjustment(OctTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self._oct_dev.polarization_adjustment

    def test_availability(self):
        self.assertFalse(self.dut.is_available())

    def test_retardation(self):
        self.assertRaises(SpectralRadarException,
                          lambda: self.dut.set_retardation(PolarizationRetarder.HALF_WAVE, 25,
                                                           WaitForCompletion.WAIT))
        self.assertRaises(SpectralRadarException,
                          lambda: self.dut.set_retardation(PolarizationRetarder.QUARTER_WAVE, 25,
                                                           WaitForCompletion.WAIT))
        self.assertRaises(SpectralRadarException,
                          lambda: self.dut.get_retardation(PolarizationRetarder.HALF_WAVE))
        self.assertRaises(SpectralRadarException,
                          lambda: self.dut.get_retardation(PolarizationRetarder.QUARTER_WAVE))


class TestRefIntensity(OctTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self._oct_dev.ref_intensity

    def test_ctrl_value(self):
        self.assertRaises(SpectralRadarException, lambda: self.dut.get_ctrl_value())
        self.assertRaises(SpectralRadarException, lambda: self.dut.set_ctrl_value(50.0, WaitForCompletion.WAIT))

    def test_get(self):
        proc = self.sys.processing_factory.from_device()
        print(self.dut.get_relative(proc))
        self.assertFalse(self.dut.is_available())
        print(self.dut.get_statistics(proc))


class TestRefStage(OctTestCase):
    def setUp(self):
        super().setUp()
        self.probe = self.sys.probe_factory.create_default()
        self.dut = self._oct_dev.ref_stage

    def test_availability(self):
        self.assertFalse(self.dut.is_available())

    def test_getter(self):
        self.assertRaises(SpectralRadarException, lambda: self.dut.get_status())

        self.assertRaises(SpectralRadarException, lambda: self.dut.get_length(self.probe))

        self.assertRaises(SpectralRadarException, lambda: self.dut.get_position(self.probe))

    def test_motion(self):
        self.assertRaises(SpectralRadarException, lambda: self.dut.home(RefStageWaitForMovement.WAIT))

        self.assertRaises(SpectralRadarException, lambda: self.dut.get_min_position_mm(self.probe))
        self.assertRaises(SpectralRadarException, lambda: self.dut.get_max_position_mm(self.probe))

        self.assertRaises(SpectralRadarException, lambda: self.dut.move_to_position(self.probe, 2.0, RefStageSpeed.FAST,
                                                                                    RefStageWaitForMovement.WAIT))

        self.assertRaises(SpectralRadarException,
                          lambda: self.dut.move_mm(self.probe, 2.0, RefStageMovementDirection.LONGER,
                                                   RefStageSpeed.FAST,
                                                   RefStageWaitForMovement.WAIT))

        self.assertRaises(SpectralRadarException,
                          lambda: self.dut.start(RefStageMovementDirection.LONGER, RefStageSpeed.FAST))
        self.assertRaises(SpectralRadarException, lambda: self.dut.stop())


if __name__ == '__main__':
    unittest.main()
