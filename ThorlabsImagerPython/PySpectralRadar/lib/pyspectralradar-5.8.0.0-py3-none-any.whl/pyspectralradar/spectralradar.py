from ctypes import *
from os import environ, path

sr_path = environ.get("THORLABS_OCT_SR_PATH")
dll_path = path.join(sr_path, "DLL", "SpectralRadar.dll")

sr = CDLL(dll_path, winmode=0)

c_handle = c_void_p


class SpectralRadarException(Exception):
    """Custom exception class"""

    def __init__(self, value):
        self.value = value

    def __str__(self):
        return repr(self.value)


def get_error():
    """Error handler"""
    sr.getError.restype = c_int
    sr.getError.argtypes = [c_char_p, c_int]
    s = create_string_buffer(1024)
    if sr.getError(c_char_p(addressof(s)), c_int(len(s))) != 0:
        raise SpectralRadarException(s.value.decode("utf8"))
