from enum import IntEnum

from pyspectralradar.base.propertygetter import FlagPropertyGetter
from pyspectralradar.base.propertysetter import FlagPropertySetter
from pyspectralradar.spectralradar import sr


class PropertyFlag(IntEnum):
    """Enum Flags that set the behaviour of the processing algorithms."""

    USE_OFFSET = 0
    """Flag identifying whether to apply offset error removal. This flag is activated by default."""

    REMOVE_DC = 1
    """Flag sets whether the DC spectrum as measured is to be removed from the spectral data. This flag is activated 
    by default."""

    REMOVE_DC_ADV = 2
    """Flag sets whether the DC spectrum to be removed is rescaled by the respective spectrum intensity it is applied 
    eto. This flag is activated by default."""

    APODIZATION = 3
    """Flag identifying whether to apply apodization. This flag is activated by default."""

    SCAN_FOR_APO = 4
    """Flag to determine whether the acquired data is to be averaged in order to compute an apodization spectrum. 
    This flag is deactivated by default."""

    UNDERSAMPLING_FILTER = 5
    """Flag to activate or deactivate a filter removing undersampled signals from the A-scan. This flag is 
    deactivated by default."""

    DISPERSION = 6
    """Flag activating or deactivating dispersion compensation. This flag is deactivated by default."""

    DECHIRP = 7
    """Flag identifying whether to apply dechirp. This flag is activated by default."""

    EXT_ADJUST = 8
    """Flag identifying whether to use extended adjust. This flag is deactivated by default."""

    FULL_RANGE = 9
    """Flag identifying whether to use full range output. This flag is deactivated by default."""

    FILTER_DC = 10
    """Experimental: Flag for an experimental lateral DC filtering algorithm. This flag is deactivated by default"""

    AUTOCORR_CORR = 11
    """ Flag activating or deactivating auto-correlation compensation. This flag is deactivated by default."""

    DEFR = 12
    """Experimental: Toggles dispersion encoded full range processing mode, eliminating folding of the signal at the 
    top. This flag is deactivated by default."""

    ONLY_WIN = 13
    """Flag deactivating deconvolution in apodization processing, using windowing only. This flag is deactivated by 
    default."""

    FIXED_PATTERN = 14
    """Flag for removal of fixed pattern noise, used for swept source OCT systems. This flag is deactivated by 
    default."""

    SATURATION = 15
    """Flag to calculate sensor saturation, used in swept source OCT systems. This flag is deactivated by default (
    Spectral Domain OCT instruments). :func:`Processing.get_relative_saturation`."""

    CALCULATE_REL_INTERFERENCE_AMP = 16
    """Flag to calculate sensor interference amplitude, relative to the full well capacity, used in swept source OCT 
    systems. This flag is deactivated by default (Spectral Domain OCT instruments). 
    :func:`Processing.get_relative_reference_intensity`."""

    INVERT_PHASE = 17
    """ Flag to invert phase, depending on the direction the spectrum was acquired with."""


class ProcessingPropertyFlag(FlagPropertyGetter, FlagPropertySetter):
    def __init__(self, handle):
        FlagPropertyGetter.__init__(self, handle, sr.getProcessingFlag)
        FlagPropertySetter.__init__(self, handle, sr.setProcessingFlag)

    def get_use_offset(self) -> bool:
        """Flag identifying whether to apply offset error removal. This flag is activated by default."""
        return self._get(PropertyFlag.USE_OFFSET)

    def set_use_offset(self, value: bool):
        """Flag identifying whether to apply offset error removal. This flag is activated by default."""
        self._set(PropertyFlag.USE_OFFSET, value)

    def get_remove_dc(self) -> bool:
        """Flag sets whether the DC spectrum as measured is to be removed from the spectral data. This flag is
        activated by default."""
        return self._get(PropertyFlag.REMOVE_DC)

    def set_remove_dc(self, value: bool):
        """Flag sets whether the DC spectrum as measured is to be removed from the spectral data. This flag is
        activated by default."""
        self._set(PropertyFlag.REMOVE_DC, value)

    def get_remove_dc_adv(self) -> bool:
        """Flag sets whether the DC spectrum to be removed is rescaled by the respective spectrum intensity it is
        applied to. This flag is activated by default."""
        return self._get(PropertyFlag.REMOVE_DC_ADV)

    def set_remove_dc_adv(self, value: bool):
        """Flag sets whether the DC spectrum to be removed is rescaled by the respective spectrum intensity it is
        applied to. This flag is activated by default."""
        self._set(PropertyFlag.REMOVE_DC_ADV, value)

    def get_apodization(self) -> bool:
        """Flag identifying whether to apply apodization. This flag is activated by default."""
        return self._get(PropertyFlag.APODIZATION)

    def set_apodization(self, value: bool):
        """Flag identifying whether to apply apodization. This flag is activated by default."""
        self._set(PropertyFlag.APODIZATION, value)

    def get_scan_for_apo(self) -> bool:
        """Flag to determine whether the acquired data is to be averaged in order to compute an apodization spectrum.
        This flag is deactivated by default."""
        return self._get(PropertyFlag.SCAN_FOR_APO)

    def set_scan_for_apo(self, value: bool):
        """Flag to determine whether the acquired data is to be averaged in order to compute an apodization spectrum.
        This flag is deactivated by default."""
        self._set(PropertyFlag.SCAN_FOR_APO, value)

    def get_undersampling_filter(self) -> bool:
        """Flag to activate or deactivate a filter removing undersampled signals from the A-scan. This flag is
        deactivated by default."""
        return self._get(PropertyFlag.UNDERSAMPLING_FILTER)

    def set_undersampling_filter(self, value: bool):
        """Flag to activate or deactivate a filter removing undersampled signals from the A-scan. This flag is
        deactivated by default."""
        self._set(PropertyFlag.UNDERSAMPLING_FILTER, value)

    def get_dispersion(self) -> bool:
        """Flag activating or deactivating dispersion compensation. This flag is deactivated by default."""
        return self._get(PropertyFlag.DISPERSION)

    def set_dispersion(self, value: bool):
        """Flag activating or deactivating dispersion compensation. This flag is deactivated by default."""
        self._set(PropertyFlag.DISPERSION, value)

    def get_dechirp(self) -> bool:
        """Flag identifying whether to apply dechirp. This flag is activated by default."""
        return self._get(PropertyFlag.DECHIRP)

    def set_dechirp(self, value: bool):
        """Flag identifying whether to apply dechirp. This flag is activated by default."""
        self._set(PropertyFlag.DECHIRP, value)

    def get_ext_adjust(self) -> bool:
        """Flag identifying whether to use extended adjust. This flag is deactivated by default."""
        return self._get(PropertyFlag.EXT_ADJUST)

    def set_ext_adjust(self, value: bool):
        """Flag identifying whether to use extended adjust. This flag is deactivated by default."""
        self._set(PropertyFlag.EXT_ADJUST, value)

    def get_full_range(self) -> bool:
        """Flag identifying whether to use full range output. This flag is deactivated by default."""
        return self._get(PropertyFlag.FULL_RANGE)

    def set_full_range(self, value: bool):
        """Flag identifying whether to use full range output. This flag is deactivated by default."""
        self._set(PropertyFlag.FULL_RANGE, value)

    def get_filter_dc(self) -> bool:
        """Experimental: Flag for an experimental lateral DC filtering algorithm. This flag is deactivated by default"""
        return self._get(PropertyFlag.FILTER_DC)

    def set_filter_dc(self, value: bool):
        """Experimental: Flag for an experimental lateral DC filtering algorithm. This flag is deactivated by default"""
        self._set(PropertyFlag.FILTER_DC, value)

    def get_autocorr_corr(self) -> bool:
        """ Flag activating or deactivating autocorrelation compensation. This flag is deactivated by default."""
        return self._get(PropertyFlag.AUTOCORR_CORR)

    def set_autocorr_corr(self, value: bool):
        """ Flag activating or deactivating autocorrelation compensation. This flag is deactivated by default."""
        self._set(PropertyFlag.AUTOCORR_CORR, value)

    def get_defr(self) -> bool:
        """ Expertimental: Toggles dispersion encoded full range processing mode, eliminating folding of the signal
        at the top. This flag is deactivated by default."""
        return self._get(PropertyFlag.DEFR)

    def set_defr(self, value: bool):
        """ Expertimental: Toggles dispersion encoded full range processing mode, eliminating folding of the signal
        at the top. This flag is deactivated by default."""
        self._set(PropertyFlag.DEFR, value)

    def get_only_win(self) -> bool:
        """ Flag deactivating deconvolution in apodization processing, using windowing only. This flag is deactivated
        by default."""
        return self._get(PropertyFlag.ONLY_WIN)

    def set_only_win(self, value: bool):
        """ Flag deactivating deconvolution in apodization processing, using windowing only. This flag is deactivated
        by default."""
        self._set(PropertyFlag.ONLY_WIN, value)

    def get_fixed_pattern(self) -> bool:
        """ Flag for removal of fixed pattern noise, used for swept source OCT systems. This flag is deactivated by
        default."""
        return self._get(PropertyFlag.FIXED_PATTERN)

    def set_fixed_pattern(self, value: bool):
        """ Flag for removal of fixed pattern noise, used for swept source OCT systems. This flag is deactivated by
        default."""
        self._set(PropertyFlag.FIXED_PATTERN, value)

    def get_saturation(self) -> bool:
        """ Flag to calculate sensor saturation, used in swept source OCT systems. This flag is deactivated by
        default (Spectral Domain OCT instruments). :func:`Processing.get_relative_saturation`."""
        return self._get(PropertyFlag.SATURATION)

    def set_saturation(self, value: bool):
        """ Flag to calculate sensor saturation, used in swept source OCT systems. This flag is deactivated by
        default (Spectral Domain OCT instruments). :func:`Processing.get_relative_saturation`."""
        self._set(PropertyFlag.SATURATION, value)

    def get_calculate_rel_interference_amp(self) -> bool:
        """ Flag to calculate sensor interference amplitude, relative to the full well capacity, used in swept source
        OCT systems. This flag is deactivated by default (Spectral Domain OCT instruments).
        :func:`Processing.get_relative_reference_intensity`."""
        return self._get(PropertyFlag.CALCULATE_REL_INTERFERENCE_AMP)

    def set_calculate_rel_interference_amp(self, value: bool):
        """ Flag to calculate sensor interference amplitude, relative to the full well capacity, used in swept source
        OCT systems. This flag is deactivated by default (Spectral Domain OCT instruments).
        :func:`Processing.get_relative_reference_intensity`."""
        self._set(PropertyFlag.CALCULATE_REL_INTERFERENCE_AMP, value)

    def get_invert_phase(self) -> bool:
        """ Flag to invert phase, depending on the direction the spectrum was acquired with."""
        return self._get(PropertyFlag.INVERT_PHASE)

    def set_invert_phase(self, value: bool):
        """ Flag to invert phase, depending on the direction the spectrum was acquired with."""
        self._set(PropertyFlag.INVERT_PHASE, value)
