from __future__ import annotations

from enum import IntEnum


class PolarizationDOPUFilterType(IntEnum):
    """Values that determine the behaviour of temporal filter, if enabled."""

    Median = 0
    """Median"""

    AVERAGE = 1
    """Average"""

    GAUSSIAN = 2
    """Convolution with a Gaussian kernel"""

    GAUSSIAN_WITH_FFT = 3
    """FFT convolution with a Gaussian kernel (presumably more efficient for very large kernels)."""


class PolarizationOutput(IntEnum):
    """Enum Values used to select the polarization output"""

    INTENSITY = 0
    """It will hold the computed intensity data upon return."""

    STOKES_Q = 1
    """It will hold the computed Stokes Q data upon return.
       The range of Q is [-1,1]. It takes the value -1 when the polarization is 100% parallel (zero degrees),
       and the value 1 when the polarization is 100% perpendicular (ninety degrees)."""

    STOKES_U = 2
    """It will hold the computed Stokes U data upon return.
       The range of U is [-1,1]. It takes the value -1 when the polarization is 100% at -45 degrees,
       and the value 1 when the polarization is 100% at 45 degrees."""

    STOKES_V = 3
    """It will hold the computed Stokes V data upon return.
       The range of V is [-1,1]. It takes the value -1 when the reflected light is 100% left-hand circularly
       polarized, and the value 1 when the reflected light is 100% right-hand circularly polarized."""

    DOPU = 4
    """It will hold the computed DOPU data upon return.
       The range of the DOPU is [0,1]. It takes the value when light appears to be completely un-polarized,
       and 1 when the opposite is the case."""

    RETARDATION = 5
    """It will hold the computed retardation data upon return.
       The range of the retardation is [0,pi/2]."""

    OPTIC_AXIS = 6
    """It will hold the computed optic-axis data upon return.
       The range of the optic axis is [-pi/2,pi/2]."""
