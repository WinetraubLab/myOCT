from .specklevar import SpeckleVariance
