import unittest

from pyspectralradar import LogLevel, set_log_level
from pyspectralradar.service import OctServiceSystem
from pyspectralradar.service.servicedevice import determine_power_threshold, \
    determine_power_threshold_state
from pyspectralradar.spectralradar import SpectralRadarException


class ServiceDeviceTestCase(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)
        # set_log_level(LogLevel.ERR)

    def setUp(self):
        self.service_system = OctServiceSystem()
        self.service_device = self.service_system.dev

    def tearDown(self):
        del self.service_device
        del self.service_system


class TestServiceDevice(ServiceDeviceTestCase):

    def test_service_mode(self):
        self.assertTrue(self.service_device.get_is_service_mode_enabled())

        self.assertFalse(self.service_device.get_is_service_mode_write_enabled())

        wrong_service_pwd = "foo"
        self.assertFalse(self.service_device.set_service_mode_write_enabled(True, wrong_service_pwd))
        self.assertFalse(self.service_device.get_is_service_mode_write_enabled())

        service_pwd = "prominent almost bathroom press allegation"
        self.assertTrue(self.service_device.set_service_mode_write_enabled(True, service_pwd))
        self.assertTrue(self.service_device.get_is_service_mode_write_enabled())

        self.assertTrue(self.service_device.set_service_mode_write_enabled(False, service_pwd))
        self.assertFalse(self.service_device.get_is_service_mode_write_enabled())

        wrong_service_pwd = "foo"
        self.assertFalse(self.service_device.set_service_mode_write_enabled(True, wrong_service_pwd))
        self.assertFalse(self.service_device.get_is_service_mode_write_enabled())


class TestServiceDeviceProperties(ServiceDeviceTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self.service_device.service_device_properties

    def test_property_flag(self):
        self.assertTrue(self.dut.get_sld_current_readout_available())
        self.assertTrue(self.dut.get_sld_current_configuration_available())
        self.assertTrue(self.dut.get_psu_readout_available())
        self.assertTrue(self.dut.get_psu_configuration_available())
        self.assertRaises(NotImplementedError, lambda: self.dut.get_has_control_board())


class TestSldProperties(ServiceDeviceTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self.service_device.sld_properties

        self.service_device.set_service_mode_write_enabled(True, "prominent almost bathroom press allegation")

    def tearDown(self):
        self.assertTrue(
            self.service_device.set_service_mode_write_enabled(False, "prominent almost bathroom press allegation"))
        super().tearDown()

    def test_property_string(self):
        print(self.dut.get_sld_error_msg(0))
        print(self.dut.get_sld_error_msg(1))
        print(self.dut.get_tec_error_msg(0))
        print(self.dut.get_tec_error_msg(1))

    def test_property_int(self):
        print(self.dut.get_sld_count(0))
        self.assertEqual(0, self.dut.get_sld_count(0))

        current_tec_pid_p = self.dut.get_tec_pid_p_share_ma_k(0)
        self.assertTrue(self.dut.set_tec_pid_p_share_ma_k(0, 100))
        self.assertEqual(100, self.dut.get_tec_pid_p_share_ma_k(0))
        self.assertTrue(self.dut.set_tec_pid_p_share_ma_k(0, current_tec_pid_p))

        current_tec_pid_i = self.dut.get_tec_pid_i_share_ma_ks(0)
        self.assertTrue(self.dut.set_tec_pid_i_share_ma_ks(0, 100))
        self.assertEqual(100, self.dut.get_tec_pid_i_share_ma_ks(0))
        self.assertTrue(self.dut.set_tec_pid_i_share_ma_ks(0, current_tec_pid_i))

        current_tec_pid_d = self.dut.get_tec_pid_d_share_mas_k(0)
        self.assertTrue(self.dut.set_tec_pid_d_share_mas_k(0, 100))
        self.assertEqual(100, self.dut.get_tec_pid_d_share_mas_k(0))
        self.assertTrue(self.dut.set_tec_pid_d_share_mas_k(0, current_tec_pid_d))

    def test_property_float(self):
        # Dummy returns index + random number
        current_ = self.dut.get_sld_current_ma(0)

        current_ = self.dut.get_sld_current_limit_ma(0)
        self.assertTrue(self.dut.set_sld_current_limit_ma(0, 100.1))
        self.assertAlmostEqual(100.1, self.dut.get_sld_current_limit_ma(0), delta=0.0001)
        self.assertTrue(self.dut.set_sld_current_limit_ma(0, current_))

        current_ = self.dut.get_sld_poti_ohm(0)
        self.assertTrue(self.dut.set_sld_poti_ohm(0, 100.1))
        self.assertAlmostEqual(100.1, self.dut.get_sld_poti_ohm(0), delta=0.0001)
        self.assertTrue(self.dut.set_sld_poti_ohm(0, current_))

        current_ = self.dut.get_sld_poti_limit_ohm(0)
        self.assertTrue(self.dut.set_sld_poti_limit_ohm(0, 100.1))
        self.assertAlmostEqual(100.1, self.dut.get_sld_poti_limit_ohm(0), delta=0.0001)
        self.assertTrue(self.dut.set_sld_poti_limit_ohm(0, current_))

        current_ = self.dut.get_sld_poti_operative_ohm(0)
        self.assertTrue(self.dut.set_sld_poti_operative_ohm(0, 100.1))
        self.assertAlmostEqual(100.1, self.dut.get_sld_poti_operative_ohm(0), delta=0.0001)
        self.assertTrue(self.dut.set_sld_poti_operative_ohm(0, current_))

        # Dummy returns 11 + index
        self.assertTrue(self.dut.set_sld_poti_goal_ohm(0, 100.1))
        self.assertAlmostEqual(11.0, self.dut.get_sld_poti_goal_ohm(0), delta=0.0001)
        self.assertAlmostEqual(12.0, self.dut.get_sld_poti_goal_ohm(1), delta=0.0001)
        self.assertAlmostEqual(13.0, self.dut.get_sld_poti_goal_ohm(2), delta=0.0001)

        # Dummy returns  0.1f + index * 0.1f
        self.assertTrue(self.dut.set_sld_poti_rate_ohm_ms(0, 100.1))
        self.assertAlmostEqual(0.1, self.dut.get_sld_poti_rate_ohm_ms(0), delta=0.0001)
        self.assertAlmostEqual(0.2, self.dut.get_sld_poti_rate_ohm_ms(1), delta=0.0001)
        self.assertAlmostEqual(0.3, self.dut.get_sld_poti_rate_ohm_ms(2), delta=0.0001)

        # Dummy returns 0.2f + index * 0.1f
        self.assertTrue(self.dut.set_sld_poti_fraction(0, 100.1))
        self.assertAlmostEqual(0.2, self.dut.get_sld_poti_fraction(0), delta=0.0001)
        self.assertAlmostEqual(0.3, self.dut.get_sld_poti_fraction(1), delta=0.0001)
        self.assertAlmostEqual(0.4, self.dut.get_sld_poti_fraction(2), delta=0.0001)

        current_ = self.dut.get_tec_setpoint_c(0)
        self.assertTrue(self.dut.set_tec_setpoint_c(0, 100.1))
        self.assertAlmostEqual(100.1, self.dut.get_tec_setpoint_c(0), delta=0.0001)
        self.assertTrue(self.dut.set_tec_setpoint_c(0, current_))

        # Dummy returns tec_temperature + random
        current_ = self.dut.get_tec_temperature_c(0)

        current_ = self.dut.get_tec_temp_window_c(0)
        self.assertTrue(self.dut.set_tec_temp_window_c(0, 100.1))
        self.assertAlmostEqual(100.1, self.dut.get_tec_temp_window_c(0), delta=0.0001)
        self.assertTrue(self.dut.set_tec_temp_window_c(0, current_))

        # Dummy returns tec_current_mA[index] + rand() * 10
        current_ = self.dut.get_tec_current_ma(0)

        # Dummy returns tec_voltage_mV[index] + rand() * 20
        current_ = self.dut.get_tec_voltage_mv(0)

        current_ = self.dut.get_power_monitoring_ohm(0)
        self.assertTrue(self.dut.set_power_monitoring_ohm(0, 100.1))
        self.assertAlmostEqual(100.1, self.dut.get_power_monitoring_ohm(0), delta=0.0001)
        self.assertTrue(self.dut.set_power_monitoring_ohm(0, current_))

        current_ = self.dut.get_photodiode_threshold_mv(0)
        self.assertTrue(self.dut.set_photodiode_threshold_mv(0, 100.1))
        self.assertAlmostEqual(100.1, self.dut.get_photodiode_threshold_mv(0), delta=0.0001)
        self.assertTrue(self.dut.set_photodiode_threshold_mv(0, current_))

        # Dummy returns pow_mon_photodiode_measured_mV = 1234.5f + rand() * 3
        current_ = self.dut.get_photodiode_measured_mv(0)

        # Dummy returns 1234.0f
        current_ = self.dut.get_tec_current_limit_ma(0)
        self.assertAlmostEqual(1234.0, self.dut.get_tec_current_limit_ma(0), delta=0.0001)

    def test_property_flag(self):
        current_ = self.dut.get_sld_exists(0)
        self.assertTrue(self.dut.set_sld_exists(0, True))
        self.assertTrue(self.dut.get_sld_exists(0))
        self.assertTrue(self.dut.set_sld_exists(0, current_))

        current_ = self.dut.get_sld_enabled(0)
        self.assertTrue(self.dut.set_sld_enabled(0, True))
        self.assertFalse(self.dut.get_sld_enabled(0))

        current_ = self.dut.get_sld_enabled(1)
        self.assertTrue(self.dut.set_sld_enabled(1, True))
        # TODO: check why false
        # self.assertTrue(self.dut.get_sld_enabled(1))

        current_ = self.dut.get_sld_in_error(0)
        self.assertEqual(True, self.dut.get_sld_in_error(0))

        current_ = self.dut.get_tec_exists(0)
        self.assertTrue(self.dut.set_tec_exists(0, True))
        self.assertEqual(True, self.dut.get_tec_exists(0))
        self.assertTrue(self.dut.set_tec_exists(0, False))
        self.assertEqual(False, self.dut.get_tec_exists(0))
        self.assertTrue(self.dut.set_tec_exists(0, current_))

        current_ = self.dut.get_tec_enabled(0)
        self.assertTrue(self.dut.set_tec_enabled(0, True))
        self.assertEqual(True, self.dut.get_tec_enabled(0))
        self.assertTrue(self.dut.set_tec_enabled(0, False))
        self.assertEqual(False, self.dut.get_tec_enabled(0))
        self.assertTrue(self.dut.set_tec_enabled(0, current_))

        current_ = self.dut.get_tec_in_error(0)
        self.assertEqual(True, self.dut.get_tec_enabled(0))

        current_ = self.dut.get_spi_uart_in_error(0)
        self.assertEqual(True, self.dut.get_spi_uart_in_error(0))

        self.assertTrue(self.dut.sld_save_params(0, True))

        self.assertTrue(self.dut.tec_save_params(0, True))

        self.assertTrue(self.dut.sld_tec_save_params(0, True))


class TestPsuProperties(ServiceDeviceTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self.service_device.psu_properties

    def test_flag(self):
        self.assertTrue(self.dut.get_psu_p33_ok())
        self.assertTrue(self.dut.get_psu_p65_ok())
        self.assertTrue(self.dut.get_psu_p12_ok())
        self.assertTrue(self.dut.get_psu_m12_ok())
        self.assertFalse(self.dut.get_psu_p24_ok())  # Note: Just for fun
        self.assertTrue(self.dut.get_psu_m24_ok())

        current_ = self.dut.get_psu_is_on()
        self.assertRaises(SpectralRadarException, lambda: self.dut.set_psu_is_on(False))
        self.service_device.set_service_mode_write_enabled(True, "prominent almost bathroom press allegation")
        self.dut.set_psu_is_on(False)
        self.assertFalse(self.dut.get_psu_is_on())
        self.dut.set_psu_is_on(True)
        self.service_device.set_service_mode_write_enabled(False, "prominent almost bathroom press allegation")

    def test_float(self):
        print(self.dut.get_psu_p33())
        self.assertIsInstance(self.dut.get_psu_p33(), float)
        print(self.dut.get_psu_p65())
        self.assertIsInstance(self.dut.get_psu_p65(), float)
        print(self.dut.get_psu_p12())
        self.assertIsInstance(self.dut.get_psu_p12(), float)
        print(self.dut.get_psu_m12())
        self.assertIsInstance(self.dut.get_psu_m12(), float)
        print(self.dut.get_psu_p24())
        self.assertIsInstance(self.dut.get_psu_p24(), float)
        print(self.dut.get_psu_m24())
        self.assertIsInstance(self.dut.get_psu_m24(), float)


class TestSystemProperties(ServiceDeviceTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self.service_device.system_properties

    def test_string(self):
        current_ = self.dut.get_system_time_on()
        print(current_)
        current_ = self.dut.get_system_time_off()
        print(current_)
        current_ = self.dut.get_system_time_total()
        print(current_)
        current_ = self.dut.get_system_status()
        print(current_)
        self.assertRaises(NotImplementedError, lambda: self.dut.get_system_temperature_alarm())
        self.assertRaises(NotImplementedError, lambda: self.dut.get_system_history())

    def test_int(self):
        current_ = self.dut.get_system_time_ms()
        print(current_)
        current_ = self.dut.get_system_time_days()
        print(current_)


class TestSRSHelper(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def test_power_threshold(self):
        pt_0 = determine_power_threshold(0)
        print("Determined threshold for SLD 0: %s", pt_0)

        pt_1 = determine_power_threshold(1)
        print("Determined threshold for SLD 1: %s", pt_1)

        print("Determined threshold state: %s", determine_power_threshold_state())

        # TODO: how to test?
        # persist_power_threshold()
