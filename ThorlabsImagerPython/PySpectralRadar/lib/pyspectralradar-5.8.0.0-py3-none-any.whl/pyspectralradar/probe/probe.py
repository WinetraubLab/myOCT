from __future__ import annotations

from ctypes import *
from typing import TYPE_CHECKING, Tuple

import numpy as np

from pyspectralradar.base import HandleManager
from pyspectralradar.data import ColoredData
from pyspectralradar.probe.probeconfigfiles import ProbeConfigFiles
from pyspectralradar.probe.properties import ProbeProperties
from pyspectralradar.probe.submodules import Objective, Scanner
from pyspectralradar.probe.supportedprobes import SupportedProbes
from pyspectralradar.scanpattern import ScanPatternFactory
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import ScanRangeShape

if TYPE_CHECKING:
    from pyspectralradar.octdevice import OCTDevice


class Probe(HandleManager):
    """
    Class containing methods for setting up a probe scan head that can be used to create scan patterns.

    This class manages the initialization and configuration of the probe scan head, including its properties and
    various submodules required for creating and managing scan patterns.

    Attributes:
        :properties: An instance of the
            :class:`~pyspectralradar.probe.properties.probeproperties.ProbeProperties` class that manages the
            properties of the probe
        :scan_pattern: An instance of the
            :class:`~pyspectralradar.scanpattern.scanpatternfactory.ScanPatternFactory` class that creates scan
            patterns for the probe
        :scanner: An instance of the
            :class:`~pyspectralradar.probe.submodules.scanner.Scanner` class that controls the scanning mechanism of
            the probe
        :objective: An instance of the
            :class:`~pyspectralradar.probe.submodules.objective.Objective` class that manages the objective lens of
            the probe, using descriptions and objectives obtained from probe properties
        :display_name: The display name of the probe, derived from its description

    Static Attributes:
        :available: An instance of the
            :class:`~pyspectralradar.probe.supportedprobe.SupportedProbes` class that checks the
            availability of the probe
        :config_files: An instance of the
            :class:`~pyspectralradar.probe.probeconfigfiles.ProbeConfigFiles` class that manages the probe
            configuration settings


    """

    # probe configuration files available at the current installation
    config_files: ProbeConfigFiles = ProbeConfigFiles()

    # probe types that are supported by the sdk
    supported_probes: SupportedProbes = SupportedProbes()

    def __init__(self, handle):
        super().__init__(handle)

        # properties
        self.properties: ProbeProperties = ProbeProperties(self.handle)

        # submodules
        self.scan_pattern = ScanPatternFactory(self.handle)
        self.scanner: Scanner = Scanner(self.handle)
        self.objective: Objective = Objective(self.handle,
                                              self.properties.get_description(),
                                              self.properties.get_objective())
        self.display_name = self._get_display_name(self.properties.get_description())

    @property
    def _del_func(self):
        return sr.closeProbe

    def save(self, probe_file: str):
        """Saves the current probe properties to a specified INI file to be reloaded using the basic probe constructor.

        Args:
            :probe_file: The filename of the .ini. If the path is not given, it will be assumed that this file should
                go in the configuration directory (typically "C:/Program Files/Thorlabs/SpectralRadar/Config") to
                indicate that file is in the current working directory, prepend a "~\" before the name. If a
                termination ``.ini`` is not there, it will be appended.
        """
        sr.saveProbe.argtypes = [c_handle, c_char_p]
        sr.saveProbe(self.handle, c_char_p(bytes(probe_file, encoding="ascii")))
        get_error()

    @staticmethod
    def _get_display_name(probe_name: str):
        """Returns the display name for the probe name specified.

        Args:
            :probe_name : Name of the probe. This string is essentially the name of the corresponding ``.prdf`` file,
                except that a version number and the termination should be added.

        Returns:
            The string to be shown in ThorImageOCT software.
        """
        str_size = 1024
        display_name = create_string_buffer(str_size)
        sr.getProbeDisplayName.argtypes = [c_char_p, c_char_p, c_int]
        sr.getProbeDisplayName(c_char_p(bytes(probe_name, encoding="ascii")), display_name, str_size)
        get_error()
        return display_name.value.decode('UTF-8')

    def get_type(self) -> str:
        """Gets the type of the specified probe.

        Returns:
            The current type name (one of ``Standard_OCTG``, ``UserCustomizable_OCTP``, ``Handheld_OCTH``).
        """
        sr.getProbeType.argtypes = [c_handle]
        sr.getProbeType.restype = c_char_p
        res = sr.getProbeType(self.handle)
        get_error()
        return res.decode('UTF-8')

    def set_type(self, probe_type: str):
        """Sets the type of the specified probe.

        Args:
            :probe_type: A zero terminated string describing the probe type (one of ``Standard_OCTG``,
                ``UserCustomizable_OCTP``, ``Handheld_OCTH``).
        """
        sr.setProbeType.argtypes = [c_handle, c_char_p]
        sr.setProbeType(self.handle, c_char_p(bytes(probe_type, encoding="ascii")))
        get_error()

    def position_to_probe_voltage(self, oct_device: 'OCTDevice', pos_x_mm: float, pos_y_mm: float) -> (
            Tuple)[float, float]:
        """Convert scan position in mm to probe output voltage

        Args:
            :oct_device: The used OCT device
            :pos_x_mm: X-Position in mm
            :pos_y_mm: Y-Position in mm

        Returns:
            A tuple (``volt_x``, ``volt_y``) containing the X-Position in volt as ``volt_x`` and the
            Y-Position in volt as ``volt_y``.
        """
        volt_x = c_double(0)
        volt_y = c_double(0)

        sr.positionToProbeVoltage.argtypes = [c_handle,
                                              c_handle,
                                              c_double,
                                              c_double,
                                              POINTER(c_double),
                                              POINTER(c_double)]
        sr.positionToProbeVoltage(oct_device.handle,
                                  self.handle,
                                  pos_x_mm,
                                  pos_y_mm,
                                  volt_x,
                                  volt_y)
        get_error()
        return volt_x.value, volt_y.value

    def camera_pixel_to_position(self, image: ColoredData, pixels_x: int, pixels_y: int) -> Tuple[float, float]:
        """Computes the physical position of a camera pixel of the video camera in the probe.

        It assumes a properly calibrated device.

        Args:
            :image: The video camera image as colored data object
            :pixels_x: The x-pixel coordinates
            :pixels_y: The y-pixel coordinates

        Returns:
            A tuple (``pos_x``, ``pos_y``) containing the x coordinate as ``pos_x`` and the y coordinate as
            ``pos_y``. If the pointer happens to be null, it will not be used.
        """
        pos_x = c_double(0)
        pos_y = c_double(0)

        sr.CameraPixelToPosition.argtypes = [c_handle,
                                             c_handle,
                                             c_int,
                                             c_int,
                                             POINTER(c_double),
                                             POINTER(c_double)]
        sr.CameraPixelToPosition(self.handle,
                                 image.handle,
                                 pixels_x,
                                 pixels_y,
                                 pos_x,
                                 pos_y)
        get_error()
        return pos_x.value, pos_y.value

    def position_to_camera_pixel(self, image: ColoredData, pos_x: float, pos_y: float) -> Tuple[int, int]:
        """Computes the pixel of the video camera corresponding to a physical position. It needs to be assured that the
        device is properly calibrated.

        Args:
            :image: The video camera image as colored data object
            :pos_x: The x coordinate
            :pos_y: The y coordinate

        Returns:
            A tuple (``pixels_x``, ``pixels_y``) containing the x-pixel coordinate as ``pixels_x`` and the y-pixel
            coordinate as ``pixels_y``. If the pointer happens to be null, it will not be used.
        """
        pixels_x = c_int(0)
        pixels_y = c_int(0)

        sr.PositionToCameraPixel.argtypes = [c_handle,
                                             c_handle,
                                             c_double,
                                             c_double,
                                             POINTER(c_int),
                                             POINTER(c_int)]
        sr.PositionToCameraPixel(self.handle,
                                 image.handle,
                                 pos_x,
                                 pos_y,
                                 pixels_x,
                                 pixels_y)
        get_error()
        return pixels_x.value, pixels_y.value

    def get_max_scan_range_shape(self) -> ScanRangeShape:
        """Returns the shape of the valid scan range for the 'Probe' handle.
        All possible scan range shapes are defined in :class:`~pyspectralradar.types.probetypes.ScanRangeShape`.

        Returns:
            The shape of the valid scan range for the :obj:`~pyspectralradar.probe.probe.Probe`.
        """
        sr.getProbeMaxScanRangeShape.restype = c_int
        sr.getProbeMaxScanRangeShape.argtypes = [c_handle]
        res = sr.getProbeMaxScanRangeShape(self.handle)
        get_error()
        return res

    def set_max_scan_range_shape(self, shape: ScanRangeShape):
        """Sets the Shape of the valid scan range for the :obj:`~pyspectralradar.probe.probe.Probe`.
        All possible scan range shapes are defined in :class:`~pyspectralradar.types.probetypes.ScanRangeShape`.

        Args:
            shape: The desired shape, which should be in the range defined by
                :class:`~pyspectralradar.types.probetypes.ScanRangeShape`.

        """
        assert isinstance(shape, ScanRangeShape)
        sr.setProbeMaxScanRangeShape.argtypes = [c_handle, c_int]
        sr.setProbeMaxScanRangeShape(self.handle, shape)
        get_error()

    def set_quadratic_factors(self, quad_factors_x: np.ndarray[float], quad_factors_y: np.ndarray[float]):
        """Sets the probe calibration factors.

        Args:
            :quad_factors_x: The specified quadratic factors for the x-axis.
            :quad_factors_y: The specified quadratic factors for the y-axis.
        """
        num_factors = len(quad_factors_x)
        sr.setQuadraticProbeFactors.argtypes = [c_handle,
                                                np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                                np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                                c_int]
        sr.setQuadraticProbeFactors(self.handle, quad_factors_x, quad_factors_y, num_factors)
        get_error()

    @staticmethod
    def use_calibration(on_off: bool):
        """Enable or disable use of probe calibration.

        Needs to be called before `Probe` object has been initialized

        :Warning: Experimental: This function may change in its interface and behaviour, or even disappear in future
            versions.

        Args:
            :on_off: ``True`` to enable probe calibration
        """
        sr.useProbeCalibration.argtypes = [c_bool]
        sr.useProbeCalibration(on_off)
        get_error()
