from __future__ import annotations

from ctypes import *
from typing import TYPE_CHECKING

from pyspectralradar.base import HandleManager
from pyspectralradar.coloring import Coloring
from pyspectralradar.data import ColoredData, ComplexData, RawData, RealData
from pyspectralradar.processing import staticmethods as stm
from pyspectralradar.processing.properties import ProcessingProperties
from pyspectralradar.processing.submodules import Apodization, Calibration, Dispersion
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import AvgAlgorithm, FFTType, SpectrumType

if TYPE_CHECKING:
    from pyspectralradar.octdevice import OCTDevice


class Processing(HandleManager, Dispersion):
    """
    Class contains Standard Processing Routines for the OCT system.

    This class manages various standard processing routines for the OCT system, including apodization, calibration,
    and dispersion. It initializes and configures these processing routines using the provided handle, incorporating
    static device methods and properties.

    Attributes:
        :properties: An instance of the
            :class:`~pyspectralradar.processing.properties.processingproperties.ProcessingProperties` class that
            manages the properties of the processing routines.
        :apo: An instance of the :class:`~pyspectralradar.processing.submodules.apodization.Apodization` class that
            handles apodization processing.
        :calibration: An instance of the :class:`~pyspectralradar.processing.submodules.calibration.Calibration` class
            that manages calibration routines.
        :dispersion: An instance of the :class:`~pyspectralradar.processing.submodules.dispersion.Dispersion` class that
            manages dispersion correction.

    """

    def __init__(self, handle: c_handle):
        super().__init__(handle)

        # static methods
        self._incorporate_static_device_methods()

        # properties
        self.properties: ProcessingProperties = ProcessingProperties(self.handle)

        # submodules
        self.apo: Apodization = Apodization(self.handle)
        self.calibration: Calibration = Calibration(self.handle)
        self.dispersion: Dispersion = Dispersion(self.handle)

    def _incorporate_static_device_methods(self):
        self.compute_chirp = stm.compute_chirp
        self.compute_dispersion = stm.compute_dispersion
        self.compute_dispersion_by_coeff = stm.compute_dispersion_by_coeff
        self.compute_dispersion_by_image = stm.compute_dispersion_by_image
        self.compute_linear_k_raw_data = stm.compute_linear_k_raw_data
        self.linearize_spectral_data = stm.linearize_spectral_data
        self.calc_contrast = stm.calc_contrast
        self.calc_spectrometer_img_quality = stm.calc_spectrometer_img_quality
        self.analyze_max_peak = stm.analyze_max_peak

    @property
    def _del_func(self):
        return sr.clearProcessing

    def set_data_output(self, data: RealData | ComplexData):
        """Sets the pointer to the resulting complex scans that will be written after subsequent processing executions.

        Suitable sizes and ranges will be automatically set during the processing (
        :func:`~pyspectralradar.processing.processing.Processing.execute`).

        If data is :obj:`~pyspectralradar.data.complexdata.ComplexData`: After the next completion of
        :func:`~pyspectralradar.processing.processing.Processing.execute`, this object will contain the real and
        imaginary parts of the scans.

        If data is :obj:`~pyspectralradar.data.realdata.RealData`: After the next completion of
        :func:`~pyspectralradar.processing.processing.Processing.execute`, this object will contain the amplitude (in
        dB) of the scans.

        If set to a nullptr, no complex data result will be written in the subsequent processing executions.

        Args:
            :data: Object that the data will be written to after processing executions.

        """
        if isinstance(data, ComplexData):
            sr.setComplexDataOutput.argtypes = [c_handle, c_handle]
            sr.setComplexDataOutput(self.handle, data.handle)
        elif isinstance(data, RealData):
            sr.setProcessedDataOutput.argtypes = [c_handle, c_handle]
            sr.setProcessedDataOutput(self.handle, data.handle)
        else:
            raise Exception('Format not yet supported. ')

    def set_colored_data_output(self, colored_data: ColoredData, color: Coloring, transposed: bool = False):
        """Sets the pointer to the resulting colored scans that will be written after subsequent processing executions.

        After the next completion of the function :func:`~pyspectralradar.processing.processing.Processing.execute`,
        this data object will contain the colored amplitude of the scans.

        If set to nullptr no colored data will be written in the subsequent processing executions.

        Args:
            :colored_data: Object that the data will be written to after processing executions.
            :color: Coloring object that holds information for data coloring.
            :transposed: Boolean to identify if colored data will be transposed in such a way that the first axis (
                normally z-axis) will be the x-axis (the depth of each individual A-scan) and the second axis (
                normally x-axis) will be the z-axis.
        """
        assert isinstance(colored_data, ColoredData)
        assert isinstance(color, Coloring)
        fun = sr.setTransposedColoredDataOutput if transposed else sr.setColoredDataOutput
        fun.argtypes = [c_handle, c_handle, c_handle]
        fun(self.handle, colored_data.handle, color.handle)
        get_error()

    def set_spectrum_output(self, data: RealData, spect_type: SpectrumType = SpectrumType.RAW):
        """Sets the location for the resulting spectral data.

        Suitable sizes and ranges will be automatically set during the processing (
        :func:`~pyspectralradar.processing.processing.Processing.execute`).

        Args:
            :data: Object that the data will be written to after processing executions
            :spect_type: Specifies the type of the resulting spectrum output data
        """
        assert isinstance(spect_type, SpectrumType)
        if spect_type == SpectrumType.RAW:
            fun = sr.setSpectrumOutput
        elif spect_type == SpectrumType.OFFSET_CORRECTED:
            fun = sr.setOffsetCorrectedSpectrumOutput
        elif spect_type == SpectrumType.DC_CORRECTED:
            fun = sr.setDCCorrectedSpectrumOutput
        elif spect_type == SpectrumType.APODIZED:
            fun = sr.setApodizedSpectrumOutput
        else:
            raise ArgumentError

        fun.argtypes = [c_handle, c_handle]
        fun(self.handle, data.handle)
        get_error()

    def execute(self, data: RawData | ComplexData):
        """Executes the processing. The results will be stored as requested through
        :func:`~pyspectralradar.processing.processing.Processing.set_spectrum_output`,
        :func:`~pyspectralradar.processing.processing.Processing.set_colored_data_output` (including coloring
        properties) and similar ones.

        In all cases, sizes and ranges will be adjusted automatically to the right values.

        If data is :obj:`~pyspectralradar.data.complexdata.ComplexData`, the processing will begin by suitable
        resampling and FFT, no further preprocessing takes place.

        Args:
            :data: The data to be processed
        """
        if isinstance(data, ComplexData):
            sr.executeComplexProcessing.argtypes = [c_handle, c_handle]
            sr.executeComplexProcessing(self.handle, data.handle)
        elif isinstance(data, RawData):
            sr.executeProcessing.argtypes = [c_handle, c_handle]
            sr.executeProcessing(self.handle, data.handle)
        else:
            raise Exception('Format not yet supported. ')

    def finish(self, complex_data: ComplexData):
        """Completes the processing. The results will be stored as requested through
        :func:`~pyspectralradar.processing.processing.Processing.set_spectrum_output`
        or :func:`~pyspectralradar.processing.processing.Processing.set_colored_data_output` (including coloring
        properties) and similar ones.

        In all cases, sizes and ranges will be adjusted automatically to the right values.

        Under normal circumstances :func:`~pyspectralradar.processing.processing.Processing.execute` takes raw-data (
        a spectrum) and computes a depth profile in decibel. In some cases (e.g. PS-OCT) it is preferred to spare the
        computational time of the last few steps, and to compute only up to the complex data (using
        :func:`~pyspectralradar.processing.processing.Processing.set_spectrum_output` right before).
        This function may be used to transform the intermediate complex data to fully processed output at a later time,
        resuming from the point where the work was last stopped.

        Args:
            :complex_data: Complex data to be finished.

        """
        assert isinstance(complex_data, ComplexData)
        sr.finishProcessing.argtypes = [c_handle, c_handle]
        sr.finishProcessing(self.handle, complex_data.handle)
        get_error()

    def get_input_size(self) -> int:
        """Returns the expected input size (pixels per spectrum) of the processing algorithms.

        This function is provided for convenience as processing routines can be used independently of the device.

        Returns:
            The number of pixels per spectrum.
        """
        sr.getInputSize.argtypes = [c_handle]
        sr.getInputSize.restype = c_int
        res = sr.getInputSize(self.handle)
        get_error()
        return res

    def get_a_scan_size(self) -> int:
        """Returns the number of pixels in an A-Scan that can be obtained (computed) with the given processing routines.

        The returned number is identical to the number of rows in a finished B-Scan, that can also be retrieved (after
        the processing has been executed) by accessing the attributes ``size1``.

        Returns:
            The number of pixels in an A-Scan that can be obtained (computed) with the given processing routines.
        """
        sr.getAScanSize.argtypes = [c_handle]
        sr.getAScanSize.restype = c_int
        res = sr.getAScanSize(self.handle)
        get_error()
        return res

    def set_dechirp_algorithm(self, fft_type: FFTType, oversampling: float):
        """Sets the algorithm to be used for de-chirping the input spectra.

        Args:
            :fft_type: Specifies the FFT algorithm that will combine the de-chirping with the Fourier transform.
            :oversampling: In case the selected FFT algorithm bases on oversampling, this parameter gives the factor.
        """
        assert isinstance(fft_type, FFTType)
        sr.setProcessingDechirpAlgorithm.argtypes = [c_handle, c_int, c_float]
        sr.setProcessingDechirpAlgorithm(self.handle, fft_type, oversampling)
        get_error()

    def set_averaging_algorithm(self, algorithm: AvgAlgorithm):
        """Sets the algorithm that will be used for averaging during the processing.

        Args:
            :algorithm: The averaging algorithm. If this function is not explicitly invoked, the value
                ``AvgAlgorithm.MEAN`` can be assumed.

        """
        assert isinstance(algorithm, AvgAlgorithm)
        sr.setProcessingAveragingAlgorithm.argtypes = [c_handle, c_int]
        sr.setProcessingAveragingAlgorithm(self.handle, algorithm)
        get_error()

    def get_fft_type(self) -> FFTType:
        """Retrieve the active FFT Type.

        Returns:
            The current FFT algorithm type that will combine the de-chirping with the Fourier transform.
        """
        sr.getProcessing_FFTType.argtypes = [c_handle]
        sr.getProcessing_FFTType.restype = c_int
        res = sr.getProcessing_FFTType(self.handle)
        res = FFTType(res)
        get_error()
        return res

    def get_ref_intensity(self) -> float:
        """Returns an absolute value that indicates the reference intensity that was present when the currently used
        apodization was determined.

        The reference intensity is the maximum value of an apodization spectrum after subtracting the offset.\n
        This value gets computed automatically along the measurement. The function returns the latest value
        computed.

        Returns:
            Absolute value that indicates the reference intensity
        """
        sr.getReferenceIntensity.argtypes = [c_handle]
        sr.getReferenceIntensity.restype = c_double
        res = sr.getReferenceIntensity(self.handle)
        get_error()
        return res

    def get_relative_ref_intensity(self, oct_device: OCTDevice) -> float:
        """Returns a value larger than 0.0 and smaller than 1.0 that indicates the reference intensity (relative to
        saturation) that was present when the currently used apodization was determined.

        The value is determined as the quotient between the reference intensity (function
        :func:`~pyspectralradar.processing.processing.Processing.get_ref_intensity`) and the full well capacity of the
        detector. Although each experiment may have its own particularities, return values below 0.5 or above 0.9 are
        considered non-satisfactory in most applications. Experience has shown that return values between 0.6 and 0.8
        enable the best measurements.

        Args:
            :oct_device: OCT Device that holds the used system information

        Returns:
            A value larger than 0.0 and smaller than 1.0 that indicates the reference intensity
        """
        sr.getRelativeReferenceIntensity.argtypes = [c_handle, c_handle]
        sr.getRelativeReferenceIntensity.restype = c_double
        res = sr.getRelativeReferenceIntensity(oct_device.handle, self.handle)
        get_error()
        return res

    def get_relative_saturation(self) -> float:
        """Returns a value larger than 0.0 and smaller than 1.0 that indicates the saturation of the sensor that was
        present during the last processing cycle.

        Returns:
            A value larger than 0.0 and smaller than 1.0 that indicates the saturation
        """
        sr.getRelativeSaturation.argtypes = [c_handle]
        sr.getRelativeSaturation.restype = c_double
        res = sr.getRelativeSaturation(self.handle)
        get_error()
        return res

    def get_relative_interference_amplitude(self) -> float:
        """Returns a value larger than 0.0 and smaller than 1.0 that mirrors the maximum interference amplitude at the
        sensor during the last processing cycle.

        This value characterizes spectra obtained with the Sweep-Source technique: it first applies a high pass filter
        that considerably affects the DC component of the spectrum. The procedure finally returns the peak-to-peak
        amplitude of the remaining signal.
        This value gets computed automatically along the measurement. The function just returns the latest value
        computed.

        Returns:
            A value larger than 0.0 and smaller than 1.0 that mirrors the maximum interference amplitude
        """
        sr.getRelativeInterferenceAmplitude.argtypes = [c_handle]
        sr.getRelativeInterferenceAmplitude.restype = c_double
        res = sr.getRelativeInterferenceAmplitude(self.handle)
        get_error()
        return res

    def get_expected_hann_fwhm(self, oct_device: OCTDevice) -> float:
        """Returns the theoretical width of a Hann point-spread function (PSF) given the current spectral width and edge
        channels

        :Warning: Experimental: This function may change in its interface and behaviour, or even disappear in future
            versions.

        Args:
            :oct_device: current device handle

        Returns:
            PSF-Width in pixels
        """
        sr.getExpectedHannFWHM.argtypes = [c_handle, c_handle]
        sr.getExpectedHannFWHM.restype = c_double
        res = sr.getExpectedHannFWHM(oct_device.handle, self.handle)
        get_error()
        return res

    def calc_contrast(self, apodized_spectrum: RealData) -> RealData:
        """Calculates the spectrometer's contrast given a modulated spectrum, a properly calibrated processing
        (containing an apodization spectrum) as a function of the camera pixel

        :Warning: Experimental: This function may change in its interface and behaviour, or even disappear in future
            versions.

        Args:
            :apodized_spectrum: Modulated spectrum that was properly apodized

        Returns:
            Result contrast
        """
        assert isinstance(apodized_spectrum, RealData)
        contrast = RealData()
        sr.calcContrastEx.argtypes = [c_handle, c_handle, c_handle]
        sr.calcContrastEx(self.handle, apodized_spectrum.handle, contrast.handle)
        get_error()
        return contrast
