import unittest

import matplotlib.pyplot as plt
import numpy as np

import pyspectralradar.types as pt
from pyspectralradar import OCTSystem, RealData, LogLevel, set_log_level

ENABLE_PLOTS = False


class DataPropertyTestCase(unittest.TestCase):
    dut = RealData()

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

        sys = OCTSystem()
        dev = sys.dev
        proc = sys.processing_factory.from_device()
        probe = sys.probe_factory.create_default()
        pattern = probe.scan_pattern.create_bscan_pattern(10.0, 1024)

        dev.acquisition.start(pattern, pt.AcqType.ASYNC_FINITE)
        raw = dev.acquisition.get_raw_data()

        proc.set_data_output(cls.dut)
        proc.execute(raw)
        dev.acquisition.stop()

        del raw
        del pattern
        del proc
        del probe
        del dev
        del sys

    @classmethod
    def tearDownClass(cls):
        del cls.dut

    def test_data_shape(self):
        self.assertTrue(self.dut.shape == (1024, 1024, 1))

    def test_data_size(self):
        self.assertEqual(self.dut.size, 1024 * 1024 * 1)

    def test_data_size_bytes(self):
        self.assertEqual(self.dut.bytes_per_element, 4)
        self.assertAlmostEqual(self.dut.size_bytes, (self.dut.size * self.dut.bytes_per_element))

    def test_data_ndim(self):
        self.assertEqual(self.dut.ndim, 2)

    def test_data_range(self):
        self.assertTrue(self.dut.range == (5.12, 10.0, 1.0))

    def test_data_crop(self):
        dut = self.dut.clone()
        dut.crop(pt.DataDirection.DIR1, 100, 1000)
        self.assertEqual(dut.size, (900 * 1024 * 1))
        self.assertTrue(dut.shape == (900, 1024, 1))
        self.assertAlmostEqual(dut.range, ((5.12 * 900 / 1024), 10.0, 1.0))

    def test_data_orientation(self):
        self.assertTrue(self.dut.get_orientation() == pt.DataOrientation.ZXY)
        dut = self.dut.clone()
        dut.set_orientation(pt.DataOrientation.XYZ)
        self.assertTrue(dut.get_orientation() == pt.DataOrientation.XYZ)

    def test_data_slice(self):
        dut = self.dut.clone()
        dut.append(self.dut, pt.DataDirection.DIR3)

        slice1 = dut.get_slice_at_pos(pt.DataDirection.DIR3, 1.0)
        slice2 = dut.get_slice_at_index(pt.DataDirection.DIR3, 1)

        self.assertIsInstance(slice1, RealData)
        self.assertIsInstance(slice2, RealData)

        print(dut.shape, dut.range)
        print(slice1.shape, slice1.range)
        print(slice2.shape, slice2.range)
        print(slice1.to_numpy().shape)
        self.assertTrue(np.all(slice1.to_numpy() == slice2.to_numpy()))

    def test_data_separate(self):
        dut = self.dut.clone()
        idx = 300
        first_half, second_half = dut.separate(pt.DataDirection.DIR1, idx)

        if ENABLE_PLOTS:
            plt.figure(1)
            plt.title('test_data_separate DIR1')
            plt.subplot(1, 3, 1)
            plt.imshow(dut.to_numpy()[:, :, 0])

            plt.subplot(1, 3, 2)
            plt.imshow(first_half.to_numpy()[:, :, 0])

            plt.subplot(1, 3, 3)
            plt.imshow(second_half.to_numpy()[:, :, 0])

        self.assertIsInstance(first_half, RealData)
        self.assertIsInstance(second_half, RealData)

        print('First half DIR1: ', first_half.shape, first_half.to_numpy().shape)
        print('Second half DIR1: ', second_half.shape, second_half.to_numpy().shape)

        self.assertTrue(first_half.shape == (idx, 1024, 1))
        self.assertTrue(second_half.shape == ((1024 - idx), 1024, 1))

        self.assertTrue(np.allclose(self.dut.to_numpy()[0, :, 0], first_half.to_numpy()[0, :, 0]))
        self.assertTrue(np.allclose(self.dut.to_numpy()[idx, :, 0], second_half.to_numpy()[0, :, 0]))

        first_half, second_half = dut.separate(pt.DataDirection.DIR2, idx)

        if ENABLE_PLOTS:
            plt.figure(2)
            plt.title('test_data_separate DIR2')
            plt.subplot(1, 3, 1)
            plt.imshow(dut.to_numpy()[:, :, 0])

            plt.subplot(1, 3, 2)
            plt.imshow(first_half.to_numpy()[:, :, 0])

            plt.subplot(1, 3, 3)
            plt.imshow(second_half.to_numpy()[:, :, 0])

        print('First half DIR2: ', first_half.shape, first_half.to_numpy().shape)
        print('Second half DIR2: ', second_half.shape, second_half.to_numpy().shape)

        self.assertTrue(first_half.shape == (1024, idx, 1))
        self.assertTrue(second_half.shape == (1024, (1024 - idx), 1))

        self.assertTrue(np.allclose(self.dut.to_numpy()[:, 0, 0], first_half.to_numpy()[:, 0, 0]))
        self.assertTrue(np.allclose(self.dut.to_numpy()[:, idx, 0], second_half.to_numpy()[:, 0, 0]))

        if ENABLE_PLOTS:
            plt.show()
        else:
            plt.close()

    def test_data_flip(self):
        dut = self.dut.clone()
        dut.flip(pt.DataDirection.DIR3)

        self.assertTrue(np.all(self.dut.to_numpy()[:, 0, 0] == dut.to_numpy()[:, 0, -1]))

        if ENABLE_PLOTS:
            plt.figure()
            plt.subplot(1, 2, 1)
            plt.title('test_data_flip')
            plt.imshow(self.dut.to_numpy()[:, :, 0])

            plt.subplot(1, 2, 2)
            plt.imshow(dut.to_numpy()[:, :, 0])
            plt.show()

    def test_data_copy(self):
        dut_copy = self.dut.copy()
        self.assertIsInstance(dut_copy, RealData)
        self.assertEqual(dut_copy.size, 1024 * 1024 * 1)
        self.assertTrue(dut_copy.shape == (1024, 1024, 1))
        self.assertTrue(dut_copy.range == (5.12, 10.0, 1.0))


if __name__ == '__main__':
    unittest.main()
