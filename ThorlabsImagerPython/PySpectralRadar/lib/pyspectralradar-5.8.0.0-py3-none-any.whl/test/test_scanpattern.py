import math
import unittest
from os import remove
from os.path import exists

import matplotlib.pyplot as plt
import numpy as np

from pyspectralradar import OCTDevice, ProbeFactory, RealData, ScanPattern, ScanPointsFactory, LogLevel, set_log_level
from pyspectralradar.spectralradar import SpectralRadarException
from pyspectralradar.types import AcqType, AcquisitionOrder, ApodizationType, BoundaryCondition, InflationMethod, \
    InterpolationMethod, ScanPointsDataFormat

ENABLE_PLOTS = False


class ScanPattenFactoryTestCase(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def setUp(self):
        self._oct_dev = OCTDevice()
        self._probe = ProbeFactory(self._oct_dev).create_default()
        self.dut = self._probe.scan_pattern

    def tearDown(self):
        del self._oct_dev
        del self._probe


class TestScanPatternFactory(ScanPattenFactoryTestCase):
    def test_create_no_scan_pattern(self):
        self.assertIsInstance(self.dut.create_no_scan_pattern(50, 1), ScanPattern)

    def test_create_a_scan_pattern(self):
        self.assertRaises(SpectralRadarException, lambda: self.dut.create_ascan_pattern(50, 15.0, 2.5))
        self.assertIsInstance(self.dut.create_ascan_pattern(50, 5.0, 2.5), ScanPattern)

    def test_create_b_scan_pattern_manual(self):
        self.assertRaises(SpectralRadarException,
                          lambda: self.dut.create_ascan_pattern(
                              self.dut.create_bscan_pattern_manual(2.0, 1.1, -10.1, 1.4, 100)))
        self.assertIsInstance(self.dut.create_bscan_pattern_manual(2.0, 1.1, 0.1, 1.4, 100), ScanPattern)

    def test_create_b_scan_pattern(self):
        self.assertRaises(SpectralRadarException, lambda: self.dut.create_bscan_pattern(11.0, 20))
        self.assertIsInstance(self.dut.create_bscan_pattern(2.0, 100), ScanPattern)

    def test_create_ideal_b_scan_pattern(self):
        self.assertIsInstance(self.dut.create_ideal_bscan_pattern(200.0, 100), ScanPattern)

    def test_create_circle_pattern(self):
        self.assertRaises(SpectralRadarException, lambda: self.dut.create_circle_pattern(6.0, 100))
        self.assertIsInstance(self.dut.create_circle_pattern(2.0, 100), ScanPattern)

    def test_create_volume_pattern(self):
        self.assertIsInstance(
            self.dut.create_volume_pattern(
                2.0, 50, 1.9, 55, ApodizationType.ONE_FOR_ALL, AcquisitionOrder.FRAME_BY_FRAME), ScanPattern)

    def test_create_volume_pattern_ex(self):
        self.assertIsInstance(
            self.dut.create_volume_pattern_ex(
                2.0, 50, 1.9, 55, 0.1, -3.0, 45, ApodizationType.ONE_FOR_ALL, AcquisitionOrder.FRAME_BY_FRAME),
            ScanPattern)


class TestFreeformScanPatternFactory(ScanPattenFactoryTestCase):
    def setUp(self):
        super().setUp()

    def test_create_freeform_pattern_2d(self):
        sp_x = np.linspace(0.0, 5.0, 10)
        sp_y = np.linspace(0.0, 5.0, 10)
        self.assertIsInstance(
            self.dut.create_freeform_pattern_2d(sp_x, sp_y, 100, InterpolationMethod.SPLINE, False), ScanPattern)

    def test_create_freeform_pattern_2d_from_file(self):
        sp_pattern = self.dut.create_bscan_pattern(4.0, 99)
        coords_x, coords_y = sp_pattern.scan_points()
        scan_indices = np.zeros(99)
        sp_file_path = 'C:\\tmp\\test_pattern_2d_scan_points.txt'
        ScanPointsFactory.save_to_file(coords_x, coords_y, scan_indices, sp_file_path, ScanPointsDataFormat.TXT)

        self.assertIsInstance(
            self.dut.create_freeform_pattern_2d_from_file(
                sp_file_path, 100, ScanPointsDataFormat.TXT, InterpolationMethod.SPLINE, True),
            ScanPattern)

        if exists(sp_file_path):
            remove(sp_file_path)

    def test_create_freeform_pattern_2d_from_lut(self):
        self._probe.properties.set_range_max_x(20.0)
        self._probe.properties.set_range_max_y(20.0)
        self.dut = self._probe.scan_pattern

        sp_pattern = self.dut.create_bscan_pattern(5.0, 100)
        volt_x, volt_y = sp_pattern.LUT.get()

        self.assertIsInstance(self.dut.create_freeform_pattern_2d_from_LUT(volt_x, volt_y, False), ScanPattern)

    def test_create_freeform_pattern_3d(self):
        sp_x = np.linspace(0.0, 4.0, 10)
        sp_y = np.linspace(0.0, 4.0, 10)
        sp_size = len(sp_x)
        ascans = 100
        sp_i = np.repeat(np.arange(sp_size), ascans)

        pattern = self.dut.create_freeform_pattern_3d(sp_x,
                                                      sp_y,
                                                      sp_i,
                                                      sp_size,
                                                      ascans,
                                                      InterpolationMethod.SPLINE,
                                                      True,
                                                      ApodizationType.ONE_FOR_ALL,
                                                      AcquisitionOrder.ACQ_ORDER_ALL)

        self.assertIsInstance(pattern, ScanPattern)
        self.assertEqual(pattern.properties.get_size_imaging_cycles(), 100)

    def test_create_freeform_pattern_3d_from_lut(self):
        self._probe.properties.set_range_max_x(200.0)
        self._probe.properties.set_range_max_y(200.0)
        self.dut = self._probe.scan_pattern

        ascans = 100
        bscans = 50

        sp = self.dut.create_volume_pattern(5.0, ascans, 3.5, bscans, ApodizationType.ONE_FOR_ALL,
                                            AcquisitionOrder.ACQ_ORDER_ALL)
        volt_x, volt_y = sp.LUT.get()

        pattern = self.dut.create_freeform_pattern_3d_from_LUT(volt_x, volt_y, ascans, bscans, True,
                                                               ApodizationType.ONE_FOR_ALL,
                                                               AcquisitionOrder.ACQ_ORDER_ALL)

        self.assertIsInstance(pattern, ScanPattern)
        self.assertEqual(pattern.properties.get_size_imaging_cycles(), ascans)


class ScanPatternTestCase(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def setUp(self):
        self.dev = OCTDevice()
        self.probe = ProbeFactory(self.dev).create_default()
        self._pattern = self.probe.scan_pattern
        self.number_of_ascans = 120
        self.number_of_bscans = 45
        self.rx = 5.0
        self.ry = 3.0
        self._pattern_2d = self.probe.scan_pattern.create_bscan_pattern(self.rx, self.number_of_ascans)
        self._pattern_3d = self.probe.scan_pattern.create_volume_pattern(
            self.rx, self.number_of_ascans, self.ry, self.number_of_bscans,
            ApodizationType.EACH_BSCAN, AcquisitionOrder.FRAME_BY_FRAME)

    def tearDown(self):
        del self.dev
        del self.probe
        del self._pattern_2d
        del self._pattern_3d


class TestScanPatternPropertyInt(ScanPatternTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self._pattern_2d.properties
        self.dut_3d = self._pattern_3d.properties

    def test_scan_pattern_scan_points_size(self):
        self.assertEqual(self._pattern_2d.size(), self.number_of_ascans)
        self.assertEqual(self._pattern_3d.size(), (self.number_of_ascans * self.number_of_bscans))

    def test_scan_pattern_property_int(self):
        self.assertEqual(self.dut.get_size_total(), self.number_of_ascans + 20 + 25 + 20)
        self.assertEqual(self.dut_3d.get_size_total(), (self.number_of_ascans + 20 + 25 + 20) * self.number_of_bscans)
        self.assertEqual(self.dut.get_cycles(), 1)
        self.assertEqual(self.dut_3d.get_cycles(), self.number_of_bscans)
        self.assertEqual(self.dut.get_size_cycles(), self.number_of_ascans + 65)
        self.assertEqual(self.dut_3d.get_size_cycles(), self.number_of_ascans + 65)
        self.assertEqual(self.dut.get_size_preparation_cycles(), 65)
        self.assertEqual(self.dut_3d.get_size_preparation_cycles(), 65)
        self.assertEqual(self.dut.get_size_imaging_cycles(), self.number_of_ascans)
        self.assertEqual(self.dut_3d.get_size_imaging_cycles(), self.number_of_ascans)
        self.assertEqual(self.dut.get_size_preparation_scan(), 0)
        self.assertEqual(self.dut_3d.get_size_preparation_scan(), 0)


class TestScanPatternPropertyFloat(ScanPatternTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self._pattern_2d.properties
        self.dut_3d = self._pattern_3d.properties

    def test_scan_pattern_scan_points_coordinates(self):
        pos_x, pos_y = self._pattern_2d.scan_points()
        self.assertAlmostEqual(pos_x[0], -(self.rx / 2))
        self.assertAlmostEqual(pos_x[1], -(self.rx / 2) + (self.rx / self.number_of_ascans))
        self.assertAlmostEqual(pos_x[-1], (self.rx / 2) - (self.rx / self.number_of_ascans))

    def test_scan_pattern_property_float(self):
        self.assertAlmostEqual(self.dut.get_range_x(), self.rx)
        self.assertAlmostEqual(self.dut_3d.get_range_x(), self.rx)

        # self.assertRaises(OSError, lambda: self.dut.get_range_y()) # TODO no range_y for bscan
        self.assertAlmostEqual(self.dut_3d.get_range_y(), self.ry)

        self.assertAlmostEqual(self.dut.get_center_x(), 0.0)
        self.assertAlmostEqual(self.dut_3d.get_center_x(), 0.0)

        self.assertAlmostEqual(self.dut.get_center_y(), 0.0)
        self.assertAlmostEqual(self.dut_3d.get_center_y(), 0.0)

        self.assertAlmostEqual(self.dut.get_angle(), 0.0)
        self.assertAlmostEqual(self.dut_3d.get_angle(), 0.0)

        pos_x, pos_y = self._pattern_2d.scan_points()
        self.assertEqual(len(self._pattern_2d), len(pos_x))
        length = 0
        for i in range(len(pos_x) - 1):
            length += math.sqrt((pos_x[i + 1] - pos_x[i]) ** 2 + (pos_y[i + 1] - pos_y[i]) ** 2)

        self.assertAlmostEqual(self.dut.get_mean_length(), length)
        self.assertAlmostEqual(self.dut_3d.get_mean_length(), length)


class TestScanPatternScanPoints(ScanPatternTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self._pattern_2d.scan_points_factory
        self.dut_3d = self._pattern_3d.scan_points_factory

    def test_scan_pattern_scan_points_interpolate(self):
        new_size = 200
        pos_x, pos_y = self._pattern_2d.scan_points()
        interp_x, interp_y = self.dut.interpolate_2d(pos_x, pos_y, new_size, InterpolationMethod.LINEAR,
                                                     BoundaryCondition.STANDARD)
        interval_x = self.rx / 200
        self.assertEqual(len(interp_x), new_size)
        self.assertEqual(pos_x[0], interp_x[0])
        self.assertAlmostEqual(pos_x[-1], interp_x[-1])
        self.assertAlmostEqual(round(interp_x[1], 3), -(self.rx / 2.0) + interval_x)

    def test_scan_pattern_scan_points_inflate(self):
        pos_x, pos_y = self._pattern_2d.scan_points()
        inflated_x, inflated_y = self.dut.inflate(pos_x, pos_y, self.number_of_bscans, self.ry,
                                                  InflationMethod.NORMAL_DIR)
        pos_x_3d, pos_y_3d = self._pattern_3d.scan_points()
        self.assertAlmostEqual(inflated_x[1], pos_x_3d[1])
        self.assertAlmostEqual(inflated_y[3] + (self.ry / 2), pos_y_3d[3])

    def test_scan_patten_scan_points_from_file(self):
        pos_x, pos_y = self._pattern_2d.scan_points()
        scan_indices = np.zeros(len(pos_x))
        sp_file_path = 'C:\\tmp\\test_pattern_scan_points_to_file.txt'
        self.dut.save_to_file(pos_x, pos_y, scan_indices, sp_file_path, ScanPointsDataFormat.TXT)

        self.assertEqual(self.dut.get_size_from_file(sp_file_path, ScanPointsDataFormat.TXT), len(pos_x))

        loaded_pos_x, loaded_pos_y, loaded_indices = self.dut.load_from_file(sp_file_path, ScanPointsDataFormat.TXT)
        self.assertAlmostEqual(loaded_pos_x[10], pos_x[10])
        self.assertAlmostEqual(loaded_pos_y[21], pos_y[21])

        if exists(sp_file_path):
            remove(sp_file_path)

    def test_scan_patten_scan_points_from_data(self):
        sp_x, sp_y = self._pattern_2d.scan_points()
        sp_indices = np.zeros(self._pattern_2d.size())
        sp_data = self.dut.set_to_data(sp_x, sp_y, sp_indices)
        self.assertIsInstance(sp_data, RealData)

        self.assertEqual(self.dut.get_size_from_data(sp_data), self._pattern_2d.size())

        pos_x, pos_y = self._pattern_2d.scan_points()
        loaded_pos_x, loaded_pos_y, loaded_indices = self.dut.load_from_data(sp_data)
        self.assertAlmostEqual(round(loaded_pos_x[10], 7), pos_x[10])
        self.assertAlmostEqual(round(loaded_pos_y[21], 7), pos_y[21])


class TestScanPatternLUT(ScanPatternTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self._pattern_2d.LUT

    def test_scan_pattern_lut(self):
        self.assertEqual(self.dut.size(), self.number_of_ascans + 20 + 25 + 20)

        volt_x, volt_y = self.dut.get()
        self.assertEqual(len(volt_x), self.dut.size())

        sp_indices = np.zeros(self.dut.size())
        file_path = 'C:\\tmp\\Test_Pattern_LUT_save.txt'
        self.dut.save_to_file(sp_indices, file_path, ScanPointsDataFormat.TXT)
        self.assertTrue(exists(file_path),
                        "The file does not exist in the specified directory")
        if exists(file_path):
            remove(file_path)


class TestScanPattern(ScanPatternTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self._pattern_2d

    def tearDown(self):
        del self.dut
        super().tearDown()

    def test_scan_pattern_acquisition_time(self):
        scan_rates = self.dev.presets.get_presets_in_category(0)
        print(scan_rates)
        # assume 10 kh scan rate
        scan_rate = 1 / 10000
        avg = 1
        t_ascan = 1 / scan_rate
        t_flyback = 2e-3
        t_apo = 25 * avg * scan_rate
        t_scan = self.dut.size() / t_ascan
        t_bscan = (2 * t_flyback + t_apo + t_scan) * avg
        self.assertAlmostEqual(self.dut.exp_acquisition_time(self.dev), t_bscan)

    def test_scan_pattern_acq_type(self):
        self.assertTrue(self.dut.is_acquisition_type_available(AcqType.ASYNC_FINITE))
        self.assertTrue(self.dut.is_acquisition_type_available(AcqType.ASYNC_CONTINUOUS))
        self.assertTrue(self.dut.is_acquisition_type_available(AcqType.SYNC))

    def test_scan_pattern_check_memory(self):
        bytes_per_pixel = self.dev.properties.get_bytes_per_element()
        spectrum_elements = self.dev.properties.get_spectrum_elements()
        scan_point_size = self.dut.LUT.size()
        req_memory = bytes_per_pixel * spectrum_elements * scan_point_size

        self.assertAlmostEqual(self.dut.memory_requirements(self.dev, AcqType.ASYNC_FINITE), req_memory)
        self.assertTrue(self.dut.check_available_memory_for_raw_data(self.dev, 0))

    def test_scan_pattern_modification(self):
        self.assertEqual(self.dut.properties.get_angle(), 0.0)
        self.dut.rotate(45 * np.pi / 180)
        self.assertEqual(self.dut.properties.get_angle(), 45.0 * np.pi / 180)

        self.assertEqual(self.dut.properties.get_center_x(), 0.0)
        self.dut.shift(2.0, -1.0, False)
        self.assertEqual(self.dut.properties.get_center_x(), 2.0)

        self.assertEqual(self.dut.properties.get_range_x(), self.rx)
        self.dut.zoom(3.7)

    def test_scan_pattern_update(self):
        self.dut.rotate(45 * np.pi / 180)
        self.dut.shift(2.0, -1.0)
        self.dut.zoom(3.7)
        self.dut.update()

    def test_scan_pattern_on_device(self):
        # TODO: What does this actually do?
        self.dut.visualize_on_device(self.dev, self.probe, True)

    def test_scan_pattern_on_image(self):
        vid_img = self.dev.camera.get_image()
        self.dut.visualize_on_image(self.probe, vid_img)
        plt.figure()
        plt.imshow(vid_img.to_numpy())
        if ENABLE_PLOTS:
            plt.show()
        else:
            plt.close()


if __name__ == '__main__':
    unittest.main()
