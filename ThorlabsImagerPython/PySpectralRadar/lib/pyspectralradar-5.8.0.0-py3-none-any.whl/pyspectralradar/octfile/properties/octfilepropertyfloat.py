from enum import IntEnum

from pyspectralradar.base.propertygetter import FloatPropertyGetter
from pyspectralradar.base.propertysetter import FloatPropertySetter
from pyspectralradar.spectralradar import sr


class MetadataFloat(IntEnum):
    """Enum identifying file metadata fields of floating point type"""

    REFRACTIVE_INDEX = 0
    """The refractive index applied to the whole image."""

    RANGE_X = 1
    """The FOV in axial direction (x) in mm."""

    RANGE_Y = 2
    """The FOV in axial direction (y) in mm."""

    RANGE_Z = 3
    """The FOV in longitudinal axis (z) in mm."""

    CENTER_X = 4
    """The center of the scan pattern in axial direction (x) in mm."""

    CENTER_Y = 5
    """The center of the scan pattern in axial direction (y) in mm."""

    ANGLE = 6
    """The angle between the scanner and the video camera image."""

    BIN_ELECTRON_SCALING = 7
    """Ratio between the binary value from the camera to the count of electrons."""

    CENTRAL_WAVELENGTH_NM = 8
    """Central wavelength of the device."""

    SOURCE_BANDWIDTH_NM = 9
    """Bandwidth of the light source."""

    MIN_ELECTRONS = 10
    """Electron cut-off parameter used for processing"""

    QUADRATIC_DISPERSION_CORRECTION_FACTOR = 11
    """Quadratic dispersion factor used for dispersion correction"""

    SPECKLE_VARIANCE_THRESHOLD = 12
    """Threshold for speckle variance mode."""

    SCAN_TIME_SEC = 13
    """Time needed for data acquisition. The processing and saving time is not included."""

    REFERENCE_INTENSITY = 14
    """Value for the reference intensity."""

    SCAN_PAUSE_SEC = 15
    """Scan pause in between scans"""

    ZOOM = 16
    """Zooms the scan pattern."""

    MIN_POINT_DISTANCE = 17
    """Minimum distance between two points of the scan pattern used for freeform scan patterns."""

    MAX_POINT_DISTANCE = 18
    """Maximum distance between two points of the scan pattern used for freeform scan patterns."""

    FFT_OVERSAMPLING = 19
    """FFT oversampling use for processing and chirp correction"""

    FULL_WELL_CAPACITY = 20
    """Sets/indicates the full-well capacity of the device used for acquiring the data."""

    SATURATION = 21
    """Sets/indicates the value of the relative saturation that was computed when acquiring the data.
    Warning: Not all devices evaluate the saturation during acquisition (Sweep-Source devices do).
    :func:`Processing.relative_saturation`."""

    CAMERA_LINE_RATE_HZ = 22
    """Sets/indicates the line rate during acquisition"""

    PMD_CORRECTION_ANGLE_RAD = 23
    """Polarization mode correction. This angle (expressed in radians) is used to compute a phasor
    (\f$\exp(i\alpha)\f$), that will be applied to the complex reflectivity vector associated with camera 0."""

    OPTIC_AXIS_OFFSET_RAD = 24
    """In birefringent samples, this offset allows referring the angle of the fast axis to an axis in the sample
            holder."""

    REFERENCE_LENGTH_MM = 25
    """Reference stage position, if adjustable reference stage is available"""

    REFERENCE_INTENSITY_CONTROL_VALUE = 26
    """Position of reference intensity control, if available"""

    POL_ADJUSTMENT_QUARTER_WAVE = 27
    """Position of quarter wave polarization adjustment, if available"""

    POL_ADJUSTMENT_HALF_WAVE = 28
    """Position of half-wave polarization adjustment, if available"""

    # TODO: not supported in release version
    REL_INTERFERENCE_AMP = 29
    """Sets/indicates the value of the relative interference amplitude that was computed when acquiring the data.
    Warning: Not all devices evaluate the relative amplitude during acquisition (Sweep-Source devices do).
    function :func:`getRelativeInterferenceAmplitude`."""


class OCTFilePropertyFloat(FloatPropertyGetter, FloatPropertySetter):

    def __init__(self, handle):
        FloatPropertyGetter.__init__(self, handle, sr.getFileMetadataFloat)
        FloatPropertySetter.__init__(self, handle, sr.setFileMetadataFloat)

    def get_refractive_index(self) -> float:
        """The refractive index applied to the whole image."""
        return self._get(MetadataFloat.REFRACTIVE_INDEX)

    def set_refractive_index(self, value: float):
        """The refractive index applied to the whole image."""
        self._set(MetadataFloat.REFRACTIVE_INDEX, value)

    def get_range_x(self) -> float:
        """The FOV in axial direction (x) in mm."""
        return self._get(MetadataFloat.RANGE_X)

    def set_range_x(self, value: float):
        """The FOV in axial direction (x) in mm."""
        self._set(MetadataFloat.RANGE_X, value)

    def get_range_y(self) -> float:
        """The FOV in axial direction (y) in mm."""
        return self._get(MetadataFloat.RANGE_Y)

    def set_range_y(self, value: float):
        """The FOV in axial direction (y) in mm."""
        self._set(MetadataFloat.RANGE_Y, value)

    def get_range_z(self) -> float:
        """The FOV in longitudinal axis (z) in mm."""
        return self._get(MetadataFloat.RANGE_Z)

    def set_range_z(self, value: float):
        """The FOV in longitudinal axis (z) in mm."""
        self._set(MetadataFloat.RANGE_Z, value)

    def get_center_x(self) -> float:
        """The center of the scan pattern in axial direction (x) in mm."""
        return self._get(MetadataFloat.CENTER_X)

    def set_center_x(self, value: float):
        """The center of the scan pattern in axial direction (x) in mm."""
        self._set(MetadataFloat.CENTER_X, value)

    def get_center_y(self) -> float:
        """The center of the scan pattern in axial direction (y) in mm."""
        return self._get(MetadataFloat.CENTER_Y)

    def set_center_y(self, value: float):
        """The center of the scan pattern in axial direction (y) in mm."""
        self._set(MetadataFloat.CENTER_Y, value)

    def get_angle(self) -> float:
        """The angle between the scanner and the video camera image."""
        return self._get(MetadataFloat.ANGLE)

    def set_angle(self, value: float):
        """The angle between the scanner and the video camera image."""
        self._set(MetadataFloat.ANGLE, value)

    def get_bin_electron_scaling(self) -> float:
        """Ratio between the binary value from the camera to the count of electrons."""
        return self._get(MetadataFloat.BIN_ELECTRON_SCALING)

    def set_bin_electron_scaling(self, value: float):
        """Ratio between the binary value from the camera to the count of electrons."""
        self._set(MetadataFloat.BIN_ELECTRON_SCALING, value)

    def get_central_wavelength_nm(self) -> float:
        """Central wavelength of the device."""
        return self._get(MetadataFloat.CENTRAL_WAVELENGTH_NM)

    def set_central_wavelength_nm(self, value: float):
        """Central wavelength of the device."""
        self._set(MetadataFloat.CENTRAL_WAVELENGTH_NM, value)

    def get_source_bandwidth_nm(self) -> float:
        """Bandwidth of the light source."""
        return self._get(MetadataFloat.SOURCE_BANDWIDTH_NM)

    def set_source_bandwidth_nm(self, value: float):
        """Bandwidth of the light source."""
        self._set(MetadataFloat.SOURCE_BANDWIDTH_NM, value)

    def get_min_electrons(self) -> float:
        """Electron cut-off parameter used for processing"""
        return self._get(MetadataFloat.MIN_ELECTRONS)

    def set_min_electrons(self, value: float):
        """Electron cut-off parameter used for processing"""
        self._set(MetadataFloat.MIN_ELECTRONS, value)

    def get_quadratic_dispersion_correction_factor(self) -> float:
        """Quadratic dispersion factor used for dispersion correction"""
        return self._get(MetadataFloat.QUADRATIC_DISPERSION_CORRECTION_FACTOR)

    def set_quadratic_dispersion_correction_factor(self, value: float):
        """Quadratic dispersion factor used for dispersion correction"""
        self._set(MetadataFloat.QUADRATIC_DISPERSION_CORRECTION_FACTOR, value)

    def get_speckle_variance_threshold(self) -> float:
        """Threshold for speckle variance mode."""
        return self._get(MetadataFloat.SPECKLE_VARIANCE_THRESHOLD)

    def set_speckle_variance_threshold(self, value: float):
        """Threshold for speckle variance mode."""
        self._set(MetadataFloat.SPECKLE_VARIANCE_THRESHOLD, value)

    def get_scan_time_sec(self) -> float:
        """Time needed for data acquisition. The processing and saving time is not included."""
        return self._get(MetadataFloat.SCAN_TIME_SEC)

    def set_scan_time_sec(self, value: float):
        """Time needed for data acquisition. The processing and saving time is not included."""
        self._set(MetadataFloat.SCAN_TIME_SEC, value)

    def get_reference_intensity(self) -> float:
        """Value for the reference intensity."""
        return self._get(MetadataFloat.REFERENCE_INTENSITY)

    def set_reference_intensity(self, value: float):
        """Value for the reference intensity."""
        self._set(MetadataFloat.REFERENCE_INTENSITY, value)

    def get_scan_pause_sec(self) -> float:
        """Scan pause in between scans"""
        return self._get(MetadataFloat.SCAN_PAUSE_SEC)

    def set_scan_pause_sec(self, value: float):
        """Scan pause in between scans"""
        self._set(MetadataFloat.SCAN_PAUSE_SEC, value)

    def get_zoom(self) -> float:
        """Zooms the scan pattern."""
        return self._get(MetadataFloat.ZOOM)

    def set_zoom(self, value: float):
        """Zooms the scan pattern."""
        self._set(MetadataFloat.ZOOM, value)

    def get_min_point_distance(self) -> float:
        """Minimum distance between two points of the scan pattern used for freeform scan patterns."""
        return self._get(MetadataFloat.MIN_POINT_DISTANCE)

    def set_min_point_distance(self, value: float):
        """Minimum distance between two points of the scan pattern used for freeform scan patterns."""
        self._set(MetadataFloat.MIN_POINT_DISTANCE, value)

    def get_max_point_distance(self) -> float:
        """Maximum distance between two points of the scan pattern used for freeform scan patterns."""
        return self._get(MetadataFloat.MAX_POINT_DISTANCE)

    def set_max_point_distance(self, value: float):
        """Maximum distance between two points of the scan pattern used for freeform scan patterns."""
        self._set(MetadataFloat.MAX_POINT_DISTANCE, value)

    def get_fft_oversampling(self) -> float:
        """FFT oversampling use for processing and chirp correction"""
        return self._get(MetadataFloat.FFT_OVERSAMPLING)

    def set_fft_oversampling(self, value: float):
        """FFT oversampling use for processing and chirp correction"""
        self._set(MetadataFloat.FFT_OVERSAMPLING, value)

    def get_full_well_capacity(self) -> float:
        """Sets/indicates the full-well capacity of the device used for acquiring the data."""
        return self._get(MetadataFloat.FULL_WELL_CAPACITY)

    def set_full_well_capacity(self, value: float):
        """Sets/indicates the full-well capacity of the device used for acquiring the data."""
        self._set(MetadataFloat.FULL_WELL_CAPACITY, value)

    def get_saturation(self) -> float:
        """Sets/indicates the value of the relative saturation that was computed when acquiring the data.
        Warning: Not all devices evaluate the saturation during acquisition (Sweep-Source devices do).
        :func:`Processing.relative_saturation`."""
        return self._get(MetadataFloat.SATURATION)

    def set_saturation(self, value: float):
        """Sets/indicates the value of the relative saturation that was computed when acquiring the data.
        Warning: Not all devices evaluate the saturation during acquisition (Sweep-Source devices do).
        :func:`Processing.relative_saturation`."""
        self._set(MetadataFloat.SATURATION, value)

    def get_camera_line_rate_hz(self) -> float:
        """Sets/indicates the line rate during acquisition"""
        return self._get(MetadataFloat.CAMERA_LINE_RATE_HZ)

    def set_camera_line_rate_hz(self, value: float):
        """Sets/indicates the line rate during acquisition"""
        self._set(MetadataFloat.CAMERA_LINE_RATE_HZ, value)

    def get_pmd_correction_angle_rad(self) -> float:
        """Polarization mode correction. This angle (expressed in radians) is used to compute a phasor
        (exp<sup>(i/alpha)</sup>), that will be applied to the complex reflectivity vector associated with camera 0."""
        return self._get(MetadataFloat.PMD_CORRECTION_ANGLE_RAD)

    def set_pmd_correction_angle_rad(self, value: float):
        """Polarization mode correction. This angle (expressed in radians) is used to compute a phasor
        (exp<sup>(i/alpha)</sup>), that will be applied to the complex reflectivity vector associated with camera 0."""
        self._set(MetadataFloat.PMD_CORRECTION_ANGLE_RAD, value)

    def get_optic_axis_offset_rad(self) -> float:
        """In birefringent samples, this offset allows referring the angle of the fast axis to an axis in the sample
        holder."""
        return self._get(MetadataFloat.OPTIC_AXIS_OFFSET_RAD)

    def set_optic_axis_offset_rad(self, value: float):
        """In birefringent samples, this offset allows referring the angle of the fast axis to an axis in the sample
        holder."""
        self._set(MetadataFloat.OPTIC_AXIS_OFFSET_RAD, value)

    def get_reference_length_mm(self) -> float:
        """Reference stage position, if adjustable reference stage is available"""
        return self._get(MetadataFloat.REFERENCE_LENGTH_MM)

    def set_reference_length_mm(self, value: float):
        """Reference stage position, if adjustable reference stage is available"""
        self._set(MetadataFloat.REFERENCE_LENGTH_MM, value)

    def get_reference_intensity_control_value(self) -> float:
        """Position of reference intensity control, if available"""
        return self._get(MetadataFloat.REFERENCE_INTENSITY_CONTROL_VALUE)

    def set_reference_intensity_control_value(self, value: float):
        """Position of reference intensity control, if available"""
        self._set(MetadataFloat.REFERENCE_INTENSITY_CONTROL_VALUE, value)

    def get_pol_adjustment_quarter_wave(self) -> float:
        """Position of quarter wave polarization adjustment, if available"""
        return self._get(MetadataFloat.POL_ADJUSTMENT_QUARTER_WAVE)

    def set_pol_adjustment_quarter_wave(self, value: float):
        """Position of quarter wave polarization adjustment, if available"""
        self._set(MetadataFloat.POL_ADJUSTMENT_QUARTER_WAVE, value)

    def get_pol_adjustment_half_wave(self) -> float:
        """Position of half-wave polarization adjustment, if available"""
        return self._get(MetadataFloat.POL_ADJUSTMENT_HALF_WAVE)

    def set_pol_adjustment_half_wave(self, value: float):
        """Position of half-wave polarization adjustment, if available"""
        self._set(MetadataFloat.POL_ADJUSTMENT_HALF_WAVE, value)

    def get_rel_interference_amp(self) -> float:
        """Sets/indicates the value of the relative interference amplitude that was computed when acquiring the data.
        Warning: Not all devices evaluate the relative amplitude during acquisition (Sweep-Source devices do).
        function :func:`getRelativeInterferenceAmplitude`."""
        # return self._get(MetadataFloat.REL_INTERFERENCE_AMP)
        raise NotImplemented('Still under development')

    def set_rel_interference_amp(self, value: float):
        """Sets/indicates the value of the relative interference amplitude that was computed when acquiring the data.
        Warning: Not all devices evaluate the relative amplitude during acquisition (Sweep-Source devices do).
        function :func:`getRelativeInterferenceAmplitude`."""
        # self._set(MetadataFloat.REL_INTERFERENCE_AMP, value)
        raise NotImplemented('Still under development')
