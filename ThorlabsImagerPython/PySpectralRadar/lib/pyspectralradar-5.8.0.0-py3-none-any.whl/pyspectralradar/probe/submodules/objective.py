from ctypes import c_char_p, c_int, create_string_buffer

from pyspectralradar.base import Submodule
from pyspectralradar.probe.properties import ObjectiveProperties
from pyspectralradar.spectralradar import get_error, sr


class Objective(Submodule):

    def __init__(self, handle, probe_type_name: str, objective_name: str):
        super().__init__(handle)
        self._probe_name = probe_type_name
        self._objective_name = objective_name
        self.properties: ObjectiveProperties = ObjectiveProperties(self.handle, self._objective_name)

    def get_display_name(self) -> str:
        """Returns the display name for the current objective specified

        Returns:
            The display name as string.
        """
        str_size = 1024
        display_name = create_string_buffer(str_size)
        sr.getObjectiveDisplayName.argtypes = [c_char_p, c_char_p, c_int]
        sr.getObjectiveDisplayName(c_char_p(bytes(self._objective_name, encoding="ascii")), display_name, str_size)
        get_error()
        return display_name.value.decode('UTF-8')[1:-1]

    def get_number_of_compatible_objective(self) -> int:
        """Returns the number of objectives compatible with the specified objective mount.

        Returns:
            The number of compatible objectives.
        """
        sr.getNumberOfCompatibleObjectives.restype = c_int
        sr.getNumberOfCompatibleObjectives.argtypes = [c_char_p]
        res = sr.getNumberOfCompatibleObjectives(c_char_p(bytes(self._probe_name, encoding="ascii")))
        get_error()
        return res

    def get_compatible_objective(self, idx: int) -> str:
        """Returns the name of the specified objective for the selected probe type.

        Args:
            :idx: Selects one specific objective from all available objective for the specified probe type.

        Returns:
            Return value for the name of the objective file.
            This string is essentially the name of the corresponding ``.odf`` file, except that a version number and the
            termination will be added.
        """
        str_size = 1024
        objective_name = create_string_buffer(str_size)
        sr.getCompatibleObjective.argtypes = [c_int, c_char_p, c_char_p, c_int]
        sr.getCompatibleObjective(idx, c_char_p(bytes(self._probe_name, encoding="ascii")), objective_name, str_size)
        get_error()
        return objective_name.value.decode('UTF-8')
