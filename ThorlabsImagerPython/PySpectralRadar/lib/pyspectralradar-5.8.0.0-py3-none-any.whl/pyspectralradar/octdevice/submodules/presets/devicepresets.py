from ctypes import c_char_p, c_int
from typing import Dict

from pyspectralradar.base import Submodule
from pyspectralradar.octdevice.submodules.presets import PresetCategories
from pyspectralradar.probe import Probe
from pyspectralradar.processing import Processing
from pyspectralradar.spectralradar import c_handle, get_error, sr


class Presets(Submodule):
    """
    Different devices support different preset categories (gain, speed, etc.). When getting or setting a preset,
    the right category must be provided. To get a dictionary of supported categories containing the names and
    indices, use the function :func:`PresetCategories.get_available_categories`. To get the index of a supported
    category, provided you know the name, use the function :func:`PresetCategories.get_category_index` (this is the
    index need when getting or setting a preset of a given category).

    A dictionary containing the description of the device preset associated with a particular index can be obtained
    by invoking the function :func:`~get_presets_in_category`.
    """

    def __init__(self, handle):
        super().__init__(handle)
        self._categories = PresetCategories(handle)

        # exposes submodule methods
        self.get_available_categories = self._categories.get_available_categories

    def get_presets_in_category(self, category_idx: int) -> Dict[str, int]:
        """Get a dictionary of all available presets (and their indices) in a given category.

        Returns:
            A dictionary containing the descriptions and indices of all available presets.
        """
        n = self.get_number_of_presets_in_category(category_idx)
        presets = {self.get_preset_description(category_idx, idx): idx for idx in range(n)}
        return presets

    def get_active_preset(self, category_idx: int) -> int:
        """Gets the currently used device preset.

        Args:
            :category_idx: An index describing the preset category in the range between 0 and the number of preset
                categories minus 1, given by the dictionaries :func:`~get_presets_in_category` length

        Returns:
            The current device preset index.
        """
        sr.getDevicePreset.argtypes = [c_handle, c_int]
        sr.getDevicePreset.restype = c_int
        index = sr.getDevicePreset(self.handle, category_idx)
        get_error()
        return index

    def set_active_preset(self, category_idx: int, preset_idx: int, probe: Probe = None, proc: Processing = None):
        """Sets the preset of the device.

        Using presets the sensitivity and acquisition speed of the device can be influenced.

        \nImportant follow-up:
        After a preset change, and before an acquisition is started, the scan patterns should
        be re-created. The reason: the preset change should be propagated to the other objects in the application.
        A programmer may write an application instantiating many different scan patterns, using them differently
        as time progresses. All those objects are independent and need to be notified when important changes take
        place.

        Args:
            :category_idx: An index describing the preset category in the range between 0 and the number of preset
                categories minus 1, given by the dictionaries :func:`get_presets_in_category` length
            :preset_idx: The index of the preset.
            :probe: The used probe.
            :proc: The used processing.
        """

        sr.setDevicePreset.argtypes = [c_handle, c_int, c_handle, c_handle, c_int]
        sr.setDevicePreset(self.handle,
                           category_idx,
                           probe.handle if probe is not None else None,
                           proc.handle if proc is not None else None,
                           preset_idx
                           )
        get_error()

    def update_after_preset_change(self, probe, proc, camera_idx: int = 1):
        """Updates the processing handle after preset change. Please use :func:`set_active_preset` first for the
        first camera (with index 0) and this function to update the corresponding
        :obj:`~pyspectralradar.processing.processing.Processing` for the second camera (with index 1).

        Args:
            :probe: A handle to the probe; whose Galvo position is to be set
            :proc: A valid (non-null) processing handle
            :camera_idx: The index of the camera. The function :func:`set_active_preset` updates the
                :obj:`~pyspectralradar.processing.processing.Processing` for the first camera (with index 0)
                automatically.
        """
        sr.updateAfterPresetChange.argtypes = [c_handle, c_handle, c_handle, c_int]
        sr.updateAfterPresetChange(self.handle, probe.handle, proc.handle, camera_idx)
        get_error()

    def get_number_of_presets_in_category(self, category_idx: int) -> int:
        """Returns the number of available device presets.

        The current device preset can be obtained by invoking the function :func:`get_active_preset`. A description
        of the device preset associated with a particular index can be obtained by invoking the function
        :func:`get_preset_description`.

        Args:
            :category_idx: An index describing the preset category in the range between 0 and the number of preset
                categories minus 1, given by :func:`PresetCategories.get_number_of_categories`

        Returns:
            The number of presets supported by the OCT device.
        """
        assert isinstance(category_idx, int)
        sr.getNumberOfDevicePresets.argtypes = [c_handle, c_int]
        sr.getNumberOfDevicePresets.restype = c_int
        res = sr.getNumberOfDevicePresets(self.handle, category_idx)
        get_error()
        return res

    def get_preset_description(self, category_idx: int, preset_index: int) -> str:
        """Returns a description of the selected device preset.
        The description contains information about sensitivity and acquisition speed of the respective set.

        The current device preset can be obtained by invoking the function
        :func:`~pyspectralradar.octdevice.devicepresets.Presets.get_active_preset`. The total number of
        presets for the active device can be retrieved with the function :func:`get_number_of_presets_in_category`.

        Args:
            :category_idx: An index describing the preset category in the range between 0 and the number of preset
                categories minus 1, given by :func:`PresetCategories.get_number_of_categories)`
            :preset_index: The index of the preset.

        Returns:
            A text describing the preset (speed, sensitivity).
        """
        sr.getDevicePresetDescription.argtypes = [c_handle, c_int, c_int]
        sr.getDevicePresetDescription.restype = c_char_p
        res = sr.getDevicePresetDescription(self.handle, category_idx, preset_index).decode('ascii')
        get_error()
        return res
