from __future__ import annotations

from ctypes import c_double, c_int
from typing import TYPE_CHECKING

from pyspectralradar.base import Submodule
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import ScanAxis

if TYPE_CHECKING:
    from pyspectralradar.octdevice import OCTDevice


class Scanner(Submodule):
    def move(self, oct_device: 'OCTDevice', axis: ScanAxis, position_mm: float):
        """Manually moves the scanner to a given position

        Args:
            :oct_device: The currently used OCT device
            :axis_name: The axis in which you want to set the position manually
            :position_mm: The actual position in mm you want to move the Galvo to.
        """
        sr.moveScanner.argtypes = [c_handle, c_handle, c_int, c_double]
        sr.moveScanner(oct_device.handle, self.handle, axis, c_double(position_mm))
        get_error()

    def move_to_apo_position(self, oct_device: 'OCTDevice'):
        """Moves the scanner to the apodization position

        Args:
            :oct_device: The currently used OCT device.
        """
        sr.moveScannerToApoPosition.argtypes = [c_handle, c_handle]
        sr.moveScannerToApoPosition(oct_device.handle, self.handle)
        get_error()
