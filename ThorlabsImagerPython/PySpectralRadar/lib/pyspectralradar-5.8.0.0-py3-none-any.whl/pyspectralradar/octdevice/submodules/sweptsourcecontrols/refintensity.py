from ctypes import POINTER, c_bool, c_double, c_float, c_int
from typing import Tuple

from pyspectralradar.base import Submodule
from pyspectralradar.processing import Processing
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import WaitForCompletion


class RefIntensity(Submodule):

    def get_ctrl_value(self) -> float:
        """Gets the current reference intensity of the specified device.

        If :func:`set_ctrl_value` was used in a non-blocking fashion, the function returns the current value of the
        control, not the final target value.

        Returns:
            The current unit-less reference intensity of the selected device (0 <= reference intensity <= 1)
        """
        sr.getReferenceIntensityControlValue.argtypes = [c_handle]
        sr.getReferenceIntensityControlValue.restype = c_double
        res = sr.getReferenceIntensityControlValue(self.handle)
        get_error()
        return res

    def set_ctrl_value(self, value: float, wait: WaitForCompletion):
        """Sets the reference intensity of the specified device.

        The intensity is a unit-less value between 0 and 1, which represents the full adjustment range of the
        reference intensity control, but may or may not be linear. The control may take some time to physically reach
        the new intensity. Use the Wait parameter to choose if the function should block until the new intensity is
        reached.

        Args:
            :value: the new reference intensity value (0 <= ``value`` <= 1)
            :wait: specify ``WAIT`` to block until the new intensity ``value`` has been reached
        """
        assert isinstance(wait, WaitForCompletion)
        sr.setReferenceIntensityControlValue.argtypes = [c_handle, c_double, c_int]
        sr.setReferenceIntensityControlValue(self.handle, value, wait)
        get_error()

    def get_relative(self, proc: Processing) -> float:
        """Returns a value larger than 0.0 and smaller than 1.0 that indicates the reference intensity (relative to
        saturation) that was present when the currently used apodization was determined.

        Args:
            :proc: The used processing.

        Returns:
            The value is determined as the quotient between the reference intensity (function
            :func:`~pyspectralradar.processing.processing.Processing.get_ref_intensity`) and the full well capacity of
            the detector.
        """
        sr.getRelativeReferenceIntensity.argtypes = [c_handle, c_handle]
        sr.getRelativeReferenceIntensity.restype = c_double
        res = sr.getRelativeReferenceIntensity(self.handle, proc.handle)
        get_error()
        return res

    def is_available(self) -> bool:
        """Returns whether an automated reference intensity control is available for the specified device.

        Returns:
            ``True`` if a reference intensity control is available
        """
        sr.isReferenceIntensityControlAvailable.argtypes = [c_handle]
        sr.isReferenceIntensityControlAvailable.restype = c_bool
        res = sr.isReferenceIntensityControlAvailable(self.handle)
        get_error()
        return res

    def set_callback(self, callback):
        """Registers the callback to get notified when the reference intensity has changed.

        Args:
            :callback: Callback the Callback to register.
        """
        raise NotImplementedError

    def get_statistics(self, proc: Processing) -> Tuple[float, float]:
        """Returns two statistical interpretations of the current light intensity on the sensor.

        Args:
            proc: The used processing

        Returns:
            A tuple containing the relative intensity and the absolute intensity divided by the absolute reference
            intensity.
        """
        rel2ref_intensity = c_float()
        rel2proj_abs_intensity = c_float()
        sr.getCurrentIntensityStatistics.argtypes = [c_handle, c_handle, POINTER(c_float), POINTER(c_float)]
        sr.getCurrentIntensityStatistics(self.handle, proc.handle, rel2ref_intensity, rel2proj_abs_intensity)
        get_error()
        return rel2ref_intensity.value, rel2proj_abs_intensity.value
