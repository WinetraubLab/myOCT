from enum import IntEnum

from pyspectralradar.base.propertygetter import StaticFlagGetter, StaticFlagSetter
from pyspectralradar.spectralradar import sr


class StaticProperties(IntEnum):
    """Boolean properties of the device that can be queried before the device is initialized. Retrieved with the
    function #getStaticDeviceFlag."""

    POWER_CONTROL_AVAIL = 0
    """Read-only flag indicating if the system can be turned on/off using #setStaticDeviceFlag with the flag 
    #Device_PowerOn"""

    POWER_ON = 1
    """Write-only flag to enable or disable the device power supply."""


class DeviceStaticFlagGetter(StaticFlagGetter):
    @staticmethod
    def _get_getter():
        return sr.getStaticDeviceFlag

    @staticmethod
    def get_power_control_avail() -> bool:
        """Read-only flag indicating if the system can be turned on/off using #setStaticDeviceFlag with the flag
        #Device_PowerOn"""
        return DeviceStaticFlagGetter._get_raw(StaticProperties.POWER_CONTROL_AVAIL)


class DeviceStaticFlagSetter(StaticFlagSetter):
    @staticmethod
    def _get_setter():
        return sr.setStaticDeviceFlag

    @staticmethod
    def set_power_on(value: bool):
        """Write-only flag to enable or disable the device power supply."""
        DeviceStaticFlagSetter._set_raw(StaticProperties.POWER_ON, value)
