import unittest

import matplotlib.pyplot as plt
import numpy as np

from pyspectralradar import ComplexData, Doppler, OCTSystem, RealData, LogLevel, set_log_level
from pyspectralradar.types import AScanAnalysis, AcqType, AcquisitionOrder, ApodizationType, ComplexDataFilterType2D, \
    DataDirection, DopplerOutput

ENABLE_PLOTS = False
allowed_delta = 0.001


def _assert_elements_eq(arr: np.ndarray, ref: np.ndarray):
    if np.all(arr == ref):
        return
    delta = np.sum(np.all(arr - ref))
    if delta < allowed_delta:
        return
    raise AssertionError(f"Arrays are not equal:\n  TestArr:\t\t{arr}\n  Reference:\t{ref}\n  Delta:\t{delta}")


class ComplexDataTest(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    @staticmethod
    def _get_data():
        ref = np.array((1 + 2j, 3 + 4j, 5 + 6j), dtype=np.complex64)
        dat = ComplexData.from_numpy(ref)
        return dat, ref

    def test_cplx(self):
        dat, ref = self._get_data()
        cplx = dat.to_numpy().flatten()
        _assert_elements_eq(cplx, ref)

    def test_real(self):
        dat, ref = self._get_data()
        real = dat.real().to_numpy().flatten()
        _assert_elements_eq(real, np.real(ref))

    def test_imag(self):
        dat, ref = self._get_data()
        imag = dat.imag().to_numpy().flatten()
        _assert_elements_eq(imag, np.imag(ref))

    def test_abs(self):
        dat, ref = self._get_data()
        magni = dat.abs().to_numpy().flatten()
        _assert_elements_eq(magni, np.abs(ref))

    def test_log_abs(self):
        dat, ref = self._get_data()
        log_abs = dat.log_abs().to_numpy().flatten()
        _assert_elements_eq(log_abs, 20 * np.log(np.abs(ref)))

    def test_arg(self):
        dat, ref = self._get_data()
        argument = dat.arg().to_numpy().flatten()
        _assert_elements_eq(argument, np.angle(ref))


# TODO: Filter tests
class ComplexFilterTest(unittest.TestCase):
    dut = ComplexData()

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

        sys = OCTSystem()
        dev = sys.dev
        proc = sys.processing_factory.from_device()
        probe = sys.probe_factory.create_default()
        pattern = probe.scan_pattern.create_volume_pattern(10.0, 128, 10.0, 128, ApodizationType.ONE_FOR_ALL,
                                                           AcquisitionOrder.ACQ_ORDER_ALL)

        dev.acquisition.start(pattern, AcqType.ASYNC_FINITE)
        raw = dev.acquisition.get_raw_data()

        proc.set_data_output(cls.dut)
        proc.execute(raw)
        dev.acquisition.stop()

        del raw
        del pattern
        del proc
        del probe
        del dev
        del sys

    @classmethod
    def tearDownClass(cls):
        del cls.dut

    def test_predefined_filter_2d(self):
        doppler_proc = Doppler()
        phases = RealData()
        amps = RealData()
        doppler_proc.set_output(DopplerOutput.PHASE, phases)
        doppler_proc.set_output(DopplerOutput.AMPLITUDE, amps)
        doppler_proc.execute(self.dut)

        try:
            self.dut.filter.predefined_filter_2d(ComplexDataFilterType2D.PHASE_CONTRAST, DataDirection.DIR1)
        except ():
            print('DIR1 failed')
        try:
            self.dut.filter.predefined_filter_2d(ComplexDataFilterType2D.PHASE_CONTRAST, DataDirection.DIR2)
        except ():
            print('DIR2 failed')
        try:
            self.dut.filter.predefined_filter_2d(ComplexDataFilterType2D.PHASE_CONTRAST, DataDirection.DIR3)
        except ():
            print('DIR3 failed')

        phases2 = RealData()
        amps2 = RealData()
        doppler_proc.set_output(DopplerOutput.PHASE, phases2)
        doppler_proc.set_output(DopplerOutput.AMPLITUDE, amps2)
        doppler_proc.execute(self.dut)

        if ENABLE_PLOTS:
            plt.figure()
            plt.imshow(phases.to_numpy()[:, 0, :])
            plt.figure()
            plt.imshow(phases.to_numpy()[:, 0, :])

            plt.show()

    def test_darkfield_filter_2d(self):
        self.dut.filter.darkfield_filter_2d(2.0, DataDirection.DIR2)

    def test_brightfield_filter_2d(self):
        self.dut.filter.brightfield_filter_2d(1.0, DataDirection.DIR1)


# TODO: analyse_ascan tests
class ComplexAnalysisTest(unittest.TestCase):
    dut = ComplexData()

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

        sys = OCTSystem()
        dev = sys.dev
        proc = sys.processing_factory.from_device()
        probe = sys.probe_factory.create_default()
        pattern = probe.scan_pattern.create_bscan_pattern(10.0, 128)

        dev.acquisition.start(pattern, AcqType.ASYNC_FINITE)
        raw = dev.acquisition.get_raw_data()

        proc.set_data_output(cls.dut)
        proc.execute(raw)
        dev.acquisition.stop()

        del raw
        del pattern
        del proc
        del probe
        del dev
        del sys

    @classmethod
    def tearDownClass(cls):
        del cls.dut

    def test_analyse_ascan(self):
        sliced = self.dut.get_slice_at_index(DataDirection.DIR2, 0)

        print(type(sliced.analysis.analyze_ascan(AScanAnalysis.NOISE_DB)))

        print('NOISE_DB', sliced.analysis.analyze_ascan(AScanAnalysis.NOISE_DB))
        print('\nNOISE_ELECTRONS', sliced.analysis.analyze_ascan(AScanAnalysis.NOISE_ELECTRONS))
        print('\nPEAK_POS_PIXEL', sliced.analysis.analyze_ascan(AScanAnalysis.PEAK_POS_PIXEL))
        print('\nPEAK_POS_PHYS_UNIT', sliced.analysis.analyze_ascan(AScanAnalysis.PEAK_POS_PHYS_UNIT))
        print('\nPEAK_HEIGHT_DB', sliced.analysis.analyze_ascan(AScanAnalysis.PEAK_HEIGHT_DB))
        print('\nPEAK_WIDTH_6DB', sliced.analysis.analyze_ascan(AScanAnalysis.PEAK_WIDTH_6DB))
        print('\nPEAK_WIDTH_20DB', sliced.analysis.analyze_ascan(AScanAnalysis.PEAK_WIDTH_20DB))
        print('\nPEAK_WIDTH_40DB', sliced.analysis.analyze_ascan(AScanAnalysis.PEAK_WIDTH_40DB))
        print('\nPEAK_PHASE', sliced.analysis.analyze_ascan(AScanAnalysis.PEAK_PHASE))
        print('\nPEAK_REAL_PART', sliced.analysis.analyze_ascan(AScanAnalysis.PEAK_REAL_PART))
        print('\nPEAK_IMAG_PART', sliced.analysis.analyze_ascan(AScanAnalysis.PEAK_IMAG_PART))


if __name__ == '__main__':
    unittest.main()
