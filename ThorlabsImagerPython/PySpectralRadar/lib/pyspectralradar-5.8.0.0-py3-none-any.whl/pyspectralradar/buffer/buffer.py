from ctypes import c_int

from pyspectralradar.base import HandleManagerWithDefaultConstructor
from pyspectralradar.data import ColoredData, RealData
from pyspectralradar.spectralradar import c_handle, get_error, sr


class Buffer(HandleManagerWithDefaultConstructor):
    """Holds functions for acquiring camera video images."""

    @property
    def _create_handle_func(self):
        return sr.createMemoryBuffer

    def __init__(self, handle: c_handle = None):
        """Creates a buffer holding data and colored data.

        :Warning: Buffers silently discard data when low on system memory. Caution when using buffers is strongly
        advised!

        """
        super().__init__(handle)

    @property
    def _del_func(self):
        """Clears the buffer and frees all data and colored data objects in it.

        If the handle is a nullptr, this function does nothing.
        """
        return sr.clearBuffer

    def append_to_buffer(self, data: RealData, colored_data: ColoredData):
        """Appends specified data and colored data to the requested buffer.

        :Warning: If insufficient memory is available the oldest items in the buffer will be freed automatically.
        """
        sr.appendToBuffer.argtypes = [c_handle, c_handle, c_handle]
        sr.appendToBuffer(self.handle, data.handle, colored_data.handle)
        get_error()

    def purge(self):
        """Discards all data."""
        sr.purgeBuffer.argtypes = [c_handle]
        sr.purgeBuffer(self.handle)
        get_error()

    def size(self) -> int:
        """
        Returns the currently available data sets in the buffer.

        Returns:
            The size of the available data within buffer.
        """
        sr.getBufferSize.restype = c_int
        sr.getBufferSize.argtypes = [c_handle]
        res = sr.getBufferSize(self.handle)
        get_error()
        return res

    def first_index(self) -> int:
        """
        Returns the index of the first data sets available in the buffer.

        Returns:
            The first data sets index.
        """
        sr.getBufferFirstIndex.restype = c_int
        sr.getBufferFirstIndex.argtypes = [c_handle]
        res = sr.getBufferFirstIndex(self.handle)
        get_error()
        return res

    def last_index(self) -> int:
        """
        Returns the index of the last data sets available in the buffer.

        Returns:
            The last data sets index.
        """
        sr.getBufferLastIndex.restype = c_int
        sr.getBufferLastIndex.argtypes = [c_handle]
        res = sr.getBufferLastIndex(self.handle)
        get_error()
        return res

    def get_real_data(self, idx: int) -> RealData:
        """Returns the data in the buffer.

        Args:
            :idx: Buffer index

        Returns:
            The data in the buffer as :class:`~pyspectralradar.data.realdata.RealData` object.
        """
        sr.getBufferData.restype = c_handle
        sr.getBufferData.argtypes = [c_handle, c_int]
        handle = sr.getBufferData(self.handle, idx)
        get_error()
        return RealData(handle)

    def get_colored_data(self, idx: int) -> ColoredData:
        """Returns the colored data in the buffer.

        Args:
            :idx: Buffer index

        Results:
            The data in the buffer as :class:`~pyspectralradar.data.coloreddata.ColoredData` object.
        """
        sr.getColoredBufferData.restype = c_handle
        sr.getColoredBufferData.argtypes = [c_handle, c_int]
        handle = sr.getColoredBufferData(self.handle, idx)
        get_error()
        return ColoredData(handle)
