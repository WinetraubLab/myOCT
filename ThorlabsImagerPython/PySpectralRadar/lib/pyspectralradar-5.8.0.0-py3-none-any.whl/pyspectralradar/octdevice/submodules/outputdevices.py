from ctypes import POINTER, c_bool, c_char_p, c_double, c_int, create_string_buffer
from typing import Dict, Tuple

from pyspectralradar.base import Submodule
from pyspectralradar.spectralradar import c_handle, get_error, sr


class OutputDevices(Submodule):
    """Class containing Functions to inquire, setup and generate output values. Whether this functionality is
    supported, and to what extent, depends on the hardware."""

    DEFAULT_NAME_BUFFER_SIZE = 1024
    DEFAULT_UNIT_BUFFER_SIZE = DEFAULT_NAME_BUFFER_SIZE

    def get_names_and_units(self) -> Tuple[Dict[str, int], Dict[int, str]]:
        """Retrieves all available devices and their units

        Returns:
            Two dictionaries (``names``, ``units``) where the first one (``names``) maps device names to their
            corresponding indices, and the second one (``units``) maps device indices to their units
        """
        n = self._get_number_output_values()
        names = {}
        units = {}
        for i in range(n):
            name, unit = self._get_name_and_unit(i)
            names.update({name: i})
            units.update({i: unit})
        return names, units

    def does_value_exist(self, name: str) -> bool:
        """Returns whether the requested output device values exists or not.

        Args:
            :name: The name of the output device

        Returns:
            ``True`` if the device value exists.
        """
        sr.doesOutputDeviceValueExist.argtypes = [c_handle, c_char_p]
        sr.doesOutputDeviceValueExist.restype = c_bool
        res = sr.doesOutputDeviceValueExist(self.handle, c_char_p(bytes(name, encoding="ascii")))
        get_error()
        return res

    def get_value_range_by_name(self, name: str):
        """Gives the range of the specified output value.

        Args:
            :name: The name of the output device

        Returns:
            A tuple containing the minimum and maximum output value.
        """
        c_min = c_double()
        c_max = c_double()
        sr.getOutputDeviceValueRangeByName.argtypes = [c_handle, c_char_p, POINTER(c_double), POINTER(c_double)]
        sr.getOutputDeviceValueRangeByName(self.handle, c_char_p(bytes(name, encoding="ascii")), c_min, c_max)
        get_error()
        return c_min.value, c_max.value

    def get_value_range_by_index(self, idx: int):
        """Gives the range of the specified output value.

        Args:
            :idx: The index of the output device

        Returns:
            A tuple containing the minimum and maximum output value.
        """
        c_min = c_double()
        c_max = c_double()
        sr.getOutputDeviceValueRangeByIndex.argtypes = [c_handle, c_int, POINTER(c_double), POINTER(c_double)]
        sr.getOutputDeviceValueRangeByIndex(self.handle, idx, c_min, c_max)
        get_error()
        return c_min.value, c_max.value

    def set_value_by_name(self, name: str, value: float):
        """Sets the specified output value.

        Args:
            :name: The name of the output device
            :value: The value to be set for the specified output device
        """
        sr.setOutputDeviceValueByName.argtypes = [c_handle, c_char_p, c_double]
        sr.setOutputDeviceValueByName(self.handle, c_char_p(bytes(name, encoding="ascii")), value)
        get_error()

    def set_value_by_index(self, idx: int, value: float):
        """Sets the value of the selected ADC.

        Args:
            :idx: The index of the internal device value. The index is a running number, starting with 0
            :value: The internal device value.
        """
        sr.setOutputDeviceValueByIndex.argtypes = [c_handle, c_int, c_double]
        sr.setOutputDeviceValueByIndex(self.handle, idx, value)
        get_error()

    def _get_number_output_values(self):
        """Returns the number of output values.

        Returns:
            The number of putput values.
        """
        sr.getNumberOfOutputDeviceValues.argtypes = [c_handle]
        sr.getNumberOfOutputDeviceValues.restype = c_int
        res = sr.getNumberOfOutputDeviceValues(self.handle)
        get_error()
        return res

    def _get_name_and_unit(self, index: int, max_name_string_size: int = DEFAULT_NAME_BUFFER_SIZE,
                           max_unit_string_size: int = DEFAULT_UNIT_BUFFER_SIZE) -> Tuple[str, str]:
        """Returns names and unit for the specified output device.

        Args:
            :index: The index of the internal value whose name and unit are sought
            :max_name_string_size: The maximal number of bytes that will be copied onto the array holding the name
            :max_unit_string_size: The maximal number of bytes that will be copied onto the array holding the unit

        Returns:
            A tuple containing the names and units of the specified output device.
        """
        name = create_string_buffer(max_name_string_size)
        unit = create_string_buffer(max_unit_string_size)
        sr.getOutputDeviceValueName.argtypes = [c_handle, c_int, c_char_p, c_int, c_char_p, c_int]
        sr.getOutputDeviceValueName(self.handle, index, name, max_name_string_size, unit, max_unit_string_size)
        get_error()
        return name.value.decode('UTF-8'), unit.value.decode('UTF-8')
