import abc
from ctypes import POINTER, c_float, c_int
from typing import Self

from pyspectralradar.base import HandleManagerWithDefaultConstructor
from pyspectralradar.data.utility import AbstractDataFileIo, NumpyConvertible
from pyspectralradar.spectralradar import c_handle, get_error
from pyspectralradar.types import DataDirection


class AbstractData(HandleManagerWithDefaultConstructor, NumpyConvertible, AbstractDataFileIo):
    """Abstract base class for OCT data (raw and processed) structures"""

    def append(self, data: Self, direction: DataDirection):
        """Appends the new data to the provided data, perpendicular to the specified direction.

        Args:
            :data: A valid :class:`AbstractData` object of the new data. These data will
                not be modified.
            :direction: The physical direction (:class:`~pyspectralradar.types.datatypes.DataDirection`) along which
                the existing data will be expanded in order to accommodate the new data. Currently,
                the :obj:`~pyspectralradar.types.datatypes.DataDirection.DataDirection.DIR1` (usually the Z-axis) is
                not supported and should not be specified.

        Appending data implies expanding the number of data and also their physical range. These expansions are
        carried out automatically before the function returns.
        """
        append_func = self._c_append_func
        append_func.argtypes = [c_handle, c_handle, c_int]
        append_func(self.handle, data.handle, c_int(direction))
        get_error()

    def pointer(self):
        """Pointer to the data"""
        func = self._pointer_func
        func.argtypes = [c_handle]
        func.restype = POINTER(c_float)
        res = func(self.handle)
        get_error()
        return res

    def reserve(self, size1: int, size2: int, size3: int):
        """Reserves memory for the data"""
        reserve_func = self._reserve_func
        reserve_func.argtypes = [c_handle, c_int, c_int, c_int]
        reserve_func(self.handle, c_int(size1), c_int(size2), c_int(size3))
        get_error()

    def clone(self) -> Self:
        """Clones the current data

        Returns:
            A clone of the current data.
        """
        clone = type(self)()
        self._copy_func.argtypes = [c_handle, c_handle]
        self._copy_func(self.handle, clone.handle)
        get_error()
        return clone

    @property
    @abc.abstractmethod
    def _copy_func(self):
        raise NotImplementedError

    @property
    @abc.abstractmethod
    def _c_append_func(self):
        raise NotImplementedError

    @property
    @abc.abstractmethod
    def _pointer_func(self):
        raise NotImplementedError

    @property
    @abc.abstractmethod
    def _reserve_func(self):
        raise NotImplementedError
