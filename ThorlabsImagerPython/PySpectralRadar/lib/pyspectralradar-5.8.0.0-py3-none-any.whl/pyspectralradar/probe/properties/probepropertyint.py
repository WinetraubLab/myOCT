from enum import IntEnum

from pyspectralradar.base.propertygetter import IntPropertyGetter
from pyspectralradar.base.propertysetter import IntPropertySetter
from pyspectralradar.spectralradar import sr


class PropertyInt(IntEnum):
    """Parameters describing the behaviour of the Probe, such as calibration factors and scan parameters."""

    APODIZATION_CYCLES = 0
    """The number of cycles used for apodization."""

    OVERSAMPLING = 1
    """A factor used as oversampling."""

    OVERSAMPLING_SLOW_AXIS = 2
    """A factor used as oversampling of the slow scanner axis."""

    SPECKLE_REDUCTION = 3
    """Number of speckles that are scanned over for averaging. Requires Oversampling >= SpeckleReduction"""


class ProbePropertyInt(IntPropertyGetter, IntPropertySetter):
    """Parameters describing the behaviour of the Probe, such as calibration factors and scan parameters."""

    def __init__(self, handle):
        IntPropertyGetter.__init__(self, handle, sr.getProbeParameterInt)
        IntPropertySetter.__init__(self, handle, sr.setProbeParameterInt)

    def get_apodization_cycles(self) -> int:
        """The number of cycles used for apodization."""
        return self._get(PropertyInt.APODIZATION_CYCLES)

    def set_apodization_cycles(self, value: int):
        """The number of cycles used for apodization."""
        self._set(PropertyInt.APODIZATION_CYCLES, value)

    def get_oversampling(self) -> int:
        """A factor used as oversampling."""
        return self._get(PropertyInt.OVERSAMPLING)

    def set_oversampling(self, value: int):
        """A factor used as oversampling."""
        self._set(PropertyInt.OVERSAMPLING, value)

    def get_oversampling_slow_axis(self) -> int:
        """A factor used as oversampling of the slow scanner axis."""
        return self._get(PropertyInt.OVERSAMPLING_SLOW_AXIS)

    def set_oversampling_slow_axis(self, value: int):
        """A factor used as oversampling of the slow scanner axis."""
        self._set(PropertyInt.OVERSAMPLING_SLOW_AXIS, value)

    def get_speckle_reduction(self) -> int:
        """Number of speckles that are scanned over for averaging. Requires Oversampling >= SpeckleReduction"""
        return self._get(PropertyInt.SPECKLE_REDUCTION)

    def set_speckle_reduction(self, value: int):
        """Number of speckles that are scanned over for averaging. Requires Oversampling >= SpeckleReduction"""
        self._set(PropertyInt.SPECKLE_REDUCTION, value)
