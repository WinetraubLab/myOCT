from enum import IntEnum


class BoundaryCondition(IntEnum):
    """Selects the boundary conditions for the interpolation."""

    STANDARD = 0
    """Matches the slope of the interpolated function at starting/end point to the following/previous points."""

    NATURAL = 1
    """Natural boundary considerations used for interpolation which means the interpolated spline will turn into a
    straight line at the start/end."""

    PERIODIC = 2
    """Periodic boundary conditions used for interpolation which means that the interpolated function will interpret
    the points as a closed loop and use therefore the points from the start/end for interpolation of the end/start."""


class ApodizationType(IntEnum):
    """Parameters describing how often the apodization spectra will be acquired.

    If you want to create a scan pattern without an apodization please use
    :class:`~pyspectralradar.probe.properties.probeproperties.ProbeProperties` method ``set_apodization_cycles`` to
    set the size of apodization to zero.
    """

    ONE_FOR_ALL = 0
    """The volume scan pattern will be acquired with one apodization for the whole pattern."""

    EACH_BSCAN = 1
    """The volume scan pattern will be acquired with one apodization before each B-scan which results in a slightly
    better image quality but longer acquisition time."""


class AcquisitionOrder(IntEnum):
    """Parameters describing the behaviour of the scan pattern."""

    FRAME_BY_FRAME = 0
    """The scan pattern will be acquired slice by slice which means that the function 
    :func:`~pyspectralradar.octdevice.submodules.acquisition.acquisition.Acquisition.get_raw_data` needs to be
    called more than once to get the data for the whole scan pattern"""

    ACQ_ORDER_ALL = 1
    """The scan patten will be acquired in one piece"""


class InterpolationMethod(IntEnum):
    """Selects the interpolation method."""

    LINEAR = 0
    """Linear interpolation."""

    SPLINE = 1
    """Cubic B-Spline interpolation."""


class InflationMethod(IntEnum):
    """Describes how to use a 2D freeform scan pattern to create a 3D scan pattern."""

    NORMAL_DIR = 0
    """Inflates the points to the outer normal direction"""


class ScanPointsDataFormat(IntEnum):
    """Selects format with the functions :func:`~pyspectralradar.scanpattern.scanpoints.ScanPoints.load_from_file` or
    :func:`~pyspectralradar.scanpattern.lut.LUT.save_to_file` to import or export data points.
    """

    TXT = 0
    """Data format txt"""

    RAW_AND_SRM = 1
    """Data format raw/srm pair"""
