import unittest

import matplotlib.pyplot as plt

from pyspectralradar import LogLevel, set_log_level
from pyspectralradar.helper import *

ENABLE_PLOTS = False


class HelperTestCase(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_config_path(self):
        self.assertEqual(get_config_path(), 'C:\\Program Files\\Thorlabs\\SpectralRadar\\Config')

    def test_plugin_path(self):
        self.assertEqual(get_plugin_path(), 'C:\\Program Files\\Thorlabs\\SpectralRadar\\Plugins')

    def test_installation_path(self):
        self.assertEqual(get_installation_path(), 'C:\\Program Files\\Thorlabs\\SpectralRadar')

    def test_software_version(self):
        # TODO: Regex
        ver = get_software_version()
        self.assertTrue('5.7.0alpha1006', "5.7.0RC1" in ver)

    def test_get_free_memory(self):
        print(get_free_memory())
        self.assertIsInstance(get_free_memory(), int)

    def test_polynomial_fit_and_eval_1d(self):
        orig_pos_x = np.array([1.0, 2.0, 3.0, 4.0], dtype=np.float32)
        orig_y = np.array([2.0, 3.0, 5.0, 8.0], dtype=np.float32)
        degree_polynom = 2
        eval_pos_x = np.array([1.5, 3.5], dtype=np.float32)

        result_y = polynomial_fit_and_eval_1d(orig_pos_x, orig_y, degree_polynom, eval_pos_x)

        if ENABLE_PLOTS:
            plt.figure()
            plt.plot(orig_pos_x, orig_y, '--ro', label='orig')
            plt.plot(eval_pos_x, result_y, '--bo', label='fitted')
            plt.legend()

            plt.show()

        self.assertAlmostEqual(float(result_y[0]), 2.375, places=4)
        self.assertAlmostEqual(float(result_y[1]), 6.375, places=4)

    def test_calc_parabola_maximum(self):
        x0 = 2.0
        y0 = 5.0
        y_left = 2.0
        y_right = 2.0

        result = calc_parabola_maximum(x0, y0, y_left, y_right)

        x = np.linspace(x0 - 2, x0 + 2, 101)
        # a*x**2 + b*x +c
        c = y0
        b = 0.5 * (y_left - y_right)
        a = y_left - b - c
        y = a * (x - x0) ** 2 + b * (x - x0) + c

        if ENABLE_PLOTS:
            plt.figure()
            plt.title('test_calc_parabola_maximum')
            plt.plot(x, y, '--b.', label='Parabola')
            plt.scatter([x0], [y0], color='red', label='Maximum Point')
            plt.legend()

            plt.show()

        self.assertAlmostEqual(result, 5.0, places=4)

    def test_interpret_reference_intensity(self):
        self.assertEqual(interpret_reference_intensity(1.0), 0x00FF0000)
        self.assertEqual(interpret_reference_intensity(0.76), 0x00FF7700)
        self.assertEqual(interpret_reference_intensity(0.5), 0x00FF7700)
        self.assertEqual(interpret_reference_intensity(0.24), 0x00FF0000)
        self.assertEqual(interpret_reference_intensity(0.0), 0x00FF0000)

    def test_interpret_reference_intensity_single(self):
        self.assertEqual(
            interpret_reference_intensity_single_value(0.5, 0.1, 0.75),
            0x00FF0000)
        self.assertEqual(
            interpret_reference_intensity_single_value(0.5, 0.1, 0.55),
            0x0000FF00)


if __name__ == '__main__':
    unittest.main()
