from ctypes import c_char_p, c_int, create_string_buffer
from typing import List

from pyspectralradar.spectralradar import get_error, sr


class SupportedProbes:

    @staticmethod
    def _get_number_of_available_probes() -> int:
        """Returns the number of the available probe types.

        Returns:
            The number of the available probe types.

        """
        sr.getNumberOfAvailableProbes.restype = c_int
        res = sr.getNumberOfAvailableProbes()
        get_error()
        return res

    @staticmethod
    def _get_available_probe(idx: int) -> str:
        """Returns the name of the desired probe type.

        Args:
            :idx: Selects one specific probe type from all available ones.

        Returns:
            The desired string with the name of the probe type, e.g. standard, user-customizable or compact handheld.
            This string is essentially the name of the corresponding .prdf file, except that a version number and the
            termination should be added.

        """
        str_size = 1024
        probe_name = create_string_buffer(str_size)
        sr.getAvailableProbe.argtypes = [c_int, c_char_p, c_int]
        sr.getAvailableProbe(idx, probe_name, str_size)
        get_error()
        return probe_name.value.decode('UTF-8')

    @staticmethod
    def get_supported_probe_names() -> List[str]:
        """Returns a list of probe type names that are supported by the SDK

        E.g. "Handheld_OCTH_OEM_V1", "Standard_OCTG_V1" ...

        Returns:
            List of probe type names

        """
        n = SupportedProbes._get_number_of_available_probes()
        probe_names = [SupportedProbes._get_available_probe(idx) for idx in range(n)]
        return probe_names
