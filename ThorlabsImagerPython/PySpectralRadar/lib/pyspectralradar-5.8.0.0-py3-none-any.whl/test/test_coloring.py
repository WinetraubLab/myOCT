import unittest

import matplotlib.pyplot as plt
import numpy as np

from pyspectralradar import (ColoredData, Coloring, ComplexData, Doppler, OCTSystem, RealData,
                             get_rgba_values, set_log_level, LogLevel)
from pyspectralradar.types import AcqType, ByteOrder, ColorEnhancement, ColorScheme, DopplerOutput

ENABLE_PLOTS = False


def show_plots(data, title):
    if not ENABLE_PLOTS:
        return
    plt.figure()
    plt.title(title)
    plt.subplot(1, 4, 1)
    plt.imshow(data[:, :, 0])
    plt.subplot(1, 4, 2)
    plt.imshow(data[:, :, 1])
    plt.subplot(1, 4, 3)
    plt.imshow(data[:, :, 2])
    plt.subplot(1, 4, 4)
    plt.imshow(data[:, :, 3])


class ColoringTest(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def setUp(self):
        self._system = OCTSystem()
        self._dev = self._system.dev
        self._probe = self._system.probe_factory.create_default()
        self._pattern = self._probe.scan_pattern.create_bscan_pattern(5.0, 100)
        self._proc = self._system.processing_factory.from_device()
        self._dev.acquisition.start(self._pattern, AcqType.ASYNC_FINITE)
        raw = self._dev.acquisition.get_raw_data()
        self.bscan = RealData()
        self._proc.set_data_output(self.bscan)
        self._proc.execute(raw)
        self._dev.acquisition.stop()

    def tearDown(self):
        del self._proc
        del self._pattern
        del self._probe
        del self._dev
        del self._system

    def test_coloring_create(self):
        self.assertIsInstance(Coloring(ColorScheme.BLACK_AND_WHITE, ByteOrder.RGBA), Coloring)

        lut = np.arange(256)
        self.assertIsInstance(Coloring.from_lut(lut), Coloring)

    def test_coloring_boundaries_and_colorize(self):
        color_bw_rgba = Coloring(ColorScheme.BLACK_AND_WHITE, )
        color_bw_rgba.set_boundaries(10.0, 70.0)
        bscan_bw_rgba = color_bw_rgba.colorize(self.bscan, False)
        print(bscan_bw_rgba.to_numpy().shape)
        bscan_bw_rgba_numpy = get_rgba_values(bscan_bw_rgba.to_numpy(), ByteOrder.RGBA)
        print(bscan_bw_rgba_numpy.shape)
        show_plots(bscan_bw_rgba_numpy, 'BW RGBA')

        color_brg = Coloring(ColorScheme.RED_GREEN_BLUE, ByteOrder.RGBA)
        color_brg.set_boundaries(10.0, 70.0)
        bscan = color_brg.colorize(self.bscan, True)
        bscan_brg_rgba_numpy = get_rgba_values(bscan.to_numpy(), ByteOrder.RGBA)
        show_plots(bscan_brg_rgba_numpy, 'RGBA')

        color_brg = Coloring(ColorScheme.RED_GREEN_BLUE, ByteOrder.BGRA)
        color_brg.set_boundaries(10.0, 70.0)
        bscan = color_brg.colorize(self.bscan, True)
        bscan_brg_bgra_numpy = get_rgba_values(bscan.to_numpy(), ByteOrder.BGRA)
        show_plots(bscan_brg_bgra_numpy, 'BGRA')

        color_brg = Coloring(ColorScheme.RED_GREEN_BLUE, ByteOrder.ARGB)
        color_brg.set_boundaries(10.0, 70.0)
        bscan = color_brg.colorize(self.bscan, True)
        bscan_brg_argb_numpy = get_rgba_values(bscan.to_numpy(), ByteOrder.ARGB)
        show_plots(bscan_brg_argb_numpy, 'ARGB')

        if ENABLE_PLOTS:
            plt.show()

        self.assertTrue(np.allclose(bscan_brg_rgba_numpy[:, :, 1], bscan_brg_bgra_numpy[:, :, 1]))
        self.assertTrue(np.allclose(bscan_brg_rgba_numpy[:, :, 1], bscan_brg_argb_numpy[:, :, 0]))
        self.assertTrue(np.allclose(bscan_brg_rgba_numpy[:, :, 2], bscan_brg_bgra_numpy[:, :, 0]))
        self.assertTrue(np.allclose(bscan_brg_rgba_numpy[:, :, 2], bscan_brg_argb_numpy[:, :, 1]))
        self.assertTrue(np.allclose(bscan_brg_rgba_numpy[:, :, 3], bscan_brg_bgra_numpy[:, :, 3]))
        self.assertTrue(np.allclose(bscan_brg_rgba_numpy[:, :, 3], bscan_brg_argb_numpy[:, :, 3]))

    def test_coloring_enhance(self):
        color_rgb = Coloring(ColorScheme.RED_GREEN_BLUE, ByteOrder.RGBA)
        color_rgb.enhance(ColorEnhancement.NONE)
        color_rgb.set_boundaries(10.0, 100.0)
        bscan_rgb = color_rgb.colorize(self.bscan, True)

        color_rgb_sine = Coloring(ColorScheme.RED_GREEN_BLUE, ByteOrder.RGBA)
        color_rgb_sine.enhance(ColorEnhancement.SINE)
        color_rgb_sine.set_boundaries(10.0, 100.0)
        bscan_rgb_sine = color_rgb_sine.colorize(self.bscan, True)

        color_rgb_parabola = Coloring(ColorScheme.RED_GREEN_BLUE, ByteOrder.RGBA)
        color_rgb_parabola.enhance(ColorEnhancement.PARABLE)
        color_rgb_parabola.set_boundaries(10.0, 100.0)
        bscan_rgb_parabola = color_rgb_parabola.colorize(self.bscan, True)

        color_rgb_cubic = Coloring(ColorScheme.RED_GREEN_BLUE, ByteOrder.RGBA)
        color_rgb_cubic.enhance(ColorEnhancement.CUBIC)
        color_rgb_cubic.set_boundaries(10.0, 100.0)
        bscan_rgb_cubic = color_rgb_cubic.colorize(self.bscan, True)

        color_rgb_sqrt = Coloring(ColorScheme.RED_GREEN_BLUE, ByteOrder.RGBA)
        color_rgb_sqrt.enhance(ColorEnhancement.SQRT)
        color_rgb_sqrt.set_boundaries(10.0, 100.0)
        bscan_rgb_sqrt = color_rgb_sqrt.colorize(self.bscan, True)

        def histogram(data: np.ndarray, title: str):
            fig, axes = plt.subplots(2, 2, figsize=(10, 8))
            channel_colors = ['red', 'green', 'blue', 'gray']

            for i in range(4):
                row = i // 2
                col = i % 2
                axes[row, col].hist(data[:, i, :].flatten(), bins=50, color=channel_colors[i],
                                    alpha=0.7)
                axes[row, col].set_title(f'{title} Channel {i}')

            plt.tight_layout()

        histogram(bscan_rgb.to_numpy(), 'Default')
        histogram(bscan_rgb_sine.to_numpy(), 'SINE')
        histogram(bscan_rgb_parabola.to_numpy(), 'PARABOLA')
        histogram(bscan_rgb_cubic.to_numpy(), 'CUBIC')
        histogram(bscan_rgb_sqrt.to_numpy(), 'SQRT')

        if ENABLE_PLOTS:
            plt.show()


class TestColoringDoppler(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def test_coloring_colorize_doppler(self):
        system = OCTSystem()
        dev = system.dev
        probe = system.probe_factory.create_default()
        pattern = probe.scan_pattern.create_bscan_pattern(5.0, 100)
        proc = system.processing_factory.from_device()

        bscan = ComplexData()

        amplitude = RealData()
        phase = RealData()

        dev.acquisition.start(pattern, AcqType.ASYNC_FINITE)
        raw = dev.acquisition.get_raw_data()
        proc.set_data_output(bscan)
        proc.execute(raw)
        dev.acquisition.stop()

        doppler = Doppler()

        doppler.set_output(DopplerOutput.AMPLITUDE, amplitude)
        doppler.set_output(DopplerOutput.PHASE, phase)
        doppler.execute(bscan)

        color_amplitude = Coloring(ColorScheme.BLACK_AND_WHITE, ByteOrder.RGBA)
        color_amplitude.set_boundaries(10.0, 70.0)
        color_phase = Coloring(ColorScheme.RED_YELLOW_GREEN_BLUE_RED, ByteOrder.RGBA)
        color_phase.set_boundaries(10.0, 70.0)

        colored_doppler = Coloring.colorize_doppler(color_amplitude, color_phase, amplitude, phase, 17.0)
        colored_doppler_np = colored_doppler.to_numpy()
        print('colored_doppler', colored_doppler.shape)
        show_plots(get_rgba_values(colored_doppler_np, ByteOrder.RGBA), 'Colored Doppler')
        if ENABLE_PLOTS:
            plt.show()
        self.assertIsInstance(colored_doppler, ColoredData)


if __name__ == '__main__':
    unittest.main()
