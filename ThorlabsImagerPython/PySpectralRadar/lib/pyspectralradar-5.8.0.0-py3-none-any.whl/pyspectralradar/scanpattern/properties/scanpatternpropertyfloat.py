from enum import IntEnum

from pyspectralradar.base.propertygetter import FloatPropertyGetter
from pyspectralradar.spectralradar import sr


class PropertyFloat(IntEnum):
    """Enum identifying different floating-type properties of the specified scan pattern."""

    RANGE_X = 0
    """The range of the scan pattern in mm for the x-direction"""

    RANGE_Y = 1
    """The range of the scan pattern in mm for the y-direction"""

    CENTER_X = 2
    """The current x-center position in mm"""

    CENTER_Y = 3
    """The current y-center position in mm"""

    ANGLE = 4
    """The current scan pattern angle in radians"""

    MEAN_LENGTH = 5
    """The mean of the B-scan lengths of the scan pattern in mm"""


class ScanPatternPropertyFloat(FloatPropertyGetter):

    def __init__(self, handle):
        super().__init__(handle, sr.getScanPatternPropertyFloat)

    def get_range_x(self) -> float:
        """The range of the scan pattern in mm for the x-direction"""
        return self._get(PropertyFloat.RANGE_X)

    def get_range_y(self) -> float:
        """The range of the scan pattern in mm for the y-direction"""
        return self._get(PropertyFloat.RANGE_Y)

    def get_center_x(self) -> float:
        """The current x-center position in mm"""
        return self._get(PropertyFloat.CENTER_X)

    def get_center_y(self) -> float:
        """The current y-center position in mm"""
        return self._get(PropertyFloat.CENTER_Y)

    def get_angle(self) -> float:
        """The current scan pattern angle in radians"""
        return self._get(PropertyFloat.ANGLE)

    def get_mean_length(self) -> float:
        """The mean of the B-scan lengths of the scan pattern in mm"""
        return self._get(PropertyFloat.MEAN_LENGTH)
