from ctypes import c_char_p, c_double, c_int
from typing import Tuple

import numpy as np

from pyspectralradar.data import RealData
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import BoundaryCondition, InflationMethod, InterpolationMethod, ScanPointsDataFormat


class ScanPointsFactory:

    @staticmethod
    def interpolate_2d(orig_positions_x_mm: np.ndarray[float],
                       orig_positions_y_mm: np.ndarray[float],
                       new_size: int,
                       interp_method: InterpolationMethod,
                       boundary_cond: BoundaryCondition) -> Tuple[np.ndarray, np.ndarray]:
        """Interpolates the imaginary curve defined by the given sequence of points with the specified interpolation
        method ``interp_method``.
        The coordinates are abstract and this function has no side effects that could affect any physical property.
        The original and the interpolated coordinates have a meaning for the user, but no consequence for SpectralRadar.

        Args:
            :orig_positions_x_mm: The array of input x-coordinates
            :orig_positions_y_mm: The array of input y-coordinates. Must be of same size as ``orig_posx``
            :new_size: The number of interpolated points
            :interp_method: The desired interpolation procedure
            :boundary_cond: The desired boundary condition

        Returns:
            A tuple (``interp_posx``, ``interp_posy``) containing the :class:`numpy` array ``interp_posx`` of
            x-coordinates and the :class:`numpy` array ``interp_posy`` of y-coordinates .
        """
        assert isinstance(interp_method, InterpolationMethod)
        assert isinstance(boundary_cond, BoundaryCondition)
        size = len(orig_positions_x_mm)
        interp_posx = np.empty(new_size)
        interp_posy = np.empty(new_size)
        sr.interpolatePoints2D.argtypes = [np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                           np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                           c_int,
                                           np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                           np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                           c_int, c_int, c_int]
        sr.interpolatePoints2D(orig_positions_x_mm, orig_positions_y_mm, size, interp_posx, interp_posy, new_size,
                               interp_method, boundary_cond)
        get_error()
        return interp_posx, interp_posy

    @staticmethod
    def inflate(positions_x_mm: np.ndarray[float],
                positions_y_mm: np.ndarray[float],
                number_of_inflation_lines: int,
                range_of_inflation: float,
                inflation_method: InflationMethod) -> Tuple[np.ndarray, np.ndarray]:
        """Inflates the provided curve in space with the specified inflation method ``inflation_method``.

        It can be used to create scan patterns of arbitrary forms with
        :func:`~pyspectralradar.scanpattern.scanpatternfactory.ScanPatternFactory.create_freeform_pattern_3d_from_LUT`
        if the used positions correspond to coordinates of the valid scan field in mm.

        Args:
            :positions_x_mm: Array of x-positions of the scan pattern
            :positions_y_mm: Array of y-positions of the scan pattern, must be of same length as ``posx``
            :number_of_inflation_lines: The number of inflation lines
            :range_of_inflation: The range of inflation which results in the width [mm] of the created data object
            :inflation_method: The specified inflation method.

        Returns:
            A tuple (``inflated_posx``, ``inflated_posy``) containing the :class:`numpy` array ``inflated_posx`` of
            x-positions of the scan pattern with original array length * number_of_inflation_lines
            and the :class:`numpy` array ``inflated_posy`` of y-positions of the scan pattern with original array
            length * number_of_inflation_lines

        """
        assert isinstance(inflation_method, InflationMethod)
        size = len(positions_x_mm)
        inflated_posx = np.empty(size * number_of_inflation_lines)
        inflated_posy = np.empty(size * number_of_inflation_lines)

        sr.inflatePoints.argtypes = [np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                     np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                     c_int,
                                     np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                     np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                     c_int, c_double, c_int]
        sr.inflatePoints(positions_x_mm, positions_y_mm, size, inflated_posx, inflated_posy, number_of_inflation_lines,
                         range_of_inflation, inflation_method)
        return inflated_posx, inflated_posy

    @staticmethod
    def get_size_from_file(filename: str, data_format: ScanPointsDataFormat) -> int:
        """Returns the number of scan points in the specified file.

        Args:
            :filename: Filename (including path) of the file that contains the scan points and indices
            :data_format: The desired import data format

        Returns:
            The number of scan points in the give file.
        """
        assert isinstance(data_format, ScanPointsDataFormat)
        sr.getSizeOfScanPointsFromFile.argtypes = [c_char_p, c_handle]
        sr.getSizeOfScanPointsFromFile.restype = c_int
        res = sr.getSizeOfScanPointsFromFile((bytes(filename, encoding="ascii")), data_format)
        get_error()
        return res

    @staticmethod
    def load_from_file(filename: str, data_format: ScanPointsDataFormat) -> (
            Tuple)[np.ndarray, np.ndarray, np.ndarray]:
        """Copies the scan points and scan indices from a given file into numpy arrays.

        Args:
            :filename: Filename (including path) of the file that contains the scan points and indices
            :data_format: The desired import data format

        Returns:
            A tuple (``scan_posx_mm``, ``scan_posx_mm``, ``scan_indices``) containing the :class:`numpy` array
            ``scan_posx_mm`` of x-positions of the scan pattern in mm, the :class:`numpy` array ``scan_posx_mm`` of
            y-positions of the scan pattern in mm and the :class:`numpy` array ``scan_indices``, which specifies the
            assignment of each point to its B-scan. It has entries from 0 to number of (B-scans - 1). The number of
            B-scans is defined with the entries of ``scan_indices``. To save scan points for a 2D-pattern set all
            entries to zero.
        """
        assert isinstance(data_format, ScanPointsDataFormat)
        size = ScanPointsFactory.get_size_from_file(filename, data_format)

        scan_posx_mm = np.empty(size)
        scan_posy_mm = np.empty(size)
        scan_indices = np.empty(size, dtype=int)

        sr.loadScanPointsFromFile.argtypes = [np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                              np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                              np.ctypeslib.ndpointer(dtype=int, flags='F_CONTIGUOUS'),
                                              c_int,
                                              c_char_p,
                                              c_handle]
        sr.loadScanPointsFromFile(scan_posx_mm,
                                  scan_posy_mm,
                                  scan_indices,
                                  size,
                                  bytes(filename, encoding="ascii"),
                                  data_format)
        get_error()
        return scan_posx_mm, scan_posy_mm, scan_indices

    @staticmethod
    def save_to_file(positions_x_mm: np.ndarray[float], positions_y_mm: np.ndarray[float], indices: np.ndarray[int],
                     filename: str, format: ScanPointsDataFormat):
        """Saves the scan points and scan indices to a file with the specified format.

        Args:
            :positions_x_mm: The array of x-positions of the scan pattern in mm
            :positions_y_mm: The array of y-positions of the scan pattern in mm
            :indices: The array specifies the assignment of each point to its B-scan. It needs to have the length size
                with entries from 0 to number of (B-scans - 1). The number of B-scans is defined with the entries of
                indices. To save scan points for a 2D-pattern set all entries to zero.
            :filename: Path and name of the file containing the scan points and indices.
            :format: The specified scan point data format
        """
        assert isinstance(format, ScanPointsDataFormat)
        size = len(indices)
        casted_positions_x = positions_x_mm.astype(np.double)
        casted_positions_y = positions_y_mm.astype(np.double)
        casted_indices = indices.astype(np.int32)
        sr.saveScanPointsToFile.argtypes = [np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                            np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                            np.ctypeslib.ndpointer(dtype=np.int32, flags='F_CONTIGUOUS'),
                                            c_int, c_char_p, c_handle]
        sr.saveScanPointsToFile(casted_positions_x,
                                casted_positions_y,
                                casted_indices,
                                size, c_char_p(bytes(filename, encoding="ascii")), format)
        get_error()

    @staticmethod
    def get_size_from_data(scan_points_data: RealData) -> int:
        """Returns the size of the scan points and scan indices in the given
        :obj:`~pyspectralradar.data.realdata.RealData`.

        Notice that in this case a data structure is used to hold data other than spectra or A-scans.

        Args:
            :scan_points_data: The :obj:`~pyspectralradar.data.realdata.RealData` object containing the provided
                points and scan indices.

        Returns:
            The number of scan points.
        """
        assert isinstance(scan_points_data, RealData)
        sr.getSizeOfScanPointsFromDataHandle.argtypes = [c_handle]
        sr.getSizeOfScanPointsFromDataHandle.restype = c_int
        res = sr.getSizeOfScanPointsFromDataHandle(scan_points_data.handle)
        get_error()
        return res

    def load_from_data(self, scan_points_data: RealData) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Copies the scan points and scan indices from the :obj:`~pyspectralradar.data.realdata.RealData` object
        handle to the provided arrays.

        Args:
            :scan_points_data: The :obj:`~pyspectralradar.data.realdata.RealData` object containing the provided
                points and scan indices.

        Returns:
            A tuple (``scan_posx_mm``, ``scan_posy_mm``, ``scan_indices``) containing the :class:`numpy` array
            ``scan_posx_mm`` of x-coordinates of the scan pattern, the :class:`numpy` array
            ``scan_posy_mm`` of y-coordinates of the scan pattern and the :class:`numpy` array
            ``scan_indices`` which specifies the assignment of each point to its B-scan. It has entries from 0 to
            number of (B-scans - 1). The number of B-scans is defined with the entries of ``scan_indices``. To save
            scan points for a 2D-pattern set all entries to zero.
        """
        assert isinstance(scan_points_data, RealData)
        size = self.get_size_from_data(scan_points_data)
        scan_posx_mm = np.empty(size, dtype=float)
        scan_posy_mm = np.empty(size, dtype=float)
        scan_indices = np.empty(size, dtype=int)

        sr.getScanPointsFromDataHandle.argtypes = [c_handle,
                                                   np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                                   np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                                   np.ctypeslib.ndpointer(dtype=int, flags='F_CONTIGUOUS'),
                                                   c_int]
        sr.getScanPointsFromDataHandle(scan_points_data.handle,
                                       scan_posx_mm,
                                       scan_posy_mm,
                                       scan_indices,
                                       size)
        get_error()
        return scan_posx_mm, scan_posy_mm, scan_indices

    @staticmethod
    def set_to_data(positions_x_mm: np.ndarray[float], positions_y_mm: np.ndarray[float],
                    scan_indices: np.ndarray[int]) -> RealData:
        """Creates a :class:`~pyspectralradar.data.realdata.RealData` instance from the specified scan points and
        corresponding indices.

        Args:
            :positions_x_mm: An array of X-coords of the scan pattern in mm
            :positions_y_mm: An array of Y-coords of the scan pattern in mm
            :scan_indices: The array specifies the assignment of each point to its B-scan. The entries need to go
                from 0 to number of B-scans - 1)

        Returns:
            A :obj:`~pyspectralradar.data.realdata.RealData` containing the scan points and indices.
        """
        length = len(scan_indices)
        casted_positions_x_mm = np.asarray(positions_x_mm, dtype=np.double)
        casted_positions_y_mm = np.asarray(positions_y_mm, dtype=np.double)
        casted_indices = np.asarray(scan_indices, dtype=np.int32)
        sr.createDataHandleFromScanPoints.argtypes = [np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                                      np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                                      np.ctypeslib.ndpointer(dtype=np.int32, flags='F_CONTIGUOUS'),
                                                      c_int]
        sr.createDataHandleFromScanPoints.restype = c_handle
        handle = sr.createDataHandleFromScanPoints(casted_positions_x_mm,
                                                   casted_positions_y_mm,
                                                   casted_indices,
                                                   length)
        get_error()
        return RealData(handle)
