from ctypes import c_bool, c_double, c_int, c_void_p

import numpy as np

from pyspectralradar.base import Submodule
from pyspectralradar.scanpattern import ScanPattern
from pyspectralradar.scanpattern.submodules import ScanPointsFactory
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import AcquisitionOrder, ApodizationType, InterpolationMethod, ScanPointsDataFormat


class ScanPatternFactory(Submodule):
    def __init__(self, probe_handle):
        super().__init__(probe_handle)

    def create_no_scan_pattern(self, ascans: int, number_of_scans: int) -> ScanPattern:
        """Creates a simple scan pattern that does not move the galvo.

        Use this pattern for point scans and/or non-scanning probes. The pattern will however use a specified amount
        of trigger signals. For continuous acquisition use NumberOfScans set to 1.

        Args:
            :ascans: The number of A-Scans that will be measured in each part of this
                :obj:`~pyspectralradar.scanpattern.scanpattern.ScanPattern`
            :number_of_scans: The number of parts in this :obj:`~pyspectralradar.scanpattern.scanpattern.ScanPattern`.
                It should be "1" for continuous acquisition.

        Returns:
            A :obj:`~pyspectralradar.scanpattern.scanpattern.ScanPattern` that does not move the galvo.
        """
        sr.createNoScanPattern.argtypes = [c_handle, c_int, c_int]
        sr.createNoScanPattern.restype = c_handle
        sp_handle = sr.createNoScanPattern(self.handle, ascans, number_of_scans)
        get_error()
        return ScanPattern(sp_handle)

    def create_ascan_pattern(self, ascans: int, posx_mm: float, posy_mm: float) -> ScanPattern:
        """Creates a scan pattern used to acquire a specific amount of Ascans at a specific position.

        Args:
            :ascans: The number of A-Scans that will be measured
            :posx_mm: The x-position of the light spot, in millimeter
            :posy_mm: The y-position of the light spot, in millimeter

        Returns:
            A :obj:`~pyspectralradar.scanpattern.scanpattern.ScanPattern` to perform A-scans
        """
        sr.createAScanPattern.argtypes = [c_handle, c_int, c_double, c_double]
        sr.createAScanPattern.restype = c_handle
        sp_handle = sr.createAScanPattern(self.handle, ascans, posx_mm, posy_mm)
        get_error()
        return ScanPattern(sp_handle)

    def create_bscan_pattern_manual(self, start_x: float, start_y: float, stop_x: float, stop_y: float,
                                    ascans: int) -> ScanPattern:
        """Creates a B-scan pattern specified by start and end points.

        Args:
            :start_x: The x-coordinate of the start point, in mm
            :start_y: The y-coordinate of the start point, in mm
            :stop_x: The x-coordinate of the stop point, in mm
            :stop_y: The y-coordinate of the stop point, in mm
            :ascans: The number of A-scans that will be measured along the segment

        Returns:
            A :obj:`~pyspectralradar.scanpattern.scanpattern.ScanPattern` to perform B-scans
            
        Depending on the situation, the function :func:`~pyspectralradar.scanpattern.scanpattern.ScanPattern.update`
        might need to be invoked after this one (check the details there).
        """
        sr.createBScanPatternManual.argtypes = [c_handle, c_double, c_double, c_double, c_double, c_int]
        sr.createBScanPatternManual.restype = c_handle
        sp_handle = sr.createBScanPatternManual(self.handle, start_x, start_y, stop_x, stop_y, ascans)
        get_error()
        return ScanPattern(sp_handle)

    def create_bscan_pattern(self, range_mm: float, ascans: int) -> ScanPattern:
        """Creates a horizontal rectilinear-segment B-scan pattern that moves the Galvo over a specified range.

        Args:
            :range_mm: The extension of the horizontal segment, expressed in mm, centered at (0,0).
            :ascans: The number of A-Scans that will be measured along the segment.

        Returns:
            A :obj:`~pyspectralradar.scanpattern.scanpattern.ScanPattern` to perform B-scans

        If a different center position is desired, the function
        :func:`~pyspectralradar.scanpattern.scanpattern.ScanPattern.shift` should be invoked afterward, passing the
        scan pattern handle returned by this function.
        If a different orientation is desired (i.e. other than horizontal), the function
        :func:`~pyspectralradar.scanpattern.scanpattern.ScanPattern.rotate` should be invoked afterward,
        passing the scan pattern handle returned by this function.
        Depending on the situation, the function :func:`~pyspectralradar.scanpattern.scanpattern.ScanPattern.update`
        might need to be invoked after this one (check the details there).
        """
        sr.createBScanPattern.argtypes = [c_handle, c_double, c_int]
        sr.createBScanPattern.restype = c_handle
        sp_handle = sr.createBScanPattern(self.handle, c_double(range_mm), c_int(ascans))
        get_error()
        return ScanPattern(sp_handle)

    def create_ideal_bscan_pattern(self, range_mm: float, ascans: int) -> ScanPattern:
        """Creates an ideal B-scan pattern assuming scanners with infinite speed.

        No correction factors are taken into account.

        This is only used for internal purposes and not as a scan pattern designed to be output to the Galvo drivers.

        Args:
            :range_mm: The extension of the segment, expressed in mm, centered at the current position.
            :ascans: The number of A-Scans that will be measured along the segment.

        Returns:
            An ideal :obj:`~pyspectralradar.scanpattern.scanpattern.ScanPattern` to perform B-scans.
        """
        sr.createIdealBScanPattern.argtypes = [c_handle, c_double, c_int]
        sr.createIdealBScanPattern.restype = c_handle
        sp_handle = sr.createIdealBScanPattern(self.handle, c_double(range_mm), c_int(ascans))
        get_error()
        return ScanPattern(sp_handle)

    def create_circle_pattern(self, radius_mm: float, ascans: int) -> ScanPattern:
        """Creates a circle scan pattern.

        :Warning: Circle patterns cannot be rotated properly.

        Args:
            :radius_mm: The radius of the circle pattern.
            :ascans: The number of A-Scans that will be measured along the segment.

        Returns:
            A :obj:`~pyspectralradar.scanpattern.scanpattern.ScanPattern` to perform circular B-scans.
        """
        sr.createCirclePattern.argtypes = [c_handle, c_double, c_int]
        sr.createCirclePattern.restype = c_handle
        sp_handle = sr.createCirclePattern(self.handle, c_double(radius_mm), c_int(ascans))
        get_error()
        return ScanPattern(sp_handle)

    def create_volume_pattern(self,
                              range_x: float, size_x: int,
                              range_y: float, size_y: int,
                              apo_type: ApodizationType,
                              acq_order: AcquisitionOrder) -> ScanPattern:
        """Creates a simple volume pattern.

        Args:
            :range_x: The extension of the volume along the x-axis, expressed in mm, centered at the current position
            :size_x: The number of planes that cross the x-axis
            :range_y: The extension of the volume along the y-axis, expressed in mm, centered at the current position
            :size_y: The number of planes that cross the y-axis
            :apo_type: The apodization type decides whether one apodization suffices for the whole set of measurements
                in the volume, or one apodization will be measured for each B-Scan (each segment)
            :acq_order: Dictates the acquisition strategy, as explained below, which reflects the way the user wants to
                retrieve the acquired data

        Returns:
            A :obj:`~pyspectralradar.scanpattern.scanpattern.ScanPattern` to perform volume scans.

        A volume scan pattern is actually a stack of B-scan patterns. At creation time the stack fills a
        parallelepiped volume in space but the shape can be subsequently modified if the individual slices are
        rotated, translated, or both (see explanation of functions
        :func:`~pyspectralradar.scanpattern.scanpattern.ScanPattern.rotate`,
        :func:`~pyspectralradar.scanpattern.scanpattern.ScanPattern.shift` for more information). Notice that the
        individual B-scans (the slices) will always contain the segment of the laser beam that illuminates the sample
        (rotations and translations cannot change that). This functions creates a parallelepiped volume scan pattern
        and in the default orientation (first axis is the depth ``z``, second axis is ``x``, third axis is ``y``) the
        slices will be accommodated along the ``y`` axis. Hence, the number of slices in the stack is given by the
        parameter ``size_y``.
        Afterwards, this parameter may be retrieved by invoking the function
        :func:`~pyspectralradar.scanpattern.properties.scanpatternpropertyint.ScanPatternPropertyInt.get_cycles`.
        Depending on the setting for :class:`~pyspectralradar.types.scanpatterntypes.ApodizationType`, there will be
        either one apodization for the entire volume (
        :class:`~pyspectralradar.types.scanpatterntypes.ApodizationType` ``ONE_FOR_ALL``) or a single apodization
        for each B-scan (:class:`~pyspectralradar.types.scanpatterntypes.ApodizationType` ``EACH_BSCAN``). The volume
        pattern with :class:`~pyspectralradar.types.scanpatterntypes.AcquisitionOrder` set to
        ``ACQ_ORDER_ALL``  consists of a single uninterrupted scan and all data is acquired in a single
        measurement. The complete volume will be returned in one :class:`~pyspectralradar.data.rawdata.RawData`
        object by calling
        :func:`~pyspectralradar.octdevice.submodules.acquisition.acquisition.Acquisition.get_raw_data`. Otherwise,
        (i.e. if :class:`~pyspectralradar.types.scanpatterntypes.AcquisitionOrder` is set
        to ``FRAME_BY_FRAME``) the scan pattern consists of individual B-Scan measurements that get retrieved
        separately through separate invocations of
        :func:`~pyspectralradar.octdevice.submodules.acquisition.acquisition.Acquisition.get_raw_data`. In other
        words: The structure of the final dataset will be identical to the former case, but the stack
        will be returned slice-by-slice by calling
        :func:`~pyspectralradar.octdevice.submodules.acquisition.acquisition.Acquisition.get_raw_data`,
        once for each slice. Notice that raw data refers to the spectra as acquired, without processing of any kind.
        Depending on the situation, the function :func:`~pyspectralradar.scanpattern.scanpattern.ScanPattern.update`
        might need to be invoked after this one (check the details there).
        """
        sr.createVolumePattern.argtypes = [c_handle, c_double, c_int, c_double, c_int, c_int, c_int]
        sr.createVolumePattern.restype = c_handle
        sp_handle = sr.createVolumePattern(self.handle, range_x, size_x, range_y, size_y, apo_type, acq_order)
        get_error()
        return ScanPattern(sp_handle)

    def create_volume_pattern_ex(self,
                                 range_x: float, size_x: int,
                                 range_y: float, size_y: int,
                                 center_x: float, center_y: float,
                                 angle_degree: float,
                                 apo_type: ApodizationType,
                                 acq_order: AcquisitionOrder) -> ScanPattern:
        """Creates a simple volume pattern.

        Args:
            :range_x: The extension of the volume along the x-axis, expressed in mm, centered at the current position
            :size_x: The number of planes that cross the x-axis
            :range_y: The extension of the volume along the y-axis, expressed in mm, centered at the current position
            :size_y: The number of planes that cross the y-axis
            :center_x: Center of the volume pattern
            :center_y: Center of the volume pattern
            :angle_degree: Rotation in degree of the entire scan pattern
            :apo_type: The apodization type decides whether one apodization suffices for the whole set of
                measurements in the volume, or one apodization will be measured for each B-Scan (each segment)
            :acq_order: Dictates the acquisition strategy, as explained below, which reflects the way the user wants
                to retrieve the acquired data.

        Returns:
            A volume :class:`~pyspectralradar.scanpattern.scanpattern.ScanPattern`.

        Depending on the situation, the function :func:`~pyspectralradar.scanpattern.scanpattern.ScanPattern.update`
        might need to be invoked after this one (check the details there).
        """
        angle_rad = (angle_degree * np.pi) / 180
        sr.createVolumePatternEx.argtypes = [c_handle, c_double, c_int, c_double, c_int, c_double, c_double,
                                             c_double, c_int, c_int]
        sr.createVolumePatternEx.restype = c_handle
        sp_handle = sr.createVolumePatternEx(self.handle, range_x, size_x, range_y, size_y, center_x, center_y,
                                             angle_rad, apo_type, acq_order)
        get_error()
        return ScanPattern(sp_handle)

    def create_freeform_pattern_2d(self,
                                   scan_posx_mm: np.ndarray[float],
                                   scan_posy_mm: np.ndarray[float],
                                   ascans: int,
                                   interp_method: InterpolationMethod,
                                   closed_pattern: bool,
                                   from_file: bool = False) -> ScanPattern | c_void_p:
        """Creates a B-scan scan pattern of arbitrary form with equidistant sampled scan points.

        Args:
            :scan_posx_mm: Array of x-positions of the scan pattern
            :scan_posy_mm: Array of y-positions of the scan pattern
            :ascans: The number of A-scans in each B-scan of the created scan pattern. The number of A-scans should
                be greater than the scan_pos array length
            :interp_method: The interpolation method used to fill up the specified points by ``scan_posx_mm`` and
                ``scan_posy_mm`` to create a pattern with evenly-spaced sampled points
            :closed_pattern: Specifies whether the scan pattern should be closed (``True``) or not (``False``).
                Closing the scan pattern will lead to the same start and end point of each B-scan
            :from_file: Specifies if pattern should be created from a scan points file

        Returns:
            A freeform 2D :class:`~pyspectralradar.scanpattern.scanpattern.ScanPattern` object.

        Depending on the situation, the function :func:`~pyspectralradar.scanpattern.scanpattern.ScanPattern.update`
        might need to be invoked after this one (check the details there).
        """
        scan_points_size = len(scan_posx_mm)
        sr.createFreeformScanPattern2D.argtypes = [c_handle,
                                                   np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                                   np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                                   c_int, c_int, c_int, c_bool]
        sr.createFreeformScanPattern2D.restype = c_handle
        sp_handle = sr.createFreeformScanPattern2D(self.handle,
                                                   scan_posx_mm,
                                                   scan_posy_mm,
                                                   scan_points_size, ascans, interp_method, closed_pattern)
        get_error()
        if not from_file:
            return ScanPattern(sp_handle)
        else:
            return sp_handle

    def create_freeform_pattern_2d_from_file(self, filename: str, ascans: int, data_format: ScanPointsDataFormat,
                                             interp_method: InterpolationMethod, closed_pattern: bool) -> ScanPattern:
        """Creates a B-scan scan pattern of arbitrary form with equidistant sampled scan points.

        Args:
            :filename: Path to file storing the data points.
            :ascans: The number of A-scans in each B-scan of the created scan pattern. The number of A-scans should
                be greater than the scan_pos array length
            :data_format: Format in which the data points have been stored, either .txt or .raw/.srm
            :interp_method: The interpolation method used to fill up the scan points read from file to create a
                pattern with evenly-spaced sampled points
            :closed_pattern: Specifies whether the scan pattern should be closed (``True``) or not (``False``).
                Closing the scan pattern will lead to the same start and end point of each B-scan.

        Returns:
            A freeform 2D :class:`~pyspectralradar.scanpattern.scanpattern.ScanPattern` object.

        Depending on the situation, the function :func:`~pyspectralradar.scanpattern.scanpattern.ScanPattern.update`
        might need to be invoked after this one (check the details there).
        """

        assert isinstance(data_format, ScanPointsDataFormat)
        assert isinstance(interp_method, InterpolationMethod)
        scan_posx_mm, scan_posy_mm, scan_indices = ScanPointsFactory.load_from_file(filename, data_format)
        sp_handle = self.create_freeform_pattern_2d(scan_posx_mm,
                                                    scan_posy_mm,
                                                    ascans, interp_method, closed_pattern, True)
        get_error()
        return ScanPattern(sp_handle)

    def create_freeform_pattern_2d_from_LUT(self,
                                            volt_x: np.ndarray[float],
                                            volt_y: np.ndarray[float],
                                            closed_pattern: bool) -> ScanPattern:
        """Creates a B-scan scan pattern of arbitrary form with the specified scan points.
        The voltages array is taken as-is, so care must be taken to use sensible values with regard to the capabilities
        of the utilized scanner system and to the resolution of the system resp. the desired resolution of your scan
        pattern.

        Args:
            :volt_x: Array of X-positions (in V) of the scan pattern with length ``scan_points_size``
            :volt_y: Array of Y-positions (in V) of the scan pattern with length ``scan_points_size``
            :closed_pattern: Specifies whether the scan pattern should be closed (``True``) or not (``False``).
                Closing the scan pattern will lead to the same start and end point of each B-scan.

        Returns:
            A freeform 2D :class:`~pyspectralradar.scanpattern.scanpattern.ScanPattern` object.

        With this function the definition of every single scan point is required. In order to create a scan pattern
        specifying only some "edge" points of the pattern, please consider
        :func:`~pyspectralradar.scanpattern.scanpatternfactory.ScanPatternFactory.create_freeform_pattern_2d`.
        """
        if len(volt_x) != len(volt_y):
            raise ValueError("Arrays volt_x and volt_y must be of same size!")

        scan_points_size = len(volt_x)
        sr.createFreeformScanPattern2DFromLUT.argtypes = [c_handle,
                                                          np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                                          np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                                          c_int, c_bool]
        sr.createFreeformScanPattern2DFromLUT.restype = c_handle
        sp_handle = sr.createFreeformScanPattern2DFromLUT(self.handle,
                                                          volt_x,
                                                          volt_y,
                                                          scan_points_size,
                                                          closed_pattern)
        get_error()
        return ScanPattern(sp_handle)

    def create_freeform_pattern_3d(self,
                                   scan_posx_mm: np.ndarray[float],
                                   scan_posy_mm: np.ndarray[float],
                                   scan_indices: np.ndarray[int],
                                   scan_points_size: int,
                                   ascans: int,
                                   interp_method: InterpolationMethod,
                                   closed_pattern: bool,
                                   apo_type: ApodizationType,
                                   acq_order: AcquisitionOrder) -> ScanPattern:
        """Creates a volume scan pattern of arbitrary form with equidistant sampled scan points.

        Args:
            :scan_posx_mm: The array of x-positions of the scan pattern
            :scan_posy_mm: The array of y-positions of the scan pattern
            :scan_indices: The array specifies the assignment of each point to its B-scan It needs to have the length
                of ``scan_posx_mm`` and ``scan_posy_mm``. The entries need to go from 0 to number of (B-scans - 1).
                The number of B-scans is defined with the entries of ``scan_indices``. For example, if the minimum entry
                is 0 (cannot be negative!) and the maximum entry is 2, there will be three B-scans in the pattern
            :scan_points_size: The length of the arrays ``scan_posx_mm``, ``scan_posy_mm``, and ``scan_indices``
            :ascans: The number of A-scans in each B-scan of the created scan pattern. The number of B-scans will be
                    defined with the entries in the ``scan_indices``
            :interp_method: The interpolation method used to fill up the specified points by ``posx_mm`` and
                ``posy_mm`` to create a pattern with evenly-spaced sampled points
            :closed_pattern: Specifies whether the scan pattern should be closed or not. Closing the scan pattern
                will lead to the same start and end point of each B-scan
            :apo_type: The specified method used for apodization in a volume pattern. Please see
                :class:`~pyspectralradar.types.scanpatterntypes.ApodizationType` for more information
            :acq_order: The specified method used for the acquisition order in a volume pattern.  Please see
                :class:`~pyspectralradar.types.scanpatterntypes.AcquisitionOrder` for more information.

        Returns:
            A scan pattern handle containing the created 3D-freeform scan pattern.

        Depending on the situation, the function :func:`~pyspectralradar.scanpattern.scanpattern.ScanPattern.update`
        might need to be invoked after this one (check the details there).
        """
        sr.createFreeformScanPattern3D.argtypes = [c_handle,
                                                   np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                                   np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                                   np.ctypeslib.ndpointer(dtype=np.int32, flags='F_CONTIGUOUS'),
                                                   c_int, c_int, c_int, c_bool, c_int, c_int]
        sr.createFreeformScanPattern3D.restype = c_handle
        sp_handle = sr.createFreeformScanPattern3D(self.handle,
                                                   scan_posx_mm,
                                                   scan_posy_mm,
                                                   scan_indices.astype(np.int32),
                                                   scan_points_size, ascans, interp_method, closed_pattern,
                                                   apo_type, acq_order)
        get_error()
        return ScanPattern(sp_handle)

    def create_freeform_pattern_3d_from_LUT(self,
                                            volt_x: np.ndarray[float],
                                            volt_y: np.ndarray[float],
                                            ascans: int,
                                            bscans: int,
                                            closed_pattern: bool,
                                            apo_type: ApodizationType,
                                            acq_order: AcquisitionOrder) -> ScanPattern:
        """Creates a volume scan pattern of arbitrary form with the specified scan voltages.
        The voltages array is taken as-is, so care must be taken to use sensible values with regard to the capabilities
        of the utilized scanner system and to the resolution of the system resp. the desired resolution of your scan
        pattern. With this function the definition of each single scan point is required.  In order to create a scan
        pattern specifying only the end coordinates, please consider
        :func:`~pyspectralradar.scanpattern.scanpatternfactory.ScanPatternFactory.create_freeform_pattern_3d`.

        Args:
            :volt_x: An array of X-positions (in V) of the scan pattern whose length is the product of ``ascans`` and
                ``bscans``
            :volt_y: An array of Y-positions (in V) of the scan pattern whose length is the product of ``ascans`` and
                ``bscans``
            :ascans: The desired number of A-scans in each B-scan of the volume pattern. All B-scans will have the
                same size.
            :bscans: The desired number of B-scans in the volume pattern
            :closed_pattern: Specifies whether the scan pattern should be closed or not. Closing the scan pattern
                will lead to the same start and end point of each B-scan
            :apo_type: The specified method used for apodization in a volume pattern
            :acq_order: The specified method used for the acquisition order in a volume pattern

        Returns:
            A :obj:`~pyspectralradar.scanpattern.scanpattern.ScanPattern` containing the created 3D-freeform scan
            pattern.
        """
        sr.createFreeformScanPattern3DFromLUT.argtypes = [c_handle,
                                                          np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                                          np.ctypeslib.ndpointer(dtype=np.double, flags='F_CONTIGUOUS'),
                                                          c_int, c_int, c_bool, c_int, c_int]
        sr.createFreeformScanPattern3DFromLUT.restype = c_handle
        sp_handle = sr.createFreeformScanPattern3DFromLUT(self.handle,
                                                          volt_x,
                                                          volt_y,
                                                          ascans, bscans, closed_pattern, apo_type, acq_order)
        get_error()
        return ScanPattern(sp_handle)
