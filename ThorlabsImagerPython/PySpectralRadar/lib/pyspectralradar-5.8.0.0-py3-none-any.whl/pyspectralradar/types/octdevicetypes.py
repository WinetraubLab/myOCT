from __future__ import annotations

from enum import IntEnum


class AcqType(IntEnum):
    """Determines the kind of acquisition process. The type of acquisition process affects e.g. whether consecutive
    B-scans are acquired or if it is possible to lose some data."""

    ASYNC_CONTINUOUS = 0
    """Specifies an asynchronous infinite/continuous measurement.
    With this acquisition type an infinite loop to acquire the specified scan pattern will be started and stopped with 
    the call of :func:`~pyspectralradar.octdevice.submodules.acquisition.acquisition.Acquisition.stop`. Several 
    buffers will be created  internally to hold the data of the specified scan pattern several times. With this 
    acquisition mode it is possible to lose data if the acquisition is faster than the copying from the frame grabber 
    with :func:`~pyspectralradar.octdevice.submodules.acquisition.acquisition.Acquisition.get_raw_data`. If you lose 
    data you will always lose a whole frame, e.g. a whole B-scan. The acquisition thread runs independently from the 
    thread for grabbing the data to acquire the data as fast as  possible. To get the information whether the data of 
    a whole scan pattern got lost please use 
    :func:`~pyspectralradar.data.properties.rawdatapropertyint.RawDataPropertyIntGetter.get_lost_frames` when 
    grabbing the data."""

    ASYNC_FINITE = 1
    """Specifies an asynchronous finite measurement. With this acquisitions type enough memory is created internally 
    to hold the data for the whole scan pattern once. Therefore it is guaranteed to grab all the data and not losing 
    frames. Please note that it is possible to acquire the scan pattern once only with this acquisition mode."""

    SYNC = 2
    """Specifies a synchronous measurement. With this acquisition mode the acquisition of the specified scan pattern 
    will be started with the call of 
    :func:`~pyspectralradar.octdevice.submodules.acquisition.acquisition.Acquisition.get_raw_data` You can interpret 
    this acquisition type as a software trigger to start the measurement. To start the data acquisition externally 
    please see the chapter in the software manual about external triggering."""


class TriggerMode(IntEnum):
    """Specifies trigger type for the OCT system."""

    FREE_RUNNING = 0
    """Standard mode."""

    EXTERNAL_START = 1
    """Used to trigger the start of an acquisition. Additional hardware is needed."""

    EXTERNAL_ASCAN = 2
    """Mode to trigger the acquisition of each A-scan. An external trigger signal is needed. Please see the 
    software manual for detailed information."""


class TriggerIoMode(IntEnum):
    """Enum identifying trigger types for the secondary trigger IO channel.
    Warning: Not all systems support trigger IO. To check if the system supports trigger IO, please use
    :func:`~pyspectralradar.octdevice.devicetriggeriomode.DeviceTriggerIoMode.get_is_available`
    """

    DISABLED = 0
    """Do not use trigger IO"""

    OUTPUT = 1
    """Output mode"""

    INPUT = 2
    """Input mode (uses trigger IO to start individual scans)"""


class DevState(IntEnum):
    """Results for function :func:`~pyspectralradar.octdevice.staticmethods.get_device_state.`"""

    UNAVAILABLE = 0
    """Device is not available (e.g. not connected, no power)"""

    STANDBY = 1
    """Device is available, but in standby mode (can be activated via software)"""

    ENABLED = 2
    """Device is enabled"""

    NO_CONFIG = 3
    """No configuration files found and could not be restored from device"""

    ERROR = 4
    """The device has an error that the user should solve."""

    STARTING = 5
    """The device starts working and it is not yet ready for normal operation."""


class RefStageStatus(IntEnum):
    """Returns the current status of the reference stage, e.g. if it is moving."""

    IDLE = 0
    """The reference stage is not busy and available for a task."""

    HOMING = 1
    """The reference stage is in its homing process. Please wait until this process is finished."""

    MOVING = 2
    """The reference stage is moving, you can stop this movement with 
    :func:`~pyspectralradar.octdevice.refstage.RefStage.stop`"""

    MOVING_TO = 3
    """The reference stage it moving to a certain position. Please wait until this process is finished."""

    STOPPING = 4
    """The reference stage is in the stopping process after :func:`~pyspectralradar.octdevice.refstage.RefStage.stop` 
    was called. Please wait until this process is finished."""

    NOT_AVAILABLE = 5
    """The reference stage is not available any more."""

    UNDEFINED = -1
    """The status of the reference stage is not defined."""


class RefStageSpeed(IntEnum):
    """Defines the velocity of movement for the motorized reference stage."""

    SLOW = 0
    """Slow speed (~0.4mm/s)"""

    FAST = 1
    """Fast speed (~1.8mm/s)"""

    VERY_SLOW = 2
    """Very slow speed"""

    VERY_FAST = 3
    """Very fast speed (~13mm/s)"""


class RefStageWaitForMovement(IntEnum):
    """Defines the behaviour whether the function should wait until the movement of the motorized reference stage
    has stopped to return."""

    WAIT = 0
    """Function waits until the movement has stopped before it returns"""

    CONTINUE = 1
    """The movement of the motorized reference stage will be started and runs in another thread. The function returns 
    while the reference stage is still moving."""


class RefStageMovementDirection(IntEnum):
    """Defines the direction of movement for the motorized reference stage. Please note that not in all systems a
    motorized reference stage is present."""

    SHORTER = 0
    """Shortens reference arm length"""

    LONGER = 1
    """Extends reference arm length"""


class WaitForCompletion(IntEnum):
    """Defines the behaviour whether a function should wait for the operation to complete or return immediately."""

    WAIT = 0
    """Wait for completion"""

    CONTINUE = 1
    """Do not wait for completion"""


class PolarizationRetarder(IntEnum):
    """List of available polarization retarders in a polarization control unit."""

    QUARTER_WAVE = 0
    """Build-in quarter-wave plate (&lambda;/4) to control polarization state"""

    HALF_WAVE = 1
    """Build-in half-wave plate (&lambda;/2) to control polarization state"""


class ScanAxis(IntEnum):
    """Axis selection for the function :func:`~pyspectralradar.octdevice.scanner.Scanner.move`."""

    X = 0
    """X-Axis of the scanner"""

    Y = 1
    """Y-Axis of the scanner"""
