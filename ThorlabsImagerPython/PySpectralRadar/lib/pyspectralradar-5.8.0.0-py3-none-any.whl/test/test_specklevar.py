import unittest

import matplotlib.pyplot as plt

from pyspectralradar import ComplexData, OCTFile, OCTSystem, RawData, RealData, SpeckleVariance, LogLevel, set_log_level
from pyspectralradar.types import AcqType, AcquisitionOrder, ApodizationType, SpeckleVarianceType

ENABLE_PLOTS = False


class TestSpeckleVarianceCreate(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def test_speckle_var_create(self):
        dut = SpeckleVariance()
        self.assertIsInstance(dut, SpeckleVariance)

    def test_speckle_var_create_from_file(self):
        oct_file = OCTFile(
            '\\\\lbknetapp01\\Public\\Doc\\Software\\Unittests\\PySpectralRadarTests\\Unittest_0001_ModePolarization'
            '.oct')
        dut = SpeckleVariance.from_file(oct_file)
        self.assertIsInstance(dut, SpeckleVariance)


class SpeckleVariancePropertyTestCase(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def setUp(self):
        self._spv = SpeckleVariance()

    def tearDown(self):
        del self._spv


class TestSpeckleVariancePropertyFloat(SpeckleVariancePropertyTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self._spv.properties

    def test_property_float(self):
        self.dut.set_threshold(56.5)
        self.assertEqual(self.dut.get_threshold(), 56.5)


class TestSpeckleVariancePropertyInt(SpeckleVariancePropertyTestCase):
    def setUp(self):
        super().setUp()
        self.dut = self._spv.properties

    def test_property_int(self):
        self.dut.set_averaging1(5)
        self.assertEqual(self.dut.get_averaging1(), 5)

        self.dut.set_averaging2(4)
        self.assertEqual(self.dut.get_averaging2(), 4)

        self.dut.set_averaging3(3)
        self.assertEqual(self.dut.get_averaging3(), 3)


class SpeckleVarianceTestCase(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        set_log_level(LogLevel.OFF)

    def setUp(self):
        self.dut = SpeckleVariance()

    def tearDown(self):
        del self.dut

    def test_speckle_var_compute(self):
        sys = OCTSystem()
        dev = sys.dev
        proc = sys.processing_factory.from_device()

        probe = sys.probe_factory.create_default()
        probe.properties.set_oversampling(2)
        probe.properties.set_oversampling_slow_axis(2)

        pattern = probe.scan_pattern.create_volume_pattern(10.0, 512, 10.0, 50, ApodizationType.ONE_FOR_ALL,
                                                           AcquisitionOrder.ACQ_ORDER_ALL)
        raw = RawData()
        volume = ComplexData()

        dev.acquisition.start(pattern, AcqType.ASYNC_FINITE)
        dev.acquisition.get_raw_data(buffer=raw)
        proc.set_data_output(volume)
        proc.execute(raw)
        dev.acquisition.stop()

        self.dut.properties.set_averaging1(2)
        self.dut.properties.set_averaging2(2)

        mean, variance = self.dut.compute(volume)

        self.assertIsInstance(mean, RealData)
        self.assertIsInstance(variance, RealData)

        print(volume.shape)
        print(mean.shape)
        print(variance.shape)

        if ENABLE_PLOTS:
            plt.figure()
            plt.title('Mean Data XY')
            plt.imshow(mean.to_numpy().reshape(mean.shape[::-1]).T[100, :, :])
            plt.figure()
            plt.title('Mean Data XZ')
            plt.imshow(mean.to_numpy().reshape(mean.shape[::-1]).T[:, 100, :])
            plt.figure()
            plt.title('Mean Data YZ')
            plt.imshow(mean.to_numpy().reshape(mean.shape[::-1]).T[:, :, 25])

            plt.figure()
            plt.title('Variance Data XY')
            plt.imshow(variance.to_numpy().reshape(variance.shape[::-1]).T[100, :, :])
            plt.figure()
            plt.title('Variance Data XZ')
            plt.imshow(variance.to_numpy().reshape(variance.shape[::-1]).T[:, 100, :])
            plt.figure()
            plt.title('Variance Data YZ')
            plt.imshow(variance.to_numpy().reshape(variance.shape[::-1]).T[:, :, 25])

            plt.show()
        else:
            plt.close()

    def test_speckle_var_types(self):
        print(self.dut.get_type())
        self.dut.set_type(SpeckleVarianceType.LOG_SCALE_VAR_LINEAR)
        self.assertEqual(self.dut.get_type(), SpeckleVarianceType.LOG_SCALE_VAR_LINEAR)


if __name__ == '__main__':
    unittest.main()
