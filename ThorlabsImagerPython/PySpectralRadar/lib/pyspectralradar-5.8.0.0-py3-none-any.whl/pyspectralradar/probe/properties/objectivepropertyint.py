from ctypes import c_char_p, c_int
from enum import IntEnum

from pyspectralradar.base.propertygetter import IntPropertyGetter
from pyspectralradar.spectralradar import sr


class PropertyInt(IntEnum):
    """Properties of the objective mounted to the scanner such as valid scan range in mm."""

    RANGE_MAX_X_MM = 0
    """The maximum range in mm of the x-direction for the specified objective"""

    RANGE_MAX_Y_MM = 1
    """The maximum range in mm of the y-direction for the specified objective"""


class ObjectivePropertyInt(IntPropertyGetter):

    def __init__(self, handle, objective_name: str):
        super().__init__(handle, sr.getObjectivePropertyInt)
        self._objective_name = objective_name
        self._getter.argtypes = [c_char_p, c_int]

    def _get_raw(self, entry: IntEnum, c_res_type):
        self._getter.restype = c_res_type
        res = self._getter(c_char_p(bytes(self._objective_name, encoding="ascii")), c_int(entry))
        return res

    def get_range_max_x_mm(self) -> int:
        """The maximum range in mm of the x-direction for the specified objective"""
        return self._get(PropertyInt.RANGE_MAX_X_MM)

    def get_range_max_y_mm(self) -> int:
        """The maximum range in mm of the y-direction for the specified objective"""
        return self._get(PropertyInt.RANGE_MAX_Y_MM)
