from enum import IntEnum

from pyspectralradar.base.propertygetter import IntPropertyGetter
from pyspectralradar.spectralradar import sr


class PropertyInt(IntEnum):
    """Enum identifying different properties of typ int of the specified scan pattern."""

    SIZE_TOTAL = 0
    """Total count of trigger pulses needed for acquisition of the scan pattern once. The acquisition will start
    again after finishing for continuous acquisition mode."""

    CYCLES = 1
    """Count of cycles for the scan pattern."""

    SIZE_CYCLES = 2
    """Count of trigger pulses needed to acquire one cycle, e.g. one B-scan in a volume scan."""

    SIZE_PREPARATION_CYCLES = 3
    """Count of trigger pulses needed before the scanning of the sample starts. The OCT beam needs to be positioned and 
    the apodization scans used for processing need to be acquired. The fly-back time is the time used to reach the 
    position of apodization and start of scan pattern."""

    SIZE_IMAGING_CYCLES = 4
    """Count of trigger pulses to acquire the sample depending on averaging and size-x of the scan pattern."""

    SIZE_PREPARATION_SCAN = 5
    """Count of trigger pulses needed before the first scanning of the sample starts. Some scan patterns implement a 
    dedicated apodization scan before the first actual scan."""


class ScanPatternPropertyInt(IntPropertyGetter):

    def __init__(self, handle):
        super().__init__(handle, sr.getScanPatternPropertyInt)

    def get_size_total(self) -> int:
        """Total count of trigger pulses needed for acquisition of the scan pattern once. The acquisition will start
        again after finishing for continuous acquisition mode."""
        return self._get(PropertyInt.SIZE_TOTAL)

    def get_cycles(self) -> int:
        """Count of cycles for the scan pattern."""
        return self._get(PropertyInt.CYCLES)

    def get_size_cycles(self) -> int:
        """Count of trigger pulses needed to acquire one cycle, e.g. one B-scan in a volume scan."""
        return self._get(PropertyInt.SIZE_CYCLES)

    def get_size_preparation_cycles(self) -> int:
        """Count of trigger pulses needed before the scanning of the sample starts. The OCT beam needs to be positioned
        and the apodization scans used for processing need to be acquired. The fly-back time is the time used to reach
        the position of apodization and start of scan pattern."""
        return self._get(PropertyInt.SIZE_PREPARATION_CYCLES)

    def get_size_imaging_cycles(self) -> int:
        """Count of trigger pulses to acquire the sample depending on averaging and size-x of the scan pattern."""
        return self._get(PropertyInt.SIZE_IMAGING_CYCLES)

    def get_size_preparation_scan(self) -> int:
        """Count of trigger pulses needed before the first scanning of the sample starts. Some scan patterns implement a
        dedicated apodization scan before the first actual scan."""
        return self._get(PropertyInt.SIZE_PREPARATION_SCAN)
