from ctypes import c_double, c_int

from pyspectralradar.base import Submodule
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import AScanAnalysis


class ComplexDataAnalysis(Submodule):
    def analyze_ascan(self, selection: AScanAnalysis) -> float:
        """Analyzes the given complex A-scan data, extracts the selected feature, and returns the computed value.

        If the given data is multidimensional, only the first A-scan will be analyzed.

        Args:
            :selection: The desired feature that should be computed.

        Returns:
            The computed feature.
        """
        assert isinstance(selection, AScanAnalysis)
        sr.analyzeComplexAScan.restype = c_double
        sr.analyzeComplexAScan.argtypes = [c_handle, c_int]
        res = sr.analyzeComplexAScan(self.handle, selection)
        get_error()
        return res
