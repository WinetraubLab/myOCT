from enum import IntEnum

from pyspectralradar.base.propertygetter import FlagPropertyGetter
from pyspectralradar.base.propertysetter import FlagPropertySetter
from pyspectralradar.spectralradar import sr


class PropertyFlag(IntEnum):
    """Enum Flags that determine the behaviour of the Doppler processing routines."""

    DOPPLER_VELOCITY_SCALING = 0
    """Averaging along the first axis, usually the longitudinal axis (z)"""


class DopplerPropertyFlag(FlagPropertyGetter, FlagPropertySetter):
    def __init__(self, handle):
        FlagPropertyGetter.__init__(self, handle, sr.getDopplerFlag)
        FlagPropertySetter.__init__(self, handle, sr.setDopplerFlag)

    def get_doppler_velocity_scaling(self) -> bool:
        """Averaging along the first axis, usually the longitudinal axis (z)"""
        return self._get(PropertyFlag.DOPPLER_VELOCITY_SCALING)

    def set_doppler_velocity_scaling(self, value: bool):
        """Averaging along the first axis, usually the longitudinal axis (z)"""
        self._set(PropertyFlag.DOPPLER_VELOCITY_SCALING, value)
