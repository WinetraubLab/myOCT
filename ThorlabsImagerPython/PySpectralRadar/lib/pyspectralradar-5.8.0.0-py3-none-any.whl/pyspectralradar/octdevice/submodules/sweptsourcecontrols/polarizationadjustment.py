from ctypes import c_bool, c_double, c_int

from pyspectralradar.base import Submodule
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import PolarizationRetarder, WaitForCompletion


class PolarizationAdjustment(Submodule):
    def is_available(self) -> bool:
        """Returns whether a motorized polarization adjustment stage is available for the specified device.

        Returns:
            ``True`` if a polarization adjustment is available.
        """
        sr.isPolarizationAdjustmentAvailable.argtypes = [c_handle]
        sr.isPolarizationAdjustmentAvailable.restype = c_bool
        res = sr.isPolarizationAdjustmentAvailable(self.handle)
        get_error()
        return res

    def _set_pol_adjustment_retardation_changed_callback(self, callback):
        """Registers the callback to get notified when the polarization adjustment retardation has changed.

        Args:
            :callback: the Callback to register.
        """
        raise NotImplementedError

    def get_retardation(self, retarder: PolarizationRetarder):
        """Gets the current retardation of the specified retarder in the polarization adjustment.

        If :func:`set_retardation` was used in a non-blocking fashion, the function returns the current position of
        the retarder, not the final target position.

        Args:
            :retarder: The polarization retarder which shall be queried

        Returns:
            The current unit-less Retardation of the selected ``retarder`` (0 <= Retardation <= 1)
        """
        assert isinstance(retarder, PolarizationRetarder)
        sr.getPolarizationAdjustmentRetardation.argtypes = [c_handle, c_int]
        sr.getPolarizationAdjustmentRetardation.restype = c_double
        res = sr.getPolarizationAdjustmentRetardation(self.handle, retarder)
        get_error()
        return res

    def set_retardation(self, retarder: PolarizationRetarder, retardation: float, wait: WaitForCompletion):
        """Sets the retardation of the specified retarder in the polarization adjustment.

        The retardation is a unit-less value between 0 and 1, which represents the full adjustment range of the
        ``retarder``. The retarder may take some time to physically reach the new ``retardation``. Use the ``wait``
        parameter to choose if the function should block until the new position is reached.

        Args:
            :retarder: The polarization retarder which shall be adjusted
            :retardation: the new retardation value (0 <= ``retardation`` <= 1)
            :wait: Specify ``WAIT`` to block until the new ``retardation`` value has been reached
        """
        assert isinstance(retarder, PolarizationRetarder)
        assert isinstance(wait, WaitForCompletion)
        sr.setPolarizationAdjustmentRetardation.argtypes = [c_handle, c_int, c_double, c_int]
        sr.setPolarizationAdjustmentRetardation(self.handle, retarder, retardation, wait)
        get_error()
