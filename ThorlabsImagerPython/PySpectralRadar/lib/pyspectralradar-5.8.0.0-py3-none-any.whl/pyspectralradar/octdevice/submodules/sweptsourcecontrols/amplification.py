from ctypes import c_bool, c_int

from pyspectralradar.base import Submodule
from pyspectralradar.spectralradar import c_handle, get_error, sr


class Amplification(Submodule):
    def is_available(self) -> bool:
        """Returns whether the sampling amplification of specified device can be adjusted.

        Returns:
            ``True`` if an amplification control is available
        """
        sr.isAmplificationControlAvailable.argtypes = [c_handle]
        sr.isAmplificationControlAvailable.restype = c_bool
        res = sr.isAmplificationControlAvailable(self.handle)
        get_error()
        return res

    def get_max(self) -> int:
        """Gets the number of discrete amplification control steps available on the specified device.

        Please note that the largest amplification step is :func:`get_max` - 1.

        Returns:
            The number of amplification steps.
        """
        sr.getAmplificationControlNumberOfSteps.argtypes = [c_handle]
        sr.getAmplificationControlNumberOfSteps.restype = c_int
        res = sr.getAmplificationControlNumberOfSteps(self.handle)
        get_error()
        return res

    def get(self) -> int:
        """Gets the current sampling amplification of the specified device.

        Returns:
            The current amplification step of the selected device (0 <= step <= :func:`get_max`)
        """
        sr.getAmplificationControlStep.argtypes = [c_handle]
        sr.getAmplificationControlStep.restype = c_int
        res = sr.getAmplificationControlStep(self.handle)
        get_error()
        return res

    def set(self, step: int):
        """Sets the sampling amplification on the specified device.

        The lowest amplification is always 0.
        In general, the amplification should be set as high as possible without going into saturation.

        Args:
            :step: Amplification step to use. 0 <= ``step`` < :func:`get_max`)
        """
        sr.setAmplificationControlStep.argtypes = [c_handle, c_int]
        sr.setAmplificationControlStep(self.handle, step)
        get_error()
