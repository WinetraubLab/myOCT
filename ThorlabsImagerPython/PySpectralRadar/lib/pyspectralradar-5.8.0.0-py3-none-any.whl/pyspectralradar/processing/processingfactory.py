from __future__ import annotations

from ctypes import c_bool, c_float, c_int
from typing import TYPE_CHECKING

from pyspectralradar.octfile import OCTFile
from pyspectralradar.processing import Processing
from pyspectralradar.spectralradar import c_handle, get_error, sr
from pyspectralradar.types import FFTType

if TYPE_CHECKING:
    from pyspectralradar.octdevice import OCTDevice


class ProcessingFactory:

    @staticmethod
    def from_oct_file(file: OCTFile, camera_idx: int = 0) -> Processing:
        """Creates processing routines for the specified OCT file (
        :class:`~pyspectralradar.octfile.octfile.OCTFile`), such that the processing conditions are exactly the same
        as those when the file had been saved.

        For systems with one camera, this function can be used with the default ``camera_idx=0``.

        Args:
            :file: OCT File that the routines shall be specified for
            :camera_idx: The detector index (first camera has zero index)

        Returns:
            The processing for the given OCT file.
        """
        sr.createProcessingForOCTFileEx.restype = c_handle
        sr.createProcessingForOCTFileEx.argtypes = [c_handle, c_int]
        handle = c_handle(sr.createProcessingForOCTFileEx(file.handle, camera_idx))
        res = Processing(handle)
        get_error()
        return res

    @staticmethod
    def from_device(device: OCTDevice, camera_idx: int = 0) -> Processing:
        """Creates processing routines for the specified device (
        :class:`~pyspectralradar.octdevice.octdevice.OCTDevice`) with ``camera_index``.

        In systems containing several cameras, there should be one set of processing routines for each camera. The
        reason is that each camera has its own calibration, and the calibration is an integral part of the computations.

        Args:
            :device: The OCT device that the routines shall be specified for
            :camera_idx: The camera index (0-based, i.e. zero for the first, one for the second, and so on)

        Returns:
            The processing for the given OCT device.
        """
        sr.createProcessingForDeviceEx.restype = c_handle
        sr.createProcessingForDeviceEx.argtypes = [c_handle, c_int]
        handle = c_handle(sr.createProcessingForDeviceEx(device.handle, camera_idx))
        res = Processing(handle)
        get_error()
        return res

    @staticmethod
    def create(size: int, bpp: int, signed: bool, scaling: float, min_electrons: float, fft_type: FFTType,
               oversampling: float) -> Processing:
        """Creates processing routines with the desired properties.

        Args:
            :size: The number of pixels in each spectrum.
            :bpp: The number of bytes in each pixel (e.g. two for a 12-bit resolution). Currently, 1, 2, and 4-bytes per
                 pixel are supported. 1 and 2-bytes per pixel assume an integer representation, whereas 4-bytes per
                 pixel assumes a single precision floating point representation
            :signed: Indicates whether the value of each pixel is signed or not. This parameter is ignored in case of
                floating point representations
            :scaling: A multiplicative constant to transform digital levels into the number of electrons actually freed
            :min_electrons: A threshold. This value is used to identify the portions of the measured spectra (close
                to the edges) where the signal-to-noise ratio is too poor for any practical purposes. After the
                ``scaling`` has been applied to the digitized data (i.e. a spectrum has been measured),
                this threshold can be used to identify the portions near the edges that can be regarded as "near zero"
            :fft_type: Specifies the FFT algorithm that will combine the de-chirping with the Fourier transform
            :oversampling: oversampling In case the selected FFT algorithm bases on oversampling, this parameter
                gives the factor

        Returns:
            Processing
        """
        assert isinstance(fft_type, FFTType)
        sr.createProcessing.restype = c_handle
        sr.createProcessing.argtypes = [c_int,
                                        c_int,
                                        c_bool,
                                        c_float,
                                        c_float,
                                        c_int,
                                        c_float]
        handle = c_handle(sr.createProcessing(c_int(size),
                                              c_int(bpp),
                                              c_bool(signed),
                                              c_float(scaling),
                                              c_float(min_electrons),
                                              c_int(fft_type),
                                              c_float(oversampling)))
        res = Processing(handle)
        get_error()
        return res


class DeviceBoundProcessingFactory(ProcessingFactory):
    def __init__(self, oct_dev: OCTDevice):
        self._dev = oct_dev

    def from_device(self, camera_idx: int = 0) -> Processing:
        """Creates processing routines for the current device (
        :class:`~pyspectralradar.octdevice.octdevice.OCTDevice`) with ``camera_index``.

        In systems containing several cameras, there should be one set of processing routines for each camera. The
        reason is that each camera has its own calibration, and the calibration is an integral part of the computations.

        Args:
            :camera_idx: The camera index (0-based, i.e. zero for the first, one for the second, and so on).

        Returns:
            The processing for the current OCT device.
        """
        return super().from_device(self._dev, camera_idx)
