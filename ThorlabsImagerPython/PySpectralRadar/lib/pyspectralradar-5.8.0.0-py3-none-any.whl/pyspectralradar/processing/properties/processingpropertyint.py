from enum import IntEnum

from pyspectralradar.base.propertygetter import IntPropertyGetter
from pyspectralradar.base.propertysetter import IntPropertySetter
from pyspectralradar.spectralradar import sr


class PropertyInt(IntEnum):
    """Enum Parameters that set the behaviour of the processing algorithms."""

    SPECTRUM_AVG = 0
    """Identifier for averaging of several subsequent spectra prior to Fourier transform."""

    ASCAN_AVG = 1
    """Identifier for averaging the absolute values of several subsequent A-scan after Fourier transform."""

    BSCAN_AVG = 2
    """Averaging of subsequent B-scans."""

    ZERO_PADDING = 3
    """Identifier for zero padding prior to Fourier transformation."""

    NUMBER_OF_THREADS = 4
    """The maximum number of threads to used by processing. A value of 0 indicates automatic selection, equal to the 
    number of cores in the host PC."""

    FOURIER_AVG = 5
    """Averaging of fourier spectra."""


class ProcessingPropertyInt(IntPropertyGetter, IntPropertySetter):
    def __init__(self, handle):
        IntPropertyGetter.__init__(self, handle, sr.getProcessingParameterInt)
        IntPropertySetter.__init__(self, handle, sr.setProcessingParameterInt)

    def get_spectrum_avg(self) -> int:
        """Identifier for averaging of several subsequent spectra prior to Fourier transform."""
        return self._get(PropertyInt.SPECTRUM_AVG)

    def set_spectrum_avg(self, value: int):
        """Identifier for averaging of several subsequent spectra prior to Fourier transform."""
        self._set(PropertyInt.SPECTRUM_AVG, value)

    def get_ascan_avg(self) -> int:
        """Identifier for averaging the absolute values of several subsequent A-scan after Fourier transform."""
        return self._get(PropertyInt.ASCAN_AVG)

    def set_ascan_avg(self, value: int):
        """Identifier for averaging the absolute values of several subsequent A-scan after Fourier transform."""
        self._set(PropertyInt.ASCAN_AVG, value)

    def get_bscan_avg(self) -> int:
        """Averaging of subsequent B-scans."""
        return self._get(PropertyInt.BSCAN_AVG)

    def set_bscan_avg(self, value: int):
        """Averaging of subsequent B-scans."""
        self._set(PropertyInt.BSCAN_AVG, value)

    def get_zero_padding(self) -> int:
        """Identifier for zero padding prior to Fourier transformation."""
        return self._get(PropertyInt.ZERO_PADDING)

    def set_zero_padding(self, value: int):
        """Identifier for zero padding prior to Fourier transformation."""
        self._set(PropertyInt.ZERO_PADDING, value)

    def get_number_of_threads(self) -> int:
        """The maximum number of threads to used by processing. A value of 0 indicates automatic selection,
        equal to the number of cores in the host PC."""
        return self._get(PropertyInt.NUMBER_OF_THREADS)

    def set_number_of_threads(self, value: int):
        """The maximum number of threads to used by processing. A value of 0 indicates automatic selection,
        equal to the number of cores in the host PC."""
        self._set(PropertyInt.NUMBER_OF_THREADS, value)

    def get_fourier_avg(self) -> int:
        """Averaging of fourier spectra."""
        return self._get(PropertyInt.FOURIER_AVG)

    def set_fourier_avg(self, value: int):
        """Averaging of fourier spectra."""
        self._set(PropertyInt.FOURIER_AVG, value)
