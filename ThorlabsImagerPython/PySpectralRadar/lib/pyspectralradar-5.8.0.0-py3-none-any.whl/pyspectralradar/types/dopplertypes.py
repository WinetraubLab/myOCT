from __future__ import annotations

from enum import IntEnum


class DopplerOutput(IntEnum):
    """Enum identifying different properties of type int to select the output data type."""

    AMPLITUDE = 0
    """Sets the location of the resulting Doppler amplitude output"""

    PHASE = 1
    """Sets the location of the resulting Doppler phase output."""
