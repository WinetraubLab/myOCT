from __future__ import annotations

from ctypes import POINTER, c_double, c_float
from typing import Tuple

from pyspectralradar.data import ComplexData, RealData
from pyspectralradar.spectralradar import c_handle, get_error, sr


def compute_chirp(spectrum: RealData) -> RealData:
    """Computes and returns the calculated chirp curve

    Args:
        :spectrum: Spectrum data

    Returns:
        Calculated Chirp data
    """
    assert isinstance(spectrum, RealData)
    chirp = RealData()
    sr.computeChirp.restype = c_handle
    sr.computeChirp.argtypes = [c_handle, c_handle]
    sr.computeChirp(spectrum.handle, chirp.handle)
    get_error()
    return chirp


def compute_dispersion(spectrum1: RealData, spectrum2: RealData) -> Tuple[RealData, RealData]:
    """Computes the dispersion and chirp of the two provided spectra, where both spectra need to have been subjected
    to same dispersion mismatch.

    Both spectra need to have been acquired for different path length differences.

    For a detailed explanation, do please refer to the documentation of #Processing.set_dispersion_presets_to_probe.

    Args:
        :spectrum1: A valid :obj:`~pyspectralradar.data.realdata.RealData` with an apodized spectrum, created with
            :func:`~pyspectralradar.processing.processing.Processing.set_spectrum_output` using
            ``SpectrumType.APODIZED`` as input followed by
            :func:`~pyspectralradar.processing.processing.Processing.execute`, measuring a test
            reflector positioned at a distance different from the one used for the second parameter.
        :spectrum2: A valid :obj:`~pyspectralradar.data.realdata.RealData` with an apodized spectrum,
            created with :func:`~pyspectralradar.processing.processing.Processing.set_spectrum_output` using
            ``SpectrumType.APODIZED`` as input followed by
            :func:`~pyspectralradar.processing.processing.Processing.execute`, measuring a test
            reflector positioned at a distance different from the one used for the first parameter.

    Returns:
        A tuple (``chirp``, ``disp``) containing, the calculated ``chirp`` curve and calculated ``disp`` dispersion
        curve
    """
    assert isinstance(spectrum1, RealData)
    assert isinstance(spectrum2, RealData)
    chirp = RealData()
    disp = RealData()
    sr.computeDispersion.argtypes = [c_handle, c_handle, c_handle, c_handle]
    sr.computeDispersion(spectrum1.handle, spectrum2.handle, chirp.handle, disp.handle)
    get_error()
    return chirp, disp


def compute_dispersion_by_coeff(quadratic: float, chirp: RealData) -> RealData:
    """Computes dispersion by a quadratic approximation specified by the quadratic factor.

    For a detailed explanation, do please refer to the documentation of
    :func:`~pyspectralradar.processing.submodules.dispersion.Dispersion.set_presets_from_probe`.

    Args:
        :quadratic: The leading coefficient of the second order polynomial that will define the dispersion curve.
        :chirp: A valid chirp curve as :obj:`~pyspectralradar.data.realdata.RealData`

    Returns:
        The calculated dispersion curve
    """
    assert isinstance(chirp, RealData)
    disp = RealData()
    sr.computeDispersionByCoeff.argtypes = [c_double, c_handle, c_handle]
    sr.computeDispersionByCoeff(c_double(quadratic), chirp.handle, disp.handle)
    get_error()
    return disp


def compute_dispersion_by_image(linear_k_spectra: RealData, chirp: RealData) -> RealData:
    """
    Guesses the dispersion based on the spectral data specified.

    The spectral data needs to be linearized in wave-number before using this function.

    For a detailed explanation, do please refer to the documentation of
    :func:`~pyspectralradar.processing.submodules.dispersion.Dispersion.set_presets_from_probe`.

    Args:
        :linear_k_spectra: Input spectra. The spectral data needs to be linearized in wave-number (not wavelength)
            before using this function.
        :chirp: A valid chirp curve as :obj:`~pyspectralradar.data.realdata.RealData`

    Returns:
        The calculated dispersion curve
    """
    assert isinstance(linear_k_spectra, RealData)
    assert isinstance(chirp, RealData)
    disp = RealData()
    sr.computeDispersionByImage.argtypes = [c_handle, c_handle, c_handle]
    sr.computeDispersionByImage(linear_k_spectra.handle, chirp.handle, disp.handle)
    get_error()
    return disp


def compute_linear_k_raw_data(complex_data_after_fft: ComplexData) -> RealData:
    """Computes the linear k raw data of the complex data after FFT by an inverse Fourier transform.

    Args:
        :complex_data_after_fft: The complex data

    Returns:
        The linear k raw data
    """
    assert isinstance(complex_data_after_fft, ComplexData)
    linear_k_data = RealData()
    sr.computeLinearKRawData.argtypes = [c_handle, c_handle]
    sr.computeLinearKRawData(complex_data_after_fft.handle, linear_k_data.handle)
    return linear_k_data


def linearize_spectral_data(spectra_in: RealData, chirp: RealData) -> RealData:
    """Linearizes the spectral data using the given chirp vector.

    Args:
        :spectra_in: Input spectra.
        :chirp: A valid chirp curve

    Returns:
        The linearized spectral data
    """
    assert isinstance(spectra_in, RealData)
    assert isinstance(chirp, RealData)
    spectra_out = RealData()
    sr.linearizeSpectralData.argtypes = [c_handle, c_handle, c_handle]
    sr.linearizeSpectralData(spectra_in.handle, spectra_out.handle, chirp.handle)
    return spectra_out


def calc_contrast(apodized_spectrum: RealData) -> RealData:
    """Computes the contrast for the specified (apodized) spectrum.

    The contrast is a measure of the amount of information in the interference pattern as a fraction of the total
    signal. The computed values are expressed as percentage of the measured amplitudes, for each camera pixel.

    Args:
        :apodized_spectrum: The spectrum after offset subtraction and apodization. This spectrum can be obtained
            using created with :func:`~pyspectralradar.processing.processing.Processing.set_spectrum_output` using
            ``SpectrumType.APODIZED`` as input followed by
            :func:`~pyspectralradar.processing.processing.Processing.execute`.

    Returns:
        Contrast, Its dimensions will be automatically be adjusted.

    """
    assert isinstance(apodized_spectrum, RealData)
    contrast = RealData()
    sr.calcContrast.argtypes = [c_handle, c_handle]
    sr.calcContrast(apodized_spectrum.handle, contrast.handle)
    get_error()
    return contrast


def calc_spectrometer_img_quality(spectrum: RealData) -> float:
    """Given a maximally modulated spectrum, this function calculates a quality indicator that describes the image
    quality of the spectrum onto the line camera.

    :Warning: Experimental: This function may change in its interface  and behaviour, or even disappear in future
        versions.

    Args:
        :spectrum: The maximally modulated spectrum that is used for quality estimation

    Returns:
        Quality value in the range of 0 to 100
    """
    assert isinstance(spectrum, RealData)
    sr.calcSpectrometerImagingQualityIndex.argtypes = [c_handle]
    sr.calcSpectrometerImagingQualityIndex.restype = c_double
    res = sr.calcSpectrometerImagingQualityIndex(spectrum.handle)
    get_error()
    return res


def analyze_max_peak(data: RealData) -> Tuple[float, float]:
    """This function analyzes the highest peak in the given A-scan data and yields its height (in dB) and full-width at
    half maximum (FWHM) in pixels.

    :Warning: Experimental: This function may change in its interface and behaviour, or even disappear in future
        versions.

    Args:
        :data: A-scan data in dB containing the peak to be analyzed

    Returns:
        A tuple (``peak_height_db``, ``peak_fwhm_pixel``) containing ``peak_height_db`` as the computed peak height (
        usually in dB) and ``peak_fwhm_pixel`` as the FWHM (-6 dB) of the highest peak
    """
    assert isinstance(data, RealData)
    peak_height_db = c_float()
    peak_fwhm_pixel = c_float()
    sr.analyzeMaxPeak.argtypes = [c_handle, POINTER(c_float), POINTER(c_float)]
    sr.analyzeMaxPeak(data.handle, peak_height_db, peak_fwhm_pixel)
    get_error()
    return peak_height_db.value, peak_fwhm_pixel.value


def compute_amplitude_and_phase(data: ComplexData) -> Tuple[RealData, RealData]:
    """Calculates amplitude and phase for each pixel of a :obj:`~pyspectralradar.data.complexdata.ComplexData` object

    Args:
        :data: The complex data to be processed

    Returns:
        A tuple containing the amplitude data and phase data as :obj:`~pyspectralradar.data.realdata.RealData` objects
    """
    assert isinstance(data, ComplexData)
    res_amp = RealData()
    res_phase = RealData()
    sr.computeAmplitudeAndPhase.argtypes = [c_handle, c_handle, c_handle]
    sr.computeAmplitudeAndPhase(data.handle, res_amp.handle, res_phase.handle)
    get_error()
    return res_amp, res_phase
