from ctypes import POINTER, c_char_p, c_float, c_int, c_ulong, c_ulonglong, create_string_buffer

import numpy as np

from pyspectralradar.spectralradar import get_error, sr


def get_config_path() -> str:
    """Returns the path that hold the config files.

    Returns:
        Path that hold the config files
    """
    str_size = 1024
    path = create_string_buffer(str_size)
    sr.getConfigPath.argtypes = [c_char_p, c_int]
    sr.getConfigPath(path, str_size)
    get_error()
    return path.value.decode('ascii')


def get_plugin_path() -> str:
    """Returns the path that hold the plugins.

    Returns:
        The path that hold the plugins
    """
    str_size = 1024
    path = create_string_buffer(str_size)
    sr.getPluginPath.argtypes = [c_char_p, c_int]
    sr.getPluginPath(path, str_size)
    get_error()
    return path.value.decode('ascii')


def get_installation_path() -> str:
    """ Returns the installation path.

    Returns:
        The installation path

    """
    str_size = 1024
    path = create_string_buffer(str_size)
    sr.getInstallationPath.argtypes = [c_char_p, c_int]
    sr.getInstallationPath(path, str_size)
    get_error()
    return path.value.decode('ascii')


def get_software_version() -> str:
    """Returns the current software version.

    Returns:
        The current software version
    """
    str_size = 1024
    version = create_string_buffer(str_size)
    sr.getSoftwareVersion.argtypes = [c_char_p, c_int]
    sr.getSoftwareVersion(version, str_size)
    get_error()
    return version.value.decode('ascii')


def get_free_memory() -> c_ulonglong:
    """Returns the amount of free system memory.

    Function is available for convenience."""
    sr.getFreeMemory.restype = c_ulonglong
    res = sr.getFreeMemory()
    get_error()
    return res


def polynomial_fit_and_eval_1d(orig_pos_x: np.ndarray, orig_y: np.ndarray, degree_polynom: int,
                               eval_pos_x: np.ndarray) -> np.ndarray:
    """Computes the polynomial fit of the given 1D data.

    Args
        :orig_pos_x: The x-positions of the ``orig_y`` of the given data
        :orig_y: The y-values to the belonging ``orig_pos_x`` of the given data
        :degree_polynom: The degree of the polynomial for the fit
        :eval_pos_x: The x-positions for evaluation the polynomial fit

    Returns:
        The resulting y-values belonging to the given positions ``eval_pos_x``.
    """
    size = len(orig_pos_x)
    eval_size = len(eval_pos_x)
    eval_y = np.empty(eval_size, dtype=c_float)
    sr.polynomialFitAndEval1D.argtypes = [c_int,
                                          np.ctypeslib.ndpointer(dtype=c_float, flags='F_CONTIGUOUS'),
                                          np.ctypeslib.ndpointer(dtype=c_float, flags='F_CONTIGUOUS'),
                                          c_int,
                                          c_int,
                                          np.ctypeslib.ndpointer(dtype=c_float, flags='F_CONTIGUOUS'),
                                          np.ctypeslib.ndpointer(dtype=c_float, flags='F_CONTIGUOUS')]
    sr.polynomialFitAndEval1D(size, orig_pos_x, orig_y, degree_polynom, eval_size, eval_pos_x, eval_y)
    get_error()
    return eval_y


def calc_parabola_maximum(x0: float, y0: float, y_left: float, y_right: float) -> float:
    """Computes the x-position of the highest peak of the parabola given by the point ``x0``, ``y0``, ``y_left``,
    ``y_right``.

    ``y0`` needs to be the point with the highest value.

    Args:
        :x0: The x-position of the point with the highest value ``y0``
        :y0: The value of ``x0``
        :y_left: The y-value from the point left to ``x0``. The distance (``x0``, ``y_left``) is assumed to be 1
        :y_right: The y-value from the point right to ``x0``. The distance (``x0``, y_right) is assumed to be 1

    Returns:
        The y-value of th highest peak.
    """
    peak_height = c_float()
    sr.calcParabolaMaximum.argtypes = [c_float, c_float, c_float, c_float, POINTER(c_float)]
    sr.calcParabolaMaximum(x0, y0, y_left, y_right, peak_height)
    get_error()
    return peak_height.value


def interpret_reference_intensity(intensity: float) -> c_ulong:
    """Interprets the reference intensity and gives a color code that reflects its state.

    \nPossible colors include:
    - red = 0x00FF0000 (bad intensity);
    - orange = 0x00FF7700 (okay intensity);
    - green = 0x0000FF00 (good intensity);

    Args:
        :intensity: The current reference intensity as a value between 0.0 and 1.0

    Returns:
        The color code reflecting the state of the reference intensity
    """
    sr.InterpretReferenceIntensity.restype = c_ulong
    sr.InterpretReferenceIntensity.argtypes = [c_float]
    res = sr.InterpretReferenceIntensity(intensity)
    get_error()
    return res


def interpret_reference_intensity_single_value(desired_intensity: float,
                                               tolerance: float,
                                               current_intensity: float) -> c_ulong:
    """Interprets the reference intensity.

     Gives ``green`` color code when the reference intensity is the desired intensity plus/minus the tolerance,
     otherwise ``red`` is returned.

    \nPossible colors include:
    - red = 0x00FF0000 (bad intensity);
    - green = 0x0000FF00 (good intensity);

    Args:
        desired_intensity: The desired reference intensity as a value between 0.0 and 1.0
        tolerance: The specified reference intensity tolerance as a value between 0.0 and 1.0
        current_intensity: The current reference intensity as a value between 0.0 and 1.0

    Returns:
        The color code reflecting the state of the reference intensity
    """
    sr.InterpretReferenceIntensitySingleValue.restype = c_ulong
    sr.InterpretReferenceIntensitySingleValue.argtypes = [c_float, c_float, c_float]
    res = sr.InterpretReferenceIntensitySingleValue(desired_intensity, tolerance, current_intensity)
    get_error()
    return res
